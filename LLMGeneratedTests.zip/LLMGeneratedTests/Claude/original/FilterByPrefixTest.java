package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FilterByPrefixTest {

    @Test
    void testEmptyList() {
        List<Object> input = new ArrayList<>();
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testNoMatchingPrefix() {
        List<Object> input = Arrays.asList("bcd", "cde", "xyz");
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testSingleMatch() {
        List<Object> input = Arrays.asList("abc", "bcd", "cde");
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testMultipleMatches() {
        List<Object> input = Arrays.asList("abc", "bcd", "array", "a1", "a2");
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc", "array", "a1", "a2");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testMatchingWithEmptyPrefix() {
        List<Object> input = Arrays.asList("abc", "bcd", "array");
        String prefix = "";
        List<Object> expected = Arrays.asList("abc", "bcd", "array");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testMatchingWithNullPrefix() {
        List<Object> input = Arrays.asList("abc", "bcd", "array");
        String prefix = null;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testAllMatching() {
        List<Object> input = Arrays.asList("aaa", "aab", "aac");
        String prefix = "a";
        List<Object> expected = Arrays.asList("aaa", "aab", "aac");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testNoInputStrings() {
        List<Object> input = new ArrayList<>();
        String prefix = "abc";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testBoundaryValues() {
        List<Object> input = Arrays.asList("a", "b", "c");
        String prefix = "a";
        List<Object> expected = Arrays.asList("a");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testNegativeValues() {
        List<Object> input = Arrays.asList("-abc", "-bcd", "abc");
        String prefix = "-";
        List<Object> expected = Arrays.asList("-abc", "-bcd");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testPrefixWithSpecialCharacters() {
        List<Object> input = Arrays.asList("@abc", "#bcd", "$abc");
        String prefix = "@";
        List<Object> expected = Arrays.asList("@abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }
}