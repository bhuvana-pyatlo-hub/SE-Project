package original;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class HowManyTimesTest {

    @Test
    void testHowManyTimes_EmptyStringAndNonEmptySubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("", "a"));
    }

    @Test
    void testHowManyTimes_NonEmptyStringAndEmptySubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("aaa", ""));
    }

    @Test
    void testHowManyTimes_EmptyStringAndEmptySubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("", ""));
    }

    @Test
    void testHowManyTimes_NonOverlappingSubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("abcde", "f"));
    }

    @Test
    void testHowManyTimes_OverlappingSubstring() {
        assertEquals(3, HowManyTimes.howManyTimes("aaa", "a"));
    }

    @Test
    void testHowManyTimes_OverlappingSubstringWithTwoCharacters() {
        assertEquals(3, HowManyTimes.howManyTimes("aaaa", "aa"));
    }

    @Test
    void testHowManyTimes_SingleCharacterSubstringInMultiplePlaces() {
        assertEquals(4, HowManyTimes.howManyTimes("xyxyxyx", "x"));
    }

    @Test
    void testHowManyTimes_ComplexOverlappingSubstring() {
        assertEquals(4, HowManyTimes.howManyTimes("cacacacac", "cac"));
    }

    @Test
    void testHowManyTimes_SingleWordMatch() {
        assertEquals(1, HowManyTimes.howManyTimes("john doe", "john"));
    }

    @Test
    void testHowManyTimes_SubstringAtEnd() {
        assertEquals(1, HowManyTimes.howManyTimes("hello world", "world"));
    }

    @Test
    void testHowManyTimes_SubstringAtBeginning() {
        assertEquals(1, HowManyTimes.howManyTimes("hello world", "hello"));
    }

    @Test
    void testHowManyTimes_SubstringNotFound() {
        assertEquals(0, HowManyTimes.howManyTimes("hello world", "planet"));
    }

    @Test
    void testHowManyTimes_SubstringWithSpecialCharacters() {
        assertEquals(2, HowManyTimes.howManyTimes("abc$abc$abc", "abc$"));
    }

    @Test
    void testHowManyTimes_SubstringWithNumbers() {
        assertEquals(2, HowManyTimes.howManyTimes("123123123", "123"));
    }

    @Test
    void testHowManyTimes_SubstringWithSpaces() {
        assertEquals(1, HowManyTimes.howManyTimes("hello  world", " "));
    }

    @Test
    void testHowManyTimes_ConsecutiveSubstrings() {
        assertEquals(2, HowManyTimes.howManyTimes("abababab", "ab"));
    }

    @Test
    void testHowManyTimes_EmptySubstringInNonEmptyString() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", ""));
    }

    @Test
    void testHowManyTimes_SingleCharacterSubstringInSingleCharacterString() {
        assertEquals(1, HowManyTimes.howManyTimes("a", "a"));
    }

    @Test
    void testHowManyTimes_SingleCharacterSubstringNotFound() {
        assertEquals(0, HowManyTimes.howManyTimes("b", "a"));
    }

    @Test
    void testHowManyTimes_OverlappingSubstringWithDifferentCharacters() {
        assertEquals(0, HowManyTimes.howManyTimes("abcde", "cdx"));
    }

    @Test
    void testHowManyTimes_OverlappingSubstringWithSameCharacters() {
        assertEquals(2, HowManyTimes.howManyTimes("aaaaaa", "aa"));
    }

    @Test
    void testHowManyTimes_SubstringWithNegativeCharacters() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", "xyz"));
    }

    @Test
    void testHowManyTimes_SingleCharacterSubstringInEmptyString() {
        assertEquals(0, HowManyTimes.howManyTimes("", "a"));
    }

    @Test
    void testHowManyTimes_OverlappingSubstringAtStartAndEnd() {
        assertEquals(2, HowManyTimes.howManyTimes("ababab", "aba"));
    }
}