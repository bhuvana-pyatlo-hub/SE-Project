package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Add1Test {

    @Test
    void testAddWithEvenAtOddIndices() {
        assertEquals(2, Add1.add(Arrays.asList(4, 2, 6, 7))); // 2 at index 1
        assertEquals(88, Add1.add(Arrays.asList(4, 88))); // 88 at index 1
        assertEquals(122, Add1.add(Arrays.asList(4, 5, 6, 7, 2, 122))); // 122 at index 5
        assertEquals(0, Add1.add(Arrays.asList(4, 0, 6, 7))); // 0 at index 1
        assertEquals(12, Add1.add(Arrays.asList(4, 4, 6, 8))); // 4 at index 1 and 8 at index 3
    }

    @Test
    void testAddWithNoEvenAtOddIndices() {
        assertEquals(0, Add1.add(Arrays.asList(1, 3, 5, 7))); // No even elements at odd indices
        assertEquals(0, Add1.add(Arrays.asList(1, 1, 1, 1))); // No even elements at odd indices
    }

    @Test
    void testAddWithEmptyList() {
        assertEquals(0, Add1.add(Collections.emptyList())); // Edge case: empty list
    }

    @Test
    void testAddWithSingleElement() {
        assertEquals(0, Add1.add(Arrays.asList(1))); // Edge case: single element
        assertEquals(0, Add1.add(Arrays.asList(2))); // Edge case: single even element
    }

    @Test
    void testAddWithNegativeNumbers() {
        assertEquals(-2, Add1.add(Arrays.asList(-4, -2, -6, -7))); // -2 at index 1
        assertEquals(0, Add1.add(Arrays.asList(-1, -3, -5, -7))); // No even elements at odd indices
        assertEquals(0, Add1.add(Arrays.asList(-1, 2, -3, 4))); // 4 at index 3
    }

    @Test
    void testAddWithBoundaryValues() {
        assertEquals(0, Add1.add(Arrays.asList(0, 0, 0, 0))); // All zeros
        assertEquals(100, Add1.add(Arrays.asList(1, 100))); // 100 at index 1
        assertEquals(0, Add1.add(Arrays.asList(-100, 0, -100, 0))); // No even elements at odd indices
        assertEquals(100, Add1.add(Arrays.asList(-100, 100))); // 100 at index 1
    }

    @Test
    void testAddWithMixedValues() {
        assertEquals(0, Add1.add(Arrays.asList(-1, -2, -3, -4))); // -2 at index 1, -4 at index 3
        assertEquals(0, Add1.add(Arrays.asList(1, 2, 3, 4, 5))); // 0 at odd indices
    }
}