package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StrangeSortListTest {

    @Test
    void testStrangeSortListWithBasicCases() {
        assertEquals(Arrays.asList(1, 4, 2, 3), StrangeSortList.strangeSortList(Arrays.asList(1, 2, 3, 4)));
        assertEquals(Arrays.asList(5, 9, 6, 8, 7), StrangeSortList.strangeSortList(Arrays.asList(5, 6, 7, 8, 9)));
        assertEquals(Arrays.asList(1, 5, 2, 4, 3), StrangeSortList.strangeSortList(Arrays.asList(1, 2, 3, 4, 5)));
        assertEquals(Arrays.asList(1, 9, 5, 8, 6, 7), StrangeSortList.strangeSortList(Arrays.asList(5, 6, 7, 8, 9, 1)));
    }

    @Test
    void testStrangeSortListWithDuplicates() {
        assertEquals(Arrays.asList(5, 5, 5, 5), StrangeSortList.strangeSortList(Arrays.asList(5, 5, 5, 5)));
    }

    @Test
    void testStrangeSortListWithEmptyList() {
        assertEquals(Arrays.asList(), StrangeSortList.strangeSortList(Arrays.asList()));
    }

    @Test
    void testStrangeSortListWithMixedValues() {
        assertEquals(Arrays.asList(-5, 5, -5, 5, 0, 2, 2, 2), StrangeSortList.strangeSortList(Arrays.asList(0, 2, 2, 2, 5, 5, -5, -5)));
    }

    @Test
    void testStrangeSortListWithSingleElement() {
        assertEquals(Arrays.asList(111111), StrangeSortList.strangeSortList(Arrays.asList(111111)));
    }

    @Test
    void testStrangeSortListWithNegativeValues() {
        assertEquals(Arrays.asList(-100, 100, -99, 99), StrangeSortList.strangeSortList(Arrays.asList(-100, -99, 99, 100)));
    }

    @Test
    void testStrangeSortListWithZeroValues() {
        assertEquals(Arrays.asList(0, 0), StrangeSortList.strangeSortList(Arrays.asList(0, 0)));
    }

    @Test
    void testStrangeSortListWithBoundaryValues() {
        assertEquals(Arrays.asList(-100, 100), StrangeSortList.strangeSortList(Arrays.asList(-100, 100)));
        assertEquals(Arrays.asList(-1, 1), StrangeSortList.strangeSortList(Arrays.asList(-1, 1)));
    }

    @Test
    void testStrangeSortListWithInvalidInputs() {
        assertEquals(Arrays.asList(), StrangeSortList.strangeSortList(Arrays.asList("string", 3.14, true)));
    }
}