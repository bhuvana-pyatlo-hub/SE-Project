package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CheckDictCaseTest {

    @Test
    void testAllLowerCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("b", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testAllUpperCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("STATE", "NC");
        dict.put("ZIP", "12345");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testMixedCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testNonStringKey() {
        Map<Object, String> dict = new HashMap<>();
        dict.put(8, "banana");
        dict.put("a", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testEmptyDictionary() {
        Map<String, String> dict = new HashMap<>();
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testAllUpperCaseWithNumbers() {
        Map<String, String> dict = new HashMap<>();
        dict.put("AGE", "36");
        dict.put("CITY", "HOUSTON");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testValidMixedKeys() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("fruit", "Orange");
        dict.put("taste", "Sweet");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testInvalidKeyType() {
        Map<Object, String> dict = new HashMap<>();
        dict.put(5, "banana");
        dict.put("a", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testBoundaryLowerCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("b", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testBoundaryUpperCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("A", "apple");
        dict.put("B", "BANANA");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testZeroKey() {
        Map<Object, String> dict = new HashMap<>();
        dict.put(0, "zero");
        dict.put("a", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testNegativeKey() {
        Map<Object, String> dict = new HashMap<>();
        dict.put(-1, "negative");
        dict.put("b", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testAllLowerCaseWithZero() {
        Map<String, String> dict = new HashMap<>();
        dict.put("zero", "value");
        dict.put("one", "value");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testAllUpperCaseWithZero() {
        Map<String, String> dict = new HashMap<>();
        dict.put("ZERO", "VALUE");
        dict.put("ONE", "VALUE");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }
}