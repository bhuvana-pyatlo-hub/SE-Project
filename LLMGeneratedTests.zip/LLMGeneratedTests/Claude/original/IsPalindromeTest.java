package original;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class IsPalindromeTest {

    @Test
    void testIsPalindrome_EmptyString() {
        assertTrue(IsPalindrome.isPalindrome(""), "Empty string should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_SingleCharacter() {
        assertTrue(IsPalindrome.isPalindrome("a"), "Single character should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_TwoSameCharacters() {
        assertTrue(IsPalindrome.isPalindrome("aa"), "Two same characters should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_TwoDifferentCharacters() {
        assertFalse(IsPalindrome.isPalindrome("ab"), "Two different characters should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_OddLengthPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("aba"), "Odd length string 'aba' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_EvenLengthPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("aaaa"), "Even length string 'aaaa' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("zbcd"), "'zbcd' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_OddLengthNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("xywyz"), "'xywyz' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_EvenLengthNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("xywzx"), "'xywzx' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_SpacesInPalindrome() {
        assertTrue(IsPalindrome.isPalindrome(" a b a "), "String with spaces ' a b a ' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_SpacesInNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome(" a b c "), "String with spaces ' a b c ' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_SpecialCharactersPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("@@@@"), "String with special characters '@@@@' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_SpecialCharactersNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("@@!@"), "String with special characters '@@!@' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NumbersAsStringPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("121"), "String '121' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NumbersAsStringNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("123"), "String '123' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_MixedCharactersPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("A man a plan a canal Panama"), "Mixed case palindrome should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_MixedCharactersNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("Hello World"), "Mixed case non-palindrome should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_LongPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("racecar"), "Long palindrome 'racecar' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_LongNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("abcdefgh"), "Long non-palindrome 'abcdefgh' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_ThreeSameCharacters() {
        assertTrue(IsPalindrome.isPalindrome("aaa"), "Three same characters 'aaa' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_SingleCharacterNonPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("b"), "Single character 'b' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NegativeValues() {
        assertFalse(IsPalindrome.isPalindrome("-1-1"), "String '-1-1' should not be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NegativeSingleCharacter() {
        assertTrue(IsPalindrome.isPalindrome("-"), "Single character '-' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NegativeTwoSameCharacters() {
        assertTrue(IsPalindrome.isPalindrome("--"), "Two same characters '--' should be considered a palindrome");
    }

    @Test
    void testIsPalindrome_NegativeTwoDifferentCharacters() {
        assertFalse(IsPalindrome.isPalindrome("-a"), "Two different characters '-a' should not be considered a palindrome");
    }
}