package original;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class StrlenTest {

    @Test
    void testLengthOfEmptyString() {
        assertEquals(0, Strlen.strlen(""));
    }

    @Test
    void testLengthOfSingleCharacterString() {
        assertEquals(1, Strlen.strlen("a"));
    }

    @Test
    void testLengthOfTwoCharacterString() {
        assertEquals(2, Strlen.strlen("ab"));
    }

    @Test
    void testLengthOfThreeCharacterString() {
        assertEquals(3, Strlen.strlen("abc"));
    }

    @Test
    void testLengthOfFourCharacterString() {
        assertEquals(4, Strlen.strlen("abcd"));
    }

    @Test
    void testLengthOfFiveCharacterString() {
        assertEquals(5, Strlen.strlen("abcde"));
    }

    @Test
    void testLengthOfSixCharacterString() {
        assertEquals(6, Strlen.strlen("abcdef"));
    }

    @Test
    void testLengthOfSevenCharacterString() {
        assertEquals(7, Strlen.strlen("abcdefg"));
    }

    @Test
    void testLengthOfEightCharacterString() {
        assertEquals(8, Strlen.strlen("abcdefgh"));
    }

    @Test
    void testLengthOfNineCharacterString() {
        assertEquals(9, Strlen.strlen("abcdefghi"));
    }

    @Test
    void testLengthOfTenCharacterString() {
        assertEquals(10, Strlen.strlen("abcdefghij"));
    }

    @Test
    void testLengthOfSpecialCharacters() {
        assertEquals(5, Strlen.strlen("@#&*%"));
    }

    @Test
    void testLengthOfWhitespaceString() {
        assertEquals(3, Strlen.strlen("   "));
    }

    @Test
    void testLengthOfStringWithNumbers() {
        assertEquals(4, Strlen.strlen("1234"));
    }

    @Test
    void testLengthOfStringWithMixedContent() {
        assertEquals(6, Strlen.strlen("a1b2c3"));
    }

    @Test
    void testLengthOfLongString() {
        assertEquals(12, Strlen.strlen("Hello World!"));
    }

    @Test
    void testLengthOfStringWithNewline() {
        assertEquals(5, Strlen.strlen("Line\n"));
    }

    @Test
    void testLengthOfStringWithTab() {
        assertEquals(4, Strlen.strlen("a\tb"));
    }

    @Test
    void testLengthOfStringWithUnicode() {
        assertEquals(3, Strlen.strlen("あいう"));
    }

    @Test
    void testLengthOfStringWithMixedUnicodeAndASCII() {
        assertEquals(5, Strlen.strlen("abcあい"));
    }

    @Test
    void testLengthOfStringWithEmptySpaces() {
        assertEquals(0, Strlen.strlen(""));
    }

    @Test
    void testLengthOfStringWithOnlyWhitespace() {
        assertEquals(0, Strlen.strlen(" "));
    }

    @Test
    void testLengthOfStringWithNegativeValues() {
        assertEquals(0, Strlen.strlen(null));
    }
}