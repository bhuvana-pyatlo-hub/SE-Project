package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExchangeTest {

    @Test
    void testAllEvenInFirstList() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(2, 4, 6), Arrays.asList(1, 3, 5)));
    }

    @Test
    void testAllOddInFirstList() {
        assertEquals("NO", Exchange.exchange(Arrays.asList(1, 3, 5), Arrays.asList(1, 3, 5)));
    }

    @Test
    void testMixedFirstListWithEvenSecondList() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(1, 2, 3), Arrays.asList(2, 4, 6)));
    }

    @Test
    void testMixedFirstListWithOddSecondList() {
        assertEquals("NO", Exchange.exchange(Arrays.asList(1, 3, 5), Arrays.asList(1, 5, 7)));
    }

    @Test
    void testEdgeCaseWithSingleElementLists() {
        assertEquals("NO", Exchange.exchange(Arrays.asList(1), Arrays.asList(2)));
        assertEquals("YES", Exchange.exchange(Arrays.asList(2), Arrays.asList(1)));
    }

    @Test
    void testAllElementsExchangePossible() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(5, 7, 3), Arrays.asList(2, 6, 4)));
    }

    @Test
    void testNoExchangePossible() {
        assertEquals("NO", Exchange.exchange(Arrays.asList(5, 7, 3), Arrays.asList(2, 6, 3)));
    }

    @Test
    void testComplexCase() {
        assertEquals("NO", Exchange.exchange(Arrays.asList(3, 2, 6, 1, 8, 9), Arrays.asList(3, 5, 5, 1, 1, 1)));
    }

    @Test
    void testBoundaryValues() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(0), Arrays.asList(2)));
        assertEquals("NO", Exchange.exchange(Arrays.asList(-1), Arrays.asList(-3)));
    }

    @Test
    void testNegativeValues() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(-2, -4), Arrays.asList(-1, -3)));
        assertEquals("NO", Exchange.exchange(Arrays.asList(-1, -3), Arrays.asList(-5, -7)));
    }

    @Test
    void testZeroValues() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(0), Arrays.asList(1)));
        assertEquals("NO", Exchange.exchange(Arrays.asList(1), Arrays.asList(0)));
    }

    @Test
    void testMinimumAndMaximumValidInputs() {
        assertEquals("YES", Exchange.exchange(Arrays.asList(-100, 100), Arrays.asList(0, 2)));
        assertEquals("NO", Exchange.exchange(Arrays.asList(99, 101), Arrays.asList(1, 3)));
    }
}