package original;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CountUpperTest {

    @Test
    void testCountUpper_EmptyString() {
        assertEquals(0, CountUpper.countUpper(""));
    }

    @Test
    void testCountUpper_NoUppercaseVowels() {
        assertEquals(0, CountUpper.countUpper("abcdefg"));
    }

    @Test
    void testCountUpper_OnlyLowercase() {
        assertEquals(0, CountUpper.countUpper("abcdEfgh"));
    }

    @Test
    void testCountUpper_UppercaseVowelsAtEvenIndices() {
        assertEquals(1, CountUpper.countUpper("aBCdEf"));
    }

    @Test
    void testCountUpper_UppercaseVowelsAtOddIndices() {
        assertEquals(0, CountUpper.countUpper("dBBE"));
    }

    @Test
    void testCountUpper_AllUppercaseVowels() {
        assertEquals(2, CountUpper.countUpper("EEEE"));
    }

    @Test
    void testCountUpper_MixedCaseWithUppercaseVowels() {
        assertEquals(1, CountUpper.countUpper("AbEcIdO"));
    }

    @Test
    void testCountUpper_UppercaseConsonants() {
        assertEquals(0, CountUpper.countUpper("BCDFG"));
    }

    @Test
    void testCountUpper_UppercaseVowelAtStart() {
        assertEquals(1, CountUpper.countUpper("AEIOU"));
    }

    @Test
    void testCountUpper_UppercaseVowelAtEnd() {
        assertEquals(1, CountUpper.countUpper("aBcdE"));
    }

    @Test
    void testCountUpper_SingleUppercaseVowel() {
        assertEquals(1, CountUpper.countUpper("A"));
    }

    @Test
    void testCountUpper_SingleUppercaseConsonant() {
        assertEquals(0, CountUpper.countUpper("B"));
    }

    @Test
    void testCountUpper_UppercaseVowelInMiddle() {
        assertEquals(1, CountUpper.countUpper("bAe"));
    }

    @Test
    void testCountUpper_UppercaseVowelAtEvenIndex() {
        assertEquals(1, CountUpper.countUpper("bAeC"));
    }

    @Test
    void testCountUpper_UppercaseVowelAtOddIndex() {
        assertEquals(0, CountUpper.countUpper("bAeCDE"));
    }

    @Test
    void testCountUpper_ConsecutiveUppercaseVowels() {
        assertEquals(2, CountUpper.countUpper("AEEI"));
    }

    @Test
    void testCountUpper_ConsecutiveUppercaseConsonants() {
        assertEquals(0, CountUpper.countUpper("BCDFG"));
    }

    @Test
    void testCountUpper_MultipleUppercaseVowels() {
        assertEquals(2, CountUpper.countUpper("AEBIOU"));
    }

    @Test
    void testCountUpper_SingleCharacterLowercase() {
        assertEquals(0, CountUpper.countUpper("a"));
    }

    @Test
    void testCountUpper_SingleCharacterUppercase() {
        assertEquals(0, CountUpper.countUpper("B"));
    }

    @Test
    void testCountUpper_MixedCaseWithNoUppercaseVowels() {
        assertEquals(0, CountUpper.countUpper("bcdEfgh"));
    }

    @Test
    void testCountUpper_UppercaseVowelWithLowercase() {
        assertEquals(1, CountUpper.countUpper("aAeE"));
    }

    @Test
    void testCountUpper_UppercaseVowelAtBoundary() {
        assertEquals(1, CountUpper.countUpper("A"));
        assertEquals(0, CountUpper.countUpper("B"));
    }

    @Test
    void testCountUpper_MultipleCharactersWithNoUppercaseVowels() {
        assertEquals(0, CountUpper.countUpper("bcdfgh"));
    }

    @Test
    void testCountUpper_MixedCaseWithOnlyUppercaseConsonants() {
        assertEquals(0, CountUpper.countUpper("BCDFGH"));
    }
}