package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortArray1Test {

    @Test
    void testEmptyArray() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testSingleElementArray() {
        List<Object> input = Collections.singletonList(5);
        List<Object> expected = Collections.singletonList(5);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testEvenSumAscending() {
        List<Object> input = Arrays.asList(2, 4, 3, 0, 1, 5);
        List<Object> expected = Arrays.asList(0, 1, 2, 3, 4, 5);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testOddSumDescending() {
        List<Object> input = Arrays.asList(2, 4, 3, 0, 1, 5, 6);
        List<Object> expected = Arrays.asList(6, 5, 4, 3, 2, 1, 0);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testTwoElementArrayAscending() {
        List<Object> input = Arrays.asList(2, 1);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testMultipleElementsEvenSumAscending() {
        List<Object> input = Arrays.asList(15, 42, 87, 32, 11, 0);
        List<Object> expected = Arrays.asList(0, 11, 15, 32, 42, 87);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testMultipleElementsOddSumDescending() {
        List<Object> input = Arrays.asList(21, 14, 23, 11);
        List<Object> expected = Arrays.asList(23, 21, 14, 11);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testNegativeValuesEvenSumAscending() {
        List<Object> input = Arrays.asList(-2, -4, -3, -1, -5);
        List<Object> expected = Arrays.asList(-5, -4, -3, -2, -1);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testNegativeValuesOddSumDescending() {
        List<Object> input = Arrays.asList(-2, -4, -3, -1, -5, -6);
        List<Object> expected = Arrays.asList(-1, -2, -3, -4, -5, -6);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 0, 100);
        List<Object> expected = Arrays.asList(-100, 0, 100);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testZeroValues() {
        List<Object> input = Arrays.asList(0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void testInvalidInput() {
        List<Object> input = Arrays.asList("invalid", 1, 2);
        List<Object> expected = Arrays.asList("invalid", 1, 2);
        assertEquals(expected, SortArray1.sortArray(input));
    }
}