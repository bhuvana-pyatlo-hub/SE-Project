package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountDistinctCharactersTest {

    @Test
    void testCountDistinctCharactersWithMixedCase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("xyzXYZ"));
    }

    @Test
    void testCountDistinctCharactersWithUniqueCharacters() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("Jerry"));
    }

    @Test
    void testCountDistinctCharactersWithEmptyString() {
        assertEquals(0, CountDistinctCharacters.countDistinctCharacters(""));
    }

    @Test
    void testCountDistinctCharactersWithAllUniqueLowercase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcde"));
    }

    @Test
    void testCountDistinctCharactersWithRepeatedCharacters() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcdecadeCADE"));
    }

    @Test
    void testCountDistinctCharactersWithAllSameCharacters() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aaaaAAAAaaaa"));
    }

    @Test
    void testCountDistinctCharactersWithSpacesAndMixedCase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("Jerry jERRY JeRRRY"));
    }

    @Test
    void testCountDistinctCharactersWithSingleCharacter() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("A"));
    }

    @Test
    void testCountDistinctCharactersWithSingleLowercaseCharacter() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("a"));
    }

    @Test
    void testCountDistinctCharactersWithTwoDifferentCharacters() {
        assertEquals(2, CountDistinctCharacters.countDistinctCharacters("ab"));
    }

    @Test
    void testCountDistinctCharactersWithTwoSameCharacters() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aa"));
    }

    @Test
    void testCountDistinctCharactersWithSpecialCharacters() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("a@b#c$a"));
    }

    @Test
    void testCountDistinctCharactersWithNumbers() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("1a2A3"));
    }

    @Test
    void testCountDistinctCharactersWithMixedAlphanumeric() {
        assertEquals(6, CountDistinctCharacters.countDistinctCharacters("abc123ABC"));
    }

    @Test
    void testCountDistinctCharactersWithLongerString() {
        assertEquals(10, CountDistinctCharacters.countDistinctCharacters("abcdefghij"));
    }

    @Test
    void testCountDistinctCharactersWithLongStringOfSameCharacter() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("zzzzzzzzzzzzzzzzzzzz"));
    }

    @Test
    void testCountDistinctCharactersWithLongStringWithSpaces() {
        assertEquals(6, CountDistinctCharacters.countDistinctCharacters("a b c d e f g"));
    }

    @Test
    void testCountDistinctCharactersWithMixedWhitespace() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters(" a b c d e "));
    }

    @Test
    void testCountDistinctCharactersWithPunctuation() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("Hello, World!"));
    }

    @Test
    void testCountDistinctCharactersWithUnicodeCharacters() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("aéaE"));
    }

    @Test
    void testCountDistinctCharactersWithLongStringWithMixedCaseAndNumbers() {
        assertEquals(7, CountDistinctCharacters.countDistinctCharacters("abcABC123"));
    }

    @Test
    void testCountDistinctCharactersWithNegativeValues() {
        assertEquals(0, CountDistinctCharacters.countDistinctCharacters("-"));
    }

    @Test
    void testCountDistinctCharactersWithBoundaryValues() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("0"));
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("100"));
        assertEquals(2, CountDistinctCharacters.countDistinctCharacters("1000"));
    }
}