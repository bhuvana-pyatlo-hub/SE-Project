package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GreatestCommonDivisorTest {

    @Test
    void testGcdWithPositiveIntegers() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(3, 5));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(25, 15));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(3, 7));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(10, 15));
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(49, 14));
        assertEquals(12, GreatestCommonDivisor.greatestCommonDivisor(144, 60));
    }

    @Test
    void testGcdWithZero() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(0, 5));
        assertEquals(0, GreatestCommonDivisor.greatestCommonDivisor(0, 0));
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(7, 0));
    }

    @Test
    void testGcdWithNegativeIntegers() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(-3, 5));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(25, -15));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(-3, -7));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(-10, 15));
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(-49, 14));
        assertEquals(12, GreatestCommonDivisor.greatestCommonDivisor(-144, 60));
    }

    @Test
    void testGcdWithMixedSignIntegers() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(3, -5));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(-25, 15));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(-3, 7));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(10, -15));
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(49, -14));
        assertEquals(12, GreatestCommonDivisor.greatestCommonDivisor(144, -60));
    }

    @Test
    void testGcdWithBoundaryValues() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(1, 1));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(-1, 1));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(1, -1));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(-1, -1));
        assertEquals(100, GreatestCommonDivisor.greatestCommonDivisor(100, 0));
        assertEquals(100, GreatestCommonDivisor.greatestCommonDivisor(0, 100));
    }

    @Test
    void testGcdWithInvalidInputs() {
        assertThrows(IllegalArgumentException.class, () -> {
            GreatestCommonDivisor.greatestCommonDivisor(Integer.MIN_VALUE, Integer.MIN_VALUE);
        });
    }
}