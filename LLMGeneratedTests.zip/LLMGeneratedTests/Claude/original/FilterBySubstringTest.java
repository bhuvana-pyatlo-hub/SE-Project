package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FilterBySubstringTest {

    @Test
    void testEmptyList() {
        List<Object> input = new ArrayList<>();
        String substring = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testNoMatch() {
        List<Object> input = List.of("bcd", "efg", "hij");
        String substring = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testSingleMatch() {
        List<Object> input = List.of("abc", "def", "ghi");
        String substring = "a";
        List<Object> expected = List.of("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testMultipleMatches() {
        List<Object> input = List.of("abc", "bacd", "cde", "array");
        String substring = "a";
        List<Object> expected = List.of("abc", "bacd", "array");
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testSubstringAtEnd() {
        List<Object> input = List.of("xxx", "asd", "xxy", "john doe", "xxxAAA", "xxx");
        String substring = "xxx";
        List<Object> expected = List.of("xxx", "xxxAAA", "xxx");
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testSubstringInMiddle() {
        List<Object> input = List.of("xxx", "asd", "aaaxxy", "john doe", "xxxAAA", "xxx");
        String substring = "xx";
        List<Object> expected = List.of("xxx", "aaaxxy", "xxxAAA", "xxx");
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testEdgeCaseWithEmptySubstring() {
        List<Object> input = List.of("abc", "def", "ghi");
        String substring = "";
        List<Object> expected = List.of("abc", "def", "ghi");
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testEdgeCaseWithNullSubstring() {
        List<Object> input = List.of("abc", "def", "ghi");
        String substring = null;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testEdgeCaseWithNullInList() {
        List<Object> input = List.of("abc", null, "ghi");
        String substring = "a";
        List<Object> expected = List.of("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testEdgeCaseWithAllNullsInList() {
        List<Object> input = List.of(null, null, null);
        String substring = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testEdgeCaseWithEmptyListAndEmptySubstring() {
        List<Object> input = new ArrayList<>();
        String substring = "";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }

    @Test
    void testEdgeCaseWithSingleNullInList() {
        List<Object> input = List.of(null);
        String substring = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(input, substring));
    }
}