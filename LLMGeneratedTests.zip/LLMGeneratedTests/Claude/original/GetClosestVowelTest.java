package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class GetClosestVowelTest {

    @Test
    void testGetClosestVowelWithVowelBetweenConsonants() {
        assertEquals("u", GetClosestVowel.getClosestVowel("yogurt")); // Valid case
        assertEquals("U", GetClosestVowel.getClosestVowel("FULL")); // Valid case
        assertEquals("a", GetClosestVowel.getClosestVowel("bad")); // Valid case
        assertEquals("o", GetClosestVowel.getClosestVowel("most")); // Valid case
        assertEquals("i", GetClosestVowel.getClosestVowel("anime")); // Valid case
        assertEquals("o", GetClosestVowel.getClosestVowel("Above")); // Valid case
    }

    @Test
    void testGetClosestVowelWithNoVowelBetweenConsonants() {
        assertEquals("", GetClosestVowel.getClosestVowel("quick")); // No vowel case
        assertEquals("", GetClosestVowel.getClosestVowel("ab")); // Edge case with only two letters
        assertEquals("", GetClosestVowel.getClosestVowel("ba")); // Edge case with only two letters
        assertEquals("", GetClosestVowel.getClosestVowel("eAsy")); // Mixed case with no valid vowel
        assertEquals("", GetClosestVowel.getClosestVowel("easy")); // Lowercase with no valid vowel
        assertEquals("", GetClosestVowel.getClosestVowel("ali")); // No valid vowel
        assertEquals("", GetClosestVowel.getClosestVowel("FULLY")); // No valid vowel
        assertEquals("", GetClosestVowel.getClosestVowel("A")); // Single letter case
        assertEquals("", GetClosestVowel.getClosestVowel("")); // Empty string case
    }

    @Test
    void testGetClosestVowelWithVowelsAtEnds() {
        assertEquals("", GetClosestVowel.getClosestVowel("aeiou")); // Vowels at the start and end
        assertEquals("", GetClosestVowel.getClosestVowel("uoei")); // Vowels at the start and end
        assertEquals("", GetClosestVowel.getClosestVowel("a")); // Single vowel case
        assertEquals("", GetClosestVowel.getClosestVowel("e")); // Single vowel case
    }

    @Test
    void testGetClosestVowelWithConsonantsOnly() {
        assertEquals("", GetClosestVowel.getClosestVowel("bcdfgh")); // All consonants
        assertEquals("", GetClosestVowel.getClosestVowel("xyz")); // All consonants
        assertEquals("", GetClosestVowel.getClosestVowel("bcd")); // All consonants
    }

    @Test
    void testGetClosestVowelWithMixedCases() {
        assertEquals("a", GetClosestVowel.getClosestVowel("bAd")); // Mixed case with valid vowel
        assertEquals("O", GetClosestVowel.getClosestVowel("mOsT")); // Mixed case with valid vowel
        assertEquals("", GetClosestVowel.getClosestVowel("aBc")); // Mixed case with no valid vowel
    }

    @Test
    void testGetClosestVowelWithBoundaryValues() {
        assertEquals("", GetClosestVowel.getClosestVowel("a")); // Single letter
        assertEquals("", GetClosestVowel.getClosestVowel("z")); // Single letter
        assertEquals("", GetClosestVowel.getClosestVowel("")); // Empty string
        assertEquals("", GetClosestVowel.getClosestVowel("A")); // Uppercase single letter
        assertEquals("", GetClosestVowel.getClosestVowel("Z")); // Uppercase single letter
    }

    @Test
    void testGetClosestVowelWithNegativeAndZeroValues() {
        assertEquals("", GetClosestVowel.getClosestVowel("0")); // Numeric character
        assertEquals("", GetClosestVowel.getClosestVowel("-")); // Negative sign
        assertEquals("", GetClosestVowel.getClosestVowel("1")); // Numeric character
    }
}