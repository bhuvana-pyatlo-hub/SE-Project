package original;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class SimplifyTest {

    @Test
    void testSimplifyTrueCases() {
        assertTrue(Simplify.simplify("1/5", "5/1"));
        assertTrue(Simplify.simplify("5/1", "3/1"));
        assertTrue(Simplify.simplify("2/10", "50/10"));
        assertTrue(Simplify.simplify("7/2", "4/2"));
        assertTrue(Simplify.simplify("11/6", "6/1"));
        assertTrue(Simplify.simplify("2/4", "8/4"));
        assertTrue(Simplify.simplify("2/4", "4/2"));
        assertTrue(Simplify.simplify("1/1", "1/1")); // Edge case: 1/1 * 1/1 = 1
        assertTrue(Simplify.simplify("100/1", "1/1")); // Edge case: max numerator
        assertTrue(Simplify.simplify("1/100", "100/1")); // Edge case: min denominator
    }

    @Test
    void testSimplifyFalseCases() {
        assertFalse(Simplify.simplify("1/6", "2/1"));
        assertFalse(Simplify.simplify("7/10", "10/2"));
        assertFalse(Simplify.simplify("2/3", "5/2"));
        assertFalse(Simplify.simplify("5/2", "3/5"));
        assertFalse(Simplify.simplify("1/5", "1/5"));
        assertFalse(Simplify.simplify("1/3", "3/2")); // Edge case: non-integer result
        assertFalse(Simplify.simplify("3/1", "2/1")); // Edge case: 3 * 2 = 6, 1 * 1 = 1, 6 % 1 = 0
        assertFalse(Simplify.simplify("1/2", "1/3")); // Edge case: 1/2 * 1/3 = 1/6
        assertFalse(Simplify.simplify("99/1", "1/99")); // Edge case: large numerator and small denominator
    }

    @Test
    void testSimplifyEdgeCases() {
        assertFalse(Simplify.simplify("0/1", "1/1")); // Edge case: zero numerator
        assertFalse(Simplify.simplify("1/0", "1/1")); // Edge case: invalid denominator (not allowed in original code)
        assertTrue(Simplify.simplify("1/1", "0/1")); // Edge case: zero denominator in second fraction
    }
}