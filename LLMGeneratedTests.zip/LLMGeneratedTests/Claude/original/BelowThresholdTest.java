package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BelowThresholdTest {

    @Test
    void testAllBelowThreshold() {
        List<Integer> numbers = Arrays.asList(1, 2, 4, 10);
        assertTrue(BelowThreshold.belowThreshold(numbers, 100));
    }

    @Test
    void testSomeAboveThreshold() {
        List<Integer> numbers = Arrays.asList(1, 20, 4, 10);
        assertFalse(BelowThreshold.belowThreshold(numbers, 5));
    }

    @Test
    void testAllBelowThresholdEqual() {
        List<Integer> numbers = Arrays.asList(1, 20, 4, 10);
        assertTrue(BelowThreshold.belowThreshold(numbers, 21));
    }

    @Test
    void testAllBelowThresholdJustAbove() {
        List<Integer> numbers = Arrays.asList(1, 20, 4, 10);
        assertTrue(BelowThreshold.belowThreshold(numbers, 22));
    }

    @Test
    void testSomeEqualThreshold() {
        List<Integer> numbers = Arrays.asList(1, 8, 4, 10);
        assertTrue(BelowThreshold.belowThreshold(numbers, 11));
    }

    @Test
    void testSomeEqualThresholdFalse() {
        List<Integer> numbers = Arrays.asList(1, 8, 4, 10);
        assertFalse(BelowThreshold.belowThreshold(numbers, 10));
    }

    @Test
    void testEmptyList() {
        List<Integer> numbers = Collections.emptyList();
        assertTrue(BelowThreshold.belowThreshold(numbers, 10));
    }

    @Test
    void testNegativeThreshold() {
        List<Integer> numbers = Arrays.asList(-1, -2, -3);
        assertTrue(BelowThreshold.belowThreshold(numbers, 0));
    }

    @Test
    void testNegativeNumbersAboveThreshold() {
        List<Integer> numbers = Arrays.asList(-1, -2, -3);
        assertFalse(BelowThreshold.belowThreshold(numbers, -2));
    }

    @Test
    void testBoundaryValueEqualThreshold() {
        List<Integer> numbers = Arrays.asList(0, 1, 2);
        assertFalse(BelowThreshold.belowThreshold(numbers, 0));
    }

    @Test
    void testBoundaryValueJustBelowThreshold() {
        List<Integer> numbers = Arrays.asList(0, 1, 2);
        assertTrue(BelowThreshold.belowThreshold(numbers, 3));
    }

    @Test
    void testMaximumValidInput() {
        List<Integer> numbers = Arrays.asList(99, 98, 97);
        assertTrue(BelowThreshold.belowThreshold(numbers, 100));
    }

    @Test
    void testMinimumValidInput() {
        List<Integer> numbers = Arrays.asList(-99, -98, -97);
        assertTrue(BelowThreshold.belowThreshold(numbers, 0));
    }

    @Test
    void testNegativeValuesEqualThreshold() {
        List<Integer> numbers = Arrays.asList(-1, -2, -3);
        assertFalse(BelowThreshold.belowThreshold(numbers, -1));
    }
}