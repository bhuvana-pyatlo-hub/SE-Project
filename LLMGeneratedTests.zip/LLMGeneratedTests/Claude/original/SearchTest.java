package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SearchTest {

    @Test
    void testSearchWithSingleElementOne() {
        List<Integer> input = Collections.singletonList(1);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithSingleElementGreaterThanOne() {
        List<Integer> input = Collections.singletonList(5);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithTwoElementsBothOne() {
        List<Integer> input = Arrays.asList(1, 1);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithTwoElementsOneAndTwo() {
        List<Integer> input = Arrays.asList(1, 2);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithTwoElementsBothTwo() {
        List<Integer> input = Arrays.asList(2, 2);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithThreeElementsOneTwoAndThree() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithFourElementsOneTwoThreeAndFour() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithFiveElementsOneTwoThreeAndFour() {
        List<Integer> input = Arrays.asList(1, 1, 2, 2, 3);
        assertEquals(2, Search.search(input));
    }

    @Test
    void testSearchWithMultipleElementsWithMaxFrequency() {
        List<Integer> input = Arrays.asList(4, 1, 2, 2, 3, 1);
        assertEquals(2, Search.search(input));
    }

    @Test
    void testSearchWithAllSameElements() {
        List<Integer> input = Arrays.asList(8, 8, 8, 8, 8, 8, 8, 8);
        assertEquals(8, Search.search(input));
    }

    @Test
    void testSearchWithNoValidFrequency() {
        List<Integer> input = Arrays.asList(5, 5, 4, 4, 4);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithHighFrequencyLowValue() {
        List<Integer> input = Arrays.asList(1, 1, 1, 1, 1);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithHighFrequencyMediumValue() {
        List<Integer> input = Arrays.asList(2, 2, 2, 2, 2);
        assertEquals(2, Search.search(input));
    }

    @Test
    void testSearchWithHighFrequencyHighValue() {
        List<Integer> input = Arrays.asList(3, 3, 3, 3, 3);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithMixedValues() {
        List<Integer> input = Arrays.asList(2, 3, 3, 2, 2);
        assertEquals(2, Search.search(input));
    }

    @Test
    void testSearchWithMoreComplexInput() {
        List<Integer> input = Arrays.asList(2, 7, 8, 8, 4, 8, 7, 3, 9, 6, 5, 10, 4, 3, 6, 7, 1, 7, 4, 10, 8, 1);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithNoElements() {
        List<Integer> input = Collections.emptyList();
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithBoundaryValues() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertEquals(1, Search.search(input));
    }

    @Test
    void testSearchWithAllElementsAboveFrequency() {
        List<Integer> input = Arrays.asList(10, 10, 10, 10, 10);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithMultipleValidFrequencies() {
        List<Integer> input = Arrays.asList(1, 1, 2, 2, 3, 3, 3);
        assertEquals(3, Search.search(input));
    }

    @Test
    void testSearchWithMultipleSameValues() {
        List<Integer> input = Arrays.asList(5, 5, 5, 5, 5, 5);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithMixedFrequencies() {
        List<Integer> input = Arrays.asList(1, 2, 2, 3, 3, 3, 4, 4, 4);
        assertEquals(3, Search.search(input));
    }

    @Test
    void testSearchWithNegativeValues() {
        List<Integer> input = Arrays.asList(-1, -2, -3);
        assertEquals(-1, Search.search(input));
    }

    @Test
    void testSearchWithZeroValues() {
        List<Integer> input = Arrays.asList(0, 0, 0);
        assertEquals(-1, Search.search(input));
    }
}