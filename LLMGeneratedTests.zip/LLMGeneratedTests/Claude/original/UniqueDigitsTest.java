package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UniqueDigitsTest {

    @Test
    void testUniqueDigitsWithNoEvenDigits() {
        List<Integer> input = Arrays.asList(15, 33, 1);
        List<Object> expected = Arrays.asList(1, 15, 33);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithAllEvenDigits() {
        List<Integer> input = Arrays.asList(152, 204, 10);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithMixedDigits() {
        List<Integer> input = Arrays.asList(12345, 2033, 111, 151);
        List<Object> expected = Arrays.asList(111, 151);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithEdgeCaseSingleDigit() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 3, 5);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithNegativeNumbers() {
        List<Integer> input = Arrays.asList(-15, -33, -1422, -1);
        List<Object> expected = Arrays.asList(-1, -15, -33);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithZero() {
        List<Integer> input = Arrays.asList(0, 1, 3, 5);
        List<Object> expected = Arrays.asList(1, 3, 5);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithEmptyList() {
        List<Integer> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithBoundaryValues() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> expected = Arrays.asList(1, 3, 5, 7, 9);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithNegativeBoundaryValues() {
        List<Integer> input = Arrays.asList(-1, -2, -3, -4, -5, -6, -7, -8, -9);
        List<Object> expected = Arrays.asList(-1, -3, -5, -7, -9);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithLargeEvenDigits() {
        List<Integer> input = Arrays.asList(2468, 4820, 204);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testUniqueDigitsWithMixedNegativeAndPositive() {
        List<Integer> input = Arrays.asList(-15, 33, 1422, 1, -2);
        List<Object> expected = Arrays.asList(1, -15, 33);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }
}