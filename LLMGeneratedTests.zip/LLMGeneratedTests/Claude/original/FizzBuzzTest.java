package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class FizzBuzzTest {

    @Test
    void testFizzBuzzWithNoSevens() {
        assertEquals(0, FizzBuzz.fizzBuzz(10)); // No numbers < 10 are divisible by 11 or 13
    }

    @Test
    void testFizzBuzzWithOneSeven() {
        assertEquals(1, FizzBuzz.fizzBuzz(20)); // 7 is the only number < 20 that is counted
    }

    @Test
    void testFizzBuzzWithTwoSevens() {
        assertEquals(2, FizzBuzz.fizzBuzz(80)); // 77 and 7 are counted
    }

    @Test
    void testFizzBuzzWithThreeSevens() {
        assertEquals(3, FizzBuzz.fizzBuzz(90)); // 7, 77, 87 are counted
    }

    @Test
    void testFizzBuzzWithMultipleDivisibles() {
        assertEquals(0, FizzBuzz.fizzBuzz(50)); // 11, 22, 33, 44 are counted, no sevens
    }

    @Test
    void testFizzBuzzWithEdgeCase() {
        assertEquals(0, FizzBuzz.fizzBuzz(11)); // Only 11 is counted, no sevens
    }

    @Test
    void testFizzBuzzWithNegativeInput() {
        assertEquals(0, FizzBuzz.fizzBuzz(-10)); // Negative input should return 0
    }

    @Test
    void testFizzBuzzWithZeroInput() {
        assertEquals(0, FizzBuzz.fizzBuzz(0)); // Zero input should return 0
    }

    @Test
    void testFizzBuzzWithBoundaryInput() {
        assertEquals(3, FizzBuzz.fizzBuzz(100)); // 77, 87 are counted
    }

    @Test
    void testFizzBuzzWithAnotherBoundaryInput() {
        assertEquals(6, FizzBuzz.fizzBuzz(200)); // 77, 87, 97, 107, 117, 127 are counted
    }

    @Test
    void testFizzBuzzWithLargeInput() {
        assertEquals(3, FizzBuzz.fizzBuzz(100)); // 77, 87 are counted
    }

    @Test
    void testFizzBuzzWithAnotherLargeInput() {
        assertEquals(6, FizzBuzz.fizzBuzz(200)); // 77, 87, 97, 107, 117, 127 are counted
    }
}