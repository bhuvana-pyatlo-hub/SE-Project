package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class NextSmallestTest {

    @Test
    void testNextSmallestWithMultipleDistinctElements() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(2, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithUnorderedDistinctElements() {
        List<Object> input = Arrays.asList(5, 1, 4, 3, 2);
        assertEquals(2, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithEmptyList() {
        List<Object> input = Collections.emptyList();
        assertNull(NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithTwoSameElements() {
        List<Object> input = Arrays.asList(1, 1);
        assertNull(NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithMultipleSameElementsAndOneDifferent() {
        List<Object> input = Arrays.asList(1, 1, 1, 1, 0);
        assertEquals(1, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithNegativeAndPositiveElements() {
        List<Object> input = Arrays.asList(-35, 34, 12, -45);
        assertEquals(-35, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithSingleElement() {
        List<Object> input = Arrays.asList(10);
        assertNull(NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithTwoDifferentElements() {
        List<Object> input = Arrays.asList(5, 10);
        assertEquals(10, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithNegativeValues() {
        List<Object> input = Arrays.asList(-10, -20, -30);
        assertEquals(-20, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithAllSameNegativeValues() {
        List<Object> input = Arrays.asList(-1, -1, -1);
        assertNull(NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 0, 100);
        assertEquals(0, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithTwoSameBoundaryValues() {
        List<Object> input = Arrays.asList(100, 100);
        assertNull(NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithZeroAndPositiveValues() {
        List<Object> input = Arrays.asList(0, 1, 2);
        assertEquals(1, NextSmallest.nextSmallest(input));
    }

    @Test
    void testNextSmallestWithZeroAndNegativeValues() {
        List<Object> input = Arrays.asList(-1, 0);
        assertEquals(0, NextSmallest.nextSmallest(input));
    }
}