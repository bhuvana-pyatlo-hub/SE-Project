package original;

import org.junit.jupiter.api.Test;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EvenOddCountTest {

    @Test
    void testEvenOddCountWithZero() {
        List<Integer> result = EvenOddCount.evenOddCount(0);
        assertEquals(List.of(1, 0), result);
    }

    @Test
    void testEvenOddCountWithPositiveEvenNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(246);
        assertEquals(List.of(3, 0), result);
    }

    @Test
    void testEvenOddCountWithPositiveOddNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(135);
        assertEquals(List.of(0, 3), result);
    }

    @Test
    void testEvenOddCountWithNegativeEvenNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-48);
        assertEquals(List.of(2, 0), result);
    }

    @Test
    void testEvenOddCountWithNegativeOddNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-57);
        assertEquals(List.of(0, 2), result);
    }

    @Test
    void testEvenOddCountWithMixedDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(3452);
        assertEquals(List.of(2, 2), result);
    }

    @Test
    void testEvenOddCountWithNegativeMixedDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(-45347);
        assertEquals(List.of(2, 3), result);
    }

    @Test
    void testEvenOddCountWithSingleDigitEven() {
        List<Integer> result = EvenOddCount.evenOddCount(2);
        assertEquals(List.of(1, 0), result);
    }

    @Test
    void testEvenOddCountWithSingleDigitOdd() {
        List<Integer> result = EvenOddCount.evenOddCount(7);
        assertEquals(List.of(0, 1), result);
    }

    @Test
    void testEvenOddCountWithNegativeSingleDigitEven() {
        List<Integer> result = EvenOddCount.evenOddCount(-4);
        assertEquals(List.of(1, 0), result);
    }

    @Test
    void testEvenOddCountWithNegativeSingleDigitOdd() {
        List<Integer> result = EvenOddCount.evenOddCount(-9);
        assertEquals(List.of(0, 1), result);
    }

    @Test
    void testEvenOddCountWithBoundaryValues() {
        List<Integer> result = EvenOddCount.evenOddCount(100);
        assertEquals(List.of(3, 0), result);
        
        result = EvenOddCount.evenOddCount(-100);
        assertEquals(List.of(3, 0), result);
    }

    @Test
    void testEvenOddCountWithNegativeBoundaryValues() {
        List<Integer> result = EvenOddCount.evenOddCount(-1);
        assertEquals(List.of(0, 1), result);
        
        result = EvenOddCount.evenOddCount(-2);
        assertEquals(List.of(1, 0), result);
    }

}