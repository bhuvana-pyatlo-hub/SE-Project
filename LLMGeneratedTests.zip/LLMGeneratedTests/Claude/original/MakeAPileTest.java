package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MakeAPileTest {

    @Test
    void testMakeAPileOdd() {
        assertEquals(List.of(1), MakeAPile.makeAPile(1)); // Minimum odd input
        assertEquals(List.of(3, 5, 7), MakeAPile.makeAPile(3)); // Small odd input
        assertEquals(List.of(5, 7, 9, 11, 13), MakeAPile.makeAPile(5)); // Small odd input
        assertEquals(List.of(99, 101, 103), MakeAPile.makeAPile(99)); // Maximum odd input
    }

    @Test
    void testMakeAPileEven() {
        assertEquals(List.of(2), MakeAPile.makeAPile(2)); // Minimum even input
        assertEquals(List.of(4, 6, 8, 10), MakeAPile.makeAPile(4)); // Small even input
        assertEquals(List.of(6, 8, 10, 12, 14, 16), MakeAPile.makeAPile(6)); // Small even input
        assertEquals(List.of(100, 102, 104, 106, 108, 110, 112, 114), MakeAPile.makeAPile(100)); // Maximum even input
    }

    @Test
    void testMakeAPileNegative() {
        assertEquals(List.of(), MakeAPile.makeAPile(-1)); // Negative input
        assertEquals(List.of(), MakeAPile.makeAPile(-50)); // Negative input
    }

    @Test
    void testMakeAPileZero() {
        assertEquals(List.of(), MakeAPile.makeAPile(0)); // Zero input
    }
}