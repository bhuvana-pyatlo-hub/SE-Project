package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MoveOneBallTest {

    @Test
    void testEmptyArray() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList()));
    }

    @Test
    void testAlreadySorted() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(1, 2, 3, 4, 5)));
    }

    @Test
    void testSingleShiftNeeded() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(3, 4, 5, 1, 2)));
    }

    @Test
    void testMultipleShiftsNeeded() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(3, 5, 10, 1, 2)));
    }

    @Test
    void testNotPossibleToSort() {
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(4, 3, 1, 2)));
    }

    @Test
    void testAnotherNotPossible() {
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(3, 5, 4, 1, 2)));
    }

    @Test
    void testTwoElementsSorted() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(1, 2)));
    }

    @Test
    void testTwoElementsUnsorted() {
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(2, 1)));
    }

    @Test
    void testThreeElementsSorted() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(1, 2, 3)));
    }

    @Test
    void testThreeElementsOneShiftNeeded() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(3, 1, 2)));
    }

    @Test
    void testThreeElementsNotPossible() {
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(3, 2, 1)));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(-100, -99, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 100)));
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87)));
    }

    @Test
    void testNegativeValues() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(-3, -2, -1, 0, 1)));
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(-1, -2, -3, 0, 1)));
    }

    @Test
    void testZeroValues() {
        assertEquals(true, MoveOneBall.moveOneBall(Arrays.asList(0, 0, 0, 0)));
        assertEquals(false, MoveOneBall.moveOneBall(Arrays.asList(0, -1, 1)));
    }
}