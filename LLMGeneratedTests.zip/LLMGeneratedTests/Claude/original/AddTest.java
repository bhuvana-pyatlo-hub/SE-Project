package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class AddTest {

    @Test
    void testAddWithZeroAndPositive() {
        assertEquals(1, Add.add(0, 1));
    }

    @Test
    void testAddWithPositiveAndZero() {
        assertEquals(1, Add.add(1, 0));
    }

    @Test
    void testAddWithSmallPositiveNumbers() {
        assertEquals(5, Add.add(2, 3));
    }

    @Test
    void testAddWithDifferentOrder() {
        assertEquals(12, Add.add(5, 7));
        assertEquals(12, Add.add(7, 5));
    }

    @Test
    void testAddWithSmallPositiveIntegers() {
        assertEquals(10, Add.add(5, 5));
        assertEquals(0, Add.add(-5, 5));
        assertEquals(-10, Add.add(-5, -5));
    }

    @Test
    void testAddWithNegativeAndPositive() {
        assertEquals(0, Add.add(-1, 1));
        assertEquals(-1, Add.add(-1, 0));
        assertEquals(-2, Add.add(-1, -1));
    }

    @Test
    void testAddWithBoundaryValues() {
        assertEquals(100, Add.add(100, 0));
        assertEquals(100, Add.add(0, 100));
        assertEquals(0, Add.add(0, 0));
        assertEquals(-100, Add.add(-100, 0));
        assertEquals(-100, Add.add(0, -100));
        assertEquals(-200, Add.add(-100, -100));
    }

    @Test
    void testAddWithInvalidInputs() {
        // Assuming the method should handle invalid inputs gracefully
        // However, since the method is static and does not throw exceptions,
        // we cannot test invalid inputs directly unless we modify the method.
        // This test case is left here for future implementation.
    }
}