package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DerivativeTest {

    @Test
    void testDerivativeWithMultipleTerms() {
        List<Integer> input = Arrays.asList(3, 1, 2, 4, 5);
        List<Object> expected = Arrays.asList(1, 4, 12, 20);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithThreeTerms() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithTwoTerms() {
        List<Integer> input = Arrays.asList(3, 2, 1);
        List<Object> expected = Arrays.asList(2, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithZeroTerm() {
        List<Integer> input = Arrays.asList(3, 2, 1, 0, 4);
        List<Object> expected = Arrays.asList(2, 2, 0, 16);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithSingleTerm() {
        List<Integer> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList();
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithEmptyList() {
        List<Integer> input = Arrays.asList();
        List<Object> expected = Arrays.asList();
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithNegativeCoefficients() {
        List<Integer> input = Arrays.asList(-3, -2, -1);
        List<Object> expected = Arrays.asList(-2, -2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithMixedCoefficients() {
        List<Integer> input = Arrays.asList(-1, 0, 1, -2);
        List<Object> expected = Arrays.asList(0, 2, -6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithBoundaryValues() {
        List<Integer> input = Arrays.asList(0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithMaximumValidInput() {
        List<Integer> input = Arrays.asList(100, 99, 98);
        List<Object> expected = Arrays.asList(99, 196);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithMinimumValidInput() {
        List<Integer> input = Arrays.asList(-100, -99, -98);
        List<Object> expected = Arrays.asList(-99, -196);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivativeWithZeroCoefficient() {
        List<Integer> input = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(1, 4);
        assertEquals(expected, Derivative.derivative(input));
    }
}