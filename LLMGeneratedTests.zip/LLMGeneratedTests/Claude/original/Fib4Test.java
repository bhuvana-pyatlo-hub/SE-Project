package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Fib4Test {

    @Test
    void testFib4WithNegativeInput() {
        assertEquals(0, Fib4.fib4(-1), "fib4(-1) should return 0 for negative input");
    }

    @Test
    void testFib4WithZeroInput() {
        assertEquals(0, Fib4.fib4(0), "fib4(0) should return 0");
    }

    @Test
    void testFib4WithOneInput() {
        assertEquals(0, Fib4.fib4(1), "fib4(1) should return 0");
    }

    @Test
    void testFib4WithTwoInput() {
        assertEquals(2, Fib4.fib4(2), "fib4(2) should return 2");
    }

    @Test
    void testFib4WithThreeInput() {
        assertEquals(0, Fib4.fib4(3), "fib4(3) should return 0");
    }

    @Test
    void testFib4WithFourInput() {
        assertEquals(2, Fib4.fib4(4), "fib4(4) should return 2");
    }

    @Test
    void testFib4WithFiveInput() {
        assertEquals(4, Fib4.fib4(5), "fib4(5) should return 4");
    }

    @Test
    void testFib4WithSixInput() {
        assertEquals(8, Fib4.fib4(6), "fib4(6) should return 8");
    }

    @Test
    void testFib4WithSevenInput() {
        assertEquals(14, Fib4.fib4(7), "fib4(7) should return 14");
    }

    @Test
    void testFib4WithEightInput() {
        assertEquals(28, Fib4.fib4(8), "fib4(8) should return 28");
    }

    @Test
    void testFib4WithNineInput() {
        assertEquals(52, Fib4.fib4(9), "fib4(9) should return 52");
    }

    @Test
    void testFib4WithTenInput() {
        assertEquals(104, Fib4.fib4(10), "fib4(10) should return 104");
    }

    @Test
    void testFib4WithElevenInput() {
        assertEquals(208, Fib4.fib4(11), "fib4(11) should return 208");
    }

    @Test
    void testFib4WithTwelveInput() {
        assertEquals(386, Fib4.fib4(12), "fib4(12) should return 386");
    }

    @Test
    void testFib4WithThirteenInput() {
        assertEquals(694, Fib4.fib4(13), "fib4(13) should return 694");
    }

    @Test
    void testFib4WithFourteenInput() {
        assertEquals(1280, Fib4.fib4(14), "fib4(14) should return 1280");
    }

    @Test
    void testFib4WithFifteenInput() {
        assertEquals(2360, Fib4.fib4(15), "fib4(15) should return 2360");
    }

    @Test
    void testFib4WithSixteenInput() {
        assertEquals(4320, Fib4.fib4(16), "fib4(16) should return 4320");
    }

    @Test
    void testFib4WithSeventeenInput() {
        assertEquals(8000, Fib4.fib4(17), "fib4(17) should return 8000");
    }

    @Test
    void testFib4WithEighteenInput() {
        assertEquals(14760, Fib4.fib4(18), "fib4(18) should return 14760");
    }

    @Test
    void testFib4WithNineteenInput() {
        assertEquals(27200, Fib4.fib4(19), "fib4(19) should return 27200");
    }

    @Test
    void testFib4WithTwentyInput() {
        assertEquals(50176, Fib4.fib4(20), "fib4(20) should return 50176");
    }
}