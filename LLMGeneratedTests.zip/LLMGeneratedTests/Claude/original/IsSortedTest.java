package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class IsSortedTest {

    @Test
    void testEmptyList() {
        assertTrue(IsSorted.isSorted(Arrays.asList()));
    }

    @Test
    void testSingleElement() {
        assertTrue(IsSorted.isSorted(Arrays.asList(5)));
    }

    @Test
    void testSortedList() {
        assertTrue(IsSorted.isSorted(Arrays.asList(1, 2, 3, 4, 5)));
        assertTrue(IsSorted.isSorted(Arrays.asList(1, 2, 2, 3, 3, 4)));
        assertTrue(IsSorted.isSorted(Arrays.asList(1, 2, 3, 4)));
    }

    @Test
    void testUnsortedList() {
        assertFalse(IsSorted.isSorted(Arrays.asList(1, 3, 2, 4, 5)));
        assertFalse(IsSorted.isSorted(Arrays.asList(1, 3, 2, 4, 5, 6, 7)));
        assertFalse(IsSorted.isSorted(Arrays.asList(3, 2, 1)));
    }

    @Test
    void testListWithDuplicates() {
        assertFalse(IsSorted.isSorted(Arrays.asList(1, 2, 2, 2, 3, 4)));
        assertFalse(IsSorted.isSorted(Arrays.asList(1, 2, 3, 3, 3, 4)));
        assertFalse(IsSorted.isSorted(Arrays.asList(1, 2, 3, 4, 5, 5)));
    }

    @Test
    void testListWithNegativeNumbers() {
        // Assuming the method should not accept negative numbers based on the comment
        assertThrows(ClassCastException.class, () -> IsSorted.isSorted(Arrays.asList(-1, 0, 1)));
    }
}