package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class NumericalLetterGradeTest {

    @Test
    void testNumericalLetterGrade_APlus() {
        assertEquals(Arrays.asList("A+"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(4.0)));
    }

    @Test
    void testNumericalLetterGrade_A() {
        assertEquals(Arrays.asList("A"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(3.8)));
    }

    @Test
    void testNumericalLetterGrade_AMinus() {
        assertEquals(Arrays.asList("A-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(3.4)));
    }

    @Test
    void testNumericalLetterGrade_BPlus() {
        assertEquals(Arrays.asList("B+"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(3.1)));
    }

    @Test
    void testNumericalLetterGrade_B() {
        assertEquals(Arrays.asList("B"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(2.8)));
    }

    @Test
    void testNumericalLetterGrade_BMinus() {
        assertEquals(Arrays.asList("B-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(2.4)));
    }

    @Test
    void testNumericalLetterGrade_CPlus() {
        assertEquals(Arrays.asList("C+"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(2.1)));
    }

    @Test
    void testNumericalLetterGrade_C() {
        assertEquals(Arrays.asList("C"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(1.8)));
    }

    @Test
    void testNumericalLetterGrade_CMinus() {
        assertEquals(Arrays.asList("C-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(1.4)));
    }

    @Test
    void testNumericalLetterGrade_DPlus() {
        assertEquals(Arrays.asList("D+"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(1.1)));
    }

    @Test
    void testNumericalLetterGrade_D() {
        assertEquals(Arrays.asList("D"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(0.8)));
    }

    @Test
    void testNumericalLetterGrade_DMinus() {
        assertEquals(Arrays.asList("D-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(0.5)));
    }

    @Test
    void testNumericalLetterGrade_E() {
        assertEquals(Arrays.asList("E"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(0.0)));
    }

    @Test
    void testNumericalLetterGrade_DMinusBoundary() {
        assertEquals(Arrays.asList("D-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(0.1)));
    }

    @Test
    void testNumericalLetterGrade_ZeroAndPositive() {
        assertEquals(Arrays.asList("E", "D-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(0.0, 0.5)));
    }

    @Test
    void testNumericalLetterGrade_MixedGrades() {
        assertEquals(Arrays.asList("A+", "B", "C-", "C", "A-"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(4.0, 2.8, 1.7, 2.0, 3.5)));
    }

    @Test
    void testNumericalLetterGrade_NegativeValues() {
        assertEquals(Arrays.asList("E"), NumericalLetterGrade.numericalLetterGrade(Arrays.asList(-1.0)));
    }

    @Test
    void testNumericalLetterGrade_EmptyList() {
        assertEquals(Arrays.asList(), NumericalLetterGrade.numericalLetterGrade(Arrays.asList()));
    }
}