package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SpecialfilterTest {

    @Test
    void testSpecialFilterWithValidInputs() {
        assertEquals(1, Specialfilter.specialfilter(Arrays.asList(15, -73, 14, -15)));
        assertEquals(2, Specialfilter.specialfilter(Arrays.asList(33, -2, -3, 45, 21, 109)));
        assertEquals(4, Specialfilter.specialfilter(Arrays.asList(43, -12, 93, 125, 121, 109)));
        assertEquals(3, Specialfilter.specialfilter(Arrays.asList(71, -2, -33, 75, 21, 19)));
        assertEquals(1, Specialfilter.specialfilter(Arrays.asList(31, 12, 51, 73))); // First and last digit odd
        assertEquals(1, Specialfilter.specialfilter(Arrays.asList(91, 22, 41, 19))); // First and last digit odd
    }

    @Test
    void testSpecialFilterWithEdgeCases() {
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(5, -2, 1, -5))); // All numbers <= 10
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(1))); // Single number <= 10
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList())); // Empty list
        assertEquals(1, Specialfilter.specialfilter(Arrays.asList(11, 21, 31))); // All valid, first and last odd
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(10, 20, 30))); // All numbers <= 10
    }

    @Test
    void testSpecialFilterWithInvalidInputs() {
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(-15, -73, -14, -15))); // All negative
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(10, 20, 30))); // All numbers <= 10
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(-11, -21, -31))); // All negative odd
        assertEquals(0, Specialfilter.specialfilter(Arrays.asList(0, 0, 0))); // All zeros
    }
}