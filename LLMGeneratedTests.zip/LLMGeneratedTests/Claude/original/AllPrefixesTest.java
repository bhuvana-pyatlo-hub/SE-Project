package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AllPrefixesTest {

    @Test
    void testAllPrefixesWithSingleCharacter() {
        List<Object> result = AllPrefixes.allPrefixes("a");
        assertEquals(List.of("a"), result);
    }

    @Test
    void testAllPrefixesWithTwoCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("ab");
        assertEquals(List.of("a", "ab"), result);
    }

    @Test
    void testAllPrefixesWithThreeCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("abc");
        assertEquals(List.of("a", "ab", "abc"), result);
    }

    @Test
    void testAllPrefixesWithEmptyString() {
        List<Object> result = AllPrefixes.allPrefixes("");
        assertEquals(List.of(), result);
    }

    @Test
    void testAllPrefixesWithFourCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("abcd");
        assertEquals(List.of("a", "ab", "abc", "abcd"), result);
    }

    @Test
    void testAllPrefixesWithFiveCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("abcde");
        assertEquals(List.of("a", "ab", "abc", "abcd", "abcde"), result);
    }

    @Test
    void testAllPrefixesWithSixCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("abcdef");
        assertEquals(List.of("a", "ab", "abc", "abcd", "abcde", "abcdef"), result);
    }

    @Test
    void testAllPrefixesWithSevenCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("abcdefg");
        assertEquals(List.of("a", "ab", "abc", "abcd", "abcde", "abcdef", "abcdefg"), result);
    }

    @Test
    void testAllPrefixesWithSpecialCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("!@#");
        assertEquals(List.of("!", "!@", "!@#"), result);
    }

    @Test
    void testAllPrefixesWithWhitespace() {
        List<Object> result = AllPrefixes.allPrefixes(" ");
        assertEquals(List.of(" "), result);
    }

    @Test
    void testAllPrefixesWithMixedCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("a1b2");
        assertEquals(List.of("a", "a1", "a1b", "a1b2"), result);
    }

    @Test
    void testAllPrefixesWithLongerString() {
        List<Object> result = AllPrefixes.allPrefixes("abcdefghij");
        assertEquals(List.of("a", "ab", "abc", "abcd", "abcde", "abcdef", "abcdefg", "abcdefgh", "abcdefghi", "abcdefghij"), result);
    }

    @Test
    void testAllPrefixesWithRepeatingCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("aaa");
        assertEquals(List.of("a", "aa", "aaa"), result);
    }

    @Test
    void testAllPrefixesWithNumbersAsString() {
        List<Object> result = AllPrefixes.allPrefixes("123");
        assertEquals(List.of("1", "12", "123"), result);
    }

    @Test
    void testAllPrefixesWithSingleCharacterRepeated() {
        List<Object> result = AllPrefixes.allPrefixes("x");
        assertEquals(List.of("x"), result);
    }

    @Test
    void testAllPrefixesWithTwoDifferentCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("xy");
        assertEquals(List.of("x", "xy"), result);
    }

    @Test
    void testAllPrefixesWithThreeDifferentCharacters() {
        List<Object> result = AllPrefixes.allPrefixes("xyz");
        assertEquals(List.of("x", "xy", "xyz"), result);
    }

    @Test
    void testAllPrefixesWithSingleWhitespace() {
        List<Object> result = AllPrefixes.allPrefixes(" ");
        assertEquals(List.of(" "), result);
    }

    @Test
    void testAllPrefixesWithNegativeInput() {
        List<Object> result = AllPrefixes.allPrefixes("-1");
        assertEquals(List.of("-", "-1"), result);
    }

    @Test
    void testAllPrefixesWithBoundaryInput() {
        List<Object> result = AllPrefixes.allPrefixes("0");
        assertEquals(List.of("0"), result);
    }

    @Test
    void testAllPrefixesWithMaxBoundaryInput() {
        List<Object> result = AllPrefixes.allPrefixes("99");
        assertEquals(List.of("9", "99"), result);
    }

    @Test
    void testAllPrefixesWithMinBoundaryInput() {
        List<Object> result = AllPrefixes.allPrefixes("-99");
        assertEquals(List.of("-", "-9", "-99"), result);
    }
}