package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class EncodeTest {

    @Test
    void testEncodeLowercaseInput() {
        assertEquals("TGST", Encode.encode("test"));
    }

    @Test
    void testEncodeUppercaseInput() {
        assertEquals("tgst", Encode.encode("TEST"));
    }

    @Test
    void testEncodeMixedCaseInput() {
        assertEquals("mWDCSKR", Encode.encode("Mudasir"));
    }

    @Test
    void testEncodeInputWithSpaces() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message"));
    }

    @Test
    void testEncodeInputWithVowels() {
        assertEquals("ygs", Encode.encode("YES"));
    }

    @Test
    void testEncodeInputWithAllVowels() {
        assertEquals("k dQnT kNqW wHcT Tq wRkTg", Encode.encode("I DoNt KnOw WhAt tO WrItE"));
    }

    @Test
    void testEncodeEmptyString() {
        assertEquals("", Encode.encode(""));
    }

    @Test
    void testEncodeSingleCharacterLowercaseVowel() {
        assertEquals("C", Encode.encode("a"));
    }

    @Test
    void testEncodeSingleCharacterUppercaseVowel() {
        assertEquals("C", Encode.encode("A"));
    }

    @Test
    void testEncodeSingleCharacterLowercaseConsonant() {
        assertEquals("T", Encode.encode("t"));
    }

    @Test
    void testEncodeSingleCharacterUppercaseConsonant() {
        assertEquals("t", Encode.encode("T"));
    }

    @Test
    void testEncodeInputWithNonAlphabeticCharacters() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message!"));
    }

    @Test
    void testEncodeInputWithNumbers() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message 123"));
    }

    @Test
    void testEncodeInputWithSpecialCharacters() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message @#$%"));
    }

    @Test
    void testEncodeInputWithMixedCaseAndSpaces() {
        assertEquals("k dQnT kNqW wHcT Tq wRkTg", Encode.encode("I DoNt KnOw WhAt tO WrItE"));
    }

    @Test
    void testEncodeInputWithAllLowercaseVowels() {
        assertEquals("cE", Encode.encode("ae"));
    }

    @Test
    void testEncodeInputWithAllUppercaseVowels() {
        assertEquals("cE", Encode.encode("AE"));
    }

    @Test
    void testEncodeInputWithConsecutiveVowels() {
        assertEquals("cE", Encode.encode("aeiou"));
    }

    @Test
    void testEncodeInputWithConsecutiveConsonants() {
        assertEquals("Tg", Encode.encode("tG"));
    }

    @Test
    void testEncodeInputWithLongString() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message that is long"));
    }

    @Test
    void testEncodeInputWithSingleCharacterSpecial() {
        assertEquals("!", Encode.encode("!"));
    }

    @Test
    void testEncodeInputWithNegativeValues() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message -1"));
    }

    @Test
    void testEncodeInputWithBoundaryValues() {
        assertEquals("C", Encode.encode("e"));
        assertEquals("C", Encode.encode("E"));
        assertEquals("T", Encode.encode("t"));
        assertEquals("t", Encode.encode("T"));
    }

    @Test
    void testEncodeInputWithMaximumValidInput() {
        assertEquals("Tg", Encode.encode("g"));
        assertEquals("G", Encode.encode("G"));
    }

}