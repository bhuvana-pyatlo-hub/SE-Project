package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class RoundedAvgTest {

    @Test
    void testRoundedAvg_ValidRange1() {
        assertEquals("0b11", RoundedAvg.roundedAvg(1, 5));
    }

    @Test
    void testRoundedAvg_ValidRange2() {
        assertEquals("0b1010", RoundedAvg.roundedAvg(7, 13));
    }

    @Test
    void testRoundedAvg_ValidRange3() {
        assertEquals("0b1111001010", RoundedAvg.roundedAvg(964, 977));
    }

    @Test
    void testRoundedAvg_ValidRange4() {
        assertEquals("0b1111100100", RoundedAvg.roundedAvg(996, 997));
    }

    @Test
    void testRoundedAvg_ValidRange5() {
        assertEquals("0b1011000010", RoundedAvg.roundedAvg(560, 851));
    }

    @Test
    void testRoundedAvg_ValidRange6() {
        assertEquals("0b101101110", RoundedAvg.roundedAvg(185, 546));
    }

    @Test
    void testRoundedAvg_ValidRange7() {
        assertEquals("0b110101101", RoundedAvg.roundedAvg(362, 496));
    }

    @Test
    void testRoundedAvg_ValidRange8() {
        assertEquals("0b1001110010", RoundedAvg.roundedAvg(350, 902));
    }

    @Test
    void testRoundedAvg_ValidRange9() {
        assertEquals("0b11010111", RoundedAvg.roundedAvg(197, 233));
    }

    @Test
    void testRoundedAvg_SingleValue() {
        assertEquals("0b101", RoundedAvg.roundedAvg(5, 5));
    }

    @Test
    void testRoundedAvg_NGreaterThanM1() {
        assertEquals(-1, RoundedAvg.roundedAvg(7, 5));
    }

    @Test
    void testRoundedAvg_NGreaterThanM2() {
        assertEquals(-1, RoundedAvg.roundedAvg(5, 1));
    }

    @Test
    void testRoundedAvg_BoundaryCase1() {
        assertEquals("0b10", RoundedAvg.roundedAvg(1, 2));
    }

    @Test
    void testRoundedAvg_BoundaryCase2() {
        assertEquals("0b1", RoundedAvg.roundedAvg(0, 1));
    }

    @Test
    void testRoundedAvg_BoundaryCase3() {
        assertEquals("0b0", RoundedAvg.roundedAvg(0, 0));
    }

    @Test
    void testRoundedAvg_ValidRangeWithSmallValues1() {
        assertEquals("0b11", RoundedAvg.roundedAvg(2, 4));
    }

    @Test
    void testRoundedAvg_ValidRangeWithSmallValues2() {
        assertEquals("0b10", RoundedAvg.roundedAvg(1, 3));
    }

    @Test
    void testRoundedAvg_ValidRangeWithSmallValues3() {
        assertEquals("0b110", RoundedAvg.roundedAvg(3, 5));
    }

    @Test
    void testRoundedAvg_ValidRangeWithSmallValues4() {
        assertEquals("0b100", RoundedAvg.roundedAvg(4, 4));
    }

    @Test
    void testRoundedAvg_ValidRangeWithSmallValues5() {
        assertEquals("0b111", RoundedAvg.roundedAvg(5, 6));
    }

    @Test
    void testRoundedAvg_ValidRangeWithSmallValues6() {
        assertEquals("0b101", RoundedAvg.roundedAvg(2, 6));
    }

    @Test
    void testRoundedAvg_NGreaterThanM3() {
        assertEquals(-1, RoundedAvg.roundedAvg(-1, -5));
    }

    @Test
    void testRoundedAvg_ValidRangeNegativeValues() {
        assertEquals("0b1", RoundedAvg.roundedAvg(-1, 1));
    }

    @Test
    void testRoundedAvg_ValidRangeNegativeToPositive() {
        assertEquals("0b0", RoundedAvg.roundedAvg(-1, 1));
    }
}