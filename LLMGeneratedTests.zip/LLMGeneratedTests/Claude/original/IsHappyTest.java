package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsHappyTest {

    @Test
    void testIsHappyWithShortString() {
        assertFalse(IsHappy.isHappy("a")); // Length < 3
    }

    @Test
    void testIsHappyWithTwoCharacters() {
        assertFalse(IsHappy.isHappy("aa")); // Length < 3
    }

    @Test
    void testIsHappyWithThreeSameCharacters() {
        assertFalse(IsHappy.isHappy("aaa")); // All characters same
    }

    @Test
    void testIsHappyWithThreeDistinctCharacters() {
        assertTrue(IsHappy.isHappy("abc")); // All characters distinct
    }

    @Test
    void testIsHappyWithThreeCharactersTwoSame() {
        assertFalse(IsHappy.isHappy("aab")); // Two characters same
    }

    @Test
    void testIsHappyWithFourCharactersTwoPairs() {
        assertFalse(IsHappy.isHappy("aabb")); // Two pairs of same characters
    }

    @Test
    void testIsHappyWithFourCharactersDistinct() {
        assertTrue(IsHappy.isHappy("abcd")); // All characters distinct
    }

    @Test
    void testIsHappyWithFourCharactersOnePair() {
        assertFalse(IsHappy.isHappy("abca")); // One pair of same characters
    }

    @Test
    void testIsHappyWithFiveCharacters() {
        assertTrue(IsHappy.isHappy("abcde")); // All characters distinct
    }

    @Test
    void testIsHappyWithFiveCharactersWithRepetition() {
        assertFalse(IsHappy.isHappy("abcab")); // Repetition of 'a' and 'b'
    }

    @Test
    void testIsHappyWithFiveCharactersWithAdjacentSame() {
        assertFalse(IsHappy.isHappy("ababa")); // Adjacent same characters
    }

    @Test
    void testIsHappyWithSixCharactersAllDistinct() {
        assertTrue(IsHappy.isHappy("abcdef")); // All characters distinct
    }

    @Test
    void testIsHappyWithSixCharactersWithOnePair() {
        assertFalse(IsHappy.isHappy("abcdea")); // One pair of same characters
    }

    @Test
    void testIsHappyWithSevenCharactersAllDistinct() {
        assertTrue(IsHappy.isHappy("abcdefg")); // All characters distinct
    }

    @Test
    void testIsHappyWithSevenCharactersWithMultiplePairs() {
        assertFalse(IsHappy.isHappy("abcabcg")); // Multiple pairs of same characters
    }

    @Test
    void testIsHappyWithEightCharactersWithDistinct() {
        assertTrue(IsHappy.isHappy("abcdefgh")); // All characters distinct
    }

    @Test
    void testIsHappyWithEightCharactersWithAdjacentSame() {
        assertFalse(IsHappy.isHappy("abcdeefg")); // Adjacent same characters
    }

    @Test
    void testIsHappyWithNineCharactersWithOnePair() {
        assertFalse(IsHappy.isHappy("abcdefabc")); // One pair of same characters
    }

    @Test
    void testIsHappyWithTenCharactersWithMultiplePairs() {
        assertFalse(IsHappy.isHappy("abcabcabca")); // Multiple pairs of same characters
    }

    @Test
    void testIsHappyWithLongStringWithDistinct() {
        assertTrue(IsHappy.isHappy("abcdefghij")); // All characters distinct
    }

    @Test
    void testIsHappyWithLongStringWithRepetition() {
        assertFalse(IsHappy.isHappy("abcdeabcde")); // Repetition of the first five characters
    }

    @Test
    void testIsHappyWithEmptyString() {
        assertFalse(IsHappy.isHappy("")); // Length < 3
    }

    @Test
    void testIsHappyWithSingleCharacterString() {
        assertFalse(IsHappy.isHappy("x")); // Length < 3
    }

    @Test
    void testIsHappyWithTwoDifferentCharacters() {
        assertFalse(IsHappy.isHappy("xy")); // Length < 3
    }

    @Test
    void testIsHappyWithThreeCharactersAllSame() {
        assertFalse(IsHappy.isHappy("xxx")); // All characters same
    }

    @Test
    void testIsHappyWithThreeCharactersTwoSame1() {
        assertFalse(IsHappy.isHappy("xyx")); // Two characters same
    }

    @Test
    void testIsHappyWithThreeCharactersDistinct() {
        assertTrue(IsHappy.isHappy("xyz")); // All characters distinct
    }
}