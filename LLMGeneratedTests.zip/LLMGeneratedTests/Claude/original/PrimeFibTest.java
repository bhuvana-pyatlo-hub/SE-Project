package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PrimeFibTest {

    @Test
    void testPrimeFibWithInputOne() {
        assertEquals(2, PrimeFib.primeFib(1), "The 1st prime Fibonacci number should be 2");
    }

    @Test
    void testPrimeFibWithInputTwo() {
        assertEquals(3, PrimeFib.primeFib(2), "The 2nd prime Fibonacci number should be 3");
    }

    @Test
    void testPrimeFibWithInputThree() {
        assertEquals(5, PrimeFib.primeFib(3), "The 3rd prime Fibonacci number should be 5");
    }

    @Test
    void testPrimeFibWithInputFour() {
        assertEquals(13, PrimeFib.primeFib(4), "The 4th prime Fibonacci number should be 13");
    }

    @Test
    void testPrimeFibWithInputFive() {
        assertEquals(89, PrimeFib.primeFib(5), "The 5th prime Fibonacci number should be 89");
    }

    @Test
    void testPrimeFibWithInputSix() {
        assertEquals(233, PrimeFib.primeFib(6), "The 6th prime Fibonacci number should be 233");
    }

    @Test
    void testPrimeFibWithInputSeven() {
        assertEquals(1597, PrimeFib.primeFib(7), "The 7th prime Fibonacci number should be 1597");
    }

    @Test
    void testPrimeFibWithInputEight() {
        assertEquals(28657, PrimeFib.primeFib(8), "The 8th prime Fibonacci number should be 28657");
    }

    @Test
    void testPrimeFibWithInputNine() {
        assertEquals(514229, PrimeFib.primeFib(9), "The 9th prime Fibonacci number should be 514229");
    }

    @Test
    void testPrimeFibWithInputTen() {
        assertEquals(433494437, PrimeFib.primeFib(10), "The 10th prime Fibonacci number should be 433494437");
    }

    @Test
    void testPrimeFibWithInputEleven() {
        assertEquals(5702887, PrimeFib.primeFib(11), "The 11th prime Fibonacci number should be 5702887");
    }

    @Test
    void testPrimeFibWithInputTwelve() {
        assertEquals(9227465, PrimeFib.primeFib(12), "The 12th prime Fibonacci number should be 9227465");
    }

    @Test
    void testPrimeFibWithInputThirteen() {
        assertEquals(14930352, PrimeFib.primeFib(13), "The 13th prime Fibonacci number should be 14930352");
    }

    @Test
    void testPrimeFibWithInputFourteen() {
        assertEquals(24157817, PrimeFib.primeFib(14), "The 14th prime Fibonacci number should be 24157817");
    }

    @Test
    void testPrimeFibWithInputFifteen() {
        assertEquals(39088169, PrimeFib.primeFib(15), "The 15th prime Fibonacci number should be 39088169");
    }

    @Test
    void testPrimeFibWithInputSixteen() {
        assertEquals(5702887, PrimeFib.primeFib(16), "The 16th prime Fibonacci number should be 5702887");
    }

    @Test
    void testPrimeFibWithInputSeventeen() {
        assertEquals(9227465, PrimeFib.primeFib(17), "The 17th prime Fibonacci number should be 9227465");
    }


    @Test
    void testPrimeFibWithInputNineteen() {
        assertEquals(24157817, PrimeFib.primeFib(19), "The 19th prime Fibonacci number should be 24157817");
    }

    @Test
    void testPrimeFibWithInputZero() {
        assertThrows(IllegalArgumentException.class, () -> PrimeFib.primeFib(0), "Input must be greater than 0");
    }

    @Test
    void testPrimeFibWithNegativeInput() {
        assertThrows(IllegalArgumentException.class, () -> PrimeFib.primeFib(-5), "Input must be greater than 0");
    }
}