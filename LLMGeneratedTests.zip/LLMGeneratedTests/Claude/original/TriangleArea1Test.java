package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TriangleArea1Test {

    @Test
    void testValidTriangleAreaWithSides3_4_5() {
        assertEquals(6.00, TriangleArea1.triangleArea(3, 4, 5));
    }

    @Test
    void testInvalidTriangleAreaWithSides1_2_10() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 10));
    }

    @Test
    void testValidTriangleAreaWithSides4_8_5() {
        assertEquals(8.18, TriangleArea1.triangleArea(4, 8, 5));
    }

    @Test
    void testValidTriangleAreaWithSides2_2_2() {
        assertEquals(1.73, TriangleArea1.triangleArea(2, 2, 2));
    }

    @Test
    void testInvalidTriangleAreaWithSides1_2_3() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 3));
    }

    @Test
    void testValidTriangleAreaWithSides10_5_7() {
        assertEquals(16.25, TriangleArea1.triangleArea(10, 5, 7));
    }

    @Test
    void testInvalidTriangleAreaWithSides2_6_3() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 6, 3));
    }

    @Test
    void testValidTriangleAreaWithSides1_1_1() {
        assertEquals(0.43, TriangleArea1.triangleArea(1, 1, 1));
    }

    @Test
    void testInvalidTriangleAreaWithSides2_2_10() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 2, 10));
    }

    @Test
    void testValidTriangleAreaWithSides5_5_8() {
        assertEquals(12.00, TriangleArea1.triangleArea(5, 5, 8));
    }

    @Test
    void testInvalidTriangleAreaWithSides1_1_3() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 3));
    }

    @Test
    void testValidTriangleAreaWithSides6_8_10() {
        assertEquals(24.00, TriangleArea1.triangleArea(6, 8, 10));
    }

    @Test
    void testInvalidTriangleAreaWithSides3_3_7() {
        assertEquals(-1, TriangleArea1.triangleArea(3, 3, 7));
    }

    @Test
    void testValidTriangleAreaWithSides7_8_9() {
        assertEquals(26.83, TriangleArea1.triangleArea(7, 8, 9));
    }

    @Test
    void testInvalidTriangleAreaWithSides1_1_2() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 2));
    }

    @Test
    void testValidTriangleAreaWithSides3_5_4() {
        assertEquals(6.00, TriangleArea1.triangleArea(3, 5, 4));
    }

    @Test
    void testInvalidTriangleAreaWithSides10_1_1() {
        assertEquals(-1, TriangleArea1.triangleArea(10, 1, 1));
    }

    @Test
    void testValidTriangleAreaWithSides9_12_15() {
        assertEquals(54.00, TriangleArea1.triangleArea(9, 12, 15));
    }

    @Test
    void testInvalidTriangleAreaWithSides2_2_5() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 2, 5));
    }

    @Test
    void testValidTriangleAreaWithSides5_12_13() {
        assertEquals(30.00, TriangleArea1.triangleArea(5, 12, 13));
    }

    @Test
    void testInvalidTriangleAreaWithSides1_1_4() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 4));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(-1, TriangleArea1.triangleArea(0, 0, 0));
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 2));
        assertEquals(-1, TriangleArea1.triangleArea(-1, 1, 1));
        assertEquals(-1, TriangleArea1.triangleArea(1, -1, 1));
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, -1));
        assertEquals(-1, TriangleArea1.triangleArea(-1, -1, -1));
    }

    @Test
    void testZeroValues() {
        assertEquals(-1, TriangleArea1.triangleArea(0, 1, 1));
        assertEquals(-1, TriangleArea1.triangleArea(1, 0, 1));
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 0));
    }

    @Test
    void testNegativeValues() {
        assertEquals(-1, TriangleArea1.triangleArea(-3, -4, -5));
        assertEquals(-1, TriangleArea1.triangleArea(-1, -1, -1));
    }
}