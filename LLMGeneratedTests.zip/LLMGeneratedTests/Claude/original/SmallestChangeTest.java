package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SmallestChangeTest {

    @Test
    void testSmallestChangeWithVariousInputs() {
        assertEquals(4, SmallestChange.smallestChange(Arrays.asList(1, 2, 3, 5, 4, 7, 9, 6))); // multiple changes needed
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(1, 2, 3, 4, 3, 2, 2))); // one change needed
        assertEquals(0, SmallestChange.smallestChange(Arrays.asList(1, 2, 3, 2, 1))); // already palindromic
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(1, 4, 2))); // one change needed
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(1, 4, 4, 2))); // one change needed
        assertEquals(0, SmallestChange.smallestChange(Arrays.asList(3, 1, 1, 3))); // already palindromic
        assertEquals(0, SmallestChange.smallestChange(Collections.singletonList(1))); // single element
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(0, 1))); // one change needed
        assertEquals(0, SmallestChange.smallestChange(Collections.singletonList(0))); // single element
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(-1, 1))); // one change needed
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(-100, 100))); // one change needed
        assertEquals(2, SmallestChange.smallestChange(Arrays.asList(-100, 0, 100))); // two changes needed
        assertEquals(0, SmallestChange.smallestChange(Arrays.asList(1, 1, 1))); // already palindromic
        assertEquals(3, SmallestChange.smallestChange(Arrays.asList(1, 2, 3, 4, 5))); // multiple changes needed
        assertEquals(0, SmallestChange.smallestChange(Arrays.asList(100, 100, 100))); // already palindromic
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(100, 99, 100))); // one change needed
        assertEquals(1, SmallestChange.smallestChange(Arrays.asList(-1, -1, -1, -2))); // one change needed
    }
}