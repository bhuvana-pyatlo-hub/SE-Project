package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class SumToNTest {

    @Test
    void testSumToNWithSmallPositiveIntegerOne() {
        assertEquals(1, SumToN.sumToN(1));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerTwo() {
        assertEquals(3, SumToN.sumToN(2));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerThree() {
        assertEquals(6, SumToN.sumToN(3));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerFour() {
        assertEquals(10, SumToN.sumToN(4));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerFive() {
        assertEquals(15, SumToN.sumToN(5));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerSix() {
        assertEquals(21, SumToN.sumToN(6));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerSeven() {
        assertEquals(28, SumToN.sumToN(7));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerEight() {
        assertEquals(36, SumToN.sumToN(8));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerNine() {
        assertEquals(45, SumToN.sumToN(9));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerTen() {
        assertEquals(55, SumToN.sumToN(10));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerEleven() {
        assertEquals(66, SumToN.sumToN(11));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerTwelve() {
        assertEquals(78, SumToN.sumToN(12));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerThirteen() {
        assertEquals(91, SumToN.sumToN(13));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerFourteen() {
        assertEquals(105, SumToN.sumToN(14));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerFifteen() {
        assertEquals(120, SumToN.sumToN(15));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerTwenty() {
        assertEquals(210, SumToN.sumToN(20));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerThirty() {
        assertEquals(465, SumToN.sumToN(30));
    }

    @Test
    void testSumToNWithSmallPositiveIntegerOneHundred() {
        assertEquals(5050, SumToN.sumToN(100));
    }

    @Test
    void testSumToNWithZero() {
        assertEquals(0, SumToN.sumToN(0));
    }

    @Test
    void testSumToNWithNegativeInteger() {
        assertEquals(0, SumToN.sumToN(-5));
    }

    @Test
    void testSumToNWithNegativeBoundaryValue() {
        assertEquals(0, SumToN.sumToN(-1));
    }

    @Test
    void testSumToNWithMinimumNegativeInteger() {
        assertEquals(0, SumToN.sumToN(-100));
    }

    @Test
    void testSumToNWithMinimumPositiveInteger() {
        assertEquals(1, SumToN.sumToN(1));
    }
}