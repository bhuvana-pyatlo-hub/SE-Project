package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FruitDistributionTest {

    @Test
    void testFruitDistributionWithValidInput1() {
        assertEquals(8, FruitDistribution.fruitDistribution("5 apples and 6 oranges", 19));
    }

    @Test
    void testFruitDistributionWithValidInput2() {
        assertEquals(10, FruitDistribution.fruitDistribution("5 apples and 6 oranges", 21));
    }

    @Test
    void testFruitDistributionWithValidInput3() {
        assertEquals(2, FruitDistribution.fruitDistribution("0 apples and 1 oranges", 3));
    }

    @Test
    void testFruitDistributionWithValidInput4() {
        assertEquals(2, FruitDistribution.fruitDistribution("1 apples and 0 oranges", 3));
    }

    @Test
    void testFruitDistributionWithValidInput5() {
        assertEquals(95, FruitDistribution.fruitDistribution("2 apples and 3 oranges", 100));
    }

    @Test
    void testFruitDistributionWithValidInput6() {
        assertEquals(0, FruitDistribution.fruitDistribution("2 apples and 3 oranges", 5));
    }

    @Test
    void testFruitDistributionWithValidInput7() {
        assertEquals(19, FruitDistribution.fruitDistribution("1 apples and 100 oranges", 120));
    }

    @Test
    void testFruitDistributionWithNoApples() {
        assertEquals(10, FruitDistribution.fruitDistribution("0 apples and 10 oranges", 20));
    }

    @Test
    void testFruitDistributionWithNoOranges() {
        assertEquals(15, FruitDistribution.fruitDistribution("10 apples and 0 oranges", 25));
    }

    @Test
    void testFruitDistributionWithOnlyMangoes() {
        assertEquals(10, FruitDistribution.fruitDistribution("0 apples and 0 oranges", 10));
    }

    @Test
    void testFruitDistributionWithNegativeMangoes() {
        assertEquals(-1, FruitDistribution.fruitDistribution("10 apples and 10 oranges", 19));
    }

    @Test
    void testFruitDistributionWithLargeNumberOfOranges() {
        assertEquals(-99, FruitDistribution.fruitDistribution("1 apples and 100 oranges", 2));
    }

    @Test
    void testFruitDistributionWithBoundaryValues() {
        assertEquals(0, FruitDistribution.fruitDistribution("0 apples and 0 oranges", 0));
    }

    @Test
    void testFruitDistributionWithSingleFruit() {
        assertEquals(0, FruitDistribution.fruitDistribution("1 apples and 0 oranges", 1));
    }

    @Test
    void testFruitDistributionWithMultipleWords() {
        assertEquals(5, FruitDistribution.fruitDistribution("1 apples and 1 oranges and more fruits", 7));
    }

    @Test
    void testFruitDistributionWithOnlyApples() {
        assertEquals(0, FruitDistribution.fruitDistribution("5 apples and 0 oranges", 5));
    }

    @Test
    void testFruitDistributionWithOnlyOranges() {
        assertEquals(0, FruitDistribution.fruitDistribution("0 apples and 5 oranges", 5));
    }

    @Test
    void testFruitDistributionWithMixedFruits() {
        assertEquals(0, FruitDistribution.fruitDistribution("3 apples and 2 oranges", 5));
    }

    @Test
    void testFruitDistributionWithInvalidInput() {
        assertThrows(NumberFormatException.class, () -> {
            FruitDistribution.fruitDistribution("apples and oranges", 10);
        });
    }

    @Test
    void testFruitDistributionWithEmptyString() {
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            FruitDistribution.fruitDistribution("", 10);
        });
    }

    @Test
    void testFruitDistributionWithNullInput() {
        assertThrows(NullPointerException.class, () -> {
            FruitDistribution.fruitDistribution(null, 10);
        });
    }

    @Test
    void testFruitDistributionWithNegativeInput() {
        assertEquals(-1, FruitDistribution.fruitDistribution("5 apples and 6 oranges", -1));
    }

    @Test
    void testFruitDistributionWithBoundaryNegativeValues() {
        assertEquals(-1, FruitDistribution.fruitDistribution("100 apples and 100 oranges", 199));
    }
}