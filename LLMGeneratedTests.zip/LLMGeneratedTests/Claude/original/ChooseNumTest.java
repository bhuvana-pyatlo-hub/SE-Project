package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ChooseNumTest {

    @Test
    void testChooseNumWithEvenRange() {
        assertEquals(14, ChooseNum.chooseNum(12, 15)); // Valid range with even numbers
    }

    @Test
    void testChooseNumWithReversedRange() {
        assertEquals(-1, ChooseNum.chooseNum(13, 12)); // Reversed range
    }

    @Test
    void testChooseNumWithMixedRange() {
        assertEquals(28, ChooseNum.chooseNum(6, 29)); // Valid range with mixed odd/even
    }

    @Test
    void testChooseNumWithReversedMixedRange() {
        assertEquals(-1, ChooseNum.chooseNum(27, 10)); // Reversed range with no evens
    }

    @Test
    void testChooseNumWithSingleOddNumber() {
        assertEquals(-1, ChooseNum.chooseNum(7, 7)); // Single odd number
    }

    @Test
    void testChooseNumWithSingleEvenNumber() {
        assertEquals(546, ChooseNum.chooseNum(546, 546)); // Single even number
    }

    @Test
    void testChooseNumWithSmallEvenRange() {
        assertEquals(2, ChooseNum.chooseNum(1, 2)); // Small range with even number
    }

    @Test
    void testChooseNumWithSmallOddRange() {
        assertEquals(-1, ChooseNum.chooseNum(1, 1)); // Small range with odd number
    }

    @Test
    void testChooseNumWithZeroAndPositive() {
        assertEquals(0, ChooseNum.chooseNum(0, 1)); // Range including zero
    }

    @Test
    void testChooseNumWithNegativeAndPositive() {
        assertEquals(0, ChooseNum.chooseNum(-1, 1)); // Range including negative and zero
    }

    @Test
    void testChooseNumWithNegativeRange() {
        assertEquals(-1, ChooseNum.chooseNum(-3, -1)); // Range with negative odd numbers
    }

    @Test
    void testChooseNumWithNegativeEven() {
        assertEquals(-2, ChooseNum.chooseNum(-3, -2)); // Range with negative even number
    }

    @Test
    void testChooseNumWithLargeNegativeRange() {
        assertEquals(-1, ChooseNum.chooseNum(-100, -99)); // Large negative range with odd numbers
    }

    @Test
    void testChooseNumWithBoundaryValues() {
        assertEquals(100, ChooseNum.chooseNum(100, 100)); // Boundary value at 100
    }

    @Test
    void testChooseNumWithAllOdds() {
        assertEquals(-1, ChooseNum.chooseNum(1, 9)); // Range with all odd numbers
    }

    @Test
    void testChooseNumWithAllEvens() {
        assertEquals(8, ChooseNum.chooseNum(0, 8)); // Range with all even numbers
    }

    @Test
    void testChooseNumWithEvenAndOdd() {
        assertEquals(8, ChooseNum.chooseNum(3, 8)); // Range with both even and odd
    }

    @Test
    void testChooseNumWithSingleNegativeEven() {
        assertEquals(-2, ChooseNum.chooseNum(-2, -2)); // Single negative even number
    }
}