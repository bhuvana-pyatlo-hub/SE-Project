package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BfTest {

    @Test
    void testValidInputWithPlanetsInOrder() {
        assertEquals(List.of("Saturn", "Uranus"), Bf.bf("Jupiter", "Neptune"));
    }

    @Test
    void testValidInputWithPlanetsReversed() {
        assertEquals(List.of("Earth", "Mars", "Jupiter", "Saturn", "Uranus"), Bf.bf("Neptune", "Venus"));
    }

    @Test
    void testValidInputWithAdjacentPlanets() {
        assertEquals(List.of("Venus"), Bf.bf("Earth", "Mercury"));
    }

    @Test
    void testValidInputWithMultiplePlanetsInBetween() {
        assertEquals(List.of("Venus", "Earth", "Mars", "Jupiter", "Saturn"), Bf.bf("Mercury", "Uranus"));
    }

    @Test
    void testSamePlanetInput() {
        assertEquals(List.of(), Bf.bf("Earth", "Earth"));
    }

    @Test
    void testInvalidPlanet2() {
        assertEquals(List.of(), Bf.bf("Jupiter", "Makemake"));
    }

    @Test
    void testInvalidPlanet1() {
        assertEquals(List.of(), Bf.bf("Pluto", "Earth"));
    }

    @Test
    void testInvalidBothPlanets() {
        assertEquals(List.of(), Bf.bf("Pluto", "Makemake"));
    }

    @Test
    void testValidInputWithPlanetsInReverseOrderAdjacent() {
        assertEquals(List.of(), Bf.bf("Mars", "Earth"));
    }

    @Test
    void testValidInputWithPlanetsInReverseOrderMultiple() {
        assertEquals(List.of("Venus", "Earth", "Mars", "Jupiter", "Saturn"), Bf.bf("Uranus", "Mercury"));
    }

    @Test
    void testValidInputWithOneValidAndOneInvalidPlanet() {
        assertEquals(List.of(), Bf.bf("Earth", "Pluto"));
    }

    @Test
    void testValidInputWithBothInvalidPlanets() {
        assertEquals(List.of(), Bf.bf("Pluto", "Pluto"));
    }

    @Test
    void testValidInputWithSamePlanet() {
        assertEquals(List.of(), Bf.bf("Neptune", "Neptune"));
    }

    @Test
    void testValidInputWithNoPlanetsInBetween() {
        assertEquals(List.of(), Bf.bf("Venus", "Earth"));
    }

    @Test
    void testValidInputWithOnePlanetInBetween() {
        assertEquals(List.of("Earth"), Bf.bf("Venus", "Mars"));
    }

    @Test
    void testValidInputWithTwoPlanetsInBetween() {
        assertEquals(List.of("Earth", "Mars"), Bf.bf("Venus", "Jupiter"));
    }

    @Test
    void testValidInputWithThreePlanetsInBetween() {
        assertEquals(List.of("Earth", "Mars", "Jupiter"), Bf.bf("Venus", "Saturn"));
    }

    @Test
    void testValidInputWithFourPlanetsInBetween() {
        assertEquals(List.of("Earth", "Mars", "Jupiter", "Saturn"), Bf.bf("Venus", "Uranus"));
    }

    @Test
    void testValidInputWithFivePlanetsInBetween() {
        assertEquals(List.of("Earth", "Mars", "Jupiter", "Saturn", "Uranus"), Bf.bf("Venus", "Neptune"));
    }

    @Test
    void testValidInputWithAllPlanetsInBetween() {
        assertEquals(List.of("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus"), Bf.bf("Mercury", "Neptune"));
    }
}