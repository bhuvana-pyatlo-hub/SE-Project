package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RightAngleTriangleTest {

    @Test
    void testRightAngleTriangleTrueCases() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(3, 4, 5));
        assertTrue(RightAngleTriangle.rightAngleTriangle(10, 6, 8));
        assertTrue(RightAngleTriangle.rightAngleTriangle(7, 24, 25));
        assertTrue(RightAngleTriangle.rightAngleTriangle(5, 12, 13));
        assertTrue(RightAngleTriangle.rightAngleTriangle(15, 8, 17));
        assertTrue(RightAngleTriangle.rightAngleTriangle(48, 55, 73));
    }

    @Test
    void testRightAngleTriangleFalseCases() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 2, 3));
        assertFalse(RightAngleTriangle.rightAngleTriangle(2, 2, 2));
        assertFalse(RightAngleTriangle.rightAngleTriangle(10, 5, 7));
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 1, 1));
        assertFalse(RightAngleTriangle.rightAngleTriangle(2, 2, 10));
    }

    @Test
    void testRightAngleTriangleEdgeCases() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(-3, 4, 5)); // Negative value
        assertFalse(RightAngleTriangle.rightAngleTriangle(0, 0, 0)); // Zero values
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 3, 5)); // Two sides equal
        assertFalse(RightAngleTriangle.rightAngleTriangle(5, 5, 5)); // All sides equal
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 2, 2)); // Two sides equal
        assertFalse(RightAngleTriangle.rightAngleTriangle(100, 100, 100)); // Large equal sides
        assertTrue(RightAngleTriangle.rightAngleTriangle(0, 3, 3)); // Right angle triangle with zero
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 4, 6)); // Not a right angle triangle
    }
}