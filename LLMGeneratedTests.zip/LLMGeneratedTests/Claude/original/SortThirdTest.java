package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortThirdTest {

    @Test
    void testSortThirdBasicCases() {
        assertEquals(Arrays.asList(1, 2, 3), SortThird.sortThird(Arrays.asList(1, 2, 3)));
        assertEquals(Arrays.asList(2, 6, 3, 4, 8, 9, 5), SortThird.sortThird(Arrays.asList(5, 6, 3, 4, 8, 9, 2)));
        assertEquals(Arrays.asList(1, 3, -5, 2, -3, 3, 5, 0, 123, 9, -10), SortThird.sortThird(Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10)));
        assertEquals(Arrays.asList(-10, 8, -12, 3, 23, 2, 4, 11, 12, 5), SortThird.sortThird(Arrays.asList(5, 8, -12, 4, 23, 2, 3, 11, 12, -10)));
    }

    @Test
    void testSortThirdEdgeCases() {
        assertEquals(Arrays.asList(2, 8, 3, 4, 6, 9, 5), SortThird.sortThird(Arrays.asList(5, 8, 3, 4, 6, 9, 2)));
        assertEquals(Arrays.asList(2, 6, 9, 4, 8, 3, 5), SortThird.sortThird(Arrays.asList(5, 6, 9, 4, 8, 3, 2)));
        assertEquals(Arrays.asList(2, 6, 3, 4, 8, 9, 5, 1), SortThird.sortThird(Arrays.asList(5, 6, 3, 4, 8, 9, 2, 1)));
    }

    @Test
    void testSortThirdWithEmptyList() {
        assertEquals(Arrays.asList(), SortThird.sortThird(Arrays.asList()));
    }

    @Test
    void testSortThirdWithSingleElement() {
        assertEquals(Arrays.asList(42), SortThird.sortThird(Arrays.asList(42)));
    }

    @Test
    void testSortThirdWithTwoElements() {
        assertEquals(Arrays.asList(1, 2), SortThird.sortThird(Arrays.asList(1, 2)));
    }

    @Test
    void testSortThirdWithThreeElements() {
        assertEquals(Arrays.asList(1, 2, 3), SortThird.sortThird(Arrays.asList(1, 2, 3)));
    }

    @Test
    void testSortThirdWithNegativeNumbers() {
        assertEquals(Arrays.asList(-3, -1, -2), SortThird.sortThird(Arrays.asList(-1, -2, -3)));
    }

    @Test
    void testSortThirdWithDuplicates() {
        assertEquals(Arrays.asList(1, 2, 1, 4, 3, 1), SortThird.sortThird(Arrays.asList(1, 2, 1, 4, 3, 1)));
    }

    @Test
    void testSortThirdWithBoundaryValues() {
        assertEquals(Arrays.asList(0, 1, 2, 3, 4, 5, 6), SortThird.sortThird(Arrays.asList(0, 1, 2, 3, 4, 5, 6)));
        assertEquals(Arrays.asList(-100, -99, -98, -97, -96, -95, -94), SortThird.sortThird(Arrays.asList(-100, -99, -98, -97, -96, -95, -94)));
        assertEquals(Arrays.asList(100, 99, 98, 97, 96, 95, 94), SortThird.sortThird(Arrays.asList(100, 99, 98, 97, 96, 95, 94)));
    }

    @Test
    void testSortThirdWithInvalidInputs() {
        // Assuming invalid inputs are not handled, but we can test with null
        try {
            SortThird.sortThird(null);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }
}