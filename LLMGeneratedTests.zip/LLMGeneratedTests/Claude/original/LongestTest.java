package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class LongestTest {

    @Test
    public void testLongestWithSingleCharacterStrings() {
        List<Object> input = Arrays.asList("a", "b", "c");
        assertEquals("a", Longest.longest(input));
    }

    @Test
    public void testLongestWithDifferentLengthStrings() {
        List<Object> input = Arrays.asList("a", "bb", "ccc");
        assertEquals("ccc", Longest.longest(input));
    }

    @Test
    public void testLongestWithEmptyList() {
        List<Object> input = Collections.emptyList();
        assertNull(Longest.longest(input));
    }

    @Test
    public void testLongestWithSameLengthStrings() {
        List<Object> input = Arrays.asList("x", "y", "z");
        assertEquals("x", Longest.longest(input));
    }

    @Test
    public void testLongestWithMultipleLongestStrings() {
        List<Object> input = Arrays.asList("x", "yyy", "zzzz", "www", "kkkk", "abc");
        assertEquals("zzzz", Longest.longest(input));
    }

    @Test
    public void testLongestWithSingleElementList() {
        List<Object> input = Collections.singletonList("single");
        assertEquals("single", Longest.longest(input));
    }

    @Test
    public void testLongestWithTwoEqualLengthStrings() {
        List<Object> input = Arrays.asList("hi", "ok");
        assertEquals("hi", Longest.longest(input));
    }

    @Test
    public void testLongestWithTwoDifferentLengthStrings() {
        List<Object> input = Arrays.asList("hi", "hello");
        assertEquals("hello", Longest.longest(input));
    }

    @Test
    public void testLongestWithNullElement() {
        List<Object> input = Arrays.asList("hello", null);
        assertEquals("hello", Longest.longest(input));
    }

    @Test
    public void testLongestWithMixedTypes() {
        List<Object> input = Arrays.asList(1, "two", 3.0, "four");
        assertEquals("four", Longest.longest(input));
    }

    @Test
    public void testLongestWithAllNulls() {
        List<Object> input = Arrays.asList(null, null, null);
        assertEquals("null", Longest.longest(input));
    }

    @Test
    public void testLongestWithEmptyStrings() {
        List<Object> input = Arrays.asList("", "", "");
        assertEquals("", Longest.longest(input));
    }

    @Test
    public void testLongestWithSingleEmptyString() {
        List<Object> input = Collections.singletonList("");
        assertEquals("", Longest.longest(input));
    }

    @Test
    public void testLongestWithLongerStringsAtEnd() {
        List<Object> input = Arrays.asList("short", "medium", "longer", "longest");
        assertEquals("longest", Longest.longest(input));
    }

    @Test
    public void testLongestWithStringsOfDifferentTypes() {
        List<Object> input = Arrays.asList("abc", 123, "defgh");
        assertEquals("defgh", Longest.longest(input));
    }

    @Test
    public void testLongestWithOnlyNumbersAsStrings() {
        List<Object> input = Arrays.asList("1", "22", "333");
        assertEquals("333", Longest.longest(input));
    }

    @Test
    public void testLongestWithWhitespaceStrings() {
        List<Object> input = Arrays.asList("   ", "  ", " ");
        assertEquals("   ", Longest.longest(input));
    }

    @Test
    public void testLongestWithSpecialCharacters() {
        List<Object> input = Arrays.asList("!@#", "$%^&*", "12345");
        assertEquals("12345", Longest.longest(input));
    }

    @Test
    public void testLongestWithMixedLengthAndType() {
        List<Object> input = Arrays.asList("short", 12345, "longerString");
        assertEquals("longerString", Longest.longest(input));
    }

    @Test
    public void testLongestWithIdenticalLongestStrings() {
        List<Object> input = Arrays.asList("same", "same");
        assertEquals("same", Longest.longest(input));
    }

    @Test
    public void testLongestWithBoundaryValues() {
        List<Object> input = Arrays.asList("a", "bb", "ccc", "dddd", "eeeee", "ffffff");
        assertEquals("ffffff", Longest.longest(input));
    }

    @Test
    public void testLongestWithNegativeAndZeroLengthStrings() {
        List<Object> input = Arrays.asList("", "a", "bb", "ccc", "dddd");
        assertEquals("dddd", Longest.longest(input));
    }
}