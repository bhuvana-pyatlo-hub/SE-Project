package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StartsOneEndsTest {

    @Test
    void testStartsOneEndsWithOneDigit() {
        assertEquals(1, StartsOneEnds.startsOneEnds(1), "Should return 1 for 1-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithTwoDigits() {
        assertEquals(18, StartsOneEnds.startsOneEnds(2), "Should return 18 for 2-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithThreeDigits() {
        assertEquals(180, StartsOneEnds.startsOneEnds(3), "Should return 180 for 3-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithFourDigits() {
        assertEquals(1800, StartsOneEnds.startsOneEnds(4), "Should return 1800 for 4-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithFiveDigits() {
        assertEquals(18000, StartsOneEnds.startsOneEnds(5), "Should return 18000 for 5-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithSixDigits() {
        assertEquals(180000, StartsOneEnds.startsOneEnds(6), "Should return 180000 for 6-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithSevenDigits() {
        assertEquals(1800000, StartsOneEnds.startsOneEnds(7), "Should return 1800000 for 7-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithEightDigits() {
        assertEquals(18000000, StartsOneEnds.startsOneEnds(8), "Should return 18000000 for 8-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithNineDigits() {
        assertEquals(180000000, StartsOneEnds.startsOneEnds(9), "Should return 180000000 for 9-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithTenDigits() {
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10), "Should return 1800000000 for 10-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithElevenDigits() {
        assertEquals(18000000000L, StartsOneEnds.startsOneEnds(11), "Should return 18000000000 for 11-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithTwelveDigits() {
        assertEquals(180000000000L, StartsOneEnds.startsOneEnds(12), "Should return 180000000000 for 12-digit numbers starting or ending with 1");
    }

    @Test
    void testStartsOneEndsWithZeroDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            StartsOneEnds.startsOneEnds(0);
        }, "Should throw IllegalArgumentException for 0 digits");
    }

    @Test
    void testStartsOneEndsWithNegativeDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            StartsOneEnds.startsOneEnds(-1);
        }, "Should throw IllegalArgumentException for negative digits");
    }

    @Test
    void testStartsOneEndsWithLargeDigitCount() {
        assertThrows(IllegalArgumentException.class, () -> {
            StartsOneEnds.startsOneEnds(1001);
        }, "Should throw IllegalArgumentException for digits greater than 1000");
    }
}