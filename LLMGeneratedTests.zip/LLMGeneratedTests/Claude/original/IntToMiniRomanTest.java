package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IntToMiniRomanTest {

    @Test
    void testIntToMiniRoman_ValidInput_1() {
        assertEquals("i", IntToMiniRoman.intToMiniRoman(1));
    }

    @Test
    void testIntToMiniRoman_ValidInput_4() {
        assertEquals("iv", IntToMiniRoman.intToMiniRoman(4));
    }

    @Test
    void testIntToMiniRoman_ValidInput_5() {
        assertEquals("v", IntToMiniRoman.intToMiniRoman(5));
    }

    @Test
    void testIntToMiniRoman_ValidInput_9() {
        assertEquals("ix", IntToMiniRoman.intToMiniRoman(9));
    }

    @Test
    void testIntToMiniRoman_ValidInput_10() {
        assertEquals("x", IntToMiniRoman.intToMiniRoman(10));
    }

    @Test
    void testIntToMiniRoman_ValidInput_19() {
        assertEquals("xix", IntToMiniRoman.intToMiniRoman(19));
    }

    @Test
    void testIntToMiniRoman_ValidInput_40() {
        assertEquals("xl", IntToMiniRoman.intToMiniRoman(40));
    }

    @Test
    void testIntToMiniRoman_ValidInput_43() {
        assertEquals("xliii", IntToMiniRoman.intToMiniRoman(43));
    }

    @Test
    void testIntToMiniRoman_ValidInput_50() {
        assertEquals("l", IntToMiniRoman.intToMiniRoman(50));
    }

    @Test
    void testIntToMiniRoman_ValidInput_90() {
        assertEquals("xc", IntToMiniRoman.intToMiniRoman(90));
    }

    @Test
    void testIntToMiniRoman_ValidInput_100() {
        assertEquals("c", IntToMiniRoman.intToMiniRoman(100));
    }

    @Test
    void testIntToMiniRoman_ValidInput_152() {
        assertEquals("clii", IntToMiniRoman.intToMiniRoman(152));
    }

    @Test
    void testIntToMiniRoman_ValidInput_251() {
        assertEquals("ccli", IntToMiniRoman.intToMiniRoman(251));
    }

    @Test
    void testIntToMiniRoman_ValidInput_400() {
        assertEquals("cd", IntToMiniRoman.intToMiniRoman(400));
    }

    @Test
    void testIntToMiniRoman_ValidInput_426() {
        assertEquals("cdxxvi", IntToMiniRoman.intToMiniRoman(426));
    }

    @Test
    void testIntToMiniRoman_ValidInput_500() {
        assertEquals("d", IntToMiniRoman.intToMiniRoman(500));
    }

    @Test
    void testIntToMiniRoman_ValidInput_532() {
        assertEquals("dxxxii", IntToMiniRoman.intToMiniRoman(532));
    }

    @Test
    void testIntToMiniRoman_ValidInput_900() {
        assertEquals("cm", IntToMiniRoman.intToMiniRoman(900));
    }

    @Test
    void testIntToMiniRoman_ValidInput_994() {
        assertEquals("cmxciv", IntToMiniRoman.intToMiniRoman(994));
    }

    @Test
    void testIntToMiniRoman_ValidInput_999() {
        assertEquals("cmxcix", IntToMiniRoman.intToMiniRoman(999));
    }

    @Test
    void testIntToMiniRoman_ValidInput_1000() {
        assertEquals("m", IntToMiniRoman.intToMiniRoman(1000));
    }

    @Test
    void testIntToMiniRoman_InvalidInput_Negative() {
        // This test is not applicable as the method does not handle invalid inputs
        // However, we can test the lower boundary
        assertEquals("", IntToMiniRoman.intToMiniRoman(0)); // Assuming we want to see behavior for 0
    }
}