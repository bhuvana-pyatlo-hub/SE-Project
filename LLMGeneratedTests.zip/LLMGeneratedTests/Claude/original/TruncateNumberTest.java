package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TruncateNumberTest {

    @Test
    void testTruncateNumber_PositiveDecimal() {
        assertEquals(0.5, TruncateNumber.truncateNumber(3.5));
    }

    @Test
    void testTruncateNumber_PositiveDecimalWithTwoDecimals() {
        assertEquals(0.33, TruncateNumber.truncateNumber(1.33));
    }

    @Test
    void testTruncateNumber_PositiveDecimalWithThreeDecimals() {
        assertEquals(0.456, TruncateNumber.truncateNumber(123.456));
    }

    @Test
    void testTruncateNumber_Zero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(0.0));
    }

    @Test
    void testTruncateNumber_PositiveInteger() {
        assertEquals(0.0, TruncateNumber.truncateNumber(5.0));
    }

    @Test
    void testTruncateNumber_SmallPositiveDecimal() {
        assertEquals(0.001, TruncateNumber.truncateNumber(0.001));
    }

    @Test
    void testTruncateNumber_BoundaryValue() {
        assertEquals(0.0, TruncateNumber.truncateNumber(1.0));
    }

    @Test
    void testTruncateNumber_ExactInteger() {
        assertEquals(0.0, TruncateNumber.truncateNumber(10.0));
    }

    @Test
    void testTruncateNumber_ExactDecimal() {
        assertEquals(0.5, TruncateNumber.truncateNumber(2.5));
    }

    @Test
    void testTruncateNumber_OneDecimal() {
        assertEquals(0.1, TruncateNumber.truncateNumber(1.1));
    }

    @Test
    void testTruncateNumber_TwoDecimals() {
        assertEquals(0.12, TruncateNumber.truncateNumber(2.12));
    }

    @Test
    void testTruncateNumber_ThreeDecimals() {
        assertEquals(0.123, TruncateNumber.truncateNumber(3.123));
    }

    @Test
    void testTruncateNumber_SmallPositiveDecimalBoundary() {
        assertEquals(0.999, TruncateNumber.truncateNumber(1.999));
    }

    @Test
    void testTruncateNumber_NegativeDecimal() {
        assertThrows(IllegalArgumentException.class, () -> {
            TruncateNumber.truncateNumber(-3.5);
        });
    }

    @Test
    void testTruncateNumber_NegativeInteger() {
        assertThrows(IllegalArgumentException.class, () -> {
            TruncateNumber.truncateNumber(-5.0);
        });
    }

    @Test
    void testTruncateNumber_NegativeSmallDecimal() {
        assertThrows(IllegalArgumentException.class, () -> {
            TruncateNumber.truncateNumber(-0.001);
        });
    }

    @Test
    void testTruncateNumber_NegativeLargeDecimal() {
        assertThrows(IllegalArgumentException.class, () -> {
            TruncateNumber.truncateNumber(-99.999);
        });
    }

    @Test
    void testTruncateNumber_LargeInteger() {
        assertEquals(0.0, TruncateNumber.truncateNumber(100.0));
    }

    @Test
    void testTruncateNumber_ExactZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(0.0));
    }
}