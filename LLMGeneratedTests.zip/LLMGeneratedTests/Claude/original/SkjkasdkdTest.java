package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SkjkasdkdTest {

    @Test
    void testLargestPrimeSum() {
        assertEquals(10, Skjkasdkd.skjkasdkd(Arrays.asList(0, 3, 2, 1, 3, 5, 7, 4, 5, 5, 5, 2, 181, 32, 4, 32, 3, 2, 32, 324, 4, 3)));
        assertEquals(25, Skjkasdkd.skjkasdkd(Arrays.asList(1, 0, 1, 8, 2, 4597, 2, 1, 3, 40, 1, 2, 1, 2, 4, 2, 5, 1)));
        assertEquals(13, Skjkasdkd.skjkasdkd(Arrays.asList(1, 3, 1, 32, 5107, 34, 83278, 109, 163, 23, 2323, 32, 30, 1, 9, 3)));
        assertEquals(11, Skjkasdkd.skjkasdkd(Arrays.asList(0, 724, 32, 71, 99, 32, 6, 0, 5, 91, 83, 0, 5, 6)));
        assertEquals(3, Skjkasdkd.skjkasdkd(Arrays.asList(0, 81, 12, 3, 1, 21)));
        assertEquals(7, Skjkasdkd.skjkasdkd(Arrays.asList(0, 8, 1, 2, 1, 7)));
        assertEquals(19, Skjkasdkd.skjkasdkd(Arrays.asList(8191)));
        assertEquals(19, Skjkasdkd.skjkasdkd(Arrays.asList(8191, 123456, 127, 7)));
        assertEquals(10, Skjkasdkd.skjkasdkd(Arrays.asList(127, 97, 8192)));
    }

    @Test
    void testEmptyList() {
        assertEquals(0, Skjkasdkd.skjkasdkd(Arrays.asList()));
    }

    @Test
    void testNoPrimes() {
        assertEquals(0, Skjkasdkd.skjkasdkd(Arrays.asList(0, 1, 4, 6, 8, 9, 10)));
    }

    @Test
    void testNegativeNumbers() {
        assertEquals(0, Skjkasdkd.skjkasdkd(Arrays.asList(-1, -2, -3, -4, -5)));
    }

    @Test
    void testSinglePrime() {
        assertEquals(2, Skjkasdkd.skjkasdkd(Arrays.asList(2)));
    }

    @Test
    void testSingleNonPrime() {
        assertEquals(0, Skjkasdkd.skjkasdkd(Arrays.asList(4)));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(0, Skjkasdkd.skjkasdkd(Arrays.asList(-100, -99, -98, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -77, -76, -75, -74, -73, -72, -71, -70, -69, -68, -67, -66, -65, -64, -63, -62, -61, -60, -59, -58, -57, -56, -55, -54, -53, -52, -51, -50, -49, -48, -47, -46, -45, -44, -43, -42, -41, -40, -39, -38, -37, -36, -35, -34, -33, -32, -31, -30, -29, -28, -27, -26, -25, -24, -23, -22, -21, -20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1)));
        assertEquals(2, Skjkasdkd.skjkasdkd(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)));
    }

    @Test
    void testMixedValues() {
        assertEquals(5, Skjkasdkd.skjkasdkd(Arrays.asList(-10, -5, 0, 1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97)));
    }
}