package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TriplesSumToZeroTest {

    @Test
    void testTriplesSumToZeroWithNoTripleSums() {
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 3, 5, 0))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 3, 5, -1))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 2, 3, 7))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 2, 5, 7))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 3, 5, -100))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(100, 3, 5, -100))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(-1, -2, -3))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(0, 0, 0))); // not distinct
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 1, 1))); // not distinct
    }

    @Test
    void testTriplesSumToZeroWithValidTriples() {
        assertTrue(TriplesSumToZero.triplesSumToZero(Arrays.asList(1, 3, -2, 1))); // 1 + 3 + (-2) = 0
        assertTrue(TriplesSumToZero.triplesSumToZero(Arrays.asList(2, 4, -5, 3, 9, 7))); // 2 + 4 + (-5) = 0
        assertTrue(TriplesSumToZero.triplesSumToZero(Arrays.asList(-1, 0, 1))); // -1 + 0 + 1 = 0
    }

    @Test
    void testTriplesSumToZeroWithEdgeCases() {
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(1))); // not enough elements
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(-100, 0, 100))); // -100 + 0 + 100 = 0
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(-99, 99, 1))); // no triple sums to zero
        assertFalse(TriplesSumToZero.triplesSumToZero(Arrays.asList(0, 0, 0, 1))); // not distinct
    }
}