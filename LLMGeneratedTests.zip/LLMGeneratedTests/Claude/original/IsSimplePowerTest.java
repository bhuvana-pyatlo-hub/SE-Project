package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsSimplePowerTest {

    @Test
    void testIsSimplePower_WhenXIsOneAndNIsAnyValue_ShouldReturnTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 4));
        assertTrue(IsSimplePower.isSimplePower(1, 2));
        assertTrue(IsSimplePower.isSimplePower(1, 1));
        assertTrue(IsSimplePower.isSimplePower(1, 12));
    }

    @Test
    void testIsSimplePower_WhenNIsOne_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(2, 1));
        assertFalse(IsSimplePower.isSimplePower(3, 1));
        assertFalse(IsSimplePower.isSimplePower(5, 1));
        assertFalse(IsSimplePower.isSimplePower(10, 1));
    }

    @Test
    void testIsSimplePower_WhenXIsPowerOfN_ShouldReturnTrue() {
        assertTrue(IsSimplePower.isSimplePower(4, 2));
        assertTrue(IsSimplePower.isSimplePower(8, 2));
        assertTrue(IsSimplePower.isSimplePower(16, 2));
        assertTrue(IsSimplePower.isSimplePower(9, 3));
        assertTrue(IsSimplePower.isSimplePower(16, 4));
    }

    @Test
    void testIsSimplePower_WhenXIsNotPowerOfN_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(3, 2));
        assertFalse(IsSimplePower.isSimplePower(5, 3));
        assertFalse(IsSimplePower.isSimplePower(24, 2));
        assertFalse(IsSimplePower.isSimplePower(128, 4));
        assertFalse(IsSimplePower.isSimplePower(12, 6));
    }

    @Test
    void testIsSimplePower_WhenXIsLessThanN_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(2, 3));
        assertFalse(IsSimplePower.isSimplePower(3, 4));
        assertFalse(IsSimplePower.isSimplePower(5, 6));
    }

    @Test
    void testIsSimplePower_WhenXIsEqualToN_ShouldReturnTrue() {
        assertTrue(IsSimplePower.isSimplePower(2, 2));
        assertTrue(IsSimplePower.isSimplePower(3, 3));
        assertTrue(IsSimplePower.isSimplePower(5, 5));
    }

    @Test
    void testIsSimplePower_WhenXIsZero_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(0, 2));
        assertFalse(IsSimplePower.isSimplePower(0, 1));
    }


    @Test
    void testIsSimplePower_WhenXIsNegative_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(-1, 2));
        assertFalse(IsSimplePower.isSimplePower(-8, 2));
        assertFalse(IsSimplePower.isSimplePower(-27, 3));
    }

    @Test
    void testIsSimplePower_WhenNIsNegative_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(8, -2));
        assertFalse(IsSimplePower.isSimplePower(27, -3));
    }

    @Test
    void testIsSimplePower_WhenXIsNegativeAndNIsNegative_ShouldReturnFalse() {
        assertFalse(IsSimplePower.isSimplePower(-1, -1));
        assertFalse(IsSimplePower.isSimplePower(-16, -2));
    }
}