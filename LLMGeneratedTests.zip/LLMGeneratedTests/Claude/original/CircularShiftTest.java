package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CircularShiftTest {

    @Test
    void testCircularShiftWithShiftGreaterThanLength() {
        assertEquals("21", CircularShift.circularShift(12, 3)); // shift > length
        assertEquals("11", CircularShift.circularShift(11, 101)); // shift > length
        assertEquals("001", CircularShift.circularShift(100, 5)); // shift > length
        assertEquals("987654321", CircularShift.circularShift(123456789, 10)); // shift > length
    }

    @Test
    void testCircularShiftWithShiftEqualToLength() {
        assertEquals("12", CircularShift.circularShift(12, 2)); // shift == length
        assertEquals("11", CircularShift.circularShift(11, 2)); // shift == length
        assertEquals("123456", CircularShift.circularShift(123456, 6)); // shift == length
    }

    @Test
    void testCircularShiftWithShiftLessThanLength() {
        assertEquals("21", CircularShift.circularShift(12, 1)); // shift < length
        assertEquals("79", CircularShift.circularShift(97, 1)); // shift < length
        assertEquals("001", CircularShift.circularShift(100, 2)); // shift < length
        assertEquals("01", CircularShift.circularShift(10, 1)); // shift < length
        assertEquals("12", CircularShift.circularShift(12, 0)); // shift = 0
        assertEquals("234567", CircularShift.circularShift(123456, 4)); // shift < length
    }

    @Test
    void testCircularShiftWithZeroInput() {
        assertEquals("0", CircularShift.circularShift(0, 1)); // zero input
        assertEquals("0", CircularShift.circularShift(0, 10)); // zero input with shift
        assertEquals("0", CircularShift.circularShift(0, 0)); // zero input with no shift
    }

    @Test
    void testCircularShiftWithNegativeInput() {
        assertEquals("0", CircularShift.circularShift(-1, 1)); // negative input
        assertEquals("0", CircularShift.circularShift(-10, 1)); // negative input
        assertEquals("0", CircularShift.circularShift(-100, 2)); // negative input
    }

    @Test
    void testCircularShiftWithSingleDigitInput() {
        assertEquals("5", CircularShift.circularShift(5, 1)); // single digit
        assertEquals("5", CircularShift.circularShift(5, 2)); // single digit with shift > length
        assertEquals("0", CircularShift.circularShift(0, 1)); // zero single digit
    }

    @Test
    void testCircularShiftWithLargeShift() {
        assertEquals("12", CircularShift.circularShift(12, 100)); // large shift
        assertEquals("21", CircularShift.circularShift(12, 200)); // large shift
        assertEquals("12345", CircularShift.circularShift(12345, 300)); // large shift
    }

    @Test
    void testCircularShiftWithMultipleDigits() {
        assertEquals("34567", CircularShift.circularShift(56734, 2)); // multiple digits
        assertEquals("45673", CircularShift.circularShift(56734, 1)); // multiple digits
        assertEquals("56734", CircularShift.circularShift(56734, 0)); // multiple digits with no shift
        assertEquals("123456789", CircularShift.circularShift(123456789, 0)); // multiple digits with no shift
    }

    @Test
    void testCircularShiftWithBoundaryValues() {
        assertEquals("0", CircularShift.circularShift(0, 0)); // boundary value
        assertEquals("1", CircularShift.circularShift(1, 0)); // boundary value
        assertEquals("1", CircularShift.circularShift(1, 1)); // boundary value
        assertEquals("10", CircularShift.circularShift(10, 1)); // boundary value
        assertEquals("01", CircularShift.circularShift(10, 2)); // boundary value
    }
}