package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TriTest {

    @Test
    void testTriZero() {
        List<Number> result = Tri.tri(0);
        assertEquals(List.of(1), result);
    }

    @Test
    void testTriOne() {
        List<Number> result = Tri.tri(1);
        assertEquals(List.of(1, 3), result);
    }

    @Test
    void testTriTwo() {
        List<Number> result = Tri.tri(2);
        assertEquals(List.of(1, 3, 2.0), result);
    }

    @Test
    void testTriThree() {
        List<Number> result = Tri.tri(3);
        assertEquals(List.of(1, 3, 2.0, 8.0), result);
    }

    @Test
    void testTriFour() {
        List<Number> result = Tri.tri(4);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0), result);
    }

    @Test
    void testTriFive() {
        List<Number> result = Tri.tri(5);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0, 15.0), result);
    }

    @Test
    void testTriSix() {
        List<Number> result = Tri.tri(6);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0), result);
    }

    @Test
    void testTriSeven() {
        List<Number> result = Tri.tri(7);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0), result);
    }

    @Test
    void testTriEight() {
        List<Number> result = Tri.tri(8);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0), result);
    }

    @Test
    void testTriNine() {
        List<Number> result = Tri.tri(9);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0), result);
    }

    @Test
    void testTriTwenty() {
        List<Number> result = Tri.tri(20);
        assertEquals(List.of(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0), result);
    }
}