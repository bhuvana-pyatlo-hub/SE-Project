package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RemoveDuplicatesTest {

    @Test
    void testRemoveDuplicatesWithMultipleDuplicates() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 4);
        List<Object> expected = Arrays.asList(1, 3, 4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithEmptyList() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithNoDuplicates() {
        List<Object> input = Arrays.asList(1, 2, 3, 4);
        List<Object> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithMultipleDifferentDuplicates() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 4, 3, 5);
        List<Object> expected = Arrays.asList(1, 4, 5);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -1, -3, -4);
        List<Object> expected = Arrays.asList(-2, -3, -4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithZero() {
        List<Object> input = Arrays.asList(0, 1, 0, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithAllDuplicates() {
        List<Object> input = Arrays.asList(1, 1, 1, 1);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithSingleElement() {
        List<Object> input = Arrays.asList(42);
        List<Object> expected = Arrays.asList(42);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicatesWithMixedValues() {
        List<Object> input = Arrays.asList(-1, 0, 1, -1, 2, 3);
        List<Object> expected = Arrays.asList(0, 1, 2, 3);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }
}