package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DigitsumTest {

    @Test
    void testDigitSum_EmptyString() {
        assertEquals(0, Digitsum.digitSum(""));
    }

    @Test
    void testDigitSum_NoUppercase() {
        assertEquals(0, Digitsum.digitSum("abcdef"));
    }

    @Test
    void testDigitSum_SingleUppercase() {
        assertEquals(65, Digitsum.digitSum("A")); // ASCII of 'A' is 65
    }

    @Test
    void testDigitSum_MultipleUppercase() {
        assertEquals(131, Digitsum.digitSum("abAB")); // 65 + 66 = 131
    }

    @Test
    void testDigitSum_MixedCase() {
        assertEquals(67, Digitsum.digitSum("abcCd")); // 67 from 'C'
    }

    @Test
    void testDigitSum_UppercaseAtEnd() {
        assertEquals(69, Digitsum.digitSum("helloE")); // 69 from 'E'
    }

    @Test
    void testDigitSum_UppercaseWithLowercase() {
        assertEquals(131, Digitsum.digitSum("woArBld")); // 65 + 66 = 131
    }

    @Test
    void testDigitSum_UppercaseWithMultipleLowercase() {
        assertEquals(153, Digitsum.digitSum("aAaaaXa")); // 65 + 88 = 153
    }

    @Test
    void testDigitSum_SpacesAndUppercase() {
        assertEquals(151, Digitsum.digitSum(" How are yOu?")); // 79 + 72 = 151
    }

    @Test
    void testDigitSum_SentenceWithUppercase() {
        assertEquals(327, Digitsum.digitSum("You arE Very Smart")); // 89 + 69 + 86 + 83 = 327
    }

    @Test
    void testDigitSum_NumbersAndSpecialChars() {
        assertEquals(0, Digitsum.digitSum("12345!@#$%")); // No uppercase letters
    }

    @Test
    void testDigitSum_OnlyUppercase() {
        assertEquals(198, Digitsum.digitSum("ABC")); // 65 + 66 + 67 = 198
    }

    @Test
    void testDigitSum_UppercaseAndSpecialChars() {
        assertEquals(65, Digitsum.digitSum("!@#$%^&*A")); // 65 from 'A'
    }

    @Test
    void testDigitSum_UppercaseWithMixedSpecialChars() {
        assertEquals(131, Digitsum.digitSum("!@#A$%B^")); // 65 + 66 = 131
    }

    @Test
    void testDigitSum_OneUppercaseInLongString() {
        assertEquals(65, Digitsum.digitSum("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")); // Only 'A' contributes
    }

    @Test
    void testDigitSum_UppercaseInMiddle() {
        assertEquals(68, Digitsum.digitSum("abcDefG")); // 68 from 'D'
    }

    @Test
    void testDigitSum_UppercaseWithNumbers() {
        assertEquals(65, Digitsum.digitSum("1234A5678")); // 65 from 'A'
    }

    @Test
    void testDigitSum_UppercaseAndLowercaseMix() {
        assertEquals(131, Digitsum.digitSum("aAAbBcC")); // 65 + 66 = 131
    }

    @Test
    void testDigitSum_OnlySpecialCharacters() {
        assertEquals(0, Digitsum.digitSum("!@#$%^&*()")); // No uppercase letters
    }

    @Test
    void testDigitSum_UppercaseWithSpaces() {
        assertEquals(198, Digitsum.digitSum(" A B C ")); // 65 + 66 + 67 = 198
    }

    @Test
    void testDigitSum_UppercaseWithLeadingSpaces() {
        assertEquals(67, Digitsum.digitSum("  C  ")); // 67 from 'C'
    }

    @Test
    void testDigitSum_UppercaseWithTrailingSpaces() {
        assertEquals(65, Digitsum.digitSum("A  ")); // 65 from 'A'
    }

    @Test
    void testDigitSum_MultipleSpacesOnly() {
        assertEquals(0, Digitsum.digitSum("     ")); // No uppercase letters
    }
}