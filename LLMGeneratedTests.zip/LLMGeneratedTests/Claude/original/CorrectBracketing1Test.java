package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketing1Test {

    @Test
    void testCorrectBracketing_EmptyString() {
        assertTrue(CorrectBracketing1.correctBracketing(""));
    }

    @Test
    void testCorrectBracketing_SingleOpeningBracket() {
        assertFalse(CorrectBracketing1.correctBracketing("("));
    }

    @Test
    void testCorrectBracketing_SingleClosingBracket() {
        assertFalse(CorrectBracketing1.correctBracketing(")"));
    }

    @Test
    void testCorrectBracketing_ValidSimple() {
        assertTrue(CorrectBracketing1.correctBracketing("()"));
    }

    @Test
    void testCorrectBracketing_ValidNested() {
        assertTrue(CorrectBracketing1.correctBracketing("(()())"));
    }

    @Test
    void testCorrectBracketing_ValidMultiple() {
        assertTrue(CorrectBracketing1.correctBracketing("()()(()())()"));
    }

    @Test
    void testCorrectBracketing_ValidComplex() {
        assertTrue(CorrectBracketing1.correctBracketing("()()((()()())())(()()(()))"));
    }

    @Test
    void testCorrectBracketing_InvalidExtraClosing() {
        assertFalse(CorrectBracketing1.correctBracketing("((()())))"));
    }

    @Test
    void testCorrectBracketing_InvalidLeadingClosing() {
        assertFalse(CorrectBracketing1.correctBracketing(")(()"));
    }

    @Test
    void testCorrectBracketing_InvalidUnmatchedOpening() {
        assertFalse(CorrectBracketing1.correctBracketing("(()"));
    }

    @Test
    void testCorrectBracketing_InvalidUnmatchedMultipleOpening() {
        assertFalse(CorrectBracketing1.correctBracketing("(((("));
    }

    @Test
    void testCorrectBracketing_InvalidUnmatchedMultipleClosing() {
        assertFalse(CorrectBracketing1.correctBracketing("())"));
    }

    @Test
    void testCorrectBracketing_InvalidComplex() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())())(()"));
    }

    @Test
    void testCorrectBracketing_InvalidComplexExtraClosing() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())()))()"));
    }

    @Test
    void testCorrectBracketing_ValidMultiplePairs() {
        assertTrue(CorrectBracketing1.correctBracketing("()()"));
    }

    @Test
    void testCorrectBracketing_ValidSinglePair() {
        assertTrue(CorrectBracketing1.correctBracketing("()"));
    }

    @Test
    void testCorrectBracketing_ValidNestedPairs() {
        assertTrue(CorrectBracketing1.correctBracketing("(())"));
    }

    @Test
    void testCorrectBracketing_ValidLongNested() {
        assertTrue(CorrectBracketing1.correctBracketing("(((())))"));
    }

    @Test
    void testCorrectBracketing_InvalidLongUnmatched() {
        assertFalse(CorrectBracketing1.correctBracketing("((((()))))("));
    }

    @Test
    void testCorrectBracketing_InvalidLongUnmatchedClosing() {
        assertFalse(CorrectBracketing1.correctBracketing(")))))"));
    }

    @Test
    void testCorrectBracketing_ValidMixed() {
        assertTrue(CorrectBracketing1.correctBracketing("()(()())"));
    }

    @Test
    void testCorrectBracketing_InvalidMixedExtraClosing() {
        assertFalse(CorrectBracketing1.correctBracketing("()(()())())("));
    }

    @Test
    void testCorrectBracketing_InvalidMixedLeadingClosing() {
        assertFalse(CorrectBracketing1.correctBracketing(")()(()())"));
    }
}