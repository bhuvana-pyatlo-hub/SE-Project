package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TriangleAreaTest {

    @Test
    void testTriangleAreaWithPositiveSmallValues() {
        assertEquals(7.5, TriangleArea.triangleArea(5, 3));
    }

    @Test
    void testTriangleAreaWithEqualSides() {
        assertEquals(2.0, TriangleArea.triangleArea(2, 2));
    }

    @Test
    void testTriangleAreaWithLargerValues() {
        assertEquals(40.0, TriangleArea.triangleArea(10, 8));
    }

    @Test
    void testTriangleAreaWithOneSideZero() {
        assertEquals(0.0, TriangleArea.triangleArea(0, 5));
    }

    @Test
    void testTriangleAreaWithHeightZero() {
        assertEquals(0.0, TriangleArea.triangleArea(5, 0));
    }

    @Test
    void testTriangleAreaWithBothSidesZero() {
        assertEquals(0.0, TriangleArea.triangleArea(0, 0));
    }

    @Test
    void testTriangleAreaWithNegativeSide() {
        assertEquals(-2.0, TriangleArea.triangleArea(-2, 2));
    }

    @Test
    void testTriangleAreaWithNegativeHeight() {
        assertEquals(-2.0, TriangleArea.triangleArea(2, -2));
    }

    @Test
    void testTriangleAreaWithNegativeValues() {
        assertEquals(5.0, TriangleArea.triangleArea(-5, -2));
    }

    @Test
    void testTriangleAreaWithLargeHeightSmallBase() {
        assertEquals(1.0, TriangleArea.triangleArea(2, 4));
    }

    @Test
    void testTriangleAreaWithLargeBaseSmallHeight() {
        assertEquals(10.0, TriangleArea.triangleArea(20, 1));
    }

    @Test
    void testTriangleAreaWithMaxValidInputs() {
        assertEquals(5000.0, TriangleArea.triangleArea(100, 100));
    }

    @Test
    void testTriangleAreaWithMinValidInputs() {
        assertEquals(0.0, TriangleArea.triangleArea(-100, 0));
    }

    @Test
    void testTriangleAreaWithSmallHeight() {
        assertEquals(0.5, TriangleArea.triangleArea(1, 1));
    }

    @Test
    void testTriangleAreaWithSmallBase() {
        assertEquals(0.5, TriangleArea.triangleArea(1, 1));
    }

    @Test
    void testTriangleAreaWithBaseOneHeightOne() {
        assertEquals(0.5, TriangleArea.triangleArea(1, 1));
    }

    @Test
    void testTriangleAreaWithBaseTwoHeightOne() {
        assertEquals(1.0, TriangleArea.triangleArea(2, 1));
    }

    @Test
    void testTriangleAreaWithBaseOneHeightTwo() {
        assertEquals(1.0, TriangleArea.triangleArea(1, 2));
    }

    @Test
    void testTriangleAreaWithBaseThreeHeightThree() {
        assertEquals(4.5, TriangleArea.triangleArea(3, 3));
    }

    @Test
    void testTriangleAreaWithBaseFourHeightFour() {
        assertEquals(8.0, TriangleArea.triangleArea(4, 4));
    }

    @Test
    void testTriangleAreaWithBaseFiveHeightFive() {
        assertEquals(12.5, TriangleArea.triangleArea(5, 5));
    }
}