package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class MultiplyTest {

    @Test
    void testMultiply_PositiveNumbers() {
        assertEquals(16, Multiply.multiply(148, 412)); // 8 * 2
        assertEquals(72, Multiply.multiply(19, 28));   // 9 * 8
        assertEquals(42, Multiply.multiply(76, 67));   // 6 * 7
        assertEquals(49, Multiply.multiply(17, 27));   // 7 * 7
    }

    @Test
    void testMultiply_NegativeNumbers() {
        assertEquals(20, Multiply.multiply(14, -15));  // 4 * 5
        assertEquals(20, Multiply.multiply(-14, 15));  // 4 * 5
        assertEquals(0, Multiply.multiply(-14, -15));  // 4 * 5
    }

    @Test
    void testMultiply_Zero() {
        assertEquals(0, Multiply.multiply(0, 1));      // 0 * 1
        assertEquals(0, Multiply.multiply(0, 0));      // 0 * 0
        assertEquals(0, Multiply.multiply(0, -5));     // 0 * 5
        assertEquals(0, Multiply.multiply(-5, 0));     // 5 * 0
    }

    @Test
    void testMultiply_BoundaryValues() {
        assertEquals(0, Multiply.multiply(2020, 1851)); // 0 * 1
        assertEquals(0, Multiply.multiply(1, 0));       // 1 * 0
        assertEquals(1, Multiply.multiply(1, 1));       // 1 * 1
        assertEquals(9, Multiply.multiply(19, 29));     // 9 * 9
    }

    @Test
    void testMultiply_InvalidInputs() {
        assertEquals(0, Multiply.multiply(100, 0));     // 0 * 0
        assertEquals(0, Multiply.multiply(0, 100));     // 0 * 0
        assertEquals(0, Multiply.multiply(-100, 0));    // 0 * 0
        assertEquals(0, Multiply.multiply(0, -100));    // 0 * 0
    }

    @Test
    void testMultiply_EdgeCases() {
        assertEquals(0, Multiply.multiply(-1, 1));      // 1 * 1
        assertEquals(0, Multiply.multiply(1, -1));      // 1 * 1
        assertEquals(0, Multiply.multiply(-1, -1));     // 1 * 1
        assertEquals(0, Multiply.multiply(-100, -100)); // 0 * 0
    }
}