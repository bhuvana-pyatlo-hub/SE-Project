package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FileNameCheckTest {

    @Test
    void testValidFileNameWithTxtExtension() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("example.txt"));
    }

    @Test
    void testValidFileNameWithExeExtension() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("MY16FILE3.exe"));
    }

    @Test
    void testValidFileNameWithDllExtension() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("K.dll"));
    }

    @Test
    void testFileNameStartsWithDigit() {
        assertEquals("No", FileNameCheck.fileNameCheck("1example.dll"));
    }

    @Test
    void testFileNameWithoutDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("example"));
    }

    @Test
    void testFileNameWithMultipleDots() {
        assertEquals("No", FileNameCheck.fileNameCheck("final..txt"));
    }

    @Test
    void testFileNameWithInvalidExtension() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_valid.wow"));
    }

    @Test
    void testFileNameWithEmptyPrefix() {
        assertEquals("No", FileNameCheck.fileNameCheck(".txt"));
    }

    @Test
    void testFileNameWithEmptySuffix() {
        assertEquals("No", FileNameCheck.fileNameCheck("file."));
    }

    @Test
    void testFileNameWithNoLetters() {
        assertEquals("No", FileNameCheck.fileNameCheck("1234.txt"));
    }

    @Test
    void testFileNameWithMoreThanThreeDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("His12FILE94.exe"));
    }

    @Test
    void testFileNameWithSpecialCharacters() {
        assertEquals("No", FileNameCheck.fileNameCheck("_Y.txt"));
    }

    @Test
    void testFileNameWithLeadingSpecialCharacter() {
        assertEquals("No", FileNameCheck.fileNameCheck("?aREYA.exe"));
    }

    @Test
    void testFileNameWithInvalidSuffix() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_valid.txtexe"));
    }

    @Test
    void testFileNameWithInvalidCharacters() {
        assertEquals("No", FileNameCheck.fileNameCheck("#this2_i4s_5valid.ten"));
    }

    @Test
    void testFileNameWithLeadingSpecialCharacterAndDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("@this1_is6_valid.exe"));
    }

    @Test
    void testFileNameWithDigitsInSuffix() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_12valid.6exe4.txt"));
    }

    @Test
    void testFileNameWithMultipleExtensions() {
        assertEquals("No", FileNameCheck.fileNameCheck("all.exe.txt"));
    }

    @Test
    void testFileNameWithValidCharactersAndDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("I563_No.exe"));
    }

    @Test
    void testFileNameWithValidCharactersAndDigitsInTxt() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("Is3youfault.txt"));
    }

    @Test
    void testFileNameWithValidCharactersAndDll() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("no_one#knows.dll"));
    }

    @Test
    void testFileNameWithLeadingDigitAndValidExtension() {
        assertEquals("No", FileNameCheck.fileNameCheck("1I563_Yes3.exe"));
    }

    @Test
    void testFileNameWithInvalidTxtExtension() {
        assertEquals("No", FileNameCheck.fileNameCheck("I563_Yes3.txtt"));
    }

    @Test
    void testFileNameWithOnlyDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("final132"));
    }

    @Test
    void testFileNameWithSpecialCharacterAtStart() {
        assertEquals("No", FileNameCheck.fileNameCheck("_f4indsartal132."));
    }

    @Test
    void testFileNameWithNoPrefix() {
        assertEquals("No", FileNameCheck.fileNameCheck(".txt"));
    }

    @Test
    void testFileNameWithSingleCharacterPrefix() {
        assertEquals("No", FileNameCheck.fileNameCheck("s."));
    }

    @Test
    void testFileNameWithThreeDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("abc123.txt"));
    }

    @Test
    void testFileNameWithExactlyThreeDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("abc1234.txt"));
    }

    @Test
    void testFileNameWithZeroDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("abc.txt"));
    }

    @Test
    void testFileNameWithNegativeDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("abc-123.txt"));
    }

    @Test
    void testFileNameWithLeadingSpace() {
        assertEquals("No", FileNameCheck.fileNameCheck(" abc.txt"));
    }

    @Test
    void testFileNameWithTrailingSpace() {
        assertEquals("No", FileNameCheck.fileNameCheck("abc.txt "));
    }
}