package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class WordsInSentenceTest {

    @Test
    void testWordsInSentence_EmptyString() {
        assertEquals("", WordsInSentence.wordsInSentence(""));
    }

    @Test
    void testWordsInSentence_SingleWordNotPrime() {
        assertEquals("", WordsInSentence.wordsInSentence("a")); // length 1, not prime
    }

    @Test
    void testWordsInSentence_SingleWordPrime() {
        assertEquals("I", WordsInSentence.wordsInSentence("I")); // length 1, not prime
    }

    @Test
    void testWordsInSentence_TwoWordsBothNotPrime() {
        assertEquals("", WordsInSentence.wordsInSentence("a b")); // lengths 1, 1
    }

    @Test
    void testWordsInSentence_TwoWordsFirstPrimeSecondNotPrime() {
        assertEquals("is", WordsInSentence.wordsInSentence("is a")); // lengths 2, 1
    }

    @Test
    void testWordsInSentence_TwoWordsFirstNotPrimeSecondPrime() {
        assertEquals("go", WordsInSentence.wordsInSentence("a go")); // lengths 1, 2
    }

    @Test
    void testWordsInSentence_TwoWordsBothPrime() {
        assertEquals("go for", WordsInSentence.wordsInSentence("go for")); // lengths 2, 3
    }

    @Test
    void testWordsInSentence_MultipleWordsMixedLengths() {
        assertEquals("is no place", WordsInSentence.wordsInSentence("This is no place available here")); // lengths 4, 2, 2, 5, 7, 4
    }

    @Test
    void testWordsInSentence_AllWordsNotPrime() {
        assertEquals("", WordsInSentence.wordsInSentence("the is a test")); // lengths 3, 2, 1, 4
    }

    @Test
    void testWordsInSentence_AllWordsPrime() {
        assertEquals("Hi am Hussein", WordsInSentence.wordsInSentence("Hi I am Hussein")); // lengths 2, 1, 2, 7
    }

    @Test
    void testWordsInSentence_SentenceWithOnlyOneWordPrime() {
        assertEquals("go", WordsInSentence.wordsInSentence("go")); // length 2
    }

    @Test
    void testWordsInSentence_SentenceWithOnlyOneWordNotPrime() {
        assertEquals("", WordsInSentence.wordsInSentence("a")); // length 1
    }

    @Test
    void testWordsInSentence_SentenceWithSpacesOnly() {
        assertEquals("", WordsInSentence.wordsInSentence("     ")); // spaces only
    }

    @Test
    void testWordsInSentence_SentenceWithMixedWords() {
        assertEquals("is go", WordsInSentence.wordsInSentence("This is a go")); // lengths 4, 2, 1, 2
    }

    @Test
    void testWordsInSentence_SentenceWithLongWords() {
        assertEquals("available", WordsInSentence.wordsInSentence("the available")); // lengths 3, 9
    }

    @Test
    void testWordsInSentence_SentenceWithAllSameLengthWords() {
        assertEquals("the the", WordsInSentence.wordsInSentence("the the")); // lengths 3, 3
    }

    @Test
    void testWordsInSentence_SentenceWithPrimeLengthWords() {
        assertEquals("is", WordsInSentence.wordsInSentence("This is a test")); // lengths 4, 2, 1, 4
    }

    @Test
    void testWordsInSentence_SentenceWithMixedPrimeAndNonPrime() {
        assertEquals("is no", WordsInSentence.wordsInSentence("This is no test")); // lengths 4, 2, 2, 4
    }

    @Test
    void testWordsInSentence_SentenceWithAllWordsLengthOne() {
        assertEquals("", WordsInSentence.wordsInSentence("a b c d e")); // lengths 1, 1, 1, 1, 1
    }

    @Test
    void testWordsInSentence_SentenceWithOneLongWord() {
        assertEquals("", WordsInSentence.wordsInSentence("abcdefghij")); // length 10
    }

    @Test
    void testWordsInSentence_SentenceWithNegativeLengthWords() {
        assertEquals("", WordsInSentence.wordsInSentence("")); // empty input
    }

    @Test
    void testWordsInSentence_SentenceWithZeroLengthWords() {
        assertEquals("", WordsInSentence.wordsInSentence(" ")); // single space
    }
}