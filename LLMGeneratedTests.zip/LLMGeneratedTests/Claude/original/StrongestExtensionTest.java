package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StrongestExtensionTest {

    @Test
    void testStrongestExtensionWithMultipleExtensions() {
        List<String> extensions = Arrays.asList("SErviNGSliCes", "Cheese", "StuFfed");
        assertEquals("Slices.SErviNGSliCes", StrongestExtension.strongestExtension("Slices", extensions));
    }

    @Test
    void testStrongestExtensionWithAllUppercase() {
        List<String> extensions = Collections.singletonList("AA");
        assertEquals("my_class.AA", StrongestExtension.strongestExtension("my_class", extensions));
    }

    @Test
    void testStrongestExtensionWithMixedCase() {
        List<String> extensions = Arrays.asList("tEN", "niNE", "eIGHt8OKe");
        assertEquals("Watashi.eIGHt8OKe", StrongestExtension.strongestExtension("Watashi", extensions));
    }

    @Test
    void testStrongestExtensionWithNumbersAndMixedCase() {
        List<String> extensions = Arrays.asList("nani", "NazeDa", "YEs.WeCaNe", "32145tggg");
        assertEquals("Boku123.YEs.WeCaNe", StrongestExtension.strongestExtension("Boku123", extensions));
    }

    @Test
    void testStrongestExtensionWithAllLowercase() {
        List<String> extensions = Arrays.asList("t", "eMptY", "nothing", "zeR00", "NuLl__", "123NoooneB321");
        assertEquals("__YESIMHERE.NuLl__", StrongestExtension.strongestExtension("__YESIMHERE", extensions));
    }

    @Test
    void testStrongestExtensionWithSingleCharacterClassName() {
        List<String> extensions = Arrays.asList("Ta", "TAR", "t234An", "cosSo");
        assertEquals("K.TAR", StrongestExtension.strongestExtension("K", extensions));
    }

    @Test
    void testStrongestExtensionWithSpecialCharacters() {
        List<String> extensions = Arrays.asList("Tab", "123", "781345", "-_-");
        assertEquals("__HAHA.123", StrongestExtension.strongestExtension("__HAHA", extensions));
    }

    @Test
    void testStrongestExtensionWithLowercaseAndSpecialCharacters() {
        List<String> extensions = Arrays.asList("HhAas", "okIWILL123", "WorkOut", "Fails", "-_-");
        assertEquals("YameRore.okIWILL123", StrongestExtension.strongestExtension("YameRore", extensions));
    }

    @Test
    void testStrongestExtensionWithAllSameStrength() {
        List<String> extensions = Arrays.asList("Die", "NowW", "Wow", "WoW");
        assertEquals("finNNalLLly.WoW", StrongestExtension.strongestExtension("finNNalLLly", extensions));
    }

    @Test
    void testStrongestExtensionWithEmptyExtensionList() {
        List<String> extensions = Collections.emptyList();
        assertEquals("EmptyClass.", StrongestExtension.strongestExtension("EmptyClass", extensions));
    }

    @Test
    void testStrongestExtensionWithSingleExtension() {
        List<String> extensions = Collections.singletonList("OnlyOne");
        assertEquals("SingleClass.OnlyOne", StrongestExtension.strongestExtension("SingleClass", extensions));
    }

    @Test
    void testStrongestExtensionWithAllDigits() {
        List<String> extensions = Collections.singletonList("12345");
        assertEquals("NumberClass.12345", StrongestExtension.strongestExtension("NumberClass", extensions));
    }

    @Test
    void testStrongestExtensionWithMixedDigitsAndLetters() {
        List<String> extensions = Arrays.asList("A1B2C3", "abc123", "XYZ");
        assertEquals("MixedClass.XYZ", StrongestExtension.strongestExtension("MixedClass", extensions));
    }

    @Test
    void testStrongestExtensionWithEmptyClassName() {
        List<String> extensions = Arrays.asList("A", "b");
        assertEquals(".A", StrongestExtension.strongestExtension("", extensions));
    }

    @Test
    void testStrongestExtensionWithNullClassName() {
        List<String> extensions = Arrays.asList("A", "b");
        assertEquals("null.A", StrongestExtension.strongestExtension(null, extensions));
    }

    @Test
    void testStrongestExtensionWithNullExtensions() {
        assertEquals("ClassName.", StrongestExtension.strongestExtension("ClassName", null));
    }

    @Test
    void testStrongestExtensionWithAllUppercaseAndLowercase() {
        List<String> extensions = Arrays.asList("AAA", "bbb", "CcC");
        assertEquals("TestClass.AAA", StrongestExtension.strongestExtension("TestClass", extensions));
    }

    @Test
    void testStrongestExtensionWithNegativeStrength() {
        List<String> extensions = Arrays.asList("abc", "def", "gHI");
        assertEquals("NegativeStrengthClass.gHI", StrongestExtension.strongestExtension("NegativeStrengthClass", extensions));
    }

    @Test
    void testStrongestExtensionWithMixedCaseAndSpecialCharacters() {
        List<String> extensions = Arrays.asList("A@B", "C#D", "E$F");
        assertEquals("SpecialClass.A@B", StrongestExtension.strongestExtension("SpecialClass", extensions));
    }

    @Test
    void testStrongestExtensionWithAllLowercaseAndSpecialCharacters() {
        List<String> extensions = Arrays.asList("abc", "def", "ghi", "123");
        assertEquals("LowercaseClass.123", StrongestExtension.strongestExtension("LowercaseClass", extensions));
    }

    @Test
    void testStrongestExtensionWithBoundaryValues() {
        List<String> extensions = Arrays.asList("A", "b", "C");
        assertEquals("BoundaryClass.C", StrongestExtension.strongestExtension("BoundaryClass", extensions));
    }

    @Test
    void testStrongestExtensionWithNegativeValues() {
        List<String> extensions = Arrays.asList("abc", "def", "GHI");
        assertEquals("NegativeValueClass.GHI", StrongestExtension.strongestExtension("NegativeValueClass", extensions));
    }
}