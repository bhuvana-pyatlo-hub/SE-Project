package original;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class HexKeyTest {

    @Test
    void testHexKeyWithSinglePrimeDigitB() {
        assertEquals(1, HexKey.hexKey("B"));
    }

    @Test
    void testHexKeyWithSingleNonPrimeDigit0() {
        assertEquals(0, HexKey.hexKey("0"));
    }

    @Test
    void testHexKeyWithMultiplePrimes() {
        assertEquals(2, HexKey.hexKey("2357B"));
    }

    @Test
    void testHexKeyWithNoPrimes() {
        assertEquals(0, HexKey.hexKey("014689"));
    }

    @Test
    void testHexKeyWithAllPrimes() {
        assertEquals(6, HexKey.hexKey("2357BD"));
    }

    @Test
    void testHexKeyWithEmptyString() {
        assertEquals(0, HexKey.hexKey(""));
    }

    @Test
    void testHexKeyWithMixedDigits() {
        assertEquals(3, HexKey.hexKey("1234567890BDF"));
    }

    @Test
    void testHexKeyWithOnlyPrimes() {
        assertEquals(4, HexKey.hexKey("B2D3"));
    }

    @Test
    void testHexKeyWithUppercaseLetters() {
        assertEquals(1, HexKey.hexKey("A"));
    }

    @Test
    void testHexKeyWithLowercaseLetters() {
        assertEquals(0, HexKey.hexKey("a"));
    }

    @Test
    void testHexKeyWithHexDigitsAndPrimes() {
        assertEquals(2, HexKey.hexKey("123B5D"));
    }

    @Test
    void testHexKeyWithAllHexDigits() {
        assertEquals(6, HexKey.hexKey("0123456789ABCDEF"));
    }

    @Test
    void testHexKeyWithRepeatedPrimes() {
        assertEquals(4, HexKey.hexKey("2223B5D7"));
    }

    @Test
    void testHexKeyWithNonHexCharacters() {
        assertEquals(0, HexKey.hexKey("GHIJKL"));
    }

    @Test
    void testHexKeyWithLongStringOfHexDigits() {
        assertEquals(12, HexKey.hexKey("112233445566778899AABBCCDDEEFF00"));
    }

    @Test
    void testHexKeyWithSingleDigitPrime() {
        assertEquals(1, HexKey.hexKey("2"));
    }

    @Test
    void testHexKeyWithSingleDigitNonPrime() {
        assertEquals(0, HexKey.hexKey("4"));
    }

    @Test
    void testHexKeyWithMixedValidAndInvalidHex() {
        assertEquals(1, HexKey.hexKey("123G45B"));
    }

    @Test
    void testHexKeyWithAllNonPrimeHexDigits() {
        assertEquals(0, HexKey.hexKey("014689A"));
    }

    @Test
    void testHexKeyWithBoundaryHexDigits() {
        assertEquals(1, HexKey.hexKey("F2"));
    }

    @Test
    void testHexKeyWithOnlyPrimeHexDigits() {
        assertEquals(4, HexKey.hexKey("2357BD"));
    }

    @Test
    void testHexKeyWithNegativeValues() {
        assertEquals(0, HexKey.hexKey("-2"));
    }

    @Test
    void testHexKeyWithZeroValue() {
        assertEquals(0, HexKey.hexKey("0"));
    }

    @Test
    void testHexKeyWithMinimumHexValue() {
        assertEquals(0, HexKey.hexKey("1"));
    }

    @Test
    void testHexKeyWithMaximumHexValue() {
        assertEquals(0, HexKey.hexKey("F"));
    }
}