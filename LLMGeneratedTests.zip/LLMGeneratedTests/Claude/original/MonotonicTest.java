package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class MonotonicTest {

    @Test
    void testSingleElementList() {
        assertTrue(Monotonic.monotonic(Arrays.asList(42)));
    }

    @Test
    void testTwoElementIncreasing() {
        assertTrue(Monotonic.monotonic(Arrays.asList(-100, 0)));
    }

    @Test
    void testTwoElementDecreasing() {
        assertTrue(Monotonic.monotonic(Arrays.asList(100, 0)));
    }

    @Test
    void testTwoElementEqual() {
        assertTrue(Monotonic.monotonic(Arrays.asList(50, 50)));
    }

    @Test
    void testThreeElementIncreasing() {
        assertTrue(Monotonic.monotonic(Arrays.asList(-10, 0, 10)));
    }

    @Test
    void testThreeElementDecreasing() {
        assertTrue(Monotonic.monotonic(Arrays.asList(10, 0, -10)));
    }

    @Test
    void testThreeElementEqual() {
        assertTrue(Monotonic.monotonic(Arrays.asList(5, 5, 5)));
    }

    @Test
    void testThreeElementMixed() {
        assertFalse(Monotonic.monotonic(Arrays.asList(1, 3, 2)));
    }

    @Test
    void testLongIncreasingList() {
        assertTrue(Monotonic.monotonic(Arrays.asList(1, 2, 3, 4, 5, 6)));
    }

    @Test
    void testLongDecreasingList() {
        assertTrue(Monotonic.monotonic(Arrays.asList(6, 5, 4, 3, 2, 1)));
    }

    @Test
    void testLongMixedList() {
        assertFalse(Monotonic.monotonic(Arrays.asList(1, 2, 3, 2, 5)));
    }

    @Test
    void testLongEqualList() {
        assertTrue(Monotonic.monotonic(Arrays.asList(7, 7, 7, 7, 7)));
    }

    @Test
    void testEdgeCaseWithZeros() {
        assertTrue(Monotonic.monotonic(Arrays.asList(0, 0, 0, 0)));
    }

    @Test
    void testEdgeCaseWithNegativeAndPositive() {
        assertFalse(Monotonic.monotonic(Arrays.asList(-1, 0, 1, -1)));
    }

    @Test
    void testEdgeCaseWithSingleNegative() {
        assertTrue(Monotonic.monotonic(Arrays.asList(-50)));
    }

    @Test
    void testEdgeCaseWithEqualAndMixed() {
        assertTrue(Monotonic.monotonic(Arrays.asList(1, 1, 1, 1)));
        assertFalse(Monotonic.monotonic(Arrays.asList(1, 2, 1, 2)));
    }

    @Test
    void testEdgeCaseWithBoundaryValues() {
        assertTrue(Monotonic.monotonic(Arrays.asList(-100, -50, 0, 50, 100)));
        assertTrue(Monotonic.monotonic(Arrays.asList(100, 50, 0, -50, -100)));
        assertFalse(Monotonic.monotonic(Arrays.asList(100, 0, -100, 50)));
    }
}