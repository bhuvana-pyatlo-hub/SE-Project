package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OddCountTest {

    @Test
    void testSingleStringWithOddDigits() {
        List<String> input = Arrays.asList("1234567");
        List<String> expected = Arrays.asList("the number of odd elements 4n the str4ng 4 of the 4nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testMultipleStringsWithMixedOddDigits() {
        List<String> input = Arrays.asList("3", "11111111");
        List<String> expected = Arrays.asList(
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 8n the str8ng 8 of the 8nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testMultipleStringsWithEvenAndOddDigits() {
        List<String> input = Arrays.asList("271", "137", "314");
        List<String> expected = Arrays.asList(
                "the number of odd elements 2n the str2ng 2 of the 2nput.",
                "the number of odd elements 3n the str3ng 3 of the 3nput.",
                "the number of odd elements 2n the str2ng 2 of the 2nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testEmptyStringList() {
        List<String> input = Arrays.asList();
        List<String> expected = Arrays.asList();
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testStringWithNoOddDigits() {
        List<String> input = Arrays.asList("2468");
        List<String> expected = Arrays.asList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testStringWithAllOddDigits() {
        List<String> input = Arrays.asList("13579");
        List<String> expected = Arrays.asList("the number of odd elements 5n the str5ng 5 of the 5nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testStringWithSingleCharacter() {
        List<String> input = Arrays.asList("5");
        List<String> expected = Arrays.asList("the number of odd elements 1n the str1ng 1 of the 1nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testStringWithNegativeDigits() {
        List<String> input = Arrays.asList("-1", "-2", "-3");
        List<String> expected = Arrays.asList(
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testStringWithBoundaryValues() {
        List<String> input = Arrays.asList("0", "1", "2", "9");
        List<String> expected = Arrays.asList(
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void testStringWithLeadingZeros() {
        List<String> input = Arrays.asList("001", "002", "003");
        List<String> expected = Arrays.asList(
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }
}