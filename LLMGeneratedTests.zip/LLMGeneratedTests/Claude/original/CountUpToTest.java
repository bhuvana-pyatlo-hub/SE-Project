package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CountUpToTest {

    @Test
    void testCountUpToZero() {
        assertEquals(List.of(), CountUpTo.countUpTo(0));
    }

    @Test
    void testCountUpToOne() {
        assertEquals(List.of(), CountUpTo.countUpTo(1));
    }

    @Test
    void testCountUpToTwo() {
        assertEquals(List.of(), CountUpTo.countUpTo(2));
    }

    @Test
    void testCountUpToThree() {
        assertEquals(List.of(2), CountUpTo.countUpTo(3));
    }

    @Test
    void testCountUpToFive() {
        assertEquals(List.of(2, 3), CountUpTo.countUpTo(5));
    }

    @Test
    void testCountUpToSix() {
        assertEquals(List.of(2, 3, 5), CountUpTo.countUpTo(6));
    }

    @Test
    void testCountUpToSeven() {
        assertEquals(List.of(2, 3, 5), CountUpTo.countUpTo(7));
    }

    @Test
    void testCountUpToTen() {
        assertEquals(List.of(2, 3, 5, 7), CountUpTo.countUpTo(10));
    }

    @Test
    void testCountUpToEleven() {
        assertEquals(List.of(2, 3, 5, 7), CountUpTo.countUpTo(11));
    }

    @Test
    void testCountUpToTwelve() {
        assertEquals(List.of(2, 3, 5, 7, 11), CountUpTo.countUpTo(12));
    }

    @Test
    void testCountUpToTwenty() {
        assertEquals(List.of(2, 3, 5, 7, 11, 13, 17, 19), CountUpTo.countUpTo(20));
    }

    @Test
    void testCountUpToEighteen() {
        assertEquals(List.of(2, 3, 5, 7, 11, 13, 17), CountUpTo.countUpTo(18));
    }

    @Test
    void testCountUpToFortySeven() {
        assertEquals(List.of(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43), CountUpTo.countUpTo(47));
    }

    @Test
    void testCountUpToOneHundredOne() {
        assertEquals(List.of(2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97), CountUpTo.countUpTo(101));
    }
}