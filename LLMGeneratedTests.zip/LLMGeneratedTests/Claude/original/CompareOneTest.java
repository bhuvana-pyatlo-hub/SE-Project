package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CompareOneTest {

    @Test
    void testCompareOneWithIntegers_LargerFirst() {
        assertEquals(2, CompareOne.compareOne(1, 2));
    }

    @Test
    void testCompareOneWithIntegers_LargerSecond() {
        assertEquals(3, CompareOne.compareOne(2, 3));
    }

    @Test
    void testCompareOneWithFloats_LargerFirst() {
        assertEquals(2.5, CompareOne.compareOne(1, 2.5));
    }

    @Test
    void testCompareOneWithFloats_LargerSecond() {
        assertEquals(6.0, CompareOne.compareOne(5.5, 6));
    }

    @Test
    void testCompareOneWithStringFloats_LargerFirst() {
        assertEquals("2.5", CompareOne.compareOne("1", "2.5"));
    }

    @Test
    void testCompareOneWithStringFloats_LargerSecond() {
        assertEquals("6", CompareOne.compareOne("5.5", "6"));
    }

    @Test
    void testCompareOneWithStringAndFloat_LargerSecond() {
        assertEquals("2.3", CompareOne.compareOne(1, "2.3"));
    }

    @Test
    void testCompareOneWithStringAndFloat_LargerFirst() {
        assertEquals(5, CompareOne.compareOne(5, "2.3"));
    }

    @Test
    void testCompareOneWithEqualIntegers() {
        assertNull(CompareOne.compareOne(1, 1));
    }

    @Test
    void testCompareOneWithEqualFloats() {
        assertNull(CompareOne.compareOne(2.5, 2.5));
    }

    @Test
    void testCompareOneWithEqualStringFloats() {
        assertNull(CompareOne.compareOne("2.5", "2.5"));
    }

    @Test
    void testCompareOneWithEqualMixedTypes() {
        assertNull(CompareOne.compareOne("1", 1));
    }

    @Test
    void testCompareOneWithStringAndInteger_LargerFirst() {
        assertEquals("5.1", CompareOne.compareOne("5.1", 5));
    }

    @Test
    void testCompareOneWithStringAndInteger_LargerSecond() {
        assertEquals(6, CompareOne.compareOne(5, "6"));
    }

    @Test
    void testCompareOneWithStringComma_LargerFirst() {
        assertEquals("6", CompareOne.compareOne("5,1", "6"));
    }

    @Test
    void testCompareOneWithStringComma_LargerSecond() {
        assertEquals("2.3", CompareOne.compareOne("1", "2,3"));
    }

    @Test
    void testCompareOneWithInvalidString() {
        assertThrows(NumberFormatException.class, () -> CompareOne.compareOne("invalid", 1));
    }

    @Test
    void testCompareOneWithNullValues() {
        assertThrows(NullPointerException.class, () -> CompareOne.compareOne(null, 1));
    }

    @Test
    void testCompareOneWithBothNullValues() {
        assertThrows(NullPointerException.class, () -> CompareOne.compareOne(null, null));
    }

    @Test
    void testCompareOneWithNegativeValues() {
        assertEquals(-1, CompareOne.compareOne(-1, -2));
    }

    @Test
    void testCompareOneWithNegativeAndPositive() {
        assertEquals(1, CompareOne.compareOne(-1, 1));
    }

    @Test
    void testCompareOneWithMixedTypesEqual() {
        assertNull(CompareOne.compareOne("1.0", 1.0));
    }

    @Test
    void testCompareOneWithBoundaryValues() {
        assertEquals(100, CompareOne.compareOne(100, 99));
        assertEquals(-100, CompareOne.compareOne(-100, -99));
        assertEquals(0, CompareOne.compareOne(0, 0));
    }

    @Test
    void testCompareOneWithZeroAndNegative() {
        assertEquals(0, CompareOne.compareOne(0, -1));
        assertEquals(-1, CompareOne.compareOne(-1, 0));
    }

    @Test
    void testCompareOneWithZeroAndPositive() {
        assertEquals(1, CompareOne.compareOne(0, 1));
        assertEquals(1, CompareOne.compareOne(1, 0));
    }
}