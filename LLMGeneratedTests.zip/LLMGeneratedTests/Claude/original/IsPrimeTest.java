package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsPrimeTest {

    @Test
    void testIsPrimeWithNegativeNumber() {
        assertFalse(IsPrime.isPrime(-10));
    }

    @Test
    void testIsPrimeWithZero() {
        assertFalse(IsPrime.isPrime(0));
    }

    @Test
    void testIsPrimeWithOne() {
        assertFalse(IsPrime.isPrime(1));
    }

    @Test
    void testIsPrimeWithTwo() {
        assertTrue(IsPrime.isPrime(2));
    }

    @Test
    void testIsPrimeWithThree() {
        assertTrue(IsPrime.isPrime(3));
    }

    @Test
    void testIsPrimeWithFour() {
        assertFalse(IsPrime.isPrime(4));
    }

    @Test
    void testIsPrimeWithFive() {
        assertTrue(IsPrime.isPrime(5));
    }

    @Test
    void testIsPrimeWithSix() {
        assertFalse(IsPrime.isPrime(6));
    }

    @Test
    void testIsPrimeWithSeventeen() {
        assertTrue(IsPrime.isPrime(17));
    }

    @Test
    void testIsPrimeWithEightyFive() {
        assertFalse(IsPrime.isPrime(85));
    }

    @Test
    void testIsPrimeWithSeventySeven() {
        assertFalse(IsPrime.isPrime(77));
    }

    @Test
    void testIsPrimeWithNinetyNine() {
        assertFalse(IsPrime.isPrime(99));
    }

    @Test
    void testIsPrimeWithHundred() {
        assertFalse(IsPrime.isPrime(100));
    }

    @Test
    void testIsPrimeWithPrimeNumber() {
        assertTrue(IsPrime.isPrime(97));
    }

    @Test
    void testIsPrimeWithLargePrimeNumber() {
        assertTrue(IsPrime.isPrime(101));
    }

    @Test
    void testIsPrimeWithBoundaryValue() {
        assertTrue(IsPrime.isPrime(2));
        assertFalse(IsPrime.isPrime(4));
    }

    @Test
    void testIsPrimeWithMinimumNegativeValue() {
        assertFalse(IsPrime.isPrime(-100));
    }

    @Test
    void testIsPrimeWithMinimumPositiveValue() {
        assertFalse(IsPrime.isPrime(1));
    }

    @Test
    void testIsPrimeWithMaximumPositiveValue() {
        assertFalse(IsPrime.isPrime(100));
    }
}