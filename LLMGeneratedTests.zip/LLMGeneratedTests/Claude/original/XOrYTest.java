package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class XOrYTest {

    @Test
    void testXOrY_WhenNIsOne_ReturnsY() {
        assertEquals(0, XOrY.xOrY(1, 2, 0));
    }

    @Test
    void testXOrY_WhenNIsTwo_ReturnsX() {
        assertEquals(2, XOrY.xOrY(2, 2, 0));
    }

    @Test
    void testXOrY_WhenNIsThree_ReturnsX() {
        assertEquals(33, XOrY.xOrY(3, 33, 5212));
    }

    @Test
    void testXOrY_WhenNIsFour_ReturnsY() {
        assertEquals(12, XOrY.xOrY(4, 10, 12));
    }

    @Test
    void testXOrY_WhenNIsFive_ReturnsX() {
        assertEquals(10, XOrY.xOrY(5, 10, 20));
    }

    @Test
    void testXOrY_WhenNIsSix_ReturnsY() {
        assertEquals(100, XOrY.xOrY(6, 50, 100));
    }

    @Test
    void testXOrY_WhenNIsSeven_ReturnsX() {
        assertEquals(50, XOrY.xOrY(7, 50, 100));
    }

    @Test
    void testXOrY_WhenNIsEight_ReturnsY() {
        assertEquals(200, XOrY.xOrY(8, 150, 200));
    }

    @Test
    void testXOrY_WhenNIsNine_ReturnsY() {
        assertEquals(300, XOrY.xOrY(9, 250, 300));
    }

    @Test
    void testXOrY_WhenNIsTen_ReturnsY() {
        assertEquals(400, XOrY.xOrY(10, 350, 400));
    }

    @Test
    void testXOrY_WhenNIsEleven_ReturnsX() {
        assertEquals(450, XOrY.xOrY(11, 450, 500));
    }

    @Test
    void testXOrY_WhenNIsTwelve_ReturnsY() {
        assertEquals(600, XOrY.xOrY(12, 550, 600));
    }

    @Test
    void testXOrY_WhenNIsThirteen_ReturnsX() {
        assertEquals(700, XOrY.xOrY(13, 700, 800));
    }

    @Test
    void testXOrY_WhenNIsFourteen_ReturnsY() {
        assertEquals(900, XOrY.xOrY(14, 850, 900));
    }

    @Test
    void testXOrY_WhenNIsFifteen_ReturnsY() {
        assertEquals(5, XOrY.xOrY(15, 8, 5));
    }

    @Test
    void testXOrY_WhenNIsSixteen_ReturnsY() {
        assertEquals(1234, XOrY.xOrY(16, 34, 1234));
    }

    @Test
    void testXOrY_WhenNIsSeventeen_ReturnsX() {
        assertEquals(34, XOrY.xOrY(17, 34, 12));
    }

    @Test
    void testXOrY_WhenNIsEighteen_ReturnsY() {
        assertEquals(200, XOrY.xOrY(18, 150, 200));
    }

    @Test
    void testXOrY_WhenNIsNineteen_ReturnsX() {
        assertEquals(250, XOrY.xOrY(19, 250, 300));
    }

    @Test
    void testXOrY_WhenNIsTwenty_ReturnsY() {
        assertEquals(400, XOrY.xOrY(20, 350, 400));
    }

    @Test
    void testXOrY_WhenNIsNegativeXAndPrime_ReturnsX() {
        assertEquals(3, XOrY.xOrY(1259, 3, 52));
    }

    @Test
    void testXOrY_WhenNIsNegativeXAndLargePrime_ReturnsX() {
        assertEquals(-1, XOrY.xOrY(7919, -1, 12));
    }

    @Test
    void testXOrY_WhenNIsComposite_ReturnsY() {
        assertEquals(583, XOrY.xOrY(3609, 1245, 583));
    }

    @Test
    void testXOrY_WhenNIsCompositeWithSmallX_ReturnsY() {
        assertEquals(129, XOrY.xOrY(91, 56, 129));
    }

    @Test
    void testXOrY_WhenNIsCompositeWithLargeY_ReturnsY() {
        assertEquals(1234, XOrY.xOrY(6, 34, 1234));
    }
}