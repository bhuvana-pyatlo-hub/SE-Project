package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FlipCaseTest {

    @Test
    void testFlipCaseWithSingleUppercaseCharacter() {
        assertEquals("a", FlipCase.flipCase("A"));
    }

    @Test
    void testFlipCaseWithSingleLowercaseCharacter() {
        assertEquals("A", FlipCase.flipCase("a"));
    }

    @Test
    void testFlipCaseWithMixedCaseString() {
        assertEquals("hELLO", FlipCase.flipCase("Hello"));
    }

    @Test
    void testFlipCaseWithEmptyString() {
        assertEquals("", FlipCase.flipCase(""));
    }

    @Test
    void testFlipCaseWithStringContainingSpecialCharacters() {
        assertEquals("hELLO!", FlipCase.flipCase("Hello!"));
    }

    @Test
    void testFlipCaseWithStringContainingSpaces() {
        assertEquals("tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS", 
                     FlipCase.flipCase("These violent delights have violent ends"));
    }

    @Test
    void testFlipCaseWithAllUppercaseString() {
        assertEquals("lowercase", FlipCase.flipCase("LOWERCASE"));
    }

    @Test
    void testFlipCaseWithAllLowercaseString() {
        assertEquals("UPPERCASE", FlipCase.flipCase("uppercase"));
    }

    @Test
    void testFlipCaseWithStringContainingNumbers() {
        assertEquals("12345", FlipCase.flipCase("12345"));
    }

    @Test
    void testFlipCaseWithStringContainingMixedCharacters() {
        assertEquals("hELLO123", FlipCase.flipCase("Hello123"));
    }

    @Test
    void testFlipCaseWithStringContainingOnlySpecialCharacters() {
        assertEquals("!@#$%", FlipCase.flipCase("!@#$%"));
    }

    @Test
    void testFlipCaseWithStringContainingOnlySpaces() {
        assertEquals("   ", FlipCase.flipCase("   "));
    }

    @Test
    void testFlipCaseWithLongString() {
        assertEquals("tHEQUICKbROWNfOXjUMPSOVERTHELAZYdOG", 
                     FlipCase.flipCase("TheQuickBrownFoxJumpsOverTheLazyDog"));
    }

    @Test
    void testFlipCaseWithSingleCharacterSpecial() {
        assertEquals("!", FlipCase.flipCase("!"));
    }

    @Test
    void testFlipCaseWithSingleCharacterNumber() {
        assertEquals("1", FlipCase.flipCase("1"));
    }

    @Test
    void testFlipCaseWithStringContainingMixedCaseAndSpecialCharacters() {
        assertEquals("hELLO@wORLD!", FlipCase.flipCase("Hello@World!"));
    }

    @Test
    void testFlipCaseWithStringContainingOnlyUppercaseSpecialCharacters() {
        assertEquals("@#$%", FlipCase.flipCase("@#$%"));
    }

    @Test
    void testFlipCaseWithStringContainingOnlyLowercaseSpecialCharacters() {
        assertEquals("!@#$%", FlipCase.flipCase("!@#$%"));
    }

    @Test
    void testFlipCaseWithStringContainingDigitsAndUppercase() {
        assertEquals("1a2B3c", FlipCase.flipCase("1A2b3C"));
    }

    @Test
    void testFlipCaseWithStringContainingDigitsAndLowercase() {
        assertEquals("1A2b3C", FlipCase.flipCase("1a2B3c"));
    }

    @Test
    void testFlipCaseWithStringContainingMixedCaseAndSpaces() {
        assertEquals("hELLO wORLD", FlipCase.flipCase("Hello World"));
    }

    @Test
    void testFlipCaseWithSingleUppercaseCharacterBoundary() {
        assertEquals("a", FlipCase.flipCase("A"));
    }

    @Test
    void testFlipCaseWithSingleLowercaseCharacterBoundary() {
        assertEquals("A", FlipCase.flipCase("a"));
    }

    @Test
    void testFlipCaseWithAllUppercaseBoundary() {
        assertEquals("lowercase", FlipCase.flipCase("LOWERCASE"));
    }

    @Test
    void testFlipCaseWithAllLowercaseBoundary() {
        assertEquals("UPPERCASE", FlipCase.flipCase("uppercase"));
    }
}