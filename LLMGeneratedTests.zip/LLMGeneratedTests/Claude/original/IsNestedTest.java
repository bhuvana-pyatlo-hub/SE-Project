package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsNestedTest {

    @Test
    void testIsNestedWithValidNestedBrackets() {
        assertTrue(IsNested.isNested("[[]]"), "Expected true for nested brackets");
    }

    @Test
    void testIsNestedWithInvalidBracketsTooManyClosing() {
        assertFalse(IsNested.isNested("[]]]]]]][[[[[]"), "Expected false for too many closing brackets");
    }

    @Test
    void testIsNestedWithNoNestedBrackets() {
        assertFalse(IsNested.isNested("[][]"), "Expected false for non-nested brackets");
    }

    @Test
    void testIsNestedWithSinglePairOfBrackets() {
        assertFalse(IsNested.isNested("[]"), "Expected false for single pair of brackets");
    }

    @Test
    void testIsNestedWithValidComplexNestedBrackets() {
        assertTrue(IsNested.isNested("[[[[]]]]"), "Expected true for complex nested brackets");
    }

    @Test
    void testIsNestedWithExcessClosingBrackets() {
        assertFalse(IsNested.isNested("[]]]]]]]]]"), "Expected false for excess closing brackets");
    }

    @Test
    void testIsNestedWithValidMultipleNestedBrackets() {
        assertTrue(IsNested.isNested("[][][[]]"), "Expected true for multiple nested brackets");
    }

    @Test
    void testIsNestedWithUnmatchedOpeningBracket() {
        assertFalse(IsNested.isNested("[[]"), "Expected false for unmatched opening bracket");
    }

    @Test
    void testIsNestedWithUnmatchedClosingBracket() {
        assertFalse(IsNested.isNested("[]]"), "Expected false for unmatched closing bracket");
    }

    @Test
    void testIsNestedWithValidNestedBracketsAtEnd() {
        assertTrue(IsNested.isNested("[[]][["), "Expected true for nested brackets at the end");
    }

    @Test
    void testIsNestedWithValidNestedBracketsInMiddle() {
        assertTrue(IsNested.isNested("[[][]]"), "Expected true for nested brackets in the middle");
    }

    @Test
    void testIsNestedWithEmptyString() {
        assertFalse(IsNested.isNested(""), "Expected false for empty string");
    }

    @Test
    void testIsNestedWithOnlyOpeningBrackets() {
        assertFalse(IsNested.isNested("[[[[[[[["), "Expected false for only opening brackets");
    }

    @Test
    void testIsNestedWithOnlyClosingBrackets() {
        assertFalse(IsNested.isNested("]]]]]]]]"), "Expected false for only closing brackets");
    }

    @Test
    void testIsNestedWithMultipleNestedBrackets() {
        assertTrue(IsNested.isNested("[[[]]]"), "Expected true for multiple nested brackets");
    }

    @Test
    void testIsNestedWithNestedBracketsFollowedByNonNested() {
        assertTrue(IsNested.isNested("[[]][]"), "Expected true for nested followed by non-nested");
    }

    @Test
    void testIsNestedWithNonNestedBracketsFollowedByNested() {
        assertTrue(IsNested.isNested("[][][[]]"), "Expected true for non-nested followed by nested");
    }

    @Test
    void testIsNestedWithValidNestedBracketsMixed() {
        assertTrue(IsNested.isNested("[[[]]][[[]]]"), "Expected true for mixed nested brackets");
    }

    @Test
    void testIsNestedWithInvalidMixedBrackets() {
        assertFalse(IsNested.isNested("[]][[]"), "Expected false for invalid mixed brackets");
    }

    @Test
    void testIsNestedWithValidNestedBracketsWithExtra() {
        assertTrue(IsNested.isNested("[[[[]]]][[]]"), "Expected true for valid nested with extra");
    }

    @Test
    void testIsNestedWithSingleNestedBracket() {
        assertFalse(IsNested.isNested("[[]]"), "Expected false for single nested bracket");
    }
}