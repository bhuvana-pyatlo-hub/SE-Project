package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MinsubarraysumTest {

    @Test
    void testPositiveNumbers() {
        assertEquals(1, Minsubarraysum.minsubarraysum(Arrays.asList(2, 3, 4, 1, 2, 4)));
    }

    @Test
    void testAllNegativeNumbers() {
        assertEquals(-6, Minsubarraysum.minsubarraysum(Arrays.asList(-1, -2, -3)));
    }

    @Test
    void testMixedNumbers() {
        assertEquals(-14, Minsubarraysum.minsubarraysum(Arrays.asList(-1, -2, -3, 2, -10)));
        assertEquals(-6, Minsubarraysum.minsubarraysum(Arrays.asList(100, -1, -2, -3, 10, -5)));
        assertEquals(-6, Minsubarraysum.minsubarraysum(Arrays.asList(-1, -2, -3, 10, -5)));
    }

    @Test
    void testZeroInArray() {
        assertEquals(0, Minsubarraysum.minsubarraysum(Arrays.asList(0, 10, 20, 0)));
    }

    @Test
    void testSingleNegativeNumber() {
        assertEquals(-10, Minsubarraysum.minsubarraysum(Arrays.asList(-10)));
    }

    @Test
    void testSinglePositiveNumber() {
        assertEquals(7, Minsubarraysum.minsubarraysum(Arrays.asList(7)));
    }

    @Test
    void testTwoNumbersWithNegativeResult() {
        assertEquals(-1, Minsubarraysum.minsubarraysum(Arrays.asList(1, -1)));
    }

    @Test
    void testEdgeCaseWithLargeNegative() {
        assertEquals(-33, Minsubarraysum.minsubarraysum(Arrays.asList(100, -33, 32, -1, 0, -2)));
    }

    @Test
    void testEdgeCaseWithOnlyOneElement() {
        assertEquals(-1, Minsubarraysum.minsubarraysum(Arrays.asList(-1)));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(-1, Minsubarraysum.minsubarraysum(Arrays.asList(-1, 1)));
        assertEquals(0, Minsubarraysum.minsubarraysum(Arrays.asList(0, 0)));
        assertEquals(-100, Minsubarraysum.minsubarraysum(Arrays.asList(-100)));
        assertEquals(100, Minsubarraysum.minsubarraysum(Arrays.asList(100)));
    }

    @Test
    void testInvalidInputs() {
        assertEquals(-1, Minsubarraysum.minsubarraysum(Arrays.asList("invalid", 1)));
        assertEquals(-1, Minsubarraysum.minsubarraysum(Arrays.asList(1, null)));
    }
}