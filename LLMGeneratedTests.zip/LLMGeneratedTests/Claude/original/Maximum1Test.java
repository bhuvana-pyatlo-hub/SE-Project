package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Maximum1Test {

    @Test
    void testMaximumWithAllNegativeNumbers() {
        List<Integer> arr = Arrays.asList(-3, -4, -5);
        int k = 2;
        List<Object> expected = Arrays.asList(-4, -3);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithMixedNumbers() {
        List<Integer> arr = Arrays.asList(4, -4, 4);
        int k = 2;
        List<Object> expected = Arrays.asList(4, 4);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithSingleElement() {
        List<Integer> arr = Arrays.asList(2);
        int k = 1;
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithAllPositiveNumbers() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 3;
        List<Object> expected = Arrays.asList(3, 4, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithZeroK() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 0;
        List<Object> expected = Arrays.asList();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithKEqualToArrayLength() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 3;
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithMoreElementsThanK() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 2;
        List<Object> expected = Arrays.asList(4, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithNegativeAndPositiveNumbers() {
        List<Integer> arr = Arrays.asList(-1, 0, 2, 5, 3);
        int k = 2;
        List<Object> expected = Arrays.asList(3, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithAllSameElements() {
        List<Integer> arr = Arrays.asList(7, 7, 7, 7);
        int k = 3;
        List<Object> expected = Arrays.asList(7, 7, 7);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithEmptyArray() {
        List<Integer> arr = Arrays.asList();
        int k = 0;
        List<Object> expected = Arrays.asList();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithNegativeValuesOnly() {
        List<Integer> arr = Arrays.asList(-10, -20, -30, -5);
        int k = 2;
        List<Object> expected = Arrays.asList(-10, -5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithBoundaryValues() {
        List<Integer> arr = Arrays.asList(-100, 0, 100);
        int k = 2;
        List<Object> expected = Arrays.asList(0, 100);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void testMaximumWithKGreaterThanArrayLength() {
        List<Integer> arr = Arrays.asList(1, 2);
        int k = 3;
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }
}