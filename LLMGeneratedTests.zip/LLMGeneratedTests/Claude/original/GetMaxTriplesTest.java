package original;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class GetMaxTriplesTest {

    @Test
    void testGetMaxTriplesWithMinimumInput() {
        // Test with n = 1 (edge case)
        assertEquals(0, GetMaxTriples.getMaxTriples(1));
    }

    @Test
    void testGetMaxTriplesWithTwoInputs() {
        // Test with n = 2 (edge case)
        assertEquals(0, GetMaxTriples.getMaxTriples(2));
    }

    @Test
    void testGetMaxTriplesWithThreeInputs() {
        // Test with n = 3 (edge case)
        assertEquals(0, GetMaxTriples.getMaxTriples(3));
    }

    @Test
    void testGetMaxTriplesWithFourInputs() {
        // Test with n = 4 (edge case)
        assertEquals(0, GetMaxTriples.getMaxTriples(4));
    }

    @Test
    void testGetMaxTriplesWithFiveInputs() {
        // Test with n = 5 (normal case)
        assertEquals(1, GetMaxTriples.getMaxTriples(5));
    }

    @Test
    void testGetMaxTriplesWithSixInputs() {
        // Test with n = 6 (normal case)
        assertEquals(4, GetMaxTriples.getMaxTriples(6));
    }

    @Test
    void testGetMaxTriplesWithSevenInputs() {
        // Test with n = 7 (normal case)
        assertEquals(10, GetMaxTriples.getMaxTriples(7));
    }

    @Test
    void testGetMaxTriplesWithEightInputs() {
        // Test with n = 8 (normal case)
        assertEquals(20, GetMaxTriples.getMaxTriples(8));
    }

    @Test
    void testGetMaxTriplesWithNineInputs() {
        // Test with n = 9 (normal case)
        assertEquals(35, GetMaxTriples.getMaxTriples(9));
    }

    @Test
    void testGetMaxTriplesWithTenInputs() {
        // Test with n = 10 (normal case)
        assertEquals(36, GetMaxTriples.getMaxTriples(10));
    }

    @Test
    void testGetMaxTriplesWithElevenInputs() {
        // Test with n = 11 (normal case)
        assertEquals(56, GetMaxTriples.getMaxTriples(11));
    }

    @Test
    void testGetMaxTriplesWithTwelveInputs() {
        // Test with n = 12 (normal case)
        assertEquals(84, GetMaxTriples.getMaxTriples(12));
    }

    @Test
    void testGetMaxTriplesWithThirteenInputs() {
        // Test with n = 13 (normal case)
        assertEquals(120, GetMaxTriples.getMaxTriples(13));
    }

    @Test
    void testGetMaxTriplesWithFourteenInputs() {
        // Test with n = 14 (normal case)
        assertEquals(164, GetMaxTriples.getMaxTriples(14));
    }

    @Test
    void testGetMaxTriplesWithFifteenInputs() {
        // Test with n = 15 (normal case)
        assertEquals(220, GetMaxTriples.getMaxTriples(15));
    }

    @Test
    void testGetMaxTriplesWithSixteenInputs() {
        // Test with n = 16 (normal case)
        assertEquals(288, GetMaxTriples.getMaxTriples(16));
    }

    @Test
    void testGetMaxTriplesWithSeventeenInputs() {
        // Test with n = 17 (normal case)
        assertEquals(370, GetMaxTriples.getMaxTriples(17));
    }

    @Test
    void testGetMaxTriplesWithEighteenInputs() {
        // Test with n = 18 (normal case)
        assertEquals(468, GetMaxTriples.getMaxTriples(18));
    }

    @Test
    void testGetMaxTriplesWithNineteenInputs() {
        // Test with n = 19 (normal case)
        assertEquals(588, GetMaxTriples.getMaxTriples(19));
    }

    @Test
    void testGetMaxTriplesWithTwentyInputs() {
        // Test with n = 20 (normal case)
        assertEquals(720, GetMaxTriples.getMaxTriples(20));
    }

    @Test
    void testGetMaxTriplesWithTwentyOneInputs() {
        // Test with n = 21 (normal case)
        assertEquals(864, GetMaxTriples.getMaxTriples(21));
    }

    @Test
    void testGetMaxTriplesWithTwentyTwoInputs() {
        // Test with n = 22 (normal case)
        assertEquals(1020, GetMaxTriples.getMaxTriples(22));
    }

    @Test
    void testGetMaxTriplesWithTwentyThreeInputs() {
        // Test with n = 23 (normal case)
        assertEquals(1188, GetMaxTriples.getMaxTriples(23));
    }

    @Test
    void testGetMaxTriplesWithTwentyFourInputs() {
        // Test with n = 24 (normal case)
        assertEquals(1368, GetMaxTriples.getMaxTriples(24));
    }

    @Test
    void testGetMaxTriplesWithTwentyFiveInputs() {
        // Test with n = 25 (normal case)
        assertEquals(1560, GetMaxTriples.getMaxTriples(25));
    }

    @Test
    void testGetMaxTriplesWithTwentySixInputs() {
        // Test with n = 26 (normal case)
        assertEquals(1764, GetMaxTriples.getMaxTriples(26));
    }

    @Test
    void testGetMaxTriplesWithTwentySevenInputs() {
        // Test with n = 27 (normal case)
        assertEquals(1980, GetMaxTriples.getMaxTriples(27));
    }

    @Test
    void testGetMaxTriplesWithTwentyEightInputs() {
        // Test with n = 28 (normal case)
        assertEquals(2208, GetMaxTriples.getMaxTriples(28));
    }

    @Test
    void testGetMaxTriplesWithTwentyNineInputs() {
        // Test with n = 29 (normal case)
        assertEquals(2448, GetMaxTriples.getMaxTriples(29));
    }

    @Test
    void testGetMaxTriplesWithThirtyInputs() {
        // Test with n = 30 (normal case)
        assertEquals(2700, GetMaxTriples.getMaxTriples(30));
    }

}