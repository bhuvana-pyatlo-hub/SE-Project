package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FibTest {

    @Test
    void testFibWithNegative() {
        assertThrows(IllegalArgumentException.class, () -> Fib.fib(-1)); // Invalid input: negative number
    }

    @Test
    void testFibWithZero() {
        assertEquals(1, Fib.fib(0)); // Edge case: fib(0) should return 1
    }

    @Test
    void testFibWithOne() {
        assertEquals(1, Fib.fib(1)); // Base case: fib(1) should return 1
    }

    @Test
    void testFibWithTwo() {
        assertEquals(1, Fib.fib(2)); // Base case: fib(2) should return 1
    }

    @Test
    void testFibWithThree() {
        assertEquals(2, Fib.fib(3)); // fib(3) should return 2
    }

    @Test
    void testFibWithFour() {
        assertEquals(3, Fib.fib(4)); // fib(4) should return 3
    }

    @Test
    void testFibWithFive() {
        assertEquals(5, Fib.fib(5)); // fib(5) should return 5
    }

    @Test
    void testFibWithSix() {
        assertEquals(8, Fib.fib(6)); // fib(6) should return 8
    }

    @Test
    void testFibWithSeven() {
        assertEquals(13, Fib.fib(7)); // fib(7) should return 13
    }

    @Test
    void testFibWithEight() {
        assertEquals(21, Fib.fib(8)); // fib(8) should return 21
    }

    @Test
    void testFibWithNine() {
        assertEquals(34, Fib.fib(9)); // fib(9) should return 34
    }

    @Test
    void testFibWithTen() {
        assertEquals(55, Fib.fib(10)); // fib(10) should return 55
    }

    @Test
    void testFibWithEleven() {
        assertEquals(89, Fib.fib(11)); // fib(11) should return 89
    }

    @Test
    void testFibWithTwelve() {
        assertEquals(144, Fib.fib(12)); // fib(12) should return 144
    }

    @Test
    void testFibWithThirteen() {
        assertEquals(233, Fib.fib(13)); // fib(13) should return 233
    }

    @Test
    void testFibWithFourteen() {
        assertEquals(377, Fib.fib(14)); // fib(14) should return 377
    }

    @Test
    void testFibWithFifteen() {
        assertEquals(610, Fib.fib(15)); // fib(15) should return 610
    }

    @Test
    void testFibWithSixteen() {
        assertEquals(987, Fib.fib(16)); // fib(16) should return 987
    }

    @Test
    void testFibWithSeventeen() {
        assertEquals(1597, Fib.fib(17)); // fib(17) should return 1597
    }

    @Test
    void testFibWithEighteen() {
        assertEquals(2584, Fib.fib(18)); // fib(18) should return 2584
    }

    @Test
    void testFibWithNineteen() {
        assertEquals(4181, Fib.fib(19)); // fib(19) should return 4181
    }

    @Test
    void testFibWithTwenty() {
        assertEquals(6765, Fib.fib(20)); // fib(20) should return 6765
    }

    @Test
    void testFibWithTwentyOne() {
        assertEquals(10946, Fib.fib(21)); // fib(21) should return 10946
    }

    @Test
    void testFibWithTwentyTwo() {
        assertEquals(17711, Fib.fib(22)); // fib(22) should return 17711
    }

    @Test
    void testFibWithTwentyThree() {
        assertEquals(28657, Fib.fib(23)); // fib(23) should return 28657
    }

    @Test
    void testFibWithTwentyFour() {
        assertEquals(46368, Fib.fib(24)); // fib(24) should return 46368
    }

    @Test
    void testFibWithTwentyFive() {
        assertEquals(75025, Fib.fib(25)); // fib(25) should return 75025
    }
}