package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SplitWordsTest {

    @Test
    void testSplitWordsWithSpaces() {
        assertEquals(List.of("Hello", "world!"), SplitWords.splitWords("Hello world!"));
        assertEquals(List.of("Hello", "world!"), SplitWords.splitWords("Hello   world!"));
        assertEquals(List.of("Hello", "world,!"), SplitWords.splitWords("Hello world,!"));
        assertEquals(List.of("Hello", "world", "test"), SplitWords.splitWords("Hello world test"));
    }

    @Test
    void testSplitWordsWithCommas() {
        assertEquals(List.of("Hello", "world!"), SplitWords.splitWords("Hello,world!"));
        assertEquals(List.of("Hello,Hello,world", "!"), SplitWords.splitWords("Hello,Hello,world !"));
        assertEquals(List.of("Hello", "world", "test"), SplitWords.splitWords("Hello,world,test"));
        assertEquals(List.of("Hello", "world", "test"), SplitWords.splitWords("Hello, world, test"));
    }

    @Test
    void testSplitWordsWithNoSeparators() {
        assertEquals(3, SplitWords.splitWords("abcdef"));
        assertEquals(2, SplitWords.splitWords("aaabb"));
        assertEquals(1, SplitWords.splitWords("aaaBb"));
        assertEquals(0, SplitWords.splitWords(""));
        assertEquals(0, SplitWords.splitWords("ABCDEF"));
        assertEquals(0, SplitWords.splitWords("12345"));
        assertEquals(0, SplitWords.splitWords("!@#$%"));
        assertEquals(0, SplitWords.splitWords("123abc"));
        assertEquals(0, SplitWords.splitWords("A"));
        assertEquals(0, SplitWords.splitWords("B"));
        assertEquals(1, SplitWords.splitWords("a"));
        assertEquals(1, SplitWords.splitWords("c"));
        assertEquals(1, SplitWords.splitWords("e"));
        assertEquals(1, SplitWords.splitWords("g"));
        assertEquals(1, SplitWords.splitWords("i"));
        assertEquals(1, SplitWords.splitWords("k"));
        assertEquals(1, SplitWords.splitWords("m"));
        assertEquals(1, SplitWords.splitWords("o"));
        assertEquals(1, SplitWords.splitWords("q"));
        assertEquals(1, SplitWords.splitWords("s"));
        assertEquals(1, SplitWords.splitWords("u"));
        assertEquals(1, SplitWords.splitWords("w"));
        assertEquals(1, SplitWords.splitWords("y"));
    }
}