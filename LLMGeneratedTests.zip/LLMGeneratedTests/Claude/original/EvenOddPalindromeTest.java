package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EvenOddPalindromeTest {

    @Test
    void testEvenOddPalindrome() {
        assertEquals(List.of(0, 1), EvenOddPalindrome.evenOddPalindrome(1)); // Edge case: n = 1
        assertEquals(List.of(0, 0), EvenOddPalindrome.evenOddPalindrome(0)); // Invalid input: n = 0
        assertEquals(List.of(0, 0), EvenOddPalindrome.evenOddPalindrome(-1)); // Invalid input: n = -1
        assertEquals(List.of(1, 2), EvenOddPalindrome.evenOddPalindrome(3)); // Basic case: n = 3
        assertEquals(List.of(4, 6), EvenOddPalindrome.evenOddPalindrome(12)); // Basic case: n = 12
        assertEquals(List.of(5, 6), EvenOddPalindrome.evenOddPalindrome(25)); // Basic case: n = 25
        assertEquals(List.of(6, 8), EvenOddPalindrome.evenOddPalindrome(63)); // Basic case: n = 63
        assertEquals(List.of(8, 13), EvenOddPalindrome.evenOddPalindrome(123)); // Basic case: n = 123
        assertEquals(List.of(4, 5), EvenOddPalindrome.evenOddPalindrome(9)); // Basic case: n = 9
        assertEquals(List.of(4, 6), EvenOddPalindrome.evenOddPalindrome(19)); // Basic case: n = 19
        assertEquals(List.of(5, 5), EvenOddPalindrome.evenOddPalindrome(11)); // Edge case: n = 11
        assertEquals(List.of(1, 0), EvenOddPalindrome.evenOddPalindrome(2)); // Edge case: n = 2
        assertEquals(List.of(0, 0), EvenOddPalindrome.evenOddPalindrome(-100)); // Invalid input: n = -100
        assertEquals(List.of(0, 0), EvenOddPalindrome.evenOddPalindrome(100)); // Upper boundary case: n = 100
    }

    @Test
    void testIsPalindrome() {
        assertEquals(true, EvenOddPalindrome.isPalindrome(121)); // Palindrome
        assertEquals(false, EvenOddPalindrome.isPalindrome(123)); // Not a palindrome
        assertEquals(true, EvenOddPalindrome.isPalindrome(0)); // Edge case: palindrome
        assertEquals(true, EvenOddPalindrome.isPalindrome(1)); // Single digit palindrome
        assertEquals(false, EvenOddPalindrome.isPalindrome(-121)); // Negative number
        assertEquals(true, EvenOddPalindrome.isPalindrome(22)); // Even digit palindrome
        assertEquals(false, EvenOddPalindrome.isPalindrome(10)); // Not a palindrome
    }
}