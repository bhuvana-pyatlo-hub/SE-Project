package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class StringXorTest {

    @Test
    void testStringXorWithEqualStrings() {
        assertEquals("0", StringXor.stringXor("1", "1"));
    }

    @Test
    void testStringXorWithDifferentSingleBits() {
        assertEquals("1", StringXor.stringXor("1", "0"));
    }

    @Test
    void testStringXorWithDifferentSingleBitsReversed() {
        assertEquals("1", StringXor.stringXor("0", "1"));
    }

    @Test
    void testStringXorWithAllZeros() {
        assertEquals("0000", StringXor.stringXor("0000", "0000"));
    }

    @Test
    void testStringXorWithAllOnes() {
        assertEquals("0000", StringXor.stringXor("1111", "1111"));
    }

    @Test
    void testStringXorWithMixedBits() {
        assertEquals("100", StringXor.stringXor("010", "110"));
    }

    @Test
    void testStringXorWithLongerStrings() {
        assertEquals("010010", StringXor.stringXor("111000", "101010"));
    }

    @Test
    void testStringXorWithEmptyStrings() {
        assertEquals("", StringXor.stringXor("", ""));
    }

    @Test
    void testStringXorWithDifferentLengths() {
        assertEquals("1", StringXor.stringXor("1", "0"));
        assertEquals("1", StringXor.stringXor("0", "1"));
    }

    @Test
    void testStringXorWithMixedLengthStrings() {
        assertEquals("1", StringXor.stringXor("1", ""));
        assertEquals("1", StringXor.stringXor("", "1"));
    }

    @Test
    void testStringXorWithAllZerosAndOnes() {
        assertEquals("1111", StringXor.stringXor("0000", "1111"));
    }

    @Test
    void testStringXorWithAllOnesAndZeros() {
        assertEquals("1111", StringXor.stringXor("1111", "0000"));
    }

    @Test
    void testStringXorWithAlternatingBits() {
        assertEquals("1111", StringXor.stringXor("0101", "1010"));
        assertEquals("1111", StringXor.stringXor("1010", "0101"));
    }

    @Test
    void testStringXorWithSingleBitZeroAndOne() {
        assertEquals("1", StringXor.stringXor("0", "1"));
    }

    @Test
    void testStringXorWithSingleBitOneAndZero() {
        assertEquals("1", StringXor.stringXor("1", "0"));
    }

    @Test
    void testStringXorWithAllZerosAndMixed() {
        assertEquals("0101", StringXor.stringXor("0101", "0000"));
    }

    @Test
    void testStringXorWithMixedAndAllOnes() {
        assertEquals("0101", StringXor.stringXor("0101", "1111"));
    }

    @Test
    void testStringXorWithEmptyAndSingleBitString() {
        assertEquals("1", StringXor.stringXor("", "1"));
    }

    @Test
    void testStringXorWithSingleBitAndEmptyString() {
        assertEquals("1", StringXor.stringXor("1", ""));
    }

    @Test
    void testStringXorWithLongerAlternatingBits() {
        assertEquals("101010", StringXor.stringXor("111000", "010010"));
    }
}