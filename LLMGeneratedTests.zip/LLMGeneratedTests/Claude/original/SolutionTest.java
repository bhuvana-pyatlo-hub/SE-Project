package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SolutionTest {

    @Test
    void testBasicCases() {
        assertEquals(12, Solution.solution(Arrays.asList(5, 8, 7, 1)));
        assertEquals(9, Solution.solution(Arrays.asList(3, 3, 3, 3, 3)));
        assertEquals(0, Solution.solution(Arrays.asList(30, 13, 24, 321)));
        assertEquals(5, Solution.solution(Arrays.asList(5, 9)));
        assertEquals(0, Solution.solution(Arrays.asList(2, 4, 8)));
        assertEquals(23, Solution.solution(Arrays.asList(30, 13, 23, 32)));
        assertEquals(3, Solution.solution(Arrays.asList(3, 13, 2, 9)));
    }

    @Test
    void testEdgeCases() {
        assertEquals(0, Solution.solution(Collections.emptyList()));
        assertEquals(0, Solution.solution(Arrays.asList(2)));
        assertEquals(5, Solution.solution(Arrays.asList(5)));
        assertEquals(0, Solution.solution(Arrays.asList(4)));
        assertEquals(0, Solution.solution(Arrays.asList(2, 4)));
        assertEquals(0, Solution.solution(Arrays.asList(2, 3)));
        assertEquals(3, Solution.solution(Arrays.asList(3, 2)));
        assertEquals(0, Solution.solution(Arrays.asList(-2, -4)));
        assertEquals(5, Solution.solution(Arrays.asList(-5, 2, -3, 4)));
        assertEquals(0, Solution.solution(Arrays.asList(0, 0, 0, 0)));
    }

    @Test
    void testNegativeValues() {
        assertEquals(0, Solution.solution(Arrays.asList(-1, -2, -3, -4)));
        assertEquals(0, Solution.solution(Arrays.asList(-1, 2, -3, 4)));
        assertEquals(0, Solution.solution(Arrays.asList(-5, -6, -7, -8)));
        assertEquals(1, Solution.solution(Arrays.asList(-1, 2, 1, 4)));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(0, Solution.solution(Arrays.asList(-100, 100, 0, 0)));
        assertEquals(99, Solution.solution(Arrays.asList(99, 0, 0, 0)));
        assertEquals(0, Solution.solution(Arrays.asList(100, 100, 100, 100)));
        assertEquals(1, Solution.solution(Arrays.asList(1, 0, 0, 0)));
    }

    @Test
    void testInvalidInputs() {
        assertEquals(0, Solution.solution(Arrays.asList(-1, -2, -3, -4)));
        assertEquals(0, Solution.solution(Arrays.asList(-1, 2, -3, 4)));
        assertEquals(0, Solution.solution(Arrays.asList(0, 0, 0, 0)));
    }
}