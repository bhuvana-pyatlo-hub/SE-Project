package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsMultiplyPrimeTest {

    @Test
    void testIsMultiplyPrime() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(30));   // 2 * 3 * 5
        assertFalse(IsMultiplyPrime.isMultiplyPrime(5));    // 5 is prime, not a product of 3 primes
        assertTrue(IsMultiplyPrime.isMultiplyPrime(8));     // 2 * 2 * 2
        assertFalse(IsMultiplyPrime.isMultiplyPrime(10));   // 2 * 5
        assertTrue(IsMultiplyPrime.isMultiplyPrime(125));   // 5 * 5 * 5
        assertTrue(IsMultiplyPrime.isMultiplyPrime(105));   // 3 * 5 * 7
        assertFalse(IsMultiplyPrime.isMultiplyPrime(126));  // 2 * 3 * 21
        assertFalse(IsMultiplyPrime.isMultiplyPrime(729));   // 3 * 3 * 3 * 3 * 3 * 3
        assertFalse(IsMultiplyPrime.isMultiplyPrime(891));   // 3 * 3 * 99
        assertTrue(IsMultiplyPrime.isMultiplyPrime(1001));   // 7 * 11 * 13
    }

    @Test
    void testEdgeCases() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(1));     // No primes
        assertFalse(IsMultiplyPrime.isMultiplyPrime(0));     // No primes
        assertFalse(IsMultiplyPrime.isMultiplyPrime(-1));    // Negative number
        assertFalse(IsMultiplyPrime.isMultiplyPrime(-10));   // Negative number
        assertFalse(IsMultiplyPrime.isMultiplyPrime(-100));   // Negative number
        assertFalse(IsMultiplyPrime.isMultiplyPrime(2));      // Only one prime factor
        assertFalse(IsMultiplyPrime.isMultiplyPrime(3));      // Only one prime factor
        assertFalse(IsMultiplyPrime.isMultiplyPrime(4));      // 2 * 2
        assertFalse(IsMultiplyPrime.isMultiplyPrime(6));      // 2 * 3
        assertFalse(IsMultiplyPrime.isMultiplyPrime(9));      // 3 * 3
        assertFalse(IsMultiplyPrime.isMultiplyPrime(15));     // 3 * 5
        assertFalse(IsMultiplyPrime.isMultiplyPrime(21));     // 3 * 7
        assertFalse(IsMultiplyPrime.isMultiplyPrime(22));     // 2 * 11
        assertFalse(IsMultiplyPrime.isMultiplyPrime(35));     // 5 * 7
        assertFalse(IsMultiplyPrime.isMultiplyPrime(49));     // 7 * 7
        assertFalse(IsMultiplyPrime.isMultiplyPrime(77));     // 7 * 11
        assertFalse(IsMultiplyPrime.isMultiplyPrime(91));     // 7 * 13
    }
}