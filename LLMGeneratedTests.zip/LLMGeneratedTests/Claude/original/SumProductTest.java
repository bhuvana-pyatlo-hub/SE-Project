package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SumProductTest {

    @Test
    void testSumProductWithPositiveIntegers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(10, 24), result);
    }

    @Test
    void testSumProductWithEmptyList() {
        List<Object> input = Collections.emptyList();
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(0, 1), result);
    }

    @Test
    void testSumProductWithAllOnes() {
        List<Object> input = Arrays.asList(1, 1, 1);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(3, 1), result);
    }

    @Test
    void testSumProductWithHundredAndZero() {
        List<Object> input = Arrays.asList(100, 0);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(100, 0), result);
    }

    @Test
    void testSumProductWithMultipleIntegers() {
        List<Object> input = Arrays.asList(3, 5, 7);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(15, 105), result);
    }

    @Test
    void testSumProductWithSingleInteger() {
        List<Object> input = Arrays.asList(10);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(10, 10), result);
    }

    @Test
    void testSumProductWithNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(-6, -6), result);
    }

    @Test
    void testSumProductWithZeroAndNegative() {
        List<Object> input = Arrays.asList(0, -5);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(-5, 0), result);
    }

    @Test
    void testSumProductWithInvalidType() {
        List<Object> input = Arrays.asList(1, "two", 3);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SumProduct.sumProduct(input);
        });
        assertEquals("Invalid number type", exception.getMessage());
    }

    @Test
    void testSumProductWithNullValue() {
        List<Object> input = Arrays.asList(1, null, 3);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SumProduct.sumProduct(input);
        });
        assertEquals("Invalid number type", exception.getMessage());
    }

    @Test
    void testSumProductWithBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 100);
        List<Integer> result = SumProduct.sumProduct(input);
        assertEquals(Arrays.asList(0, -10000), result);
    }
}