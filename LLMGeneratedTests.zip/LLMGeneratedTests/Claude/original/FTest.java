package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FTest {

    @Test
    void testFWithSmallValues() {
        assertEquals(List.of(1), F.f(1));
        assertEquals(List.of(1, 2), F.f(2));
        assertEquals(List.of(1, 2, 6), F.f(3));
        assertEquals(List.of(1, 2, 6, 24), F.f(4));
        assertEquals(List.of(1, 2, 6, 24, 15), F.f(5));
        assertEquals(List.of(1, 2, 6, 24, 15, 720), F.f(6));
        assertEquals(List.of(1, 2, 6, 24, 15, 720, 28), F.f(7));
    }

    @Test
    void testFWithEdgeCases() {
        assertEquals(List.of(), F.f(0)); // Edge case: n = 0
        assertEquals(List.of(1), F.f(1)); // Edge case: n = 1
        assertEquals(List.of(1, 2), F.f(2)); // Edge case: n = 2
        assertEquals(List.of(1, 2, 6, 24, 15, 720, 28, 5040), F.f(8)); // Edge case: n = 8
        assertEquals(List.of(1, 2, 6, 24, 15, 720, 28, 5040, 45), F.f(9)); // Edge case: n = 9
        assertEquals(List.of(1, 2, 6, 24, 15, 720, 28, 5040, 45, 3628800), F.f(10)); // Edge case: n = 10
    }

    @Test
    void testFWithNegativeInput() {
        assertEquals(List.of(), F.f(-1)); // Edge case: n < 0
    }
}