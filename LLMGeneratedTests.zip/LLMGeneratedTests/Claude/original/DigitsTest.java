package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DigitsTest {

    @Test
    void testSingleOddDigit() {
        assertEquals(1, Digits.digits(1)); // Test with the smallest odd digit
    }

    @Test
    void testSingleEvenDigit() {
        assertEquals(0, Digits.digits(4)); // Test with the smallest even digit
    }

    @Test
    void testMultipleDigitsWithOdd() {
        assertEquals(15, Digits.digits(235)); // Test with mixed digits
    }

    @Test
    void testMultipleDigitsWithOnlyOdd() {
        assertEquals(5, Digits.digits(5)); // Test with single odd digit
    }

    @Test
    void testMultipleDigitsWithLeadingEven() {
        assertEquals(5, Digits.digits(54)); // Test with leading even digit
    }

    @Test
    void testMultipleDigitsWithLeadingZero() {
        assertEquals(1, Digits.digits(120)); // Test with leading zero
    }

    @Test
    void testMultipleDigitsWithTrailingEven() {
        assertEquals(5, Digits.digits(5014)); // Test with trailing even digits
    }

    @Test
    void testMultipleDigitsAllOdd() {
        assertEquals(315, Digits.digits(98765)); // Test with all odd digits
    }

    @Test
    void testMultipleDigitsAllOddWithRepetition() {
        assertEquals(2625, Digits.digits(5576543)); // Test with repeated odd digits
    }

    @Test
    void testAllEvenDigits() {
        assertEquals(0, Digits.digits(2468)); // Test with all even digits
    }

    @Test
    void testSingleDigitOddBoundary() {
        assertEquals(1, Digits.digits(9)); // Test with the largest single odd digit
    }

    @Test
    void testSingleDigitEvenBoundary() {
        assertEquals(0, Digits.digits(8)); // Test with the largest single even digit
    }

    @Test
    void testTwoDigitsBothOdd() {
        assertEquals(9, Digits.digits(39)); // Test with two odd digits
    }

    @Test
    void testTwoDigitsBothEven() {
        assertEquals(0, Digits.digits(42)); // Test with two even digits
    }

    @Test
    void testTwoDigitsMixed() {
        assertEquals(3, Digits.digits(32)); // Test with one odd and one even
    }

    @Test
    void testThreeDigitsAllOdd() {
        assertEquals(105, Digits.digits(135)); // Test with three odd digits
    }

    @Test
    void testThreeDigitsAllEven() {
        assertEquals(0, Digits.digits(246)); // Test with three even digits
    }

    @Test
    void testThreeDigitsMixed() {
        assertEquals(15, Digits.digits(135)); // Test with mixed odd and even digits
    }

    @Test
    void testFourDigitsAllEven() {
        assertEquals(0, Digits.digits(4826)); // Test with four even digits
    }

    @Test
    void testFourDigitsMixed() {
        assertEquals(15, Digits.digits(1235)); // Test with four digits, mixed
    }

    @Test
    void testZeroInput() {
        assertEquals(0, Digits.digits(0)); // Test with zero input
    }

    @Test
    void testNegativeInput() {
        assertEquals(0, Digits.digits(-123)); // Test with negative input (should be treated as zero)
    }

    @Test
    void testLargeEvenInput() {
        assertEquals(0, Digits.digits(8888)); // Test with large even digits
    }

    @Test
    void testLargeOddInput() {
        assertEquals(945, Digits.digits(13579)); // Test with large odd digits
    }

}