package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetPositiveTest {

    @Test
    void testGetPositiveWithMixedValues() {
        List<Object> input = Arrays.asList(-1, 2, -4, 5, 6);
        List<Object> expected = Arrays.asList(2, 5, 6);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithAllPositiveValues() {
        List<Object> input = Arrays.asList(5, 3, 2, 3, 9, 123, 1);
        List<Object> expected = Arrays.asList(5, 3, 2, 3, 9, 123, 1);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithAllNegativeValues() {
        List<Object> input = Arrays.asList(-1, -2, -4, -5, -6);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithZero() {
        List<Object> input = Arrays.asList(0, -1, -2);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithEmptyList() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithNullValues() {
        List<Object> input = Arrays.asList(null, -1, 2, null, 3);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithMixedTypes() {
        List<Object> input = Arrays.asList("string", -1, 2.5, 3, -4, 5);
        List<Object> expected = Arrays.asList(3, 5);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 0, 100);
        List<Object> expected = Arrays.asList(100);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithNegativeBoundaryValues() {
        List<Object> input = Arrays.asList(-99, -1, -100);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositiveWithPositiveBoundaryValues() {
        List<Object> input = Arrays.asList(1, 50, 99);
        List<Object> expected = Arrays.asList(1, 50, 99);
        assertEquals(expected, GetPositive.getPositive(input));
    }
}