package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class RemoveVowelsTest {

    @Test
    void testRemoveVowelsWithNoVowels() {
        assertEquals("bcdf", RemoveVowels.removeVowels("abcdef"));
    }

    @Test
    void testRemoveVowelsWithAllVowels() {
        assertEquals("", RemoveVowels.removeVowels("aaaaa"));
    }

    @Test
    void testRemoveVowelsWithMixedCaseVowels() {
        assertEquals("B", RemoveVowels.removeVowels("aaBAA"));
    }

    @Test
    void testRemoveVowelsWithNoVowelsInInput() {
        assertEquals("zbcd", RemoveVowels.removeVowels("zbcd"));
    }

    @Test
    void testRemoveVowelsWithEmptyString() {
        assertEquals("", RemoveVowels.removeVowels(""));
    }

    @Test
    void testRemoveVowelsWithNewlineCharacter() {
        assertEquals("bcdf\nghjklm", RemoveVowels.removeVowels("abcdef\nghijklm"));
    }

    @Test
    void testRemoveVowelsWithReversedAlphabet() {
        assertEquals("fdcb", RemoveVowels.removeVowels("fedcba"));
    }

    @Test
    void testRemoveVowelsWithRepeatedVowels() {
        assertEquals("", RemoveVowels.removeVowels("eeeee"));
    }

    @Test
    void testRemoveVowelsWithSingleConsonant() {
        assertEquals("cB", RemoveVowels.removeVowels("acBAA"));
    }

    @Test
    void testRemoveVowelsWithUppercaseVowels() {
        assertEquals("cB", RemoveVowels.removeVowels("EcBOO"));
    }

    @Test
    void testRemoveVowelsWithConsonantsOnly() {
        assertEquals("ybcd", RemoveVowels.removeVowels("ybcd"));
    }

    @Test
    void testRemoveVowelsWithMixedCharacters() {
        assertEquals("Hll Wrld", RemoveVowels.removeVowels("Hello World"));
    }

    @Test
    void testRemoveVowelsWithSingleVowel() {
        assertEquals("", RemoveVowels.removeVowels("A"));
    }

    @Test
    void testRemoveVowelsWithMultipleSpaces() {
        assertEquals(" ", RemoveVowels.removeVowels(" A "));
    }

    @Test
    void testRemoveVowelsWithSpecialCharacters() {
        assertEquals("!@#$$%", RemoveVowels.removeVowels("!@aeiou#$%"));
    }

    @Test
    void testRemoveVowelsWithMixedCaseAndSpaces() {
        assertEquals("Ths s n tst", RemoveVowels.removeVowels("This is an test"));
    }

    @Test
    void testRemoveVowelsWithSingleCharacter() {
        assertEquals("b", RemoveVowels.removeVowels("aAb"));
    }

    @Test
    void testRemoveVowelsWithAllUppercase() {
        assertEquals("BCD", RemoveVowels.removeVowels("AEIOUBCD"));
    }

    @Test
    void testRemoveVowelsWithAllLowercase() {
        assertEquals("bcd", RemoveVowels.removeVowels("aeioubcd"));
    }

    @Test
    void testRemoveVowelsWithMixedVowelsAndConsonants() {
        assertEquals("bcdfghjklmnpqrstvwxyz", RemoveVowels.removeVowels("abcdefghijklmnopqrstuvwxyz"));
    }

    @Test
    void testRemoveVowelsWithBoundaryValues() {
        assertEquals("", RemoveVowels.removeVowels("aeiouAEIOU"));
    }

    @Test
    void testRemoveVowelsWithNegativeValues() {
        assertEquals("123", RemoveVowels.removeVowels("123aeiou"));
    }

    @Test
    void testRemoveVowelsWithLongString() {
        assertEquals("Ths s lng strng wth n vwls", RemoveVowels.removeVowels("This is a long string with no vowels"));
    }
}