package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FindMaxTest {

    @Test
    void testFindMaxWithNormalCases() {
        assertEquals("string", FindMax.findMax(Arrays.asList("name", "of", "string")));
        assertEquals("enam", FindMax.findMax(Arrays.asList("name", "enam", "game")));
        assertEquals("aaaaaaa", FindMax.findMax(Arrays.asList("aaaaaaa", "bb", "cc")));
        assertEquals("abc", FindMax.findMax(Arrays.asList("abc", "cba")));
        assertEquals("footbott", FindMax.findMax(Arrays.asList("play", "this", "game", "of", "footbott")));
        assertEquals("gonna", FindMax.findMax(Arrays.asList("we", "are", "gonna", "rock")));
        assertEquals("nation", FindMax.findMax(Arrays.asList("we", "are", "a", "mad", "nation")));
        assertEquals("this", FindMax.findMax(Arrays.asList("this", "is", "a", "prrk")));
        assertEquals("b", FindMax.findMax(Collections.singletonList("b")));
        assertEquals("play", FindMax.findMax(Arrays.asList("play", "play", "play")));
    }

    @Test
    void testFindMaxWithEdgeCases() {
        assertEquals(null, FindMax.findMax(null));
        assertEquals(null, FindMax.findMax(Collections.emptyList()));
        assertEquals("a", FindMax.findMax(Collections.singletonList("a")));
        assertEquals("ab", FindMax.findMax(Arrays.asList("ab", "aa")));
        assertEquals("abc", FindMax.findMax(Arrays.asList("abc", "abcd", "ab")));
        assertEquals("abc", FindMax.findMax(Arrays.asList("abc", "a", "ab")));
        assertEquals("xyz", FindMax.findMax(Arrays.asList("xyz", "xy", "x")));
        assertEquals("hello", FindMax.findMax(Arrays.asList("hello", "world", "hi")));
    }

    @Test
    void testFindMaxWithSingleCharacterWords() {
        assertEquals("a", FindMax.findMax(Arrays.asList("a", "b", "c")));
        assertEquals("b", FindMax.findMax(Arrays.asList("b", "a", "c")));
        assertEquals("c", FindMax.findMax(Arrays.asList("c", "a", "b")));
    }

    @Test
    void testFindMaxWithIdenticalWords() {
        assertEquals("same", FindMax.findMax(Arrays.asList("same", "same", "same")));
        assertEquals("same", FindMax.findMax(Arrays.asList("same", "same", "same", "same")));
    }

    @Test
    void testFindMaxWithWordsHavingSameUniqueCount() {
        assertEquals("abc", FindMax.findMax(Arrays.asList("abc", "cab", "bac")));
        assertEquals("abc", FindMax.findMax(Arrays.asList("abc", "acb", "bac")));
    }

    @Test
    void testFindMaxWithEmptyStrings() {
        assertEquals("", FindMax.findMax(Arrays.asList("", "a", "b")));
        assertEquals("a", FindMax.findMax(Arrays.asList("a", "", "b")));
        assertEquals("b", FindMax.findMax(Arrays.asList("b", "a", "")));
    }
}