package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetOddCollatzTest {

    @Test
    void testGetOddCollatzWithInput1() {
        List<Integer> result = GetOddCollatz.getOddCollatz(1);
        assertEquals(List.of(1), result);
    }

    @Test
    void testGetOddCollatzWithInput2() {
        List<Integer> result = GetOddCollatz.getOddCollatz(2);
        assertEquals(List.of(1), result);
    }

    @Test
    void testGetOddCollatzWithInput3() {
        List<Integer> result = GetOddCollatz.getOddCollatz(3);
        assertEquals(List.of(1, 3), result);
    }

    @Test
    void testGetOddCollatzWithInput4() {
        List<Integer> result = GetOddCollatz.getOddCollatz(4);
        assertEquals(List.of(1), result);
    }

    @Test
    void testGetOddCollatzWithInput5() {
        List<Integer> result = GetOddCollatz.getOddCollatz(5);
        assertEquals(List.of(1, 5), result);
    }

    @Test
    void testGetOddCollatzWithInput6() {
        List<Integer> result = GetOddCollatz.getOddCollatz(6);
        assertEquals(List.of(1, 3, 5), result);
    }

    @Test
    void testGetOddCollatzWithInput7() {
        List<Integer> result = GetOddCollatz.getOddCollatz(7);
        assertEquals(List.of(1, 7), result);
    }

    @Test
    void testGetOddCollatzWithInput8() {
        List<Integer> result = GetOddCollatz.getOddCollatz(8);
        assertEquals(List.of(1), result);
    }

    @Test
    void testGetOddCollatzWithInput9() {
        List<Integer> result = GetOddCollatz.getOddCollatz(9);
        assertEquals(List.of(1, 9), result);
    }

    @Test
    void testGetOddCollatzWithInput10() {
        List<Integer> result = GetOddCollatz.getOddCollatz(10);
        assertEquals(List.of(1, 3, 5), result);
    }

    @Test
    void testGetOddCollatzWithInput11() {
        List<Integer> result = GetOddCollatz.getOddCollatz(11);
        assertEquals(List.of(1, 11), result);
    }

    @Test
    void testGetOddCollatzWithInput12() {
        List<Integer> result = GetOddCollatz.getOddCollatz(12);
        assertEquals(List.of(1, 3, 5), result);
    }

    @Test
    void testGetOddCollatzWithInput13() {
        List<Integer> result = GetOddCollatz.getOddCollatz(13);
        assertEquals(List.of(1, 13), result);
    }

    @Test
    void testGetOddCollatzWithInput14() {
        List<Integer> result = GetOddCollatz.getOddCollatz(14);
        assertEquals(List.of(1, 5, 7, 11, 13), result);
    }

    @Test
    void testGetOddCollatzWithInput15() {
        List<Integer> result = GetOddCollatz.getOddCollatz(15);
        assertEquals(List.of(1, 15), result);
    }

    @Test
    void testGetOddCollatzWithInput16() {
        List<Integer> result = GetOddCollatz.getOddCollatz(16);
        assertEquals(List.of(1), result);
    }

    @Test
    void testGetOddCollatzWithInput17() {
        List<Integer> result = GetOddCollatz.getOddCollatz(17);
        assertEquals(List.of(1, 17), result);
    }

    @Test
    void testGetOddCollatzWithInput18() {
        List<Integer> result = GetOddCollatz.getOddCollatz(18);
        assertEquals(List.of(1, 3, 5, 9), result);
    }

    @Test
    void testGetOddCollatzWithInput19() {
        List<Integer> result = GetOddCollatz.getOddCollatz(19);
        assertEquals(List.of(1, 19), result);
    }

    @Test
    void testGetOddCollatzWithInput20() {
        List<Integer> result = GetOddCollatz.getOddCollatz(20);
        assertEquals(List.of(1, 5, 9, 13, 17), result);
    }



}