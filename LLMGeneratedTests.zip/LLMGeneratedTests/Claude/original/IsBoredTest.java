package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class IsBoredTest {

    @Test
    void testIsBoredWithNoSentences() {
        assertEquals(0, IsBored.isBored(""));
    }

    @Test
    void testIsBoredWithSingleSentenceNoI() {
        assertEquals(0, IsBored.isBored("Hello world."));
    }

    @Test
    void testIsBoredWithSingleSentenceWithI() {
        assertEquals(1, IsBored.isBored("I love this weather."));
    }

    @Test
    void testIsBoredWithMultipleSentencesOneI() {
        assertEquals(1, IsBored.isBored("The sky is blue. I love this weather."));
    }

    @Test
    void testIsBoredWithMultipleSentencesTwoIs() {
        assertEquals(2, IsBored.isBored("I feel good today. I will be productive. I am happy."));
    }

    @Test
    void testIsBoredWithMultipleSentencesNoI() {
        assertEquals(0, IsBored.isBored("The sun is shining. The stars are bright."));
    }

    @Test
    void testIsBoredWithExclamationMark() {
        assertEquals(1, IsBored.isBored("I am excited! Let's go!"));
    }

    @Test
    void testIsBoredWithQuestionMark() {
        assertEquals(0, IsBored.isBored("Is it going to rain?"));
    }

    @Test
    void testIsBoredWithEmptySentences() {
        assertEquals(0, IsBored.isBored("I. .I."));
    }

    @Test
    void testIsBoredWithLeadingSpaces() {
        assertEquals(1, IsBored.isBored("   I am here.   "));
    }

    @Test
    void testIsBoredWithTrailingSpaces() {
        assertEquals(1, IsBored.isBored("I am here.   "));
    }

    @Test
    void testIsBoredWithMixedCaseI() {
        assertEquals(0, IsBored.isBored("i am here."));
    }

    @Test
    void testIsBoredWithMultipleSpacesBetweenWords() {
        assertEquals(1, IsBored.isBored("I     love     coding. I enjoy it too."));
    }

    @Test
    void testIsBoredWithOnlyI() {
        assertEquals(1, IsBored.isBored("I."));
    }

    @Test
    void testIsBoredWithIAtStartAndEnd() {
        assertEquals(2, IsBored.isBored("I am happy. I am also sad."));
    }

    @Test
    void testIsBoredWithNoWords() {
        assertEquals(0, IsBored.isBored("!?."));
    }

    @Test
    void testIsBoredWithSpecialCharacters() {
        assertEquals(1, IsBored.isBored("I love coding! #fun"));
    }

    @Test
    void testIsBoredWithLongSentence() {
        assertEquals(1, IsBored.isBored("I went to the store. It was fun! I bought apples."));
    }

    @Test
    void testIsBoredWithMultipleIInSameSentence() {
        assertEquals(1, IsBored.isBored("I love it. I really do!"));
    }

    @Test
    void testIsBoredWithSentenceEndingInI() {
        assertEquals(1, IsBored.isBored("I am here?"));
    }

    @Test
    void testIsBoredWithNoIInComplexSentence() {
        assertEquals(0, IsBored.isBored("You and I are going for a walk."));
    }

    @Test
    void testIsBoredWithMultipleSentencesWithLeadingSpaces() {
        assertEquals(1, IsBored.isBored("   I am here. The weather is nice.   "));
    }

    @Test
    void testIsBoredWithMultipleSentencesWithTrailingSpaces() {
        assertEquals(1, IsBored.isBored("I am here.   The weather is nice."));
    }

    @Test
    void testIsBoredWithOnlySpacesBetweenSentences() {
        assertEquals(0, IsBored.isBored("   .   .   "));
    }

    @Test
    void testIsBoredWithEmptyWords() {
        assertEquals(0, IsBored.isBored("I . . . . I ."));
    }
}