package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ParseNestedParensTest {

    @Test
    void testSinglePairOfParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens("()");
        assertEquals(Arrays.asList(1), result);
    }

    @Test
    void testMultipleSinglePairs() {
        List<Integer> result = ParseNestedParens.parseNestedParens("() () ()");
        assertEquals(Arrays.asList(1, 1, 1), result);
    }

    @Test
    void testNestedParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens("(()())");
        assertEquals(Arrays.asList(2), result);
    }

    @Test
    void testDeepNestedParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens("((()))");
        assertEquals(Arrays.asList(3), result);
    }

    @Test
    void testMultipleGroupsOfNestedParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens("(()()) ((())) () ((())()())");
        assertEquals(Arrays.asList(2, 3, 1, 3), result);
    }

    @Test
    void testMultipleLevelsOfNesting() {
        List<Integer> result = ParseNestedParens.parseNestedParens("() (()) ((())) (((())))");
        assertEquals(Arrays.asList(1, 2, 3, 4), result);
    }

    @Test
    void testEmptyString() {
        List<Integer> result = ParseNestedParens.parseNestedParens("");
        assertEquals(Arrays.asList(), result);
    }

    @Test
    void testUnmatchedParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens("(()");
        assertEquals(Arrays.asList(), result);
    }

    @Test
    void testOnlyClosingParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens(")))");
        assertEquals(Arrays.asList(), result);
    }

    @Test
    void testOnlyOpeningParentheses() {
        List<Integer> result = ParseNestedParens.parseNestedParens("((((");
        assertEquals(Arrays.asList(), result);
    }

    @Test
    void testMixedValidAndInvalid() {
        List<Integer> result = ParseNestedParens.parseNestedParens("(())) (())");
        assertEquals(Arrays.asList(2, 2), result);
    }

    @Test
    void testComplexNesting() {
        List<Integer> result = ParseNestedParens.parseNestedParens("((())(()))");
        assertEquals(Arrays.asList(3), result);
    }

    @Test
    void testMultipleDeepNesting() {
        List<Integer> result = ParseNestedParens.parseNestedParens("((())) (((())))");
        assertEquals(Arrays.asList(3, 4), result);
    }

    @Test
    void testSpacesBetweenGroups() {
        List<Integer> result = ParseNestedParens.parseNestedParens("()   (())   ((()))");
        assertEquals(Arrays.asList(1, 2, 3), result);
    }

    @Test
    void testNoSpacesBetweenGroups() {
        List<Integer> result = ParseNestedParens.parseNestedParens("()()()()");
        assertEquals(Arrays.asList(1, 1, 1, 1), result);
    }

    @Test
    void testSingleDeepGroup() {
        List<Integer> result = ParseNestedParens.parseNestedParens("((((()))))");
        assertEquals(Arrays.asList(6), result);
    }

    @Test
    void testMultipleDeepGroupsWithSpaces() {
        List<Integer> result = ParseNestedParens.parseNestedParens("((()))   (((())))   ()");
        assertEquals(Arrays.asList(3, 4, 1), result);
    }

    @Test
    void testMultipleUnmatchedGroups() {
        List<Integer> result = ParseNestedParens.parseNestedParens("(()()(()");
        assertEquals(Arrays.asList(2, 2), result);
    }

    @Test
    void testAllValidGroups() {
        List<Integer> result = ParseNestedParens.parseNestedParens("() (()) ((())) (((())))");
        assertEquals(Arrays.asList(1, 2, 3, 4), result);
    }
}