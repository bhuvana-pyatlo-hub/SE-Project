package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketingTest {

    @Test
    void testCorrectBracketing_EmptyString() {
        assertTrue(CorrectBracketing.correctBracketing(""));
    }

    @Test
    void testCorrectBracketing_SingleOpeningBracket() {
        assertFalse(CorrectBracketing.correctBracketing("<"));
    }

    @Test
    void testCorrectBracketing_SingleClosingBracket() {
        assertFalse(CorrectBracketing.correctBracketing(">"));
    }

    @Test
    void testCorrectBracketing_SinglePair() {
        assertTrue(CorrectBracketing.correctBracketing("<>"));
    }

    @Test
    void testCorrectBracketing_NestedPairs() {
        assertTrue(CorrectBracketing.correctBracketing("<<><>>"));
    }

    @Test
    void testCorrectBracketing_ComplexValid() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>><<>"));
    }

    @Test
    void testCorrectBracketing_ValidLongSequence() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><><>><>><<><><<>>>"));
    }

    @Test
    void testCorrectBracketing_ExcessClosingBracket() {
        assertFalse(CorrectBracketing.correctBracketing("><<>"));
    }

    @Test
    void testCorrectBracketing_ExcessOpeningBracket() {
        assertFalse(CorrectBracketing.correctBracketing("<<<<"));
    }

    @Test
    void testCorrectBracketing_ComplexInvalid() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>>><>"));
    }

    @Test
    void testCorrectBracketing_TooManyClosingBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("<<<><>>>>"));
    }

    @Test
    void testCorrectBracketing_ValidMultiplePairs() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>"));
    }

    @Test
    void testCorrectBracketing_ValidWithExtraPairs() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>><<><>"));
    }

    @Test
    void testCorrectBracketing_OnlyClosingBrackets() {
        assertFalse(CorrectBracketing.correctBracketing(">>>>"));
    }

    @Test
    void testCorrectBracketing_OnlyOpeningBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("<<<<"));
    }

    @Test
    void testCorrectBracketing_ValidWithInterleavedBrackets() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>><<>"));
    }

    @Test
    void testCorrectBracketing_ValidWithInterleavedBrackets2() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><><>><>><<><><<>>>"));
    }

    @Test
    void testCorrectBracketing_TooManyOpeningBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("<<>"));
    }

    @Test
    void testCorrectBracketing_TooManyClosingBrackets2() {
        assertFalse(CorrectBracketing.correctBracketing("><><"));
    }

    @Test
    void testCorrectBracketing_ValidWithMultiplePairs() {
        assertTrue(CorrectBracketing.correctBracketing("<<><>"));
    }

    @Test
    void testCorrectBracketing_ValidWithSinglePairAtStart() {
        assertTrue(CorrectBracketing.correctBracketing("<><>"));
    }

    @Test
    void testCorrectBracketing_ValidWithSinglePairAtEnd() {
        assertTrue(CorrectBracketing.correctBracketing("<>><>"));
    }

    @Test
    void testCorrectBracketing_ValidWithInterleavedBracketsAndExtra() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>><<><>><>"));
    }

    @Test
    void testCorrectBracketing_ExcessClosingBracketsAtStart() {
        assertFalse(CorrectBracketing.correctBracketing(">>><<"));
    }

    @Test
    void testCorrectBracketing_ExcessOpeningBracketsAtEnd() {
        assertFalse(CorrectBracketing.correctBracketing("<<><<"));
    }
}