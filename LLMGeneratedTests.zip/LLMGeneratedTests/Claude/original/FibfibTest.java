package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FibfibTest {

    @Test
    void testFibfibWithNegativeInput() {
        assertEquals(0, Fibfib.fibfib(-1));
    }

    @Test
    void testFibfibWithZero() {
        assertEquals(0, Fibfib.fibfib(0));
    }

    @Test
    void testFibfibWithOne() {
        assertEquals(0, Fibfib.fibfib(1));
    }

    @Test
    void testFibfibWithTwo() {
        assertEquals(1, Fibfib.fibfib(2));
    }

    @Test
    void testFibfibWithThree() {
        assertEquals(1, Fibfib.fibfib(3));
    }

    @Test
    void testFibfibWithFour() {
        assertEquals(2, Fibfib.fibfib(4));
    }

    @Test
    void testFibfibWithFive() {
        assertEquals(4, Fibfib.fibfib(5));
    }

    @Test
    void testFibfibWithSix() {
        assertEquals(7, Fibfib.fibfib(6));
    }

    @Test
    void testFibfibWithSeven() {
        assertEquals(13, Fibfib.fibfib(7));
    }

    @Test
    void testFibfibWithEight() {
        assertEquals(24, Fibfib.fibfib(8));
    }

    @Test
    void testFibfibWithNine() {
        assertEquals(44, Fibfib.fibfib(9));
    }

    @Test
    void testFibfibWithTen() {
        assertEquals(81, Fibfib.fibfib(10));
    }

    @Test
    void testFibfibWithEleven() {
        assertEquals(149, Fibfib.fibfib(11));
    }

    @Test
    void testFibfibWithTwelve() {
        assertEquals(274, Fibfib.fibfib(12));
    }

    @Test
    void testFibfibWithThirteen() {
        assertEquals(504, Fibfib.fibfib(13));
    }

    @Test
    void testFibfibWithFourteen() {
        assertEquals(927, Fibfib.fibfib(14));
    }

    @Test
    void testFibfibWithFifteen() {
        assertEquals(1705, Fibfib.fibfib(15));
    }

    @Test
    void testFibfibWithSixteen() {
        assertEquals(3136, Fibfib.fibfib(16));
    }

    @Test
    void testFibfibWithSeventeen() {
        assertEquals(5768, Fibfib.fibfib(17));
    }

    @Test
    void testFibfibWithEighteen() {
        assertEquals(10609, Fibfib.fibfib(18));
    }

    @Test
    void testFibfibWithNineteen() {
        assertEquals(19513, Fibfib.fibfib(19));
    }

    @Test
    void testFibfibWithTwenty() {
        assertEquals(35890, Fibfib.fibfib(20));
    }

    @Test
    void testFibfibWithTwentyOne() {
        assertEquals(66012, Fibfib.fibfib(21));
    }

    @Test
    void testFibfibWithTwentyTwo() {
        assertEquals(121415, Fibfib.fibfib(22));
    }

    @Test
    void testFibfibWithTwentyThree() {
        assertEquals(223317, Fibfib.fibfib(23));
    }

    @Test
    void testFibfibWithTwentyFour() {
        assertEquals(410244, Fibfib.fibfib(24));
    }

    @Test
    void testFibfibWithTwentyFive() {
        assertEquals(755476, Fibfib.fibfib(25));
    }

    @Test
    void testFibfibWithTwentySix() {
        assertEquals(1389537, Fibfib.fibfib(26));
    }

    @Test
    void testFibfibWithTwentySeven() {
        assertEquals(2555757, Fibfib.fibfib(27));
    }

    @Test
    void testFibfibWithTwentyEight() {
        assertEquals(4700770, Fibfib.fibfib(28));
    }

    @Test
    void testFibfibWithTwentyNine() {
        assertEquals(8646064, Fibfib.fibfib(29));
    }

    @Test
    void testFibfibWithThirty() {
        assertEquals(15902591, Fibfib.fibfib(30));
    }
}