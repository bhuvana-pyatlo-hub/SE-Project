package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

class BelowZeroTest {

    @Test
    void testBelowZeroWithPositiveOperations() {
        assertFalse(BelowZero.belowZero(Arrays.asList(1, 2, 3)));
    }

    @Test
    void testBelowZeroWithNegativeBalance() {
        assertTrue(BelowZero.belowZero(Arrays.asList(1, 2, -4, 5)));
    }

    @Test
    void testBelowZeroWithEmptyList() {
        assertFalse(BelowZero.belowZero(Collections.emptyList()));
    }

    @Test
    void testBelowZeroWithMixedOperations() {
        assertFalse(BelowZero.belowZero(Arrays.asList(1, 2, -3, 1, 2, -3)));
    }

    @Test
    void testBelowZeroWithNegativeBalanceAfterPositive() {
        assertTrue(BelowZero.belowZero(Arrays.asList(1, 2, -4, 5, 6)));
    }

    @Test
    void testBelowZeroWithAlternatingOperations() {
        assertFalse(BelowZero.belowZero(Arrays.asList(1, -1, 2, -2, 5, -5, 4, -4)));
    }

    @Test
    void testBelowZeroWithNegativeBalanceAtEnd() {
        assertTrue(BelowZero.belowZero(Arrays.asList(1, -1, 2, -2, 5, -5, 4, -5)));
    }

    @Test
    void testBelowZeroWithNegativeBalanceInMiddle() {
        assertTrue(BelowZero.belowZero(Arrays.asList(1, -2, 2, -2, 5, -5, 4, -4)));
    }

    @Test
    void testBelowZeroWithSingleNegativeOperation() {
        assertTrue(BelowZero.belowZero(Arrays.asList(-1)));
    }

    @Test
    void testBelowZeroWithSinglePositiveOperation() {
        assertFalse(BelowZero.belowZero(Arrays.asList(1)));
    }

    @Test
    void testBelowZeroWithMultipleNegativeOperations() {
        assertTrue(BelowZero.belowZero(Arrays.asList(-1, -2, -3)));
    }

    @Test
    void testBelowZeroWithMultiplePositiveAndNegativeOperations() {
        assertTrue(BelowZero.belowZero(Arrays.asList(5, -10, 5)));
    }

    @Test
    void testBelowZeroWithZeroBalance() {
        assertFalse(BelowZero.belowZero(Arrays.asList(0, 0, 0)));
    }

    @Test
    void testBelowZeroWithSmallPositiveAndNegative() {
        assertFalse(BelowZero.belowZero(Arrays.asList(10, -5, -5)));
    }

    @Test
    void testBelowZeroWithNegativeAndPositiveOperations() {
        assertTrue(BelowZero.belowZero(Arrays.asList(-5, 3, 2)));
    }

    @Test
    void testBelowZeroWithInvalidOperationType() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            BelowZero.belowZero(Arrays.asList("invalid", 1, 2));
        });
        assertEquals("Invalid operation type", exception.getMessage());
    }

    @Test
    void testBelowZeroWithMixedTypesIncludingDouble() {
        assertFalse(BelowZero.belowZero(Arrays.asList(1.0, 2.0, -2.0)));
    }

    @Test
    void testBelowZeroWithMixedTypesIncludingIntegerAndDouble() {
        assertTrue(BelowZero.belowZero(Arrays.asList(1, 2.0, -4)));
    }

    @Test
    void testBelowZeroWithAllZeroOperations() {
        assertFalse(BelowZero.belowZero(Arrays.asList(0, 0, 0, 0)));
    }

    @Test
    void testBelowZeroWithNegativeDouble() {
        assertTrue(BelowZero.belowZero(Arrays.asList(1.0, -2.0)));
    }

    @Test
    void testBelowZeroWithBoundaryNegative() {
        assertTrue(BelowZero.belowZero(Arrays.asList(-100, 50, 50)));
    }

    @Test
    void testBelowZeroWithBoundaryPositive() {
        assertFalse(BelowZero.belowZero(Arrays.asList(100, -50, -50)));
    }
}