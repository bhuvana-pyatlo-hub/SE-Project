package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SpecialFactorialTest {

    @Test
    void testSpecialFactorialWithInput1() {
        assertEquals(1, SpecialFactorial.specialFactorial(1));
    }

    @Test
    void testSpecialFactorialWithInput2() {
        assertEquals(2, SpecialFactorial.specialFactorial(2));
    }

    @Test
    void testSpecialFactorialWithInput3() {
        assertEquals(6, SpecialFactorial.specialFactorial(3));
    }

    @Test
    void testSpecialFactorialWithInput4() {
        assertEquals(288, SpecialFactorial.specialFactorial(4));
    }

    @Test
    void testSpecialFactorialWithInput5() {
        assertEquals(34560, SpecialFactorial.specialFactorial(5));
    }

    @Test
    void testSpecialFactorialWithInput6() {
        assertEquals(518918400, SpecialFactorial.specialFactorial(6));
    }

    @Test
    void testSpecialFactorialWithInput7() {
        assertEquals(125411328000L, SpecialFactorial.specialFactorial(7));
    }

    @Test
    void testSpecialFactorialWithInput9() {
        assertEquals(1853020188851841L, SpecialFactorial.specialFactorial(9));
    }

    @Test
    void testSpecialFactorialWithInput10() {
        assertEquals(13168189440000L, SpecialFactorial.specialFactorial(10));
    }

    @Test
    void testSpecialFactorialWithInputNegative() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SpecialFactorial.specialFactorial(-1);
        });
        assertEquals("Input must be greater than 0", exception.getMessage());
    }

    @Test
    void testSpecialFactorialWithInputZero() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SpecialFactorial.specialFactorial(0);
        });
        assertEquals("Input must be greater than 0", exception.getMessage());
    }

    @Test
    void testSpecialFactorialWithInputBoundary() {
        assertEquals(1, SpecialFactorial.specialFactorial(1));
        assertEquals(288, SpecialFactorial.specialFactorial(4));
        assertEquals(34560, SpecialFactorial.specialFactorial(5));
        assertEquals(125411328000L, SpecialFactorial.specialFactorial(7));
    }


    @Test
    void testSpecialFactorialWithInputMax() {
        // Testing the maximum valid input for the factorial calculation
        assertEquals(0, SpecialFactorial.specialFactorial(11)); // This is a placeholder, as the actual value is too large
    }

    @Test
    void testSpecialFactorialWithInputHighValue() {
        // Testing a high value input
        assertEquals(0, SpecialFactorial.specialFactorial(12)); // This is a placeholder, as the actual value is too large
    }

    @Test
    void testSpecialFactorialWithInputHighBoundary() {
        // Testing a higher boundary input
        assertEquals(0, SpecialFactorial.specialFactorial(13)); // This is a placeholder, as the actual value is too large
    }

    @Test
    void testSpecialFactorialWithInputHighEdgeCase() {
        // Testing an even higher edge case
        assertEquals(0, SpecialFactorial.specialFactorial(14)); // This is a placeholder, as the actual value is too large
    }
}