package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DecimalToBinaryTest {

    @Test
    void testDecimalToBinary_Zero() {
        // Test case for input 0
        assertEquals("db0db", DecimalToBinary.decimalToBinary(0));
    }

    @Test
    void testDecimalToBinary_One() {
        // Test case for input 1
        assertEquals("db1db", DecimalToBinary.decimalToBinary(1));
    }

    @Test
    void testDecimalToBinary_Two() {
        // Test case for input 2
        assertEquals("db10db", DecimalToBinary.decimalToBinary(2));
    }

    @Test
    void testDecimalToBinary_Three() {
        // Test case for input 3
        assertEquals("db11db", DecimalToBinary.decimalToBinary(3));
    }

    @Test
    void testDecimalToBinary_Four() {
        // Test case for input 4
        assertEquals("db100db", DecimalToBinary.decimalToBinary(4));
    }

    @Test
    void testDecimalToBinary_Five() {
        // Test case for input 5
        assertEquals("db101db", DecimalToBinary.decimalToBinary(5));
    }

    @Test
    void testDecimalToBinary_Six() {
        // Test case for input 6
        assertEquals("db110db", DecimalToBinary.decimalToBinary(6));
    }

    @Test
    void testDecimalToBinary_Seven() {
        // Test case for input 7
        assertEquals("db111db", DecimalToBinary.decimalToBinary(7));
    }

    @Test
    void testDecimalToBinary_Eight() {
        // Test case for input 8
        assertEquals("db1000db", DecimalToBinary.decimalToBinary(8));
    }

    @Test
    void testDecimalToBinary_Nine() {
        // Test case for input 9
        assertEquals("db1001db", DecimalToBinary.decimalToBinary(9));
    }

    @Test
    void testDecimalToBinary_Ten() {
        // Test case for input 10
        assertEquals("db1010db", DecimalToBinary.decimalToBinary(10));
    }

    @Test
    void testDecimalToBinary_Eleven() {
        // Test case for input 11
        assertEquals("db1011db", DecimalToBinary.decimalToBinary(11));
    }

    @Test
    void testDecimalToBinary_Twelve() {
        // Test case for input 12
        assertEquals("db1100db", DecimalToBinary.decimalToBinary(12));
    }

    @Test
    void testDecimalToBinary_Thirteen() {
        // Test case for input 13
        assertEquals("db1101db", DecimalToBinary.decimalToBinary(13));
    }

    @Test
    void testDecimalToBinary_Fourteen() {
        // Test case for input 14
        assertEquals("db1110db", DecimalToBinary.decimalToBinary(14));
    }

    @Test
    void testDecimalToBinary_Fifteen() {
        // Test case for input 15
        assertEquals("db1111db", DecimalToBinary.decimalToBinary(15));
    }

    @Test
    void testDecimalToBinary_Sixteen() {
        // Test case for input 16
        assertEquals("db10000db", DecimalToBinary.decimalToBinary(16));
    }

    @Test
    void testDecimalToBinary_ThirtyTwo() {
        // Test case for input 32
        assertEquals("db100000db", DecimalToBinary.decimalToBinary(32));
    }

    @Test
    void testDecimalToBinary_SeventyFive() {
        // Test case for input 75
        assertEquals("db1001011db", DecimalToBinary.decimalToBinary(75));
    }

    @Test
    void testDecimalToBinary_OneHundredThree() {
        // Test case for input 103
        assertEquals("db1100111db", DecimalToBinary.decimalToBinary(103));
    }

    @Test
    void testDecimalToBinary_OneHundredTwentySeven() {
        // Test case for input 127
        assertEquals("db1111111db", DecimalToBinary.decimalToBinary(127));
    }

    @Test
    void testDecimalToBinary_OneHundredTwentyEight() {
        // Test case for input 128 (invalid case, should not be tested as per original method)
        // This test case is not necessary as the method does not handle negative or out-of-bound inputs.
    }

    @Test
    void testDecimalToBinary_NegativeValue() {
        // Test case for negative input (not applicable in the original method)
        // This test case is not necessary as the method does not handle negative inputs.
    }
}