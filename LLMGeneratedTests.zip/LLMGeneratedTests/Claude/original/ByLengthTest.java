package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ByLengthTest {

    @Test
    void testByLengthWithValidInput() {
        List<Object> input = Arrays.asList(2, 1, 1, 4, 5, 8, 2, 3);
        List<Object> expected = Arrays.asList("Eight", "Five", "Four", "Three", "Two", "Two", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithEmptyInput() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithNegativeAndLargeNumbers() {
        List<Object> input = Arrays.asList(1, -1, 55);
        List<Object> expected = Collections.singletonList("One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithNegativeNumbersOnly() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithMixedValidAndInvalidNumbers() {
        List<Object> input = Arrays.asList(1, -1, 3, 2);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithOnlyValidNumbers() {
        List<Object> input = Arrays.asList(9, 4, 8);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Four");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithAllInvalidNumbers() {
        List<Object> input = Arrays.asList(10, 11, 12);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithSingleValidNumber() {
        List<Object> input = Collections.singletonList(5);
        List<Object> expected = Collections.singletonList("Five");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithSingleInvalidNumber() {
        List<Object> input = Collections.singletonList(15);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithMultipleSameValidNumbers() {
        List<Object> input = Arrays.asList(3, 3, 3);
        List<Object> expected = Arrays.asList("Three", "Three", "Three");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithMixedTypes() {
        List<Object> input = Arrays.asList(1, "string", 2.5, 3);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithNullValues() {
        List<Object> input = Arrays.asList(1, null, 2, null, 3);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithAllValidNumbers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithZero() {
        List<Object> input = Arrays.asList(0, 1, 2, 3);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithLargeValidNumbers() {
        List<Object> input = Arrays.asList(100, 200, 300, 1);
        List<Object> expected = Collections.singletonList("One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithAllEdgeNumbers() {
        List<Object> input = Arrays.asList(1, 9);
        List<Object> expected = Arrays.asList("Nine", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithMixedValidAndInvalidTypes() {
        List<Object> input = Arrays.asList(1, "text", 5.5, 7);
        List<Object> expected = Arrays.asList("Seven", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithOnlyInvalidTypes() {
        List<Object> input = Arrays.asList("text", 5.5, true);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void testByLengthWithAllValidNumbersInReverse() {
        List<Object> input = Arrays.asList(9, 8, 7, 6, 5, 4, 3, 2, 1);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }
}