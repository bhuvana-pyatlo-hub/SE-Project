package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CheckIfLastCharIsALetterTest {

    @Test
    void testEmptyString() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(""));
    }

    @Test
    void testSingleLetter() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("A"));
    }

    @Test
    void testSingleNonLetter() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("1"));
    }

    @Test
    void testLastCharIsLetterWithWord() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pie"));
    }

    @Test
    void testLastCharIsLetterNotPartOfWord() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e"));
    }

    @Test
    void testLastCharIsSpaceAfterLetter() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e "));
    }

    @Test
    void testLastCharIsLetterFollowedByNonLetter() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie 1"));
    }

    @Test
    void testLastCharIsLetterWithMultipleWords() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee e "));
    }

    @Test
    void testLastCharIsNonLetterWithWord() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e 1"));
    }

    @Test
    void testLastCharIsNonLetterWithOnlyLettersBefore() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e 1a"));
    }

    @Test
    void testLastCharIsLetterWithSingleWord() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Z"));
    }

    @Test
    void testLastCharIsLetterWithTwoWords() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World"));
    }

    @Test
    void testLastCharIsLetterWithTrailingSpaces() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World   "));
    }

    @Test
    void testLastCharIsSpecialCharacter() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World!"));
    }

    @Test
    void testLastCharIsDigit() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World2"));
    }

    @Test
    void testLastCharIsLetterWithOnlySpaces() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("     "));
    }

    @Test
    void testLastCharIsLetterWithMultipleSpaces() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello "));
    }

    @Test
    void testLastCharIsLetterWithMixedContent() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc d e f g h i j k l m n o p q r s t u v w x y z A"));
    }

    @Test
    void testLastCharIsLetterWithLeadingSpaces() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(" A"));
    }

    @Test
    void testLastCharIsLetterWithTrailingSpacesAndWord() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(" A "));
    }

    @Test
    void testLastCharIsLetterWithOnlyNonLetters() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("1234567890"));
    }

    @Test
    void testLastCharIsLetterWithMultipleWordsAndTrailingSpaces() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World  "));
    }

    @Test
    void testLastCharIsLetterWithMixedContentAndTrailingSpaces() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc d e f g h i j k l m n o p q r s t u v w x y z A "));
    }
}