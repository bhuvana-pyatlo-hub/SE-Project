package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CarRaceCollisionTest {

    @Test
    void testCarRaceCollisionWith2() {
        assertEquals(4, CarRaceCollision.carRaceCollision(2));
    }

    @Test
    void testCarRaceCollisionWith3() {
        assertEquals(9, CarRaceCollision.carRaceCollision(3));
    }

    @Test
    void testCarRaceCollisionWith4() {
        assertEquals(16, CarRaceCollision.carRaceCollision(4));
    }

    @Test
    void testCarRaceCollisionWith5() {
        assertEquals(25, CarRaceCollision.carRaceCollision(5));
    }

    @Test
    void testCarRaceCollisionWith6() {
        assertEquals(36, CarRaceCollision.carRaceCollision(6));
    }

    @Test
    void testCarRaceCollisionWith7() {
        assertEquals(49, CarRaceCollision.carRaceCollision(7));
    }

    @Test
    void testCarRaceCollisionWith8() {
        assertEquals(64, CarRaceCollision.carRaceCollision(8));
    }

    @Test
    void testCarRaceCollisionWith9() {
        assertEquals(81, CarRaceCollision.carRaceCollision(9));
    }

    @Test
    void testCarRaceCollisionWith10() {
        assertEquals(100, CarRaceCollision.carRaceCollision(10));
    }

    @Test
    void testCarRaceCollisionWith0() {
        assertEquals(0, CarRaceCollision.carRaceCollision(0));
    }

    @Test
    void testCarRaceCollisionWithNegative() {
        assertEquals(0, CarRaceCollision.carRaceCollision(-1));
    }

    @Test
    void testCarRaceCollisionWithBoundaryValues() {
        assertEquals(1, CarRaceCollision.carRaceCollision(1)); // Testing the minimum valid input
    }
}