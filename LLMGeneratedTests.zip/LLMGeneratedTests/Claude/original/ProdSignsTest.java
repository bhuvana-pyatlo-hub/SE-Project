package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ProdSignsTest {

    @Test
    void testEmptyArray() {
        assertEquals(null, ProdSigns.prodSigns(Arrays.asList()));
    }

    @Test
    void testAllPositive() {
        assertEquals(-9, ProdSigns.prodSigns(Arrays.asList(1, 2, 2, -4)));
    }

    @Test
    void testContainsZero() {
        assertEquals(0, ProdSigns.prodSigns(Arrays.asList(0, 1)));
    }

    @Test
    void testMixedValues() {
        assertEquals(-10, ProdSigns.prodSigns(Arrays.asList(1, 1, 1, 2, 3, -1, 1)));
    }

    @Test
    void testAllNegative() {
        assertEquals(20, ProdSigns.prodSigns(Arrays.asList(2, 4, 1, 2, -1, -1, 9)));
    }

    @Test
    void testAlternatingSigns() {
        assertEquals(4, ProdSigns.prodSigns(Arrays.asList(-1, 1, -1, 1)));
    }

    @Test
    void testNegativeAndPositive() {
        assertEquals(-4, ProdSigns.prodSigns(Arrays.asList(-1, 1, 1, 1)));
    }

    @Test
    void testNegativeWithZero() {
        assertEquals(0, ProdSigns.prodSigns(Arrays.asList(-1, 1, 1, 0)));
    }

    @Test
    void testSinglePositive() {
        assertEquals(1, ProdSigns.prodSigns(Arrays.asList(1)));
    }

    @Test
    void testSingleNegative() {
        assertEquals(-1, ProdSigns.prodSigns(Arrays.asList(-1)));
    }

    @Test
    void testSingleZero() {
        assertEquals(0, ProdSigns.prodSigns(Arrays.asList(0)));
    }

    @Test
    void testMultipleZeros() {
        assertEquals(0, ProdSigns.prodSigns(Arrays.asList(0, 0, 0)));
    }

    @Test
    void testSingleNegativeWithPositive() {
        assertEquals(-2, ProdSigns.prodSigns(Arrays.asList(-1, 1)));
    }

    @Test
    void testAllZeros() {
        assertEquals(0, ProdSigns.prodSigns(Arrays.asList(0, 0, 0, 0)));
    }

    @Test
    void testMixedWithZeroes() {
        assertEquals(0, ProdSigns.prodSigns(Arrays.asList(0, -2, 3, 0)));
    }

    @Test
    void testNegativeOnly() {
        assertEquals(4, ProdSigns.prodSigns(Arrays.asList(-2, -2)));
    }

    @Test
    void testPositiveOnly() {
        assertEquals(-6, ProdSigns.prodSigns(Arrays.asList(2, 2, 2)));
    }
}