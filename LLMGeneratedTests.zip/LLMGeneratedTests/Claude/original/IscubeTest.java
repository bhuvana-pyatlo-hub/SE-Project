package original;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class IscubeTest {

    @Test
    void testIsCubeWithPositiveCube() {
        assertTrue(Iscube.iscube(1), "1 is a cube (1^3)");
    }

    @Test
    void testIsCubeWithPositiveNonCube() {
        assertFalse(Iscube.iscube(2), "2 is not a cube");
    }

    @Test
    void testIsCubeWithNegativeCube() {
        assertTrue(Iscube.iscube(-1), "-1 is a cube (-1^3)");
    }

    @Test
    void testIsCubeWithPositivePerfectCube() {
        assertTrue(Iscube.iscube(64), "64 is a cube (4^3)");
    }

    @Test
    void testIsCubeWithZero() {
        assertTrue(Iscube.iscube(0), "0 is a cube (0^3)");
    }

    @Test
    void testIsCubeWithPositiveNonCubeLarge() {
        assertFalse(Iscube.iscube(180), "180 is not a cube");
    }

    @Test
    void testIsCubeWithPositiveCubeLarge() {
        assertTrue(Iscube.iscube(1000), "1000 is a cube (10^3)");
    }

    @Test
    void testIsCubeWithNegativeNonCube() {
        assertFalse(Iscube.iscube(-2), "-2 is not a cube");
    }

    @Test
    void testIsCubeWithNegativePerfectCube() {
        assertTrue(Iscube.iscube(-27), "-27 is a cube (-3^3)");
    }

    @Test
    void testIsCubeWithNegativeLargeNonCube() {
        assertFalse(Iscube.iscube(-1729), "-1729 is not a cube");
    }

    @Test
    void testIsCubeWithNegativeZero() {
        assertTrue(Iscube.iscube(0), "0 is a cube (0^3)");
    }

    @Test
    void testIsCubeWithPositiveEdgeCase() {
        assertTrue(Iscube.iscube(8), "8 is a cube (2^3)");
    }

    @Test
    void testIsCubeWithPositiveEdgeCaseNonCube() {
        assertFalse(Iscube.iscube(9), "9 is not a cube");
    }

    @Test
    void testIsCubeWithNegativeEdgeCase() {
        assertTrue(Iscube.iscube(-8), "-8 is a cube (-2^3)");
    }

    @Test
    void testIsCubeWithNegativeEdgeCaseNonCube() {
        assertFalse(Iscube.iscube(-7), "-7 is not a cube");
    }

    @Test
    void testIsCubeWithLargePositiveCube() {
        assertTrue(Iscube.iscube(729), "729 is a cube (9^3)");
    }

    @Test
    void testIsCubeWithLargePositiveNonCube() {
        assertFalse(Iscube.iscube(730), "730 is not a cube");
    }

    @Test
    void testIsCubeWithLargeNegativeCube() {
        assertTrue(Iscube.iscube(-512), "-512 is a cube (-8^3)");
    }

    @Test
    void testIsCubeWithLargeNegativeNonCube() {
        assertFalse(Iscube.iscube(-511), "-511 is not a cube");
    }

    @Test
    void testIsCubeWithPositiveSmallCube() {
        assertTrue(Iscube.iscube(27), "27 is a cube (3^3)");
    }

    @Test
    void testIsCubeWithPositiveSmallNonCube() {
        assertFalse(Iscube.iscube(28), "28 is not a cube");
    }

    @Test
    void testIsCubeWithNegativeSmallCube() {
        assertTrue(Iscube.iscube(-64), "-64 is a cube (-4^3)");
    }

    @Test
    void testIsCubeWithNegativeSmallNonCube() {
        assertFalse(Iscube.iscube(-65), "-65 is not a cube");
    }
}