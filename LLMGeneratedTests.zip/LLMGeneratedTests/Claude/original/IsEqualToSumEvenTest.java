package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsEqualToSumEvenTest {

    @Test
    void testIsEqualToSumEven_WithValueLessThan8_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(4));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo8_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(8));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo10_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(10));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo12_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(12));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo6_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(6));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo11_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(11));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo13_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(13));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo16_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(16));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo14_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(14));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo18_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(18));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo20_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(20));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo7_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(7));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo5_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(5));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo3_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(3));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo2_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(2));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo1_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(1));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualTo0_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(0));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualToNegative1_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-1));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualToNegative2_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-2));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualToNegative8_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-8));
    }

    @Test
    void testIsEqualToSumEven_WithValueEqualToNegative10_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-10));
    }

}