package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class AntiShuffleTest {

    @Test
    void testAntiShuffleWithSingleWord() {
        assertEquals("Hi", AntiShuffle.antiShuffle("Hi"));
    }

    @Test
    void testAntiShuffleWithLowercaseWord() {
        assertEquals("ehllo", AntiShuffle.antiShuffle("hello"));
    }

    @Test
    void testAntiShuffleWithNumberWord() {
        assertEquals("bemnru", AntiShuffle.antiShuffle("number"));
    }

    @Test
    void testAntiShuffleWithAlreadySortedWord() {
        assertEquals("abcd", AntiShuffle.antiShuffle("abcd"));
    }

    @Test
    void testAntiShuffleWithMultipleWords() {
        assertEquals("Hello !!!Wdlor", AntiShuffle.antiShuffle("Hello World!!!"));
    }

    @Test
    void testAntiShuffleWithEmptyString() {
        assertEquals("", AntiShuffle.antiShuffle(""));
    }

    @Test
    void testAntiShuffleWithComplexSentence() {
        assertEquals(".Hi My aemn is Meirst .Rboot How aer ?ouy", AntiShuffle.antiShuffle("Hi. My name is Mister Robot. How are you?"));
    }

    @Test
    void testAntiShuffleWithLeadingSpaces() {
        assertEquals("   a", AntiShuffle.antiShuffle("   a"));
    }

    @Test
    void testAntiShuffleWithTrailingSpaces() {
        assertEquals("a   ", AntiShuffle.antiShuffle("a   "));
    }

    @Test
    void testAntiShuffleWithMultipleSpacesBetweenWords() {
        assertEquals("a  b", AntiShuffle.antiShuffle("a  b"));
    }

    @Test
    void testAntiShuffleWithSpecialCharacters() {
        assertEquals("!@#abc", AntiShuffle.antiShuffle("abc!#@"));
    }

    @Test
    void testAntiShuffleWithMixedCaseAndSpecialCharacters() {
        assertEquals("!@#Aabc", AntiShuffle.antiShuffle("Aabc!#@"));
    }

    @Test
    void testAntiShuffleWithSingleCharacterWord() {
        assertEquals("a", AntiShuffle.antiShuffle("a"));
    }

    @Test
    void testAntiShuffleWithTwoCharacterWord() {
        assertEquals("ab", AntiShuffle.antiShuffle("ba"));
    }

    @Test
    void testAntiShuffleWithThreeCharacterWord() {
        assertEquals("abc", AntiShuffle.antiShuffle("cba"));
    }

    @Test
    void testAntiShuffleWithMultipleWordsAndPunctuation() {
        assertEquals("!@#abc  .de", AntiShuffle.antiShuffle("abc!@# de."));
    }

    @Test
    void testAntiShuffleWithAllSpaces() {
        assertEquals("   ", AntiShuffle.antiShuffle("   "));
    }

    @Test
    void testAntiShuffleWithWordsContainingSpaces() {
        assertEquals("Hello  World", AntiShuffle.antiShuffle("Hello  World"));
    }

    @Test
    void testAntiShuffleWithLongerSentence() {
        assertEquals("  a  b  c", AntiShuffle.antiShuffle("c b a"));
    }

    @Test
    void testAntiShuffleWithSingleWordAndSpecialCharacter() {
        assertEquals("!", AntiShuffle.antiShuffle("!"));
    }
}