package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FixSpacesTest {

    @Test
    void testFixSpacesWithNoSpaces() {
        assertEquals("Example", FixSpaces.fixSpaces("Example"));
    }

    @Test
    void testFixSpacesWithSingleSpace() {
        assertEquals("Example_1", FixSpaces.fixSpaces("Example 1"));
    }

    @Test
    void testFixSpacesWithLeadingSpace() {
        assertEquals("_Example_2", FixSpaces.fixSpaces(" Example 2"));
    }

    @Test
    void testFixSpacesWithConsecutiveSpaces() {
        assertEquals("_Example-3", FixSpaces.fixSpaces(" Example   3"));
    }

    @Test
    void testFixSpacesWithTrailingSpace() {
        assertEquals("Mudasir_Hanif_", FixSpaces.fixSpaces("Mudasir Hanif "));
    }

    @Test
    void testFixSpacesWithMultipleWordsAndSpaces() {
        assertEquals("Yellow_Yellow__Dirty__Fellow", FixSpaces.fixSpaces("Yellow Yellow  Dirty  Fellow"));
    }

    @Test
    void testFixSpacesWithConsecutiveSpacesInMiddle() {
        assertEquals("Exa-mple", FixSpaces.fixSpaces("Exa   mple"));
    }

    @Test
    void testFixSpacesWithLeadingAndTrailingSpaces() {
        assertEquals("-Exa_1_2_2_mple", FixSpaces.fixSpaces("   Exa 1 2 2 mple"));
    }

    @Test
    void testFixSpacesWithOnlySpaces() {
        assertEquals("-", FixSpaces.fixSpaces("   "));
    }

    @Test
    void testFixSpacesWithSingleCharacter() {
        assertEquals("A", FixSpaces.fixSpaces("A"));
    }

    @Test
    void testFixSpacesWithTwoSpaces() {
        assertEquals("A_B", FixSpaces.fixSpaces("A  B"));
    }

    @Test
    void testFixSpacesWithThreeSpaces() {
        assertEquals("A-B", FixSpaces.fixSpaces("A   B"));
    }

    @Test
    void testFixSpacesWithMixedSpaces() {
        assertEquals("A_B-C", FixSpaces.fixSpaces("A  B   C"));
    }

    @Test
    void testFixSpacesWithNoLeadingOrTrailingSpaces() {
        assertEquals("Hello-World", FixSpaces.fixSpaces("Hello   World"));
    }

    @Test
    void testFixSpacesWithSingleSpaceBetweenWords() {
        assertEquals("Hello_World", FixSpaces.fixSpaces("Hello World"));
    }

    @Test
    void testFixSpacesWithMultipleConsecutiveSpaces() {
        assertEquals("A-B-C", FixSpaces.fixSpaces("A    B    C"));
    }

    @Test
    void testFixSpacesWithEmptyString() {
        assertEquals("", FixSpaces.fixSpaces(""));
    }

    @Test
    void testFixSpacesWithSpecialCharacters() {
        assertEquals("Hello-World!", FixSpaces.fixSpaces("Hello   World!"));
    }

    @Test
    void testFixSpacesWithNumbersAndSpaces() {
        assertEquals("1_2-3", FixSpaces.fixSpaces("1 2   3"));
    }

    @Test
    void testFixSpacesWithOnlySpacesAndSpecialCharacters() {
        assertEquals("-", FixSpaces.fixSpaces("   !@#   "));
    }

    @Test
    void testFixSpacesWithSpacesBeforeAndAfterSpecialCharacters() {
        assertEquals("_Hello-World_!", FixSpaces.fixSpaces("  Hello   World!  "));
    }

    @Test
    void testFixSpacesWithLeadingSpacesAndSpecialCharacters() {
        assertEquals("_!_Hello-World", FixSpaces.fixSpaces("  ! Hello   World"));
    }

    @Test
    void testFixSpacesWithTrailingSpacesAndSpecialCharacters() {
        assertEquals("Hello-World_!", FixSpaces.fixSpaces("Hello   World!  "));
    }

    @Test
    void testFixSpacesWithAllSpaces() {
        assertEquals("-", FixSpaces.fixSpaces("          "));
    }

}