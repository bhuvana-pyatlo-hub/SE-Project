package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class WillItFlyTest {

    @Test
    void testBalancedAndWithinWeight() {
        assertTrue(WillItFly.willItFly(Arrays.asList(3, 2, 3), 9)); // Balanced and within weight
        assertTrue(WillItFly.willItFly(Arrays.asList(3), 5)); // Single element, balanced and within weight
        assertTrue(WillItFly.willItFly(Arrays.asList(5), 5)); // Single element, equal to weight
        assertTrue(WillItFly.willItFly(Arrays.asList(0), 1)); // Single element, balanced
    }

    @Test
    void testUnbalancedOrOverWeight() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2), 5)); // Unbalanced
        assertFalse(WillItFly.willItFly(Arrays.asList(3, 2, 3), 1)); // Balanced but over weight
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3), 6)); // Unbalanced and equal to weight
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 1), 4)); // Unbalanced and within weight
    }

    @Test
    void testEdgeCases() {
        assertTrue(WillItFly.willItFly(Arrays.asList(0), 1)); // Single element, balanced
        assertFalse(WillItFly.willItFly(Arrays.asList(-1, 1), 0)); // Balanced but sum exceeds weight
        assertTrue(WillItFly.willItFly(Arrays.asList(-1, 0, -1), 1)); // Balanced and within weight
        assertFalse(WillItFly.willItFly(Arrays.asList(-1, 1, -1), 0)); // Unbalanced and sum exceeds weight
        assertTrue(WillItFly.willItFly(Arrays.asList(-100, 0, -100), 0)); // Edge case with minimum valid inputs
        assertFalse(WillItFly.willItFly(Arrays.asList(-100, 1, -100), 0)); // Unbalanced with negative values
    }

    @Test
    void testEmptyList() {
        assertTrue(WillItFly.willItFly(Arrays.asList(), 0)); // Empty list, considered balanced
    }

    @Test
    void testNegativeValues() {
        assertTrue(WillItFly.willItFly(Arrays.asList(-1, -1), 0)); // Balanced and within weight
        assertFalse(WillItFly.willItFly(Arrays.asList(-1, 2, -1), 0)); // Unbalanced
        assertFalse(WillItFly.willItFly(Arrays.asList(-100, 100), 0)); // Unbalanced with extreme negative and positive
    }
}