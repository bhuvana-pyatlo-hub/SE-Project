package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CanArrangeTest {

    @Test
    void testCanArrangeWithDecreasingOrder() {
        List<Object> input = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithIncreasingOrder() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithSingleElement() {
        List<Object> input = Collections.singletonList(1);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithEmptyList() {
        List<Object> input = Collections.emptyList();
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithTwoElementsDescending() {
        List<Object> input = Arrays.asList(2, 1);
        assertEquals(1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithTwoElementsAscending() {
        List<Object> input = Arrays.asList(1, 2);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithMixedOrder() {
        List<Object> input = Arrays.asList(1, 3, 2, 4);
        assertEquals(2, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithAllEqualElements() {
        List<Object> input = Arrays.asList(2, 2, 2, 2);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithNegativeAndPositive() {
        List<Object> input = Arrays.asList(-1, 0, 1, 2);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithNegativeValues() {
        List<Object> input = Arrays.asList(-1, -2, -3, -4);
        assertEquals(1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithLargeGap() {
        List<Object> input = Arrays.asList(1, 2, 4, 3, 5);
        assertEquals(3, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithAdjacentDecreasing() {
        List<Object> input = Arrays.asList(1, 2, 3, 3, 2);
        assertEquals(4, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithMultipleDecreasing() {
        List<Object> input = Arrays.asList(10, 9, 8, 7, 6, 5);
        assertEquals(1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithSingleNegativeElement() {
        List<Object> input = Collections.singletonList(-1);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithMixedTypes() {
        List<Object> input = Arrays.asList(1, "string", 2, 3);
        assertEquals(2, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithNullElement() {
        List<Object> input = Arrays.asList(1, null, 2);
        assertEquals(2, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithLargeNegativeGap() {
        List<Object> input = Arrays.asList(-10, -5, -15, -20);
        assertEquals(2, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithTwoNegativeElements() {
        List<Object> input = Arrays.asList(-1, -2);
        assertEquals(1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithThreeElementsDescending() {
        List<Object> input = Arrays.asList(3, 2, 1);
        assertEquals(1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithThreeElementsAscending() {
        List<Object> input = Arrays.asList(1, 2, 3);
        assertEquals(-1, CanArrange.canArrange(input));
    }

    @Test
    void testCanArrangeWithBoundaryValues() {
        List<Object> input = Arrays.asList(100, 99, 98, 97);
        assertEquals(1, CanArrange.canArrange(input));
        
        input = Arrays.asList(-100, -99, -98, -97);
        assertEquals(1, CanArrange.canArrange(input));
        
        input = Arrays.asList(0, -1, 1);
        assertEquals(1, CanArrange.canArrange(input));
    }
}