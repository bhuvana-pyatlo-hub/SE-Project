package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortedListSumTest {

    @Test
    void testEmptyList() {
        List<String> input = Arrays.asList();
        List<Object> expected = Arrays.asList();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testAllOddLengthStrings() {
        List<String> input = Arrays.asList("a", "b", "c");
        List<Object> expected = Arrays.asList();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testMixedLengthStrings() {
        List<String> input = Arrays.asList("ab", "a", "cd", "aaa");
        List<Object> expected = Arrays.asList("ab", "cd");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testEvenLengthStrings() {
        List<String> input = Arrays.asList("abcd", "dcba", "efgh", "ijkl");
        List<Object> expected = Arrays.asList("abcd", "dcba", "efgh", "ijkl");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testDuplicateEvenLengthStrings() {
        List<String> input = Arrays.asList("aa", "bb", "aa", "cc");
        List<Object> expected = Arrays.asList("aa", "aa", "bb", "cc");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testStringsWithSameLength() {
        List<String> input = Arrays.asList("cat", "bat", "rat", "dog");
        List<Object> expected = Arrays.asList();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testStringsWithDifferentLengths() {
        List<String> input = Arrays.asList("school", "AI", "asdf", "b");
        List<Object> expected = Arrays.asList("AI", "asdf", "school");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testEdgeCaseSingleEvenLengthString() {
        List<String> input = Arrays.asList("aa");
        List<Object> expected = Arrays.asList("aa");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testEdgeCaseSingleOddLengthString() {
        List<String> input = Arrays.asList("a");
        List<Object> expected = Arrays.asList();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testAllEvenLengthStrings() {
        List<String> input = Arrays.asList("abcd", "efgh", "ijkl");
        List<Object> expected = Arrays.asList("abcd", "efgh", "ijkl");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testMixedEvenAndOddLengthStrings() {
        List<String> input = Arrays.asList("d", "dcba", "abcd", "a");
        List<Object> expected = Arrays.asList("abcd", "dcba");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testAllDuplicatesWithEvenLength() {
        List<String> input = Arrays.asList("ee", "ff", "ee", "gg");
        List<Object> expected = Arrays.asList("ee", "ee", "ff", "gg");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testAllDuplicatesWithOddLength() {
        List<String> input = Arrays.asList("a", "b", "a", "c");
        List<Object> expected = Arrays.asList();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void testBoundaryValues() {
        List<String> input = Arrays.asList("a", "bb", "ccc", "dddd");
        List<Object> expected = Arrays.asList("bb", "dddd");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }
}