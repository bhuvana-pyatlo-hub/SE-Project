package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class SortNumbersTest {

    @Test
    void testSortNumbersWithMultipleValidInputs() {
        assertEquals("one three five", SortNumbers.sortNumbers("three one five"));
        assertEquals("zero four five seven eight nine", SortNumbers.sortNumbers("five zero four seven nine eight"));
        assertEquals("zero one two three four five six", SortNumbers.sortNumbers("six five four three two one zero"));
    }

    @Test
    void testSortNumbersWithSingleValidInput() {
        assertEquals("three", SortNumbers.sortNumbers("three"));
        assertEquals("zero", SortNumbers.sortNumbers("zero"));
        assertEquals("nine", SortNumbers.sortNumbers("nine"));
    }

    @Test
    void testSortNumbersWithEmptyInput() {
        assertEquals("", SortNumbers.sortNumbers(""));
    }

    @Test
    void testSortNumbersWithInvalidInput() {
        assertEquals("", SortNumbers.sortNumbers("ten"));
        assertEquals("one", SortNumbers.sortNumbers("one ten"));
        assertEquals("three five", SortNumbers.sortNumbers("three five ten"));
        assertEquals("zero one", SortNumbers.sortNumbers("zero one ten"));
    }

    @Test
    void testSortNumbersWithAllValidInputs() {
        assertEquals("zero one two three four five six seven eight nine", SortNumbers.sortNumbers("nine eight seven six five four three two one zero"));
        assertEquals("zero one two three four five six seven eight nine", SortNumbers.sortNumbers("zero one two three four five six seven eight nine"));
    }

    @Test
    void testSortNumbersWithMixedValidAndInvalidInputs() {
        assertEquals("zero one two", SortNumbers.sortNumbers("one two three four five six seven eight nine ten"));
        assertEquals("zero one", SortNumbers.sortNumbers("zero one invalid"));
        assertEquals("three five", SortNumbers.sortNumbers("three five invalid"));
    }

    @Test
    void testSortNumbersWithRepeatedValidInputs() {
        assertEquals("zero zero one one two two", SortNumbers.sortNumbers("one zero two zero one two"));
        assertEquals("five five five", SortNumbers.sortNumbers("five five five"));
    }

    @Test
    void testSortNumbersWithLeadingAndTrailingSpaces() {
        assertEquals("zero one two", SortNumbers.sortNumbers("   zero   one   two   "));
        assertEquals("three five", SortNumbers.sortNumbers("   three   five   "));
    }

    @Test
    void testSortNumbersWithSingleInvalidInput() {
        assertEquals("", SortNumbers.sortNumbers("invalid"));
        assertEquals("", SortNumbers.sortNumbers("invalid invalid"));
    }

    @Test
    void testSortNumbersWithAllInvalidInputs() {
        assertEquals("", SortNumbers.sortNumbers("invalid invalid invalid"));
    }

    @Test
    void testSortNumbersWithBoundaryValues() {
        assertEquals("zero", SortNumbers.sortNumbers("zero"));
        assertEquals("nine", SortNumbers.sortNumbers("nine"));
        assertEquals("zero nine", SortNumbers.sortNumbers("nine zero"));
    }

    @Test
    void testSortNumbersWithSpacesOnly() {
        assertEquals("", SortNumbers.sortNumbers("     "));
    }

    @Test
    void testSortNumbersWithLeadingSpacesAndValidInputs() {
        assertEquals("one two three", SortNumbers.sortNumbers("   one   two   three   "));
    }

    @Test
    void testSortNumbersWithTrailingSpacesAndValidInputs() {
        assertEquals("four five six", SortNumbers.sortNumbers("four five six   "));
    }

    @Test
    void testSortNumbersWithMixedSpacesAndValidInputs() {
        assertEquals("seven eight", SortNumbers.sortNumbers("   seven eight   "));
    }
}