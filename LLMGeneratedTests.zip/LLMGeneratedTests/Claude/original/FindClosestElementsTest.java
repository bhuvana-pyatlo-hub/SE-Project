package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FindClosestElementsTest {

    @Test
    void testBasicCases() {
        assertEquals(Arrays.asList(3.9, 4.0), FindClosestElements.findClosestElements(Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2)));
        assertEquals(Arrays.asList(5.0, 5.9), FindClosestElements.findClosestElements(Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0)));
        assertEquals(Arrays.asList(2.0, 2.2), FindClosestElements.findClosestElements(Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.2)));
        assertEquals(Arrays.asList(2.0, 2.0), FindClosestElements.findClosestElements(Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.0)));
        assertEquals(Arrays.asList(2.2, 3.1), FindClosestElements.findClosestElements(Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1)));
    }

    @Test
    void testEdgeCases() {
        assertEquals(Arrays.asList(-1.0, 0.0), FindClosestElements.findClosestElements(Arrays.asList(-1.0, 0.0, 1.0)));
        assertEquals(Arrays.asList(-100.0, -99.0), FindClosestElements.findClosestElements(Arrays.asList(-100.0, -99.0, 0.0, 100.0)));
        assertEquals(Arrays.asList(99.0, 100.0), FindClosestElements.findClosestElements(Arrays.asList(99.0, 100.0, 0.0, -100.0)));
        assertEquals(Arrays.asList(0.0, 0.0), FindClosestElements.findClosestElements(Arrays.asList(0.0, 0.0, 0.0)));
        assertEquals(Arrays.asList(-50.0, -49.0), FindClosestElements.findClosestElements(Arrays.asList(-50.0, -49.0, -100.0, 100.0)));
    }

    @Test
    void testInvalidInputs() {
        assertEquals(Arrays.asList(0.0, 1.0), FindClosestElements.findClosestElements(Arrays.asList(0.0, 1.0)));
        assertEquals(Arrays.asList(1.0, 1.0), FindClosestElements.findClosestElements(Arrays.asList(1.0, 1.0)));
        assertEquals(Arrays.asList(0.0, 0.0), FindClosestElements.findClosestElements(Arrays.asList(0.0, 0.0, 0.0)));
        assertEquals(Arrays.asList(-1.0, 1.0), FindClosestElements.findClosestElements(Arrays.asList(-1.0, 1.0, 0.0)));
    }
}