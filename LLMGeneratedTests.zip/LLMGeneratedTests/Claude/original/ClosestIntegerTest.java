package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClosestIntegerTest {

    @Test
    void testPositiveInteger() {
        assertEquals(10, ClosestInteger.closestInteger("10"));
    }

    @Test
    void testPositiveDecimal() {
        assertEquals(15, ClosestInteger.closestInteger("15.3"));
    }

    @Test
    void testEquidistantPositive() {
        assertEquals(15, ClosestInteger.closestInteger("14.5"));
    }

    @Test
    void testNegativeEquidistant() {
        assertEquals(-16, ClosestInteger.closestInteger("-15.5"));
    }

    @Test
    void testNegativeDecimal() {
        assertEquals(-15, ClosestInteger.closestInteger("-14.3"));
    }

    @Test
    void testNegativeInteger() {
        assertEquals(-10, ClosestInteger.closestInteger("-10"));
    }

    @Test
    void testZero() {
        assertEquals(0, ClosestInteger.closestInteger("0"));
    }

    @Test
    void testNegativeEquidistantZero() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.5"));
    }

    @Test
    void testPositiveEquidistantZero() {
        assertEquals(1, ClosestInteger.closestInteger("0.5"));
    }

    @Test
    void testBoundaryPositive() {
        assertEquals(100, ClosestInteger.closestInteger("100"));
    }

    @Test
    void testBoundaryNegative() {
        assertEquals(-100, ClosestInteger.closestInteger("-100"));
    }

    @Test
    void testInvalidInput() {
        assertThrows(NumberFormatException.class, () -> ClosestInteger.closestInteger("invalid"));
    }

    @Test
    void testEdgeCasePositive() {
        assertEquals(1, ClosestInteger.closestInteger("0.999"));
    }

    @Test
    void testEdgeCaseNegative() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.999"));
    }
}