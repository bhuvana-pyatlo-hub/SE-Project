package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PluckTest {

    @Test
    void testPluckWithSmallestEvenValue() {
        List<Object> input = Arrays.asList(4, 2, 3);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithMultipleSmallestEvenValues() {
        List<Object> input = Arrays.asList(5, 0, 3, 0, 4, 2);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithNoEvenValues() {
        List<Object> input = Arrays.asList(7, 9, 7, 1);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithEmptyList() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithSingleEvenValue() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithMultipleEvenValues() {
        List<Object> input = Arrays.asList(5, 4, 8, 4, 8);
        List<Object> expected = Arrays.asList(4, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithEvenValueAtEnd() {
        List<Object> input = Arrays.asList(1, 2, 3, 0, 5, 3);
        List<Object> expected = Arrays.asList(0, 3);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithNegativeAndPositiveValues() {
        List<Object> input = Arrays.asList(-2, -4, 1, 3);
        List<Object> expected = Arrays.asList(-4, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithAllOddValues() {
        List<Object> input = Arrays.asList(1, 3, 5, 7);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithBoundaryEvenValue() {
        List<Object> input = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(0, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithBoundaryNegativeEvenValue() {
        List<Object> input = Arrays.asList(-100, -2, -1);
        List<Object> expected = Arrays.asList(-100, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithBoundaryPositiveEvenValue() {
        List<Object> input = Arrays.asList(100, 2, 1);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void testPluckWithInvalidInput() {
        List<Object> input = Arrays.asList("string", 2, 4);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }
}