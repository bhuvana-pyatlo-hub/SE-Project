package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CommonTest {

    @Test
    void testCommonWithBasicCases() {
        assertEquals(Arrays.asList(1, 5, 653), Common.common(Arrays.asList(1, 4, 3, 34, 653, 2, 5), Arrays.asList(5, 7, 1, 5, 9, 653, 121)));
        assertEquals(Arrays.asList(2, 3), Common.common(Arrays.asList(5, 3, 2, 8), Arrays.asList(3, 2)));
        assertEquals(Arrays.asList(2, 3, 4), Common.common(Arrays.asList(4, 3, 2, 8), Arrays.asList(3, 2, 4)));
    }

    @Test
    void testCommonWithEmptyList() {
        assertEquals(Collections.emptyList(), Common.common(Arrays.asList(4, 3, 2, 8), Collections.emptyList()));
        assertEquals(Collections.emptyList(), Common.common(Collections.emptyList(), Arrays.asList(1, 2, 3)));
    }

    @Test
    void testCommonWithNoCommonElements() {
        assertEquals(Collections.emptyList(), Common.common(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6)));
    }

    @Test
    void testCommonWithInvalidInputs() {
        assertEquals(Collections.emptyList(), Common.common(Arrays.asList(1, 2, 3), Arrays.asList("a", "b", "c")));
        assertEquals(Collections.emptyList(), Common.common(Collections.emptyList(), Arrays.asList("a", "b", "c")));
    }

    @Test
    void testCommonWithDuplicates() {
        assertEquals(Arrays.asList(1, 2, 3), Common.common(Arrays.asList(1, 2, 2, 3, 3), Arrays.asList(3, 2, 1, 1)));
    }

    @Test
    void testCommonWithNegativeNumbers() {
        assertEquals(Arrays.asList(-1, -2), Common.common(Arrays.asList(-1, -2, -3), Arrays.asList(-2, -1, -4)));
    }

    @Test
    void testCommonWithBoundaryValues() {
        assertEquals(Arrays.asList(-100, 0, 100), Common.common(Arrays.asList(-100, 0, 100), Arrays.asList(0, 100, -100)));
        assertEquals(Collections.emptyList(), Common.common(Arrays.asList(-100, 0, 100), Arrays.asList(-99, 1, 101)));
    }

    @Test
    void testCommonWithZeroValues() {
        assertEquals(Arrays.asList(0), Common.common(Arrays.asList(0, 1, 2), Arrays.asList(0, 3, 4)));
        assertEquals(Collections.emptyList(), Common.common(Arrays.asList(1, 2), Arrays.asList(3, 4)));
    }
}