package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class Solve1Test {

    @Test
    void testSolveWithZero() {
        assertEquals("0", Solve1.solve(0));
    }

    @Test
    void testSolveWithSingleDigit() {
        assertEquals("0", Solve1.solve(0));
        assertEquals("1", Solve1.solve(1));
        assertEquals("10", Solve1.solve(2));
        assertEquals("11", Solve1.solve(3));
        assertEquals("100", Solve1.solve(4));
        assertEquals("101", Solve1.solve(5));
        assertEquals("110", Solve1.solve(6));
        assertEquals("111", Solve1.solve(7));
        assertEquals("1000", Solve1.solve(8));
        assertEquals("1001", Solve1.solve(9));
    }

    @Test
    void testSolveWithTwoDigits() {
        assertEquals("10", Solve1.solve(10));
        assertEquals("11", Solve1.solve(11));
        assertEquals("110", Solve1.solve(12));
        assertEquals("111", Solve1.solve(13));
        assertEquals("1000", Solve1.solve(14));
        assertEquals("1001", Solve1.solve(15));
        assertEquals("1100", Solve1.solve(16));
        assertEquals("1101", Solve1.solve(17));
        assertEquals("1110", Solve1.solve(18));
        assertEquals("1111", Solve1.solve(19));
    }

    @Test
    void testSolveWithThreeDigits() {
        assertEquals("110", Solve1.solve(100));
        assertEquals("111", Solve1.solve(101));
        assertEquals("1000", Solve1.solve(102));
        assertEquals("1001", Solve1.solve(103));
        assertEquals("1010", Solve1.solve(104));
        assertEquals("1011", Solve1.solve(105));
        assertEquals("1100", Solve1.solve(106));
        assertEquals("1101", Solve1.solve(107));
        assertEquals("1110", Solve1.solve(108));
        assertEquals("1111", Solve1.solve(109));
        assertEquals("10010", Solve1.solve(110));
    }

    @Test
    void testSolveWithFourDigits() {
        assertEquals("1001", Solve1.solve(1000));
        assertEquals("110", Solve1.solve(150));
        assertEquals("1100", Solve1.solve(147));
        assertEquals("1001", Solve1.solve(333));
        assertEquals("10010", Solve1.solve(963));
    }

    @Test
    void testSolveWithEdgeValues() {
        assertEquals("100110001001", Solve1.solve(9999)); // 81 in binary
        assertEquals("10000", Solve1.solve(10000)); // 1 in binary
    }

    @Test
    void testSolveWithNegativeValues() {
        // Since the original code does not handle negative values, we can assume that
        // we won't test negative values as per the constraints provided.
    }
}