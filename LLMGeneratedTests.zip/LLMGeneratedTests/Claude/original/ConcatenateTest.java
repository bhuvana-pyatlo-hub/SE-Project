package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ConcatenateTest {

    @Test
    void testEmptyList() {
        assertEquals("", Concatenate.concatenate(Collections.emptyList()));
    }

    @Test
    void testSingleElementList() {
        assertEquals("a", Concatenate.concatenate(Collections.singletonList("a")));
        assertEquals("1", Concatenate.concatenate(Collections.singletonList(1)));
        assertEquals("true", Concatenate.concatenate(Collections.singletonList(true)));
    }

    @Test
    void testMultipleElementsList() {
        assertEquals("abc", Concatenate.concatenate(Arrays.asList("a", "b", "c")));
        assertEquals("123", Concatenate.concatenate(Arrays.asList(1, 2, 3)));
        assertEquals("truefalse", Concatenate.concatenate(Arrays.asList(true, false)));
    }

    @Test
    void testDifferentTypes() {
        assertEquals("123", Concatenate.concatenate(Arrays.asList(1, 2, 3)));
        assertEquals("truefalse", Concatenate.concatenate(Arrays.asList(true, false)));
    }

    @Test
    void testMixedTypes() {
        assertEquals("a1b2", Concatenate.concatenate(Arrays.asList("a", 1, "b", 2)));
        assertEquals("a1true", Concatenate.concatenate(Arrays.asList("a", 1, true)));
    }

    @Test
    void testNullElement() {
        assertEquals("anullb", Concatenate.concatenate(Arrays.asList("a", null, "b")));
        assertEquals("null", Concatenate.concatenate(Collections.singletonList(null)));
    }

    @Test
    void testAllTypes() {
        assertEquals("abc123truefalse", Concatenate.concatenate(Arrays.asList("a", "b", "c", 1, 2, 3, true, false)));
    }

    @Test
    void testBoundaryValues() {
        assertEquals("0", Concatenate.concatenate(Collections.singletonList(0)));
        assertEquals("-1", Concatenate.concatenate(Collections.singletonList(-1)));
        assertEquals("100", Concatenate.concatenate(Collections.singletonList(100)));
        assertEquals("-100", Concatenate.concatenate(Collections.singletonList(-100)));
    }

    @Test
    void testNegativeValues() {
        assertEquals("-1-2-3", Concatenate.concatenate(Arrays.asList(-1, -2, -3)));
        assertEquals("-100-50-1", Concatenate.concatenate(Arrays.asList(-100, -50, -1)));
    }

    @Test
    void testZeroValues() {
        assertEquals("000", Concatenate.concatenate(Arrays.asList(0, 0, 0)));
        assertEquals("0-1", Concatenate.concatenate(Arrays.asList(0, -1)));
    }

    @Test
    void testLargeList() {
        assertEquals("abcdefghijklmnopqrstuvwxyz", Concatenate.concatenate(Arrays.asList("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z")));
    }
}