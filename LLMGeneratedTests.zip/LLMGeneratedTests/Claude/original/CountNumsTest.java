package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CountNumsTest {

    @Test
    void testEmptyList() {
        assertEquals(0, CountNums.countNums(Arrays.asList()));
    }

    @Test
    void testAllNegativeAndZero() {
        assertEquals(0, CountNums.countNums(Arrays.asList(-1, -2, 0)));
    }

    @Test
    void testAllPositive() {
        assertEquals(3, CountNums.countNums(Arrays.asList(1, 1, 2)));
    }

    @Test
    void testMixedNumbers() {
        assertEquals(6, CountNums.countNums(Arrays.asList(1, 1, 2, -2, 3, 4, 5)));
    }

    @Test
    void testWithNegativeAndPositive() {
        assertEquals(5, CountNums.countNums(Arrays.asList(1, 6, 9, -6, 0, 1, 5)));
    }

    @Test
    void testWithLargerNumbers() {
        assertEquals(4, CountNums.countNums(Arrays.asList(1, 100, 98, -7, 1, -1)));
    }

    @Test
    void testWithNegativeDigits() {
        assertEquals(5, CountNums.countNums(Arrays.asList(12, 23, 34, -45, -56, 0)));
    }

    @Test
    void testSingleElementPositive() {
        assertEquals(1, CountNums.countNums(Arrays.asList(1)));
    }

    @Test
    void testSingleElementNegative() {
        assertEquals(0, CountNums.countNums(Arrays.asList(-1)));
    }

    @Test
    void testSingleElementZero() {
        assertEquals(0, CountNums.countNums(Arrays.asList(0)));
    }
}