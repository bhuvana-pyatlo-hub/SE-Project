package original;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class PrimeLengthTest {

    @Test
    void testEmptyString() {
        assertFalse(PrimeLength.primeLength(""));
    }

    @Test
    void testStringWithLengthOne() {
        assertFalse(PrimeLength.primeLength("A"));
    }

    @Test
    void testStringWithLengthTwo() {
        assertTrue(PrimeLength.primeLength("AB"));
    }

    @Test
    void testStringWithLengthThree() {
        assertTrue(PrimeLength.primeLength("ABC"));
    }

    @Test
    void testStringWithLengthFour() {
        assertFalse(PrimeLength.primeLength("ABCD"));
    }

    @Test
    void testStringWithLengthFive() {
        assertTrue(PrimeLength.primeLength("ABCDE"));
    }

    @Test
    void testStringWithLengthSix() {
        assertFalse(PrimeLength.primeLength("ABCDEF"));
    }

    @Test
    void testStringWithLengthSeven() {
        assertTrue(PrimeLength.primeLength("ABCDEFG"));
    }

    @Test
    void testStringWithLengthEight() {
        assertFalse(PrimeLength.primeLength("ABCDEFGH"));
    }

    @Test
    void testStringWithLengthNine() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHI"));
    }

    @Test
    void testStringWithLengthTen() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJ"));
    }

    @Test
    void testStringWithLengthEleven() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJK"));
    }

    @Test
    void testStringWithLengthTwelve() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKL"));
    }

    @Test
    void testStringWithLengthThirteen() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJKLM"));
    }

    @Test
    void testStringWithLengthFourteen() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMN"));
    }

    @Test
    void testStringWithLengthFifteen() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNO"));
    }

    @Test
    void testStringWithLengthSixteen() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNOP"));
    }

    @Test
    void testStringWithLengthSeventeen() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQ"));
    }

    @Test
    void testStringWithLengthEighteen() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQR"));
    }

    @Test
    void testStringWithLengthNineteen() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRST"));
    }

    @Test
    void testStringWithLengthTwenty() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTU"));
    }

    @Test
    void testStringWithLengthTwentyOne() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTUV"));
    }

    @Test
    void testStringWithLengthTwentyTwo() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTUVW"));
    }

    @Test
    void testStringWithLengthTwentyThree() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTUVWX"));
    }

    @Test
    void testStringWithLengthTwentyFour() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTUVWXY"));
    }

    @Test
    void testStringWithLengthTwentyFive() {
        assertFalse(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTUVWXYA"));
    }

    @Test
    void testStringWithLengthTwentySix() {
        assertTrue(PrimeLength.primeLength("ABCDEFGHIJKLMNOPQRSTUVWXYAB"));
    }
}