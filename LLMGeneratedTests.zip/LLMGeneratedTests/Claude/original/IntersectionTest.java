package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IntersectionTest {

    @Test
    void testIntersectionWhenIntervalsDoNotIntersect() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 2), Arrays.asList(3, 5)));
    }

    @Test
    void testIntersectionWhenIntervalsTouchAtStart() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 2), Arrays.asList(2, 3)));
    }

    @Test
    void testIntersectionWhenIntervalsTouchAtEnd() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(2, 3), Arrays.asList(1, 2)));
    }

    @Test
    void testIntersectionWhenIntervalsAreIdentical() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 2), Arrays.asList(1, 2)));
    }

    @Test
    void testIntersectionWhenIntervalsOverlapWithPrimeLength() {
        assertEquals("YES", Intersection.intersection(Arrays.asList(-3, -1), Arrays.asList(-5, 5)));
    }

    @Test
    void testIntersectionWhenIntervalsOverlapWithNonPrimeLength() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 3), Arrays.asList(2, 4)));
    }

    @Test
    void testIntersectionWhenOneIntervalIsInsideAnother() {
        assertEquals("YES", Intersection.intersection(Arrays.asList(-2, 2), Arrays.asList(-4, 0)));
    }

    @Test
    void testIntersectionWhenIntervalsAreNegativeAndDoNotIntersect() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(-11, -5), Arrays.asList(-4, -1)));
    }

    @Test
    void testIntersectionWhenIntervalsAreNegativeAndTouch() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(-2, -2), Arrays.asList(-3, -2)));
    }

    @Test
    void testIntersectionWhenIntervalsAreNegativeAndOverlapWithPrimeLength() {
        assertEquals("YES", Intersection.intersection(Arrays.asList(-5, -3), Arrays.asList(-4, -1)));
    }

    @Test
    void testIntersectionWhenIntervalsAreNegativeAndOverlapWithNonPrimeLength() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(-4, -2), Arrays.asList(-3, -1)));
    }

    @Test
    void testIntersectionWhenFirstIntervalIsCompletelyBeforeSecond() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(0, 1), Arrays.asList(2, 3)));
    }

    @Test
    void testIntersectionWhenFirstIntervalIsCompletelyAfterSecond() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(2, 3), Arrays.asList(0, 1)));
    }

    @Test
    void testIntersectionWhenFirstIntervalIsSinglePointAndSecondIntervalIsLarger() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 1), Arrays.asList(0, 2)));
    }

    @Test
    void testIntersectionWhenFirstIntervalIsLargerAndSecondIsSinglePoint() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(0, 2), Arrays.asList(1, 1)));
    }

    @Test
    void testIntersectionWhenBothIntervalsAreSinglePointsAndDoNotIntersect() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 1), Arrays.asList(2, 2)));
    }

    @Test
    void testIntersectionWhenBothIntervalsAreSinglePointsAndIntersect() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 1), Arrays.asList(1, 1)));
    }

    @Test
    void testIntersectionWhenIntervalsAreVeryCloseButDoNotIntersect() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 1), Arrays.asList(1, 1)));
    }

    @Test
    void testIntersectionWhenIntervalsAreVeryCloseAndOverlap() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 2), Arrays.asList(1, 1)));
    }

    @Test
    void testIntersectionWhenBothIntervalsAreEmpty() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(0, 0), Arrays.asList(0, 0)));
    }

    @Test
    void testIntersectionWhenFirstIntervalIsEmptyAndSecondIsValid() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 1), Arrays.asList(0, 2)));
    }

    @Test
    void testIntersectionWhenFirstIntervalIsValidAndSecondIsEmpty() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(0, 2), Arrays.asList(1, 1)));
    }

    @Test
    void testIntersectionWhenIntervalsOverlapWithZeroLength() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 1), Arrays.asList(1, 1)));
    }

    @Test
    void testIntersectionWhenIntervalsOverlapWithNegativeLength() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(-1, -1), Arrays.asList(-1, -1)));
    }

    @Test
    void testIntersectionWhenIntervalsOverlapWithPrimeLengthAtBoundary() {
        assertEquals("YES", Intersection.intersection(Arrays.asList(1, 3), Arrays.asList(2, 5)));
    }

    @Test
    void testIntersectionWhenIntervalsOverlapWithNonPrimeLengthAtBoundary() {
        assertEquals("NO", Intersection.intersection(Arrays.asList(1, 4), Arrays.asList(2, 5)));
    }
}