package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PairsSumToZeroTest {

    @Test
    void testPairsSumToZeroWithDistinctElements() {
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(1, 3, 5, 0))); // No pairs
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(1, 3, -2, 1))); // No pairs
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(1, 2, 3, 7))); // No pairs
        assertTrue(PairsSumToZero.pairsSumToZero(Arrays.asList(2, 4, -5, 3, 5, 7))); // 2 and -2
        assertFalse(PairsSumToZero.pairsSumToZero(Collections.singletonList(1))); // Single element
    }

    @Test
    void testPairsSumToZeroWithNegativeAndPositivePairs() {
        assertTrue(PairsSumToZero.pairsSumToZero(Arrays.asList(-3, 9, -1, 3, 2, 30))); // -1 and 1
        assertTrue(PairsSumToZero.pairsSumToZero(Arrays.asList(-3, 9, -1, 3, 2, 31))); // -1 and 1
    }

    @Test
    void testPairsSumToZeroWithNoPairs() {
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(-3, 9, -1, 4, 2, 30))); // No pairs
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(-3, 9, -1, 4, 2, 31))); // No pairs
    }

    @Test
    void testPairsSumToZeroWithEmptyList() {
        assertFalse(PairsSumToZero.pairsSumToZero(Collections.emptyList())); // Empty list
    }

    @Test
    void testPairsSumToZeroWithSingleElement() {
        assertFalse(PairsSumToZero.pairsSumToZero(Collections.singletonList(0))); // Single zero
        assertFalse(PairsSumToZero.pairsSumToZero(Collections.singletonList(-1))); // Single negative
        assertFalse(PairsSumToZero.pairsSumToZero(Collections.singletonList(1))); // Single positive
    }

    @Test
    void testPairsSumToZeroWithBoundaryValues() {
        assertTrue(PairsSumToZero.pairsSumToZero(Arrays.asList(-100, 100))); // Minimum and maximum
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(-100, 99))); // Close to boundary
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(0, 0))); // Two zeros
    }

    @Test
    void testPairsSumToZeroWithNegativeValues() {
        assertTrue(PairsSumToZero.pairsSumToZero(Arrays.asList(-1, 1))); // Negative and positive
        assertFalse(PairsSumToZero.pairsSumToZero(Arrays.asList(-1, -2, -3))); // All negatives
    }
}