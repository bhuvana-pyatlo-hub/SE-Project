package original;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class AnyIntTest {

    @Test
    void testAnyInt_WithValidIntegers_SumOfTwoEqualsThird() {
        assertTrue(AnyInt.anyInt(5, 2, 7)); // 5 + 2 = 7
    }

    @Test
    void testAnyInt_WithValidIntegers_SumOfTwoEqualsThird_ReverseOrder() {
        assertTrue(AnyInt.anyInt(2, 5, 7)); // 2 + 5 = 7
    }

    @Test
    void testAnyInt_WithValidIntegers_SumOfTwoEqualsThird_Negative() {
        assertTrue(AnyInt.anyInt(3, -2, 1)); // 3 + (-2) = 1
    }

    @Test
    void testAnyInt_WithValidIntegers_SumOfTwoEqualsThird_AnotherCase() {
        assertTrue(AnyInt.anyInt(4, 2, 2)); // 4 = 2 + 2
    }

    @Test
    void testAnyInt_WithValidIntegers_SumOfTwoEqualsThird_AnotherOrder() {
        assertTrue(AnyInt.anyInt(2, 1, 1)); // 2 = 1 + 1
    }

    @Test
    void testAnyInt_WithValidIntegers_SumOfTwoEqualsThird_ThreeNumbers() {
        assertTrue(AnyInt.anyInt(3, 4, 7)); // 3 + 4 = 7
    }

    @Test
    void testAnyInt_WithInvalidIntegers_SumOfTwoNotEqualsThird() {
        assertFalse(AnyInt.anyInt(3, 2, 2)); // No sum equals
    }

    @Test
    void testAnyInt_WithInvalidIntegers_SumOfTwoNotEqualsThird_AnotherCase() {
        assertFalse(AnyInt.anyInt(2, 6, 2)); // No sum equals
    }

    @Test
    void testAnyInt_WithNonIntegerInputs() {
        assertFalse(AnyInt.anyInt(3.6, -2.2, 2)); // Not all integers
    }

    @Test
    void testAnyInt_WithMixedTypes() {
        assertFalse(AnyInt.anyInt(2.5, 2, 3)); // Not all integers
    }

    @Test
    void testAnyInt_WithAnotherMixedTypes() {
        assertFalse(AnyInt.anyInt(1.5, 5, 3.5)); // Not all integers
    }

    @Test
    void testAnyInt_WithAllNonIntegerInputs() {
        assertFalse(AnyInt.anyInt(2.2, 2.2, 2.2)); // Not all integers
    }

    @Test
    void testAnyInt_WithNegativeAndPositiveIntegers_SumOfTwoEqualsThird() {
        assertTrue(AnyInt.anyInt(-4, 6, 2)); // -4 + 6 = 2
    }

    @Test
    void testAnyInt_WithZeroAndPositiveIntegers_SumOfTwoEqualsThird() {
        assertTrue(AnyInt.anyInt(0, 2, 2)); // 0 + 2 = 2
    }

    @Test
    void testAnyInt_WithZeroAndNegativeIntegers_SumOfTwoEqualsThird() {
        assertTrue(AnyInt.anyInt(0, -2, -2)); // 0 + (-2) = -2
    }

    @Test
    void testAnyInt_WithZeroAndPositiveIntegers_SumOfTwoNotEqualsThird() {
        assertFalse(AnyInt.anyInt(0, 3, 2)); // 0 + 3 != 2
    }

    @Test
    void testAnyInt_WithNegativeIntegers_SumOfTwoNotEqualsThird() {
        assertFalse(AnyInt.anyInt(-1, -2, -2)); // -1 + -2 != -2
    }

    @Test
    void testAnyInt_WithBoundaryValues_SumOfTwoEqualsThird() {
        assertTrue(AnyInt.anyInt(-100, 100, 0)); // -100 + 100 = 0
    }

    @Test
    void testAnyInt_WithBoundaryValues_SumOfTwoNotEqualsThird() {
        assertFalse(AnyInt.anyInt(-100, 50, 50)); // -100 + 50 != 50
    }

    @Test
    void testAnyInt_WithMixedTypesAndInvalidSum() {
        assertFalse(AnyInt.anyInt(3.0, 4, 7)); // Not all integers
    }
}