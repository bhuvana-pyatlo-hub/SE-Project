package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SumSquaresTest {

    @Test
    void testPositiveIntegers() {
        assertEquals(14, SumSquares.sumSquares(Arrays.asList(1, 2, 3)));
        assertEquals(98, SumSquares.sumSquares(Arrays.asList(1, 4, 9)));
        assertEquals(84, SumSquares.sumSquares(Arrays.asList(1, 3, 5, 7)));
        assertEquals(10230, SumSquares.sumSquares(Arrays.asList(100, 1, 15, 2)));
    }

    @Test
    void testMixedNumbers() {
        assertEquals(29, SumSquares.sumSquares(Arrays.asList(1.4, 4.2, 0)));
        assertEquals(6, SumSquares.sumSquares(Arrays.asList(-2.4, 1, 1)));
        assertEquals(75, SumSquares.sumSquares(Arrays.asList(-1.4, 4.6, 6.3)));
        assertEquals(1086, SumSquares.sumSquares(Arrays.asList(-1.4, 17.9, 18.9, 19.9)));
    }

    @Test
    void testEdgeCases() {
        assertEquals(0, SumSquares.sumSquares(Arrays.asList(0)));
        assertEquals(1, SumSquares.sumSquares(Arrays.asList(-1)));
        assertEquals(2, SumSquares.sumSquares(Arrays.asList(-1, 1, 0)));
        assertEquals(1, SumSquares.sumSquares(Arrays.asList(-0.1))); // Test small negative
        assertEquals(1, SumSquares.sumSquares(Arrays.asList(0.1)));  // Test small positive
        assertEquals(1, SumSquares.sumSquares(Arrays.asList(-0.5))); // Test negative fraction
        assertEquals(1, SumSquares.sumSquares(Arrays.asList(0.5)));  // Test positive fraction
    }

    @Test
    void testNegativeIntegers() {
        assertEquals(1, SumSquares.sumSquares(Arrays.asList(-1))); // Test single negative integer
        assertEquals(2, SumSquares.sumSquares(Arrays.asList(-1, 1, 0))); // Test mix of negative, positive, and zero
        assertEquals(4, SumSquares.sumSquares(Arrays.asList(-2))); // Test negative integer
    }

    @Test
    void testZeroValues() {
        assertEquals(0, SumSquares.sumSquares(Arrays.asList(0))); // Test single zero
        assertEquals(0, SumSquares.sumSquares(Arrays.asList(0, 0, 0))); // Test multiple zeros
    }
}