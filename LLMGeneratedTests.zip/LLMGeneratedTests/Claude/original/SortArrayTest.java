package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortArrayTest {

    @Test
    void testSortArrayWithBasicCases() {
        assertEquals(Arrays.asList(1, 2, 4, 3, 5), SortArray.sortArray(Arrays.asList(1, 5, 2, 3, 4)));
        assertEquals(Arrays.asList(0, 1, 2, 3, 4), SortArray.sortArray(Arrays.asList(1, 0, 2, 3, 4)));
    }

    @Test
    void testSortArrayWithEmptyArray() {
        assertEquals(Arrays.asList(), SortArray.sortArray(Arrays.asList()));
    }

    @Test
    void testSortArrayWithRepeatedNumbers() {
        assertEquals(Arrays.asList(2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77), 
                     SortArray.sortArray(Arrays.asList(2, 5, 77, 4, 5, 3, 5, 7, 2, 3, 4)));
    }

    @Test
    void testSortArrayWithDifferentBinaryOnes() {
        assertEquals(Arrays.asList(32, 3, 5, 6, 12, 44), 
                     SortArray.sortArray(Arrays.asList(3, 6, 44, 12, 32, 5)));
        assertEquals(Arrays.asList(2, 4, 8, 16, 32), 
                     SortArray.sortArray(Arrays.asList(2, 4, 8, 16, 32)));
    }

    @Test
    void testSortArrayWithNegativeAndZero() {
        assertEquals(Arrays.asList(0, 1, 2, 3, 4), 
                     SortArray.sortArray(Arrays.asList(1, 0, 2, 3, 4)));
    }

    @Test
    void testSortArrayWithNegativeValues() {
        assertEquals(Arrays.asList(-1, -2, -3, -4), 
                     SortArray.sortArray(Arrays.asList(-1, -2, -3, -4)));
    }

    @Test
    void testSortArrayWithBoundaryValues() {
        assertEquals(Arrays.asList(-100, 0, 1, 100), 
                     SortArray.sortArray(Arrays.asList(100, 0, -100, 1)));
    }

    @Test
    void testSortArrayWithSingleElement() {
        assertEquals(Arrays.asList(42), 
                     SortArray.sortArray(Arrays.asList(42)));
    }

    @Test
    void testSortArrayWithAllZeros() {
        assertEquals(Arrays.asList(0, 0, 0), 
                     SortArray.sortArray(Arrays.asList(0, 0, 0)));
    }
}