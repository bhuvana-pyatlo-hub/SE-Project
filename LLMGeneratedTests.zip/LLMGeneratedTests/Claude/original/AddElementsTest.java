package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AddElementsTest {

    @Test
    void testBasicCases() {
        assertEquals(24, AddElements.addElements(Arrays.asList(111, 21, 3, 4000, 5, 6, 7, 8, 9), 4));
        assertEquals(-4, AddElements.addElements(Arrays.asList(1, -2, -3, 41, 57, 76, 87, 88, 99), 3));
        assertEquals(0, AddElements.addElements(Arrays.asList(111, 121, 3, 4000, 5, 6), 2));
        assertEquals(125, AddElements.addElements(Arrays.asList(11, 21, 3, 90, 5, 6, 7, 8, 9), 4));
        assertEquals(1, AddElements.addElements(Arrays.asList(1), 1));
    }

    @Test
    void testEdgeCases() {
        assertEquals(0, AddElements.addElements(Arrays.asList(100, 100, 100), 3));
        assertEquals(99, AddElements.addElements(Arrays.asList(99, 100, 101), 2));
        assertEquals(0, AddElements.addElements(Arrays.asList(100, 101, 102), 3));
        assertEquals(100, AddElements.addElements(Arrays.asList(100, 0, 0), 2));
        assertEquals(0, AddElements.addElements(Arrays.asList(0, 0, 0), 3));
        assertEquals(0, AddElements.addElements(Arrays.asList(-1, -2, -3), 3));
        assertEquals(50, AddElements.addElements(Arrays.asList(50, 150, 200), 1));
    }

    @Test
    void testInvalidInputs() {
        assertEquals(0, AddElements.addElements(Arrays.asList(), 0));
        assertEquals(0, AddElements.addElements(Arrays.asList(100), 0));
        assertEquals(0, AddElements.addElements(Arrays.asList(100), 1));
        assertEquals(0, AddElements.addElements(Arrays.asList(101, 102, 103), 3));
        assertEquals(0, AddElements.addElements(Arrays.asList(0, 0, 0), 0));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(0, AddElements.addElements(Arrays.asList(100, 100, 100), 3));
        assertEquals(99, AddElements.addElements(Arrays.asList(99, 100, 101), 2));
        assertEquals(0, AddElements.addElements(Arrays.asList(100, 101, 102), 3));
        assertEquals(1, AddElements.addElements(Arrays.asList(1, 2, 3), 1));
        assertEquals(0, AddElements.addElements(Arrays.asList(-1, -2, -3), 3));
    }
}