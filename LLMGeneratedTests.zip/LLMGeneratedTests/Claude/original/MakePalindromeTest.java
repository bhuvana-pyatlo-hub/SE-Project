package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MakePalindromeTest {

    @Test
    void testMakePalindrome_EmptyString() {
        assertEquals("", MakePalindrome.makePalindrome(""));
    }

    @Test
    void testMakePalindrome_SingleCharacter() {
        assertEquals("x", MakePalindrome.makePalindrome("x"));
    }

    @Test
    void testMakePalindrome_TwoDifferentCharacters() {
        assertEquals("xyzyx", MakePalindrome.makePalindrome("xy"));
    }

    @Test
    void testMakePalindrome_TwoSameCharacters() {
        assertEquals("aa", MakePalindrome.makePalindrome("a"));
    }

    @Test
    void testMakePalindrome_ThreeDifferentCharacters() {
        assertEquals("abcba", MakePalindrome.makePalindrome("abc"));
    }

    @Test
    void testMakePalindrome_ThreeSameCharacters() {
        assertEquals("aaa", MakePalindrome.makePalindrome("aa"));
    }

    @Test
    void testMakePalindrome_FourDifferentCharacters() {
        assertEquals("abcdedcba", MakePalindrome.makePalindrome("abcd"));
    }

    @Test
    void testMakePalindrome_FourCharactersWithPalindromeSuffix() {
        assertEquals("catac", MakePalindrome.makePalindrome("cat"));
    }

    @Test
    void testMakePalindrome_FourCharactersWithPalindromePrefix() {
        assertEquals("abba", MakePalindrome.makePalindrome("ab"));
    }

    @Test
    void testMakePalindrome_FiveCharactersWithPalindromeSuffix() {
        assertEquals("jerryrrej", MakePalindrome.makePalindrome("jerry"));
    }

    @Test
    void testMakePalindrome_FiveCharactersWithPalindromePrefix() {
        assertEquals("racecar", MakePalindrome.makePalindrome("rac"));
    }

    @Test
    void testMakePalindrome_SixCharactersWithPalindromeSuffix() {
        assertEquals("abcdefedcba", MakePalindrome.makePalindrome("abcdef"));
    }

    @Test
    void testMakePalindrome_SixCharactersWithPalindromePrefix() {
        assertEquals("deed", MakePalindrome.makePalindrome("de"));
    }

    @Test
    void testMakePalindrome_SevenCharactersWithPalindromeSuffix() {
        assertEquals("aabbccbaaa", MakePalindrome.makePalindrome("aabbc"));
    }

    @Test
    void testMakePalindrome_SevenCharactersWithPalindromePrefix() {
        assertEquals("madam", MakePalindrome.makePalindrome("mad"));
    }

    @Test
    void testMakePalindrome_EightCharactersWithPalindromeSuffix() {
        assertEquals("abcdefghgfedcba", MakePalindrome.makePalindrome("abcdefgh"));
    }

    @Test
    void testMakePalindrome_EightCharactersWithPalindromePrefix() {
        assertEquals("noon", MakePalindrome.makePalindrome("no"));
    }

    @Test
    void testMakePalindrome_NineCharactersWithPalindromeSuffix() {
        assertEquals("abcdefgihgfedcba", MakePalindrome.makePalindrome("abcdefg"));
    }

    @Test
    void testMakePalindrome_NineCharactersWithPalindromePrefix() {
        assertEquals("step on no pets", MakePalindrome.makePalindrome("step on no pet"));
    }

    @Test
    void testMakePalindrome_TenCharactersWithPalindromeSuffix() {
        assertEquals("abcdefghijkjihgfedcba", MakePalindrome.makePalindrome("abcdefghijk"));
    }

    @Test
    void testMakePalindrome_TenCharactersWithPalindromePrefix() {
        assertEquals("detartrated", MakePalindrome.makePalindrome("detartr"));
    }

    @Test
    void testMakePalindrome_NegativeInput() {
        assertEquals(null, MakePalindrome.makePalindrome("-1"));
    }

    @Test
    void testMakePalindrome_SpecialCharacters() {
        assertEquals("!@#@!", MakePalindrome.makePalindrome("!@#"));
    }

    @Test
    void testMakePalindrome_SingleSpecialCharacter() {
        assertEquals("@", MakePalindrome.makePalindrome("@"));
    }

    @Test
    void testMakePalindrome_SingleSpace() {
        assertEquals(" ", MakePalindrome.makePalindrome(" "));
    }

    @Test
    void testMakePalindrome_SpacePrefix() {
        assertEquals(" abba", MakePalindrome.makePalindrome(" ab"));
    }

    @Test
    void testMakePalindrome_SpaceSuffix() {
        assertEquals("cata ", MakePalindrome.makePalindrome("cat "));
    }
}