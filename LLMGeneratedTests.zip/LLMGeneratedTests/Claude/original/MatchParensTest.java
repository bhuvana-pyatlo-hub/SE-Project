package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MatchParensTest {

    @Test
    void testMatchParens_ValidConcatenation1() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("()(", ")")));
    }

    @Test
    void testMatchParens_InvalidConcatenation1() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList(")", ")")));
    }

    @Test
    void testMatchParens_InvalidConcatenation2() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("(()(())", "())())")));
    }

    @Test
    void testMatchParens_ValidConcatenation2() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList(")())", "(()()(")));
    }

    @Test
    void testMatchParens_ValidConcatenation3() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(())))", "(()())((")));
    }

    @Test
    void testMatchParens_InvalidConcatenation3() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("()", "())")));
    }

    @Test
    void testMatchParens_ValidConcatenation4() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(()(", "()))()")));
    }

    @Test
    void testMatchParens_InvalidConcatenation4() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("((((", "((())")));
    }

    @Test
    void testMatchParens_InvalidConcatenation5() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList(")(()", "(()(")));
    }

    @Test
    void testMatchParens_InvalidConcatenation6() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList(")(", ")(")));
    }

    @Test
    void testMatchParens_ValidSinglePair() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(", ")")));
    }

    @Test
    void testMatchParens_ValidSinglePairReversed() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList(")", "(")));
    }

    @Test
    void testMatchParens_EmptyStrings() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("", "")));
    }

    @Test
    void testMatchParens_OnlyOpenParentheses() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("((((", "(((((")));
    }

    @Test
    void testMatchParens_OnlyCloseParentheses() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("))))", "))))")));
    }

    @Test
    void testMatchParens_OneOpenOneClose() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(", ")")));
    }

    @Test
    void testMatchParens_OneCloseOneOpen() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList(")", "(")));
    }

    @Test
    void testMatchParens_MixedValid() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("()()", "(())")));
    }

    @Test
    void testMatchParens_MixedInvalid() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("())", "(()")));
    }

    @Test
    void testMatchParens_ComplexValid() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(()", "())()")));
    }

    @Test
    void testMatchParens_ComplexInvalid() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("())(", "())")));
    }

    @Test
    void testMatchParens_ValidLongSequence() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(((((((((", "))))))))")));
    }

    @Test
    void testMatchParens_InvalidLongSequence() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("(((((", "))))")));
    }

    @Test
    void testMatchParens_ValidEdgeCase1() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("(", ")))")));
    }

    @Test
    void testMatchParens_ValidEdgeCase2() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList(")))", "(")));
    }

    @Test
    void testMatchParens_ValidEdgeCase3() {
        assertEquals("Yes", MatchParens.matchParens(Arrays.asList("()", "()")));
    }

    @Test
    void testMatchParens_InvalidEdgeCase1() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList(")", "(")));
    }

    @Test
    void testMatchParens_InvalidEdgeCase2() {
        assertEquals("No", MatchParens.matchParens(Arrays.asList("))", ")")));
    }
}