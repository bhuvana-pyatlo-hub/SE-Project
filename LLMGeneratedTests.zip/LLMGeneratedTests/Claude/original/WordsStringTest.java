package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WordsStringTest {

    @Test
    void testWordsStringWithNormalInput() {
        assertEquals(List.of("Hi", "my", "name", "is", "John"), WordsString.wordsString("Hi, my name is John"));
        assertEquals(List.of("One", "two", "three", "four", "five", "six"), WordsString.wordsString("One, two, three, four, five, six"));
        assertEquals(List.of("Hi", "my", "name"), WordsString.wordsString("Hi, my name"));
    }

    @Test
    void testWordsStringWithExtraCommasAndSpaces() {
        assertEquals(List.of("One", "two", "three", "four", "five", "six"), WordsString.wordsString("One,, two, three, four, five, six,"));
        assertEquals(List.of("ahmed", "gamal"), WordsString.wordsString("ahmed     , gamal"));
    }

    @Test
    void testWordsStringWithEmptyInput() {
        assertEquals(List.of(), WordsString.wordsString(""));
    }

    @Test
    void testWordsStringWithOnlySpaces() {
        assertEquals(List.of(), WordsString.wordsString("     "));
    }

    @Test
    void testWordsStringWithSingleWord() {
        assertEquals(List.of("Hello"), WordsString.wordsString("Hello"));
    }

    @Test
    void testWordsStringWithMultipleSpacesBetweenWords() {
        assertEquals(List.of("Hello", "World"), WordsString.wordsString("Hello     World"));
    }

    @Test
    void testWordsStringWithLeadingAndTrailingSpaces() {
        assertEquals(List.of("Hello", "World"), WordsString.wordsString("   Hello, World   "));
    }

    @Test
    void testWordsStringWithOnlyCommas() {
        assertEquals(List.of(), WordsString.wordsString(", , , ,"));
    }

    @Test
    void testWordsStringWithSingleComma() {
        assertEquals(List.of(), WordsString.wordsString(","));
    }

    @Test
    void testWordsStringWithMixedInput() {
        assertEquals(List.of("One", "two", "three", "four", "five", "six"), WordsString.wordsString("One, two, three, four, five, six"));
        assertEquals(List.of("A", "B", "C"), WordsString.wordsString("A, B, C"));
    }
}