package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class EncryptTest {

    @Test
    void testEncryptWithLowercaseLetters() {
        assertEquals("lm", Encrypt.encrypt("hi")); // Basic case
        assertEquals("ewhjklnop", Encrypt.encrypt("asdfghjkl")); // Longer string
        assertEquals("kj", Encrypt.encrypt("gf")); // Short string
        assertEquals("ix", Encrypt.encrypt("et")); // Short string
        assertEquals("jeiajeaijeiak", Encrypt.encrypt("faewfawefaewg")); // Repeated characters
        assertEquals("lippsqcjvmirh", Encrypt.encrypt("hellomyfriend")); // Longer string
        assertEquals("hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl", Encrypt.encrypt("dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh")); // Very long string
    }

    @Test
    void testEncryptWithSingleCharacter() {
        assertEquals("e", Encrypt.encrypt("a")); // Single character
        assertEquals("g", Encrypt.encrypt("c")); // Single character
        assertEquals("i", Encrypt.encrypt("e")); // Single character
        assertEquals("k", Encrypt.encrypt("g")); // Single character
        assertEquals("m", Encrypt.encrypt("i")); // Single character
        assertEquals("o", Encrypt.encrypt("k")); // Single character
        assertEquals("q", Encrypt.encrypt("m")); // Single character
        assertEquals("s", Encrypt.encrypt("o")); // Single character
        assertEquals("u", Encrypt.encrypt("q")); // Single character
        assertEquals("w", Encrypt.encrypt("s")); // Single character
        assertEquals("y", Encrypt.encrypt("u")); // Single character
        assertEquals("a", Encrypt.encrypt("w")); // Wrap around
        assertEquals("c", Encrypt.encrypt("y")); // Wrap around
    }

    @Test
    void testEncryptWithCharactersOutsideRange() {
        assertEquals(" ", Encrypt.encrypt(" ")); // Space character
        assertEquals("1", Encrypt.encrypt("1")); // Non-letter character
        assertEquals("!", Encrypt.encrypt("!")); // Non-letter character
        assertEquals("@", Encrypt.encrypt("@")); // Non-letter character
        assertEquals("#", Encrypt.encrypt("#")); // Non-letter character
        assertEquals("Z", Encrypt.encrypt("Z")); // Uppercase letter (not handled)
    }

    @Test
    void testEncryptWithEmptyString() {
        assertEquals("", Encrypt.encrypt("")); // Empty string
    }

    @Test
    void testEncryptWithUppercaseLetters() {
        assertEquals("A", Encrypt.encrypt("Y")); // Uppercase letter (not handled)
        assertEquals("B", Encrypt.encrypt("Z")); // Uppercase letter (not handled)
        assertEquals("C", Encrypt.encrypt("A")); // Uppercase letter (not handled)
        assertEquals("D", Encrypt.encrypt("B")); // Uppercase letter (not handled)
        assertEquals("E", Encrypt.encrypt("C")); // Uppercase letter (not handled)
    }

    @Test
    void testEncryptWithMixedContent() {
        assertEquals("e1g", Encrypt.encrypt("a1c")); // Mixed content
        assertEquals(" ", Encrypt.encrypt(" ")); // Space character
        assertEquals("!", Encrypt.encrypt("!")); // Non-letter character
        assertEquals("1", Encrypt.encrypt("1")); // Non-letter character
        assertEquals("A", Encrypt.encrypt("Y")); // Uppercase letter (not handled)
        assertEquals("B", Encrypt.encrypt("Z")); // Uppercase letter (not handled)
    }
}