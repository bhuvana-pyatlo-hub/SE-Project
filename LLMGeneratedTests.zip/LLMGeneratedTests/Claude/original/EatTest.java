package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EatTest {

    @Test
    void testEatEnoughCarrots() {
        assertEquals(List.of(11, 4), Eat.eat(5, 6, 10)); // Basic case
        assertEquals(List.of(12, 1), Eat.eat(4, 8, 9)); // Basic case
        assertEquals(List.of(11, 0), Eat.eat(1, 10, 10)); // Basic case
        assertEquals(List.of(9, 2), Eat.eat(4, 5, 7)); // Basic case
        assertEquals(List.of(10, 0), Eat.eat(10, 0, 0)); // Need is zero
    }

    @Test
    void testEatNotEnoughCarrots() {
        assertEquals(List.of(7, 0), Eat.eat(2, 11, 5)); // Edge case
        assertEquals(List.of(5, 0), Eat.eat(4, 5, 1)); // Edge case
        assertEquals(List.of(10, 0), Eat.eat(10, 5, 0)); // Remaining is zero
    }

    @Test
    void testEdgeCases() {
        assertEquals(List.of(0, 0), Eat.eat(0, 0, 0)); // All inputs are zero
        assertEquals(List.of(100, 0), Eat.eat(100, 0, 0)); // Need is zero
        assertEquals(List.of(100, 0), Eat.eat(0, 100, 100)); // Remaining is enough
        assertEquals(List.of(10, 0), Eat.eat(10, 100, 100)); // Need exceeds remaining
        assertEquals(List.of(10, 0), Eat.eat(10, 10, 0)); // Remaining is zero
    }

    @Test
    void testNegativeInputs() {
        assertEquals(List.of(0, 0), Eat.eat(-1, -1, -1)); // Invalid inputs, should treat as zero
        assertEquals(List.of(0, 0), Eat.eat(-10, 10, 10)); // Invalid number of eaten carrots
        assertEquals(List.of(0, 0), Eat.eat(10, -10, 10)); // Invalid need
        assertEquals(List.of(0, 0), Eat.eat(10, 10, -10)); // Invalid remaining
    }

    @Test
    void testBoundaryValues() {
        assertEquals(List.of(100, 0), Eat.eat(100, 100, 100)); // Maximum valid inputs
        assertEquals(List.of(100, 0), Eat.eat(100, 0, 100)); // Maximum eaten, zero need
        assertEquals(List.of(0, 0), Eat.eat(0, 100, 100)); // Minimum eaten, need exceeds remaining
    }
}