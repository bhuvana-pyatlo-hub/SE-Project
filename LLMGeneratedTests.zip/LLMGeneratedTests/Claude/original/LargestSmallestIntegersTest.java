package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LargestSmallestIntegersTest {

    @Test
    void testWithOnlyPositiveIntegers() {
        List<Object> input = Arrays.asList(2, 4, 1, 3, 5, 7);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithOnlyNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -3, -5, -6);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithMixedIntegers() {
        List<Object> input = Arrays.asList(1, 3, 2, 4, 5, 6, -2);
        List<Integer> expected = Arrays.asList(-2, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithZeroOnly() {
        List<Object> input = Arrays.asList(0);
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithEmptyList() {
        List<Object> input = Arrays.asList();
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithNegativeAndZero() {
        List<Object> input = Arrays.asList(-1, -3, -5, -6, 0);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithNegativeAndPositiveIntegers() {
        List<Object> input = Arrays.asList(-6, -4, -4, -3, 1);
        List<Integer> expected = Arrays.asList(-3, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithNegativeAndPositiveIntegersWithMultipleValues() {
        List<Object> input = Arrays.asList(-6, -4, -4, -3, -100, 1);
        List<Integer> expected = Arrays.asList(-3, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithOnlyPositiveIntegersWithZero() {
        List<Object> input = Arrays.asList(2, 4, 1, 3, 5, 7, 0);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithNegativeAndPositiveIntegersWithDuplicates() {
        List<Object> input = Arrays.asList(4, 5, 3, 6, 2, 7, -7);
        List<Integer> expected = Arrays.asList(-7, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithSingleNegativeInteger() {
        List<Object> input = Arrays.asList(-10);
        List<Integer> expected = Arrays.asList(-10, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithSinglePositiveInteger() {
        List<Object> input = Arrays.asList(10);
        List<Integer> expected = Arrays.asList(null, 10);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithNegativeAndPositiveIntegersIncludingZero() {
        List<Object> input = Arrays.asList(-5, 0, 3);
        List<Integer> expected = Arrays.asList(-5, 3);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithAllZeros() {
        List<Object> input = Arrays.asList(0, 0, 0);
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithNegativeEdgeCase() {
        List<Object> input = Arrays.asList(-100, -50, -1);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testWithPositiveEdgeCase() {
        List<Object> input = Arrays.asList(1, 50, 100);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }
}