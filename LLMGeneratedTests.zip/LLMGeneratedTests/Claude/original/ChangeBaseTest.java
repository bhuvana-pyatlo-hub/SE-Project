package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ChangeBaseTest {

    @Test
    void testChangeBase_ValidInput_Base2() {
        assertEquals("1000", ChangeBase.changeBase(8, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base3() {
        assertEquals("22", ChangeBase.changeBase(8, 3));
    }

    @Test
    void testChangeBase_ValidInput_Base2_234() {
        assertEquals("11101010", ChangeBase.changeBase(234, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base2_16() {
        assertEquals("10000", ChangeBase.changeBase(16, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base3_9() {
        assertEquals("100", ChangeBase.changeBase(9, 3));
    }

    @Test
    void testChangeBase_ValidInput_Base2_7() {
        assertEquals("111", ChangeBase.changeBase(7, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base3_2() {
        assertEquals("2", ChangeBase.changeBase(2, 3));
    }

    @Test
    void testChangeBase_ValidInput_Base4_3() {
        assertEquals("3", ChangeBase.changeBase(3, 4));
    }

    @Test
    void testChangeBase_ValidInput_Base5_4() {
        assertEquals("4", ChangeBase.changeBase(4, 5));
    }

    @Test
    void testChangeBase_ValidInput_Base6_5() {
        assertEquals("5", ChangeBase.changeBase(5, 6));
    }

    @Test
    void testChangeBase_ValidInput_Base7_6() {
        assertEquals("6", ChangeBase.changeBase(6, 7));
    }

    @Test
    void testChangeBase_ValidInput_Base8_7() {
        assertEquals("7", ChangeBase.changeBase(7, 8));
    }

    @Test
    void testChangeBase_ValidInput_Zero() {
        assertEquals("", ChangeBase.changeBase(0, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base10() {
        assertEquals("10", ChangeBase.changeBase(10, 10));
    }

    @Test
    void testChangeBase_ValidInput_Base9() {
        assertEquals("11", ChangeBase.changeBase(10, 9));
    }

    @Test
    void testChangeBase_ValidInput_Base3_1() {
        assertEquals("1", ChangeBase.changeBase(1, 3));
    }

    @Test
    void testChangeBase_ValidInput_Base2_1() {
        assertEquals("1", ChangeBase.changeBase(1, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base2_3() {
        assertEquals("11", ChangeBase.changeBase(3, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base2_4() {
        assertEquals("100", ChangeBase.changeBase(4, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base2_5() {
        assertEquals("101", ChangeBase.changeBase(5, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base2_6() {
        assertEquals("110", ChangeBase.changeBase(6, 2));
    }

    @Test
    void testChangeBase_ValidInput_Base2_8() {
        assertEquals("1000", ChangeBase.changeBase(8, 2));
    }

    @Test
    void testChangeBase_InvalidInput_NegativeBase() {
        assertEquals("", ChangeBase.changeBase(10, -2));
    }

    @Test
    void testChangeBase_InvalidInput_ZeroBase() {
        assertEquals("", ChangeBase.changeBase(10, 0));
    }

    @Test
    void testChangeBase_InvalidInput_NegativeNumber() {
        assertEquals("", ChangeBase.changeBase(-10, 2));
    }
}