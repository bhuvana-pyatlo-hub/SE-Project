package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SeparateParenGroupsTest {

    @Test
    void testSeparateParenGroupsWithMultipleGroups() {
        List<String> result = SeparateParenGroups.separateParenGroups("(()()) ((())) () ((())()())");
        assertEquals(List.of("(()())", "((()))", "()", "((())()())"), result);
    }

    @Test
    void testSeparateParenGroupsWithDifferentNestedGroups() {
        List<String> result = SeparateParenGroups.separateParenGroups("() (()) ((())) (((())))");
        assertEquals(List.of("()", "(())", "((()))", "(((())))"), result);
    }

    @Test
    void testSeparateParenGroupsWithSingleGroup() {
        List<String> result = SeparateParenGroups.separateParenGroups("(()(())((())))");
        assertEquals(List.of("(()(())((())))"), result);
    }

    @Test
    void testSeparateParenGroupsWithSpaces() {
        List<String> result = SeparateParenGroups.separateParenGroups("( ) (( )) (( )( ))");
        assertEquals(List.of("()", "(())", "(()())"), result);
    }

    @Test
    void testSeparateParenGroupsWithEmptyString() {
        List<String> result = SeparateParenGroups.separateParenGroups("");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithNoParentheses() {
        List<String> result = SeparateParenGroups.separateParenGroups("abc def");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithSingleOpenParenthesis() {
        List<String> result = SeparateParenGroups.separateParenGroups("(");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithSingleCloseParenthesis() {
        List<String> result = SeparateParenGroups.separateParenGroups(")");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithUnbalancedParentheses() {
        List<String> result = SeparateParenGroups.separateParenGroups("(()");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithAllOpenParentheses() {
        List<String> result = SeparateParenGroups.separateParenGroups("(((((");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithAllCloseParentheses() {
        List<String> result = SeparateParenGroups.separateParenGroups(")))))");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithMixedCharacters() {
        List<String> result = SeparateParenGroups.separateParenGroups("a(b)c(d)e(f)g");
        assertEquals(List.of("()", "()", "()", "()"), result);
    }

    @Test
    void testSeparateParenGroupsWithNestedGroups() {
        List<String> result = SeparateParenGroups.separateParenGroups("((()))((()))");
        assertEquals(List.of("((()))", "((()))"), result);
    }

    @Test
    void testSeparateParenGroupsWithAdjacentGroups() {
        List<String> result = SeparateParenGroups.separateParenGroups("()()()()");
        assertEquals(List.of("()", "()", "()", "()"), result);
    }

    @Test
    void testSeparateParenGroupsWithComplexInput() {
        List<String> result = SeparateParenGroups.separateParenGroups("() (()) () () (())");
        assertEquals(List.of("()", "(())", "()", "()", "(())"), result);
    }

    @Test
    void testSeparateParenGroupsWithLeadingSpaces() {
        List<String> result = SeparateParenGroups.separateParenGroups("   ()   (())   ");
        assertEquals(List.of("()", "(())"), result);
    }

    @Test
    void testSeparateParenGroupsWithTrailingSpaces() {
        List<String> result = SeparateParenGroups.separateParenGroups("() (())   ");
        assertEquals(List.of("()", "(())"), result);
    }

    @Test
    void testSeparateParenGroupsWithSpacesBetweenGroups() {
        List<String> result = SeparateParenGroups.separateParenGroups("()   ()   ()");
        assertEquals(List.of("()", "()", "()"), result);
    }

    @Test
    void testSeparateParenGroupsWithNoSpaces() {
        List<String> result = SeparateParenGroups.separateParenGroups("()()()()");
        assertEquals(List.of("()", "()", "()", "()"), result);
    }

    @Test
    void testSeparateParenGroupsWithSingleGroupWithSpaces() {
        List<String> result = SeparateParenGroups.separateParenGroups(" ( ) ");
        assertEquals(List.of("()"), result);
    }

    @Test
    void testSeparateParenGroupsWithInvalidInput() {
        List<String> result = SeparateParenGroups.separateParenGroups("1234");
        assertEquals(List.of(), result);
    }

    @Test
    void testSeparateParenGroupsWithSpecialCharacters() {
        List<String> result = SeparateParenGroups.separateParenGroups("!@#$%^&*()_+");
        assertEquals(List.of("()"), result);
    }
}