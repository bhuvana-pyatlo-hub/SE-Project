package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UniqueTest {

    @Test
    void testUniqueWithDuplicates() {
        List<Integer> input = Arrays.asList(5, 3, 5, 2, 3, 3, 9, 0, 123);
        List<Integer> expected = Arrays.asList(0, 2, 3, 5, 9, 123);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithNoDuplicates() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithAllDuplicates() {
        List<Integer> input = Arrays.asList(7, 7, 7, 7);
        List<Integer> expected = Collections.singletonList(7);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithEmptyList() {
        List<Integer> input = Collections.emptyList();
        List<Integer> expected = Collections.emptyList();
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithNegativeNumbers() {
        List<Integer> input = Arrays.asList(-1, -2, -1, -3, -2);
        List<Integer> expected = Arrays.asList(-3, -2, -1);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithMixedNumbers() {
        List<Integer> input = Arrays.asList(-1, 0, 1, -1, 2, -2);
        List<Integer> expected = Arrays.asList(-2, -1, 0, 1, 2);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithLargeRange() {
        List<Integer> input = Arrays.asList(100, -100, 0, 50, -50, 100, -100);
        List<Integer> expected = Arrays.asList(-100, -50, 0, 50, 100);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithZeroes() {
        List<Integer> input = Arrays.asList(0, 0, 0, 0);
        List<Integer> expected = Collections.singletonList(0);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithSingleElement() {
        List<Integer> input = Collections.singletonList(42);
        List<Integer> expected = Collections.singletonList(42);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUniqueWithNegativeAndPositiveBoundaryValues() {
        List<Integer> input = Arrays.asList(-100, 100, -100, 100, 0);
        List<Integer> expected = Arrays.asList(-100, 0, 100);
        assertEquals(expected, Unique.unique(input));
    }
}