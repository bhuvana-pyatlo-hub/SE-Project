package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CycpatternCheckTest {

    @Test
    void testCycpatternCheck() {
        // Basic cases
        assertFalse(CycpatternCheck.cycpatternCheck("abcd", "abd")); // No rotation matches
        assertTrue(CycpatternCheck.cycpatternCheck("hello", "ell")); // "ell" is a substring
        assertFalse(CycpatternCheck.cycpatternCheck("whassup", "psus")); // No rotation matches
        assertTrue(CycpatternCheck.cycpatternCheck("abab", "baa")); // "baa" is a rotation
        assertFalse(CycpatternCheck.cycpatternCheck("efef", "eeff")); // No rotation matches
        assertTrue(CycpatternCheck.cycpatternCheck("himenss", "simen")); // "simen" is a rotation

        // Edge cases
        assertFalse(CycpatternCheck.cycpatternCheck("xyzw", "xyw")); // No rotation matches
        assertTrue(CycpatternCheck.cycpatternCheck("yello", "ell")); // "ell" is a substring
        assertFalse(CycpatternCheck.cycpatternCheck("whattup", "ptut")); // No rotation matches
        assertTrue(CycpatternCheck.cycpatternCheck("efef", "fee")); // "fee" is a rotation
        assertFalse(CycpatternCheck.cycpatternCheck("abab", "aabb")); // No rotation matches
        assertTrue(CycpatternCheck.cycpatternCheck("winemtt", "tinem")); // "tinem" is a rotation

        // Invalid inputs
        assertFalse(CycpatternCheck.cycpatternCheck("", "a")); // First string empty
        assertFalse(CycpatternCheck.cycpatternCheck("a", "")); // Second string empty
        assertFalse(CycpatternCheck.cycpatternCheck("", "")); // Both strings empty
        assertFalse(CycpatternCheck.cycpatternCheck("abc", "abcd")); // Second string longer
        assertFalse(CycpatternCheck.cycpatternCheck("abc", "ab")); // Second string shorter, no rotation

        // Boundary values
        assertTrue(CycpatternCheck.cycpatternCheck("a", "a")); // Single character match
        assertFalse(CycpatternCheck.cycpatternCheck("a", "b")); // Single character no match
        assertTrue(CycpatternCheck.cycpatternCheck("abc", "abc")); // Exact match
        assertTrue(CycpatternCheck.cycpatternCheck("abc", "cab")); // "cab" is a rotation
        assertFalse(CycpatternCheck.cycpatternCheck("abc", "xyz")); // No rotation matches
    }
}