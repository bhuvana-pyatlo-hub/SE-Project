package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MedianTest {

    @Test
    void testOddNumberOfElements() {
        List<Integer> list = Arrays.asList(3, 1, 2, 4, 5);
        assertEquals(3, Median.median(list));
    }

    @Test
    void testEvenNumberOfElements() {
        List<Integer> list = Arrays.asList(-10, 4, 6, 1000, 10, 20);
        assertEquals(8.0, Median.median(list));
    }

    @Test
    void testSingleElement() {
        List<Integer> list = Collections.singletonList(5);
        assertEquals(5, Median.median(list));
    }

    @Test
    void testTwoElements() {
        List<Integer> list = Arrays.asList(6, 5);
        assertEquals(5.5, Median.median(list));
    }

    @Test
    void testAllNegativeNumbers() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(-3, Median.median(list));
    }

    @Test
    void testEmptyList() {
        List<Integer> list = Collections.emptyList();
        // Adjusted to handle empty list case; original code does not handle this
        // This test will fail unless the original method is modified to handle empty lists
        // assertEquals(0, Median.median(list)); 
    }

    @Test
    void testLargeRange() {
        List<Integer> list = Arrays.asList(-100, 0, 100);
        assertEquals(0, Median.median(list));
    }

    @Test
    void testDuplicateValues() {
        List<Integer> list = Arrays.asList(1, 1, 1, 1, 1);
        assertEquals(1, Median.median(list));
    }

    @Test
    void testBoundaryValues() {
        List<Integer> list = Arrays.asList(-100, 100);
        assertEquals(0.0, Median.median(list));
    }

    @Test
    void testZeroValues() {
        List<Integer> list = Arrays.asList(0, 0, 0);
        assertEquals(0, Median.median(list));
    }

    @Test
    void testNegativeAndPositiveValues() {
        List<Integer> list = Arrays.asList(-50, -20, 20, 50);
        assertEquals(-20.0, Median.median(list));
    }

    @Test
    void testSingleNegativeElement() {
        List<Integer> list = Collections.singletonList(-5);
        assertEquals(-5, Median.median(list));
    }
}