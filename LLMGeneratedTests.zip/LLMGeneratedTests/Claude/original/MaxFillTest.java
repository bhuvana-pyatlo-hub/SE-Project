package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MaxFillTest {

    @Test
    void testMaxFillBasicCases() {
        assertEquals(6, MaxFill.maxFill(Arrays.asList(Arrays.asList(0, 0, 1, 0), Arrays.asList(0, 1, 0, 0), Arrays.asList(1, 1, 1, 1)), 1));
        assertEquals(5, MaxFill.maxFill(Arrays.asList(Arrays.asList(0, 0, 1, 1), Arrays.asList(0, 0, 0, 0), Arrays.asList(1, 1, 1, 1), Arrays.asList(0, 1, 1, 1)), 2));
        assertEquals(0, MaxFill.maxFill(Arrays.asList(Arrays.asList(0, 0, 0), Arrays.asList(0, 0, 0)), 5));
    }

    @Test
    void testMaxFillEdgeCases() {
        assertEquals(4, MaxFill.maxFill(Arrays.asList(Arrays.asList(1, 1, 1, 1), Arrays.asList(1, 1, 1, 1)), 2));
        assertEquals(2, MaxFill.maxFill(Arrays.asList(Arrays.asList(1, 1, 1, 1), Arrays.asList(1, 1, 1, 1)), 9));
        assertEquals(1, MaxFill.maxFill(Collections.singletonList(Collections.singletonList(1)), 1));
        assertEquals(1, MaxFill.maxFill(Collections.singletonList(Arrays.asList(1, 0, 0)), 1));
        assertEquals(1, MaxFill.maxFill(Collections.singletonList(Arrays.asList(0, 1, 0)), 1));
        assertEquals(1, MaxFill.maxFill(Collections.singletonList(Arrays.asList(0, 0, 1)), 1));
    }

    @Test
    void testMaxFillInvalidInputs() {
        assertEquals(0, MaxFill.maxFill(Collections.emptyList(), 1));
        assertEquals(0, MaxFill.maxFill(Arrays.asList(Collections.emptyList()), 1));
        assertEquals(0, MaxFill.maxFill(Arrays.asList(Arrays.asList(0, 0), Arrays.asList(0, 0)), 10));
        assertEquals(0, MaxFill.maxFill(Arrays.asList(Arrays.asList(0, 0), Arrays.asList(0, 0)), 0)); // Invalid capacity
    }

    @Test
    void testMaxFillBoundaryValues() {
        assertEquals(1, MaxFill.maxFill(Arrays.asList(Arrays.asList(1)), 1)); // Minimum grid
        assertEquals(1, MaxFill.maxFill(Arrays.asList(Arrays.asList(1)), 2)); // Capacity greater than water
        assertEquals(2, MaxFill.maxFill(Arrays.asList(Arrays.asList(1, 1)), 1)); // Minimum capacity
        assertEquals(0, MaxFill.maxFill(Arrays.asList(Arrays.asList(0)), 1)); // No water
    }

    @Test
    void testMaxFillLargeInput() {
        assertEquals(100, MaxFill.maxFill(Arrays.asList(Collections.nCopies(100, 1)), 1));
        assertEquals(10, MaxFill.maxFill(Arrays.asList(Collections.nCopies(100, 1)), 10));
    }
}