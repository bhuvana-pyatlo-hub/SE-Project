package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RescaleToUnitTest {

    @Test
    void testBasicCases() {
        assertEquals(Arrays.asList(0.0, 0.25, 0.5, 0.75, 1.0), RescaleToUnit.rescaleToUnit(Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0)));
        assertEquals(Arrays.asList(0.0, 1.0), RescaleToUnit.rescaleToUnit(Arrays.asList(2.0, 49.9)));
        assertEquals(Arrays.asList(1.0, 0.0), RescaleToUnit.rescaleToUnit(Arrays.asList(100.0, 49.9)));
        assertEquals(Arrays.asList(0.25, 0.0, 1.0, 0.5, 0.75), RescaleToUnit.rescaleToUnit(Arrays.asList(2.0, 1.0, 5.0, 3.0, 4.0)));
        assertEquals(Arrays.asList(0.25, 0.0, 1.0, 0.5, 0.75), RescaleToUnit.rescaleToUnit(Arrays.asList(12.0, 11.0, 15.0, 13.0, 14.0)));
    }

    @Test
    void testEdgeCases() {
        assertEquals(Arrays.asList(0.0, 1.0), RescaleToUnit.rescaleToUnit(Arrays.asList(-100.0, 100.0)));
        assertEquals(Arrays.asList(0.0, 0.0), RescaleToUnit.rescaleToUnit(Arrays.asList(0.0, 0.0)));
        assertEquals(Arrays.asList(0.0, 0.5, 1.0), RescaleToUnit.rescaleToUnit(Arrays.asList(0.0, 50.0, 100.0)));
        assertEquals(Arrays.asList(0.0, 0.5, 1.0), RescaleToUnit.rescaleToUnit(Arrays.asList(-50.0, 0.0, 50.0)));
        assertEquals(Arrays.asList(0.0, 0.0, 0.0), RescaleToUnit.rescaleToUnit(Arrays.asList(-1.0, -1.0, -1.0)));
    }

    @Test
    void testInvalidInputs() {
        assertThrows(IndexOutOfBoundsException.class, () -> RescaleToUnit.rescaleToUnit(Arrays.asList(1.0)));
        assertThrows(IndexOutOfBoundsException.class, () -> RescaleToUnit.rescaleToUnit(Arrays.asList()));
        assertThrows(IndexOutOfBoundsException.class, () -> RescaleToUnit.rescaleToUnit(Arrays.asList(-1.0)));
    }
}