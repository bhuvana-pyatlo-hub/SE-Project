package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CompareTest {

    @Test
    void testCompareAllCorrectGuesses() {
        List<Integer> game = Arrays.asList(1, 2, 3, 4, 5, 1);
        List<Integer> guess = Arrays.asList(1, 2, 3, 4, 2, -2);
        List<Integer> expected = Arrays.asList(0, 0, 0, 0, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareAllZeros() {
        List<Integer> game = Arrays.asList(0, 0, 0, 0, 0, 0);
        List<Integer> guess = Arrays.asList(0, 0, 0, 0, 0, 0);
        List<Integer> expected = Arrays.asList(0, 0, 0, 0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareNegativeGuesses() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(-1, -2, -3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareMixedGuesses() {
        List<Integer> game = Arrays.asList(1, 2, 3, 5);
        List<Integer> guess = Arrays.asList(-1, 2, 3, 4);
        List<Integer> expected = Arrays.asList(2, 0, 0, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareEdgeValues() {
        List<Integer> game = Arrays.asList(-100, 100, 0);
        List<Integer> guess = Arrays.asList(100, -100, 0);
        List<Integer> expected = Arrays.asList(200, 200, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareSingleElement() {
        List<Integer> game = Arrays.asList(50);
        List<Integer> guess = Arrays.asList(50);
        List<Integer> expected = Arrays.asList(0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareDifferentLengths() {
        List<Integer> game = Arrays.asList(1, 2);
        List<Integer> guess = Arrays.asList(1);
        // This case is not defined in the original method, but we can test it for robustness.
        // Assuming we want to handle it gracefully, we can catch an exception.
        try {
            Compare.compare(game, guess);
        } catch (IndexOutOfBoundsException e) {
            assertEquals("Index 1 out of bounds for length 1", e.getMessage());
        }
    }

    @Test
    void testCompareEmptyLists() {
        List<Integer> game = Arrays.asList();
        List<Integer> guess = Arrays.asList();
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void testCompareBoundaryValues() {
        List<Integer> game = Arrays.asList(-100, 100);
        List<Integer> guess = Arrays.asList(100, -100);
        List<Integer> expected = Arrays.asList(200, 200);
        assertEquals(expected, Compare.compare(game, guess));
    }
}