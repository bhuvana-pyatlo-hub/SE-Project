package original;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class LargestDivisorTest {

    @Test
    void testLargestDivisorWithEvenNumber() {
        assertEquals(5, LargestDivisor.largestDivisor(10));
    }

    @Test
    void testLargestDivisorWithOddNumber() {
        assertEquals(7, LargestDivisor.largestDivisor(49));
    }

    @Test
    void testLargestDivisorWithPrimeNumber() {
        assertEquals(1, LargestDivisor.largestDivisor(3));
    }

    @Test
    void testLargestDivisorWithAnotherPrimeNumber() {
        assertEquals(1, LargestDivisor.largestDivisor(7));
    }

    @Test
    void testLargestDivisorWithCompositeNumber() {
        assertEquals(50, LargestDivisor.largestDivisor(100));
    }

    @Test
    void testLargestDivisorWithSmallestCompositeNumber() {
        assertEquals(1, LargestDivisor.largestDivisor(4));
    }

    @Test
    void testLargestDivisorWithSmallestPrimeNumber() {
        assertEquals(1, LargestDivisor.largestDivisor(2));
    }

    @Test
    void testLargestDivisorWithNumberOne() {
        assertEquals(1, LargestDivisor.largestDivisor(1));
    }

    @Test
    void testLargestDivisorWithNumberFifteen() {
        assertEquals(5, LargestDivisor.largestDivisor(15));
    }

    @Test
    void testLargestDivisorWithNumberTwenty() {
        assertEquals(10, LargestDivisor.largestDivisor(20));
    }

    @Test
    void testLargestDivisorWithNumberThirty() {
        assertEquals(15, LargestDivisor.largestDivisor(30));
    }

    @Test
    void testLargestDivisorWithNumberSix() {
        assertEquals(3, LargestDivisor.largestDivisor(6));
    }

    @Test
    void testLargestDivisorWithNumberEight() {
        assertEquals(4, LargestDivisor.largestDivisor(8));
    }

    @Test
    void testLargestDivisorWithNumberNineteen() {
        assertEquals(1, LargestDivisor.largestDivisor(19));
    }

    @Test
    void testLargestDivisorWithNumberTwentyFive() {
        assertEquals(5, LargestDivisor.largestDivisor(25));
    }

    @Test
    void testLargestDivisorWithNumberThirtyFive() {
        assertEquals(7, LargestDivisor.largestDivisor(35));
    }

    @Test
    void testLargestDivisorWithNumberForty() {
        assertEquals(20, LargestDivisor.largestDivisor(40));
    }

    @Test
    void testLargestDivisorWithNumberFifty() {
        assertEquals(25, LargestDivisor.largestDivisor(50));
    }

    @Test
    void testLargestDivisorWithNumberSixty() {
        assertEquals(30, LargestDivisor.largestDivisor(60));
    }

    @Test
    void testLargestDivisorWithNumberSeventy() {
        assertEquals(35, LargestDivisor.largestDivisor(70));
    }

    @Test
    void testLargestDivisorWithNumberEighty() {
        assertEquals(40, LargestDivisor.largestDivisor(80));
    }

    @Test
    void testLargestDivisorWithNumberNinety() {
        assertEquals(45, LargestDivisor.largestDivisor(90));
    }

    @Test
    void testLargestDivisorWithNegativeNumber() {
        assertEquals(1, LargestDivisor.largestDivisor(-10));
    }

    @Test
    void testLargestDivisorWithZero() {
        assertEquals(1, LargestDivisor.largestDivisor(0));
    }
}