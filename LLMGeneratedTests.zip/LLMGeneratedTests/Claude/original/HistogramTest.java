package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HistogramTest {

    @Test
    void testEmptyString() {
        assertEquals(new HashMap<>(), Histogram.histogram(""));
    }

    @Test
    void testSingleCharacter() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        assertEquals(expected, Histogram.histogram("a"));
    }

    @Test
    void testMultipleUniqueCharacters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        expected.put("c", 1);
        expected.put("d", 1);
        expected.put("g", 1);
        assertEquals(expected, Histogram.histogram("a b c d g"));
    }

    @Test
    void testMultipleOccurrences() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b b a"));
    }

    @Test
    void testMaxRepetition() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("b", 4);
        assertEquals(expected, Histogram.histogram("b b b b a"));
    }

    @Test
    void testMultipleMaxRepetitions() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b c a b"));
    }

    @Test
    void testNullInput() {
        assertEquals(new HashMap<>(), Histogram.histogram(null));
    }

    @Test
    void testSingleCharacterRepeated() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 5);
        assertEquals(expected, Histogram.histogram("a a a a a"));
    }

    @Test
    void testAllSameCharacters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("x", 3);
        assertEquals(expected, Histogram.histogram("x x x"));
    }

    @Test
    void testNegativeAndZeroValues() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("0", 1);
        expected.put("-1", 1);
        assertEquals(expected, Histogram.histogram("0 -1"));
    }

    @Test
    void testLeadingAndTrailingSpaces() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        assertEquals(expected, Histogram.histogram("  a  b  "));
    }

    @Test
    void testMultipleSpacesBetweenWords() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        assertEquals(expected, Histogram.histogram("a    b"));
    }
}