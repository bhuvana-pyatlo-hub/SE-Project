package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IntersperseTest {

    @Test
    void testIntersperseEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseSingleElement() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseMultipleElements() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, 4, 2, 4, 3);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseWithNegativeDelimiter() {
        List<Object> input = Arrays.asList(5, 6, 3, 2);
        List<Object> expected = Arrays.asList(5, -8, 6, -8, 3, -8, 2);
        assertEquals(expected, Intersperse.intersperse(input, -8));
    }

    @Test
    void testIntersperseWithZeroDelimiter() {
        List<Object> input = Arrays.asList(2, 2, 2);
        List<Object> expected = Arrays.asList(2, 0, 2, 0, 2);
        assertEquals(expected, Intersperse.intersperse(input, 0));
    }

    @Test
    void testIntersperseAllSameElements() {
        List<Object> input = Arrays.asList(2, 2, 2);
        List<Object> expected = Arrays.asList(2, 2, 2, 2, 2);
        assertEquals(expected, Intersperse.intersperse(input, 2));
    }

    @Test
    void testIntersperseWithNegativeInput() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(-1, 4, -2, 4, -3);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseWithBoundaryValues() {
        List<Object> input = Arrays.asList(100, -100);
        List<Object> expected = Arrays.asList(100, 4, -100);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseWithMinimumValidInput() {
        List<Object> input = Arrays.asList(-100);
        List<Object> expected = Arrays.asList(-100);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseWithMaximumValidInput() {
        List<Object> input = Arrays.asList(100);
        List<Object> expected = Arrays.asList(100);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void testIntersperseWithInvalidDelimiter() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, -1, 2, -1, 3);
        assertEquals(expected, Intersperse.intersperse(input, -1));
    }
}