package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FilterIntegersTest {

    @Test
    void testFilterIntegersWithMixedTypes() {
        List<Object> input = Arrays.asList("a", 3.14, 5);
        List<Object> expected = Collections.singletonList(5);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithIntegersAndStrings() {
        List<Object> input = Arrays.asList(1, 2, 3, "abc", new Object(), new ArrayList<>());
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithEmptyList() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithVariousTypes() {
        List<Object> input = Arrays.asList(4, new Object(), new ArrayList<>(), 23.2, 9, "adasd");
        List<Object> expected = Arrays.asList(4, 9);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithOnlyIntegers() {
        List<Object> input = Arrays.asList(3, "c", 3, 3, "a", "b");
        List<Object> expected = Arrays.asList(3, 3, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithNegativeAndPositiveIntegers() {
        List<Object> input = Arrays.asList(-1, -2, 0, 1, 2);
        List<Object> expected = Arrays.asList(-1, -2, 0, 1, 2);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithInvalidTypes() {
        List<Object> input = Arrays.asList("string", 3.14, new Object(), true);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 0, 100);
        List<Object> expected = Arrays.asList(-100, 0, 100);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegersWithOnlyInvalidTypes() {
        List<Object> input = Arrays.asList("text", 3.14, new Object(), false);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }
}