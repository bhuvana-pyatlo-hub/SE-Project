package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MeanAbsoluteDeviationTest {

    @Test
    void testMeanAbsoluteDeviationBasicCases() {
        List<Double> numbers1 = Arrays.asList(1.0, 2.0, 3.0);
        assertEquals(0.6666666666666666, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers1));

        List<Double> numbers2 = Arrays.asList(1.0, 2.0, 3.0, 4.0);
        assertEquals(1.0, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers2));

        List<Double> numbers3 = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        assertEquals(1.2, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers3));
    }

    @Test
    void testMeanAbsoluteDeviationEdgeCases() {
        List<Double> numbers4 = Collections.singletonList(0.0);
        assertEquals(0.0, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers4));

        List<Double> numbers5 = Arrays.asList(-1.0, 0.0, 1.0);
        assertEquals(0.6666666666666666, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers5));

        List<Double> numbers6 = Arrays.asList(-100.0, 0.0, 100.0);
        assertEquals(66.66666666666667, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers6));

        List<Double> numbers7 = Arrays.asList(-50.0, 0.0, 50.0);
        assertEquals(50.0, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers7));
    }

    @Test
    void testMeanAbsoluteDeviationInvalidInput() {
        List<Double> numbers8 = Arrays.asList();
        assertEquals(Double.NaN, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers8));
    }

    @Test
    void testMeanAbsoluteDeviationSingleNegativeValue() {
        List<Double> numbers9 = Collections.singletonList(-42.0);
        assertEquals(0.0, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers9));
    }

    @Test
    void testMeanAbsoluteDeviationSinglePositiveValue() {
        List<Double> numbers10 = Collections.singletonList(42.0);
        assertEquals(0.0, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers10));
    }

    @Test
    void testMeanAbsoluteDeviationMultipleIdenticalValues() {
        List<Double> numbers11 = Arrays.asList(5.0, 5.0, 5.0);
        assertEquals(0.0, MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers11));
    }
}