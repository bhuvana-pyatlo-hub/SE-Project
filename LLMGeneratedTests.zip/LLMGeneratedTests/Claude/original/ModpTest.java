package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ModpTest {

    @Test
    void testModpWithSmallValues() {
        assertEquals(1, Modp.modp(0, 101)); // Test with n = 0
        assertEquals(3, Modp.modp(3, 5)); // Test with n = 3, p = 5
        assertEquals(8, Modp.modp(3, 11)); // Test with n = 3, p = 11
        assertEquals(1, Modp.modp(100, 101)); // Test with n = 100, p = 101
        assertEquals(4, Modp.modp(30, 5)); // Test with n = 30, p = 5
        assertEquals(3, Modp.modp(31, 5)); // Test with n = 31, p = 5
    }

    @Test
    void testModpWithBoundaryValues() {
        assertEquals(0, Modp.modp(1, 1)); // Test with p = 1
        assertEquals(1, Modp.modp(1, 2)); // Test with n = 1, p = 2
        assertEquals(0, Modp.modp(2, 2)); // Test with n = 2, p = 2
        assertEquals(1, Modp.modp(2, 3)); // Test with n = 2, p = 3
    }

    @Test
    void testModpWithNegativeAndZeroInputs() {
        assertEquals(1, Modp.modp(0, 5)); // Test with n = 0, p > 0
        assertEquals(1, Modp.modp(-1, 5)); // Test with negative n
        assertEquals(1, Modp.modp(0, -5)); // Test with negative p
        assertEquals(1, Modp.modp(0, 0)); // Test with both n and p as zero
    }

    @Test
    void testModpWithEdgeCases() {
        assertEquals(1, Modp.modp(1, 1)); // Edge case with n = 1, p = 1
        assertEquals(0, Modp.modp(1, 0)); // Edge case with p = 0
        assertEquals(1, Modp.modp(1, 2)); // Edge case with n = 1, p = 2
        assertEquals(0, Modp.modp(2, 2)); // Edge case with n = 2, p = 2
    }
}