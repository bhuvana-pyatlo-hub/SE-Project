package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FactorizeTest {

    @Test
    void testFactorizeWithInput0() {
        List<Integer> result = Factorize.factorize(0);
        assertEquals(List.of(), result);
    }

    @Test
    void testFactorizeWithInput1() {
        List<Integer> result = Factorize.factorize(1);
        assertEquals(List.of(), result);
    }

    @Test
    void testFactorizeWithInput2() {
        List<Integer> result = Factorize.factorize(2);
        assertEquals(List.of(2), result);
    }

    @Test
    void testFactorizeWithInput3() {
        List<Integer> result = Factorize.factorize(3);
        assertEquals(List.of(3), result);
    }

    @Test
    void testFactorizeWithInput4() {
        List<Integer> result = Factorize.factorize(4);
        assertEquals(List.of(2, 2), result);
    }

    @Test
    void testFactorizeWithInput5() {
        List<Integer> result = Factorize.factorize(5);
        assertEquals(List.of(5), result);
    }

    @Test
    void testFactorizeWithInput6() {
        List<Integer> result = Factorize.factorize(6);
        assertEquals(List.of(2, 3), result);
    }

    @Test
    void testFactorizeWithInput8() {
        List<Integer> result = Factorize.factorize(8);
        assertEquals(List.of(2, 2, 2), result);
    }

    @Test
    void testFactorizeWithInput9() {
        List<Integer> result = Factorize.factorize(9);
        assertEquals(List.of(3, 3), result);
    }

    @Test
    void testFactorizeWithInput10() {
        List<Integer> result = Factorize.factorize(10);
        assertEquals(List.of(2, 5), result);
    }

    @Test
    void testFactorizeWithInput12() {
        List<Integer> result = Factorize.factorize(12);
        assertEquals(List.of(2, 2, 3), result);
    }

    @Test
    void testFactorizeWithInput15() {
        List<Integer> result = Factorize.factorize(15);
        assertEquals(List.of(3, 5), result);
    }

    @Test
    void testFactorizeWithInput18() {
        List<Integer> result = Factorize.factorize(18);
        assertEquals(List.of(2, 3, 3), result);
    }

    @Test
    void testFactorizeWithInput21() {
        List<Integer> result = Factorize.factorize(21);
        assertEquals(List.of(3, 7), result);
    }

    @Test
    void testFactorizeWithInput25() {
        List<Integer> result = Factorize.factorize(25);
        assertEquals(List.of(5, 5), result);
    }

    @Test
    void testFactorizeWithInput28() {
        List<Integer> result = Factorize.factorize(28);
        assertEquals(List.of(2, 2, 7), result);
    }

    @Test
    void testFactorizeWithInput30() {
        List<Integer> result = Factorize.factorize(30);
        assertEquals(List.of(2, 3, 5), result);
    }

    @Test
    void testFactorizeWithInput35() {
        List<Integer> result = Factorize.factorize(35);
        assertEquals(List.of(5, 7), result);
    }

    @Test
    void testFactorizeWithInput49() {
        List<Integer> result = Factorize.factorize(49);
        assertEquals(List.of(7, 7), result);
    }

    @Test
    void testFactorizeWithInput70() {
        List<Integer> result = Factorize.factorize(70);
        assertEquals(List.of(2, 5, 7), result);
    }

    @Test
    void testFactorizeWithInput57() {
        List<Integer> result = Factorize.factorize(57);
        assertEquals(List.of(3, 19), result);
    }

    @Test
    void testFactorizeWithInput100() {
        List<Integer> result = Factorize.factorize(100);
        assertEquals(List.of(2, 2, 5, 5), result);
    }

    @Test
    void testFactorizeWithInput121() {
        List<Integer> result = Factorize.factorize(121);
        assertEquals(List.of(11, 11), result);
    }

    @Test
    void testFactorizeWithInput144() {
        List<Integer> result = Factorize.factorize(144);
        assertEquals(List.of(2, 2, 2, 2, 3, 3), result);
    }
}