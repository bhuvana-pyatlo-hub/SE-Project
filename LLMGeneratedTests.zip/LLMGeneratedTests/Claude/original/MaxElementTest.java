package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MaxElementTest {

    @Test
    void testMaxElementWithPositiveNumbers() {
        List<Integer> numbers = Arrays.asList(1, 2, 3);
        assertEquals(3, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithMixedNumbers() {
        List<Integer> numbers = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10);
        assertEquals(123, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithSingleElement() {
        List<Integer> numbers = Collections.singletonList(42);
        assertEquals(42, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithNegativeNumbers() {
        List<Integer> numbers = Arrays.asList(-1, -2, -3);
        assertEquals(-1, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithEmptyList() {
        List<Integer> numbers = Collections.emptyList();
        assertEquals(Integer.MIN_VALUE, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithAllSameElements() {
        List<Integer> numbers = Arrays.asList(7, 7, 7, 7);
        assertEquals(7, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithEdgeValues() {
        List<Integer> numbers = Arrays.asList(-100, 0, 100);
        assertEquals(100, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithMinimumValue() {
        List<Integer> numbers = Collections.singletonList(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithMaximumValue() {
        List<Integer> numbers = Collections.singletonList(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithZeroValue() {
        List<Integer> numbers = Collections.singletonList(0);
        assertEquals(0, MaxElement.maxElement(numbers));
    }

    @Test
    void testMaxElementWithNegativeAndPositive() {
        List<Integer> numbers = Arrays.asList(-50, -1, 0, 1, 50);
        assertEquals(50, MaxElement.maxElement(numbers));
    }
}