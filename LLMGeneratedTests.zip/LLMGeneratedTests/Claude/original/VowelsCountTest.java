package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class VowelsCountTest {

    @Test
    void testVowelsCountWithAllVowelsLowercase() {
        assertEquals(5, VowelsCount.vowelsCount("aeiou"));
    }

    @Test
    void testVowelsCountWithAllVowelsUppercase() {
        assertEquals(5, VowelsCount.vowelsCount("AEIOU"));
    }

    @Test
    void testVowelsCountWithMixedCaseVowels() {
        assertEquals(5, VowelsCount.vowelsCount("aEIoU"));
    }

    @Test
    void testVowelsCountWithNoVowels() {
        assertEquals(0, VowelsCount.vowelsCount("bcdfgh"));
    }

    @Test
    void testVowelsCountWithVowelsAndConsonants() {
        assertEquals(3, VowelsCount.vowelsCount("abcde"));
    }

    @Test
    void testVowelsCountWithUppercaseAndLowercase() {
        assertEquals(3, VowelsCount.vowelsCount("Alone"));
    }

    @Test
    void testVowelsCountWithYAtEnd() {
        assertEquals(2, VowelsCount.vowelsCount("key"));
    }

    @Test
    void testVowelsCountWithYAtEndUppercase() {
        assertEquals(2, VowelsCount.vowelsCount("keY"));
    }

    @Test
    void testVowelsCountWithYNotAtEnd() {
        assertEquals(1, VowelsCount.vowelsCount("bye"));
    }

    @Test
    void testVowelsCountWithYNotAtEndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("bYe"));
    }

    @Test
    void testVowelsCountWithYAtEndAndNoOtherVowels() {
        assertEquals(1, VowelsCount.vowelsCount("sky"));
    }

    @Test
    void testVowelsCountWithYAtEndAndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("SKY"));
    }

    @Test
    void testVowelsCountWithEmptyString() {
        assertEquals(0, VowelsCount.vowelsCount(""));
    }

    @Test
    void testVowelsCountWithSingleVowel() {
        assertEquals(1, VowelsCount.vowelsCount("a"));
    }

    @Test
    void testVowelsCountWithSingleConsonant() {
        assertEquals(0, VowelsCount.vowelsCount("b"));
    }

    @Test
    void testVowelsCountWithSingleYAtEnd() {
        assertEquals(1, VowelsCount.vowelsCount("y"));
    }

    @Test
    void testVowelsCountWithSingleYNotAtEnd() {
        assertEquals(0, VowelsCount.vowelsCount("x"));
    }

    @Test
    void testVowelsCountWithMultipleYsAtEnd() {
        assertEquals(2, VowelsCount.vowelsCount("playY"));
    }

    @Test
    void testVowelsCountWithMultipleYsNotAtEnd() {
        assertEquals(0, VowelsCount.vowelsCount("pLayY"));
    }

    @Test
    void testVowelsCountWithMixedContent() {
        assertEquals(3, VowelsCount.vowelsCount("ACEDY"));
    }

    @Test
    void testVowelsCountWithAllConsonants() {
        assertEquals(0, VowelsCount.vowelsCount("bcdfghjklmnpqrstvwxyz"));
    }

    @Test
    void testVowelsCountWithBoundaryValues() {
        assertEquals(0, VowelsCount.vowelsCount("")); // empty string
        assertEquals(1, VowelsCount.vowelsCount("a")); // single vowel
        assertEquals(0, VowelsCount.vowelsCount("b")); // single consonant
        assertEquals(1, VowelsCount.vowelsCount("y")); // single y
        assertEquals(1, VowelsCount.vowelsCount("Y")); // single uppercase y
        assertEquals(1, VowelsCount.vowelsCount("yY")); // multiple y's
    }
}