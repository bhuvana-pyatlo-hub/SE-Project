package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IncrListTest {

    @Test
    void testIncrListWithPositiveIntegers() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 3, 4);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithMixedIntegers() {
        List<Object> input = Arrays.asList(5, 3, 5, 2, 3, 3, 9, 0, 123);
        List<Object> expected = Arrays.asList(6, 4, 6, 3, 4, 4, 10, 1, 124);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithDescendingIntegers() {
        List<Object> input = Arrays.asList(3, 2, 1);
        List<Object> expected = Arrays.asList(4, 3, 2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithRepeatedIntegers() {
        List<Object> input = Arrays.asList(5, 2, 5, 2, 3, 3, 9, 0, 123);
        List<Object> expected = Arrays.asList(6, 3, 6, 3, 4, 4, 10, 1, 124);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithNonIntegerValues() {
        List<Object> input = Arrays.asList("string", 1.5, null, -1);
        List<Object> expected = Arrays.asList(0); // Only -1 is incremented
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(0, -1, -2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithZero() {
        List<Object> input = Arrays.asList(0);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 100);
        List<Object> expected = Arrays.asList(-99, 101);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void testIncrListWithAllNonIntegerValues() {
        List<Object> input = Arrays.asList("string", 1.5, null);
        List<Object> expected = new ArrayList<>(); // No integers to increment
        assertEquals(expected, IncrList.incrList(input));
    }
}