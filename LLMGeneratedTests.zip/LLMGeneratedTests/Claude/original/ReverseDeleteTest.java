package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ReverseDeleteTest {

    @Test
    void testBasicCases() {
        assertEquals(List.of("bcd", false), ReverseDelete.reverseDelete("abcde", "ae"));
        assertEquals(List.of("acdef", false), ReverseDelete.reverseDelete("abcdef", "b"));
        assertEquals(List.of("cdedc", true), ReverseDelete.reverseDelete("abcdedcba", "ab"));
        assertEquals(List.of("dik", false), ReverseDelete.reverseDelete("dwik", "w"));
    }

    @Test
    void testEdgeCases() {
        assertEquals(List.of("", true), ReverseDelete.reverseDelete("a", "a"));
        assertEquals(List.of("abcdedcba", true), ReverseDelete.reverseDelete("abcdedcba", ""));
        assertEquals(List.of("abcdedcba", true), ReverseDelete.reverseDelete("abcdedcba", "v"));
        assertEquals(List.of("abba", true), ReverseDelete.reverseDelete("vabba", "v"));
        assertEquals(List.of("", true), ReverseDelete.reverseDelete("mamma", "mia"));
    }

    @Test
    void testInvalidInputs() {
        assertEquals(List.of("", true), ReverseDelete.reverseDelete("", "a"));
        assertEquals(List.of("", true), ReverseDelete.reverseDelete("", ""));
        assertEquals(List.of("", true), ReverseDelete.reverseDelete("", "abc"));
    }

    @Test
    void testBoundaryValues() {
        assertEquals(List.of("a", true), ReverseDelete.reverseDelete("a", ""));
        assertEquals(List.of("a", true), ReverseDelete.reverseDelete("a", "b"));
        assertEquals(List.of("b", false), ReverseDelete.reverseDelete("b", "b"));
        assertEquals(List.of("c", true), ReverseDelete.reverseDelete("c", "c"));
        assertEquals(List.of("d", true), ReverseDelete.reverseDelete("d", "d"));
    }

    @Test
    void testNegativeValues() {
        assertEquals(List.of("abc", false), ReverseDelete.reverseDelete("abc", "d"));
        assertEquals(List.of("abc", false), ReverseDelete.reverseDelete("abc", "xyz"));
        assertEquals(List.of("cde", true), ReverseDelete.reverseDelete("abcde", "ab"));
        assertEquals(List.of("efg", false), ReverseDelete.reverseDelete("efg", "h"));
    }
}