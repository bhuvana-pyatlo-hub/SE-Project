package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ValidDateTest {

    @Test
    void testValidDateWithValidInput() {
        assertTrue(ValidDate.validDate("03-11-2000")); // Valid date
        assertTrue(ValidDate.validDate("06-04-2020")); // Valid date
        assertTrue(ValidDate.validDate("01-01-2007")); // Valid date
        assertTrue(ValidDate.validDate("06-06-2005")); // Valid date
        assertTrue(ValidDate.validDate("04-12-2003")); // Valid date
        assertTrue(ValidDate.validDate("02-29-2020")); // Valid leap year date
        assertTrue(ValidDate.validDate("12-31-1999")); // Valid date at year boundary
    }

    @Test
    void testValidDateWithInvalidInput() {
        assertFalse(ValidDate.validDate("15-01-2012")); // Invalid month
        assertFalse(ValidDate.validDate("04-0-2040")); // Invalid day format
        assertFalse(ValidDate.validDate("03-32-2011")); // Invalid day for month
        assertFalse(ValidDate.validDate("04-31-3000")); // Invalid day for month
        assertFalse(ValidDate.validDate("21-31-2000")); // Invalid month
        assertFalse(ValidDate.validDate("02-30-2020")); // Invalid day for February
        assertFalse(ValidDate.validDate("02-29-2021")); // Invalid day for non-leap year
        assertFalse(ValidDate.validDate("04-32-2020")); // Invalid day
        assertFalse(ValidDate.validDate("06-31-2020")); // Invalid day for June
    }

    @Test
    void testValidDateWithEmptyString() {
        assertFalse(ValidDate.validDate("")); // Empty string
    }

    @Test
    void testValidDateWithIncorrectFormat() {
        assertFalse(ValidDate.validDate("06/04/2020")); // Incorrect separator
        assertFalse(ValidDate.validDate("04122003")); // Missing separator
        assertFalse(ValidDate.validDate("20030412")); // Missing separator
        assertFalse(ValidDate.validDate("2003-04")); // Incomplete date
        assertFalse(ValidDate.validDate("2003-04-12")); // Incomplete date
        assertFalse(ValidDate.validDate("04-2003")); // Incomplete date
    }

    @Test
    void testValidDateWithBoundaryValues() {
        assertTrue(ValidDate.validDate("01-31-2020")); // Valid day for January
        assertTrue(ValidDate.validDate("12-31-2020")); // Valid day for December
        assertFalse(ValidDate.validDate("02-30-2020")); // Invalid day for February
        assertFalse(ValidDate.validDate("02-29-2021")); // Invalid day for non-leap year
        assertTrue(ValidDate.validDate("02-29-2020")); // Valid day for leap year
        assertFalse(ValidDate.validDate("04-31-2020")); // Invalid day for April
        assertFalse(ValidDate.validDate("06-31-2020")); // Invalid day for June
    }

    @Test
    void testValidDateWithEdgeCases() {
        assertFalse(ValidDate.validDate("00-01-2020")); // Invalid month
        assertFalse(ValidDate.validDate("13-01-2020")); // Invalid month
        assertFalse(ValidDate.validDate("04-00-2020")); // Invalid day
        assertFalse(ValidDate.validDate("04-32-2020")); // Invalid day
    }
}