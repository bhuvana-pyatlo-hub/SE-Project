package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetRowTest {

    @Test
    void testGetRowWithMultipleOccurrences() {
        List<Object> input = Arrays.asList(
                Arrays.asList(1, 2, 3, 4, 5, 6),
                Arrays.asList(1, 2, 3, 4, 1, 6),
                Arrays.asList(1, 2, 3, 4, 5, 1)
        );
        List<Object> expected = Arrays.asList(
                Arrays.asList(0, 0),
                Arrays.asList(1, 4),
                Arrays.asList(1, 0),
                Arrays.asList(2, 5),
                Arrays.asList(2, 0)
        );
        assertEquals(expected, GetRow.getRow(input, 1));
    }

    @Test
    void testGetRowWithEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(input, 1));
    }

    @Test
    void testGetRowWithNoMatch() {
        List<Object> input = Arrays.asList(
                Arrays.asList(2, 3, 4),
                Arrays.asList(5, 6, 7)
        );
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(input, 1));
    }

    @Test
    void testGetRowWithSingleElementNoMatch() {
        List<Object> input = Arrays.asList(
                Arrays.asList(2)
        );
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(input, 1));
    }

    @Test
    void testGetRowWithSingleElementMatch() {
        List<Object> input = Arrays.asList(
                Arrays.asList(1)
        );
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0));
        assertEquals(expected, GetRow.getRow(input, 1));
    }

    @Test
    void testGetRowWithNestedEmptyList() {
        List<Object> input = Arrays.asList(
                new ArrayList<>(),
                Arrays.asList(1),
                Arrays.asList(1, 2, 3)
        );
        List<Object> expected = Arrays.asList(Arrays.asList(2, 2));
        assertEquals(expected, GetRow.getRow(input, 3));
    }

    @Test
    void testGetRowWithMultipleRowsAndDifferentLengths() {
        List<Object> input = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(1, 1),
                Arrays.asList(2, 1, 1)
        );
        List<Object> expected = Arrays.asList(
                Arrays.asList(0, 0),
                Arrays.asList(1, 0),
                Arrays.asList(1, 1),
                Arrays.asList(2, 1),
                Arrays.asList(2, 2)
        );
        assertEquals(expected, GetRow.getRow(input, 1));
    }

    @Test
    void testGetRowWithZeroValue() {
        List<Object> input = Arrays.asList(
                Arrays.asList(0, 1, 2),
                Arrays.asList(3, 0, 5)
        );
        List<Object> expected = Arrays.asList(
                Arrays.asList(0, 0),
                Arrays.asList(1, 1)
        );
        assertEquals(expected, GetRow.getRow(input, 0));
    }

    @Test
    void testGetRowWithNegativeValue() {
        List<Object> input = Arrays.asList(
                Arrays.asList(-1, -2, -3),
                Arrays.asList(-1, 0, 1)
        );
        List<Object> expected = Arrays.asList(
                Arrays.asList(0, 0),
                Arrays.asList(1, 0)
        );
        assertEquals(expected, GetRow.getRow(input, -1));
    }

    @Test
    void testGetRowWithInvalidInput() {
        List<Object> input = Arrays.asList(
                Arrays.asList("a", "b"),
                Arrays.asList("c", "d")
        );
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(input, 1));
    }
}