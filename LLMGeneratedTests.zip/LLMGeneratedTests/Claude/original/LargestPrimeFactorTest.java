package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LargestPrimeFactorTest {

    @Test
    void testLargestPrimeFactorWithEvenNumber() {
        assertEquals(2, LargestPrimeFactor.largestPrimeFactor(2048));
    }

    @Test
    void testLargestPrimeFactorWithCompositeNumber() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(15));
    }

    @Test
    void testLargestPrimeFactorWithCubeOfPrime() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(27));
    }

    @Test
    void testLargestPrimeFactorWithMultipleFactors() {
        assertEquals(7, LargestPrimeFactor.largestPrimeFactor(63));
    }

    @Test
    void testLargestPrimeFactorWithMixedFactors() {
        assertEquals(11, LargestPrimeFactor.largestPrimeFactor(330));
    }

    @Test
    void testLargestPrimeFactorWithLargeComposite() {
        assertEquals(29, LargestPrimeFactor.largestPrimeFactor(13195));
    }

    @Test
    void testLargestPrimeFactorWithSmallestComposite() {
        assertEquals(2, LargestPrimeFactor.largestPrimeFactor(4));
    }

    @Test
    void testLargestPrimeFactorWithAnotherSmallComposite() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(9));
    }

    @Test
    void testLargestPrimeFactorWithProductOfTwoPrimes() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(10));
    }

    @Test
    void testLargestPrimeFactorWithAnotherProductOfTwoPrimes() {
        assertEquals(7, LargestPrimeFactor.largestPrimeFactor(14));
    }

    @Test
    void testLargestPrimeFactorWithProductOfThreePrimes() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(30));
    }

    @Test
    void testLargestPrimeFactorWithSquareOfPrime() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(25));
    }

    @Test
    void testLargestPrimeFactorWithMultipleSameFactors() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(125));
    }

    @Test
    void testLargestPrimeFactorWithAnotherEvenComposite() {
        assertEquals(7, LargestPrimeFactor.largestPrimeFactor(28));
    }

    @Test
    void testLargestPrimeFactorWithAnotherOddComposite() {
        assertEquals(11, LargestPrimeFactor.largestPrimeFactor(121));
    }

    @Test
    void testLargestPrimeFactorWithEvenNumberWithMultipleFactors() {
        assertEquals(13, LargestPrimeFactor.largestPrimeFactor(78));
    }

    @Test
    void testLargestPrimeFactorWithAnotherLargeComposite() {
        assertEquals(13, LargestPrimeFactor.largestPrimeFactor(91));
    }

    @Test
    void testLargestPrimeFactorWithAnotherMixedFactors() {
        assertEquals(17, LargestPrimeFactor.largestPrimeFactor(34));
    }

    @Test
    void testLargestPrimeFactorWithAnotherSmallestComposite() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(6));
    }

    @Test
    void testLargestPrimeFactorWithAnotherEvenComposite1() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(20));
    }

    @Test
    void testLargestPrimeFactorWithPrimeInput() {
        // This is an invalid case as per the assumption in the method, but testing for coverage
        assertThrows(IllegalArgumentException.class, () -> LargestPrimeFactor.largestPrimeFactor(2));
    }

    @Test
    void testLargestPrimeFactorWithNegativeInput() {
        assertThrows(IllegalArgumentException.class, () -> LargestPrimeFactor.largestPrimeFactor(-10));
    }

    @Test
    void testLargestPrimeFactorWithZeroInput() {
        assertThrows(IllegalArgumentException.class, () -> LargestPrimeFactor.largestPrimeFactor(0));
    }
}