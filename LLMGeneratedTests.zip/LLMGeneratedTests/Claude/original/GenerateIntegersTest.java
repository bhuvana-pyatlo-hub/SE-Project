package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GenerateIntegersTest {

    @Test
    void testGenerateIntegersBasicCase() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(2, 8));
    }

    @Test
    void testGenerateIntegersReversedOrder() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(8, 2));
    }

    @Test
    void testGenerateIntegersNoEvenDigits() {
        assertEquals(List.of(), GenerateIntegers.generateIntegers(10, 14));
    }

    @Test
    void testGenerateIntegersLowerBound() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(2, 10));
    }

    @Test
    void testGenerateIntegersUpperBound() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(10, 2));
    }

    @Test
    void testGenerateIntegersOutsideRange() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(132, 2));
    }

    @Test
    void testGenerateIntegersNoEvenDigitsInRange() {
        assertEquals(List.of(), GenerateIntegers.generateIntegers(17, 89));
    }

    @Test
    void testGenerateIntegersNegativeInput() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(-10, 5));
    }

    @Test
    void testGenerateIntegersBothNegative() {
        assertEquals(List.of(), GenerateIntegers.generateIntegers(-10, -5));
    }

    @Test
    void testGenerateIntegersZeroInput() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(0, 8));
    }

    @Test
    void testGenerateIntegersBoundaryValues() {
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(2, 8));
        assertEquals(List.of(2, 4, 6, 8), GenerateIntegers.generateIntegers(8, 2));
    }

    @Test
    void testGenerateIntegersMinimumValidInput() {
        assertEquals(List.of(2), GenerateIntegers.generateIntegers(2, 2));
    }

    @Test
    void testGenerateIntegersMaximumValidInput() {
        assertEquals(List.of(8), GenerateIntegers.generateIntegers(8, 8));
    }
}