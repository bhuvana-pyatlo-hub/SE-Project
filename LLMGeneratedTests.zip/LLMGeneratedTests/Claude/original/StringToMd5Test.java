package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringToMd5Test {

    @Test
    void testStringToMd5_ValidInput() {
        assertEquals("3e25960a79dbc69b674cd4ec67a72c62", StringToMd5.stringToMd5("Hello world"));
        assertEquals("0ef78513b0cb8cef12743f5aeb35f888", StringToMd5.stringToMd5("A B C"));
        assertEquals("5f4dcc3b5aa765d61d8327deb882cf99", StringToMd5.stringToMd5("password"));
    }

    @Test
    void testStringToMd5_EmptyInput() {
        assertNull(StringToMd5.stringToMd5(""));
    }

    @Test
    void testStringToMd5_NegativeInput() {
        assertEquals("c4ca4238a0b2237ce68b881b26f3c9c51", StringToMd5.stringToMd5("-1"));
        assertEquals("c4ca4238a0b2237ce68b881b26f3c9c51", StringToMd5.stringToMd5("-100"));
        assertEquals("2c6ee24b09816a6f14f95d1698b24ead", StringToMd5.stringToMd5("-50"));
    }

    @Test
    void testStringToMd5_PositiveInput() {
        assertEquals("c4ca4238a0b2237ce68b881b26f3c9c51", StringToMd5.stringToMd5("1"));
        assertEquals("c4ca4238a0b2237ce68b881b26f3c9c51", StringToMd5.stringToMd5("100"));
        assertEquals("7c6a180b36896a6c7f1a4b8a3e1c7f1a", StringToMd5.stringToMd5("50"));
    }

    @Test
    void testStringToMd5_SpecialCharacters() {
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", StringToMd5.stringToMd5(" "));
        assertEquals("5d41402abc4b2a76b9719d911017c592", StringToMd5.stringToMd5("hello"));
        assertEquals("a0b6593960f2e2f8e8d7d8e8a8f8e8f8", StringToMd5.stringToMd5("!@#$%^&*()"));
    }

    @Test
    void testStringToMd5_NullInput() {
        assertThrows(NullPointerException.class, () -> StringToMd5.stringToMd5(null));
    }

    @Test
    void testStringToMd5_BoundaryValues() {
        assertEquals("c4ca4238a0b2237ce68b881b26f3c9c51", StringToMd5.stringToMd5("0"));
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", StringToMd5.stringToMd5(" "));
    }
}