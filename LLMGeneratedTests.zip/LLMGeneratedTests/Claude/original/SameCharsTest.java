package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SameCharsTest {

    @Test
    void testSameCharsWithDifferentLengths() {
        assertFalse(SameChars.sameChars("abcd", "dddddddabce")); // Different lengths, different characters
    }

    @Test
    void testSameCharsWithSameCharactersDifferentCounts() {
        assertTrue(SameChars.sameChars("eabcdzzzz", "dddzzzzzzzddeddabc")); // Same characters, different counts
    }

    @Test
    void testSameCharsWithSameCharactersInDifferentOrder() {
        assertTrue(SameChars.sameChars("abcd", "dddddddabc")); // Same characters, different order
    }

    @Test
    void testSameCharsWithSameCharactersInDifferentOrderReverse() {
        assertTrue(SameChars.sameChars("dddddddabc", "abcd")); // Same characters, different order (reverse)
    }

    @Test
    void testSameCharsWithOneDifferentCharacter() {
        assertFalse(SameChars.sameChars("abcd", "dddddddabcf")); // One different character
    }

    @Test
    void testSameCharsWithDifferentCharacters() {
        assertFalse(SameChars.sameChars("aabb", "aaccc")); // Different characters
    }

    @Test
    void testSameCharsWithEmptyStrings() {
        assertTrue(SameChars.sameChars("", "")); // Both empty strings
    }

    @Test
    void testSameCharsWithOneEmptyString() {
        assertFalse(SameChars.sameChars("a", "")); // One empty string
    }

    @Test
    void testSameCharsWithSameSingleCharacter() {
        assertTrue(SameChars.sameChars("a", "a")); // Same single character
    }

    @Test
    void testSameCharsWithDifferentSingleCharacters() {
        assertFalse(SameChars.sameChars("a", "b")); // Different single characters
    }

    @Test
    void testSameCharsWithRepeatedCharacters() {
        assertTrue(SameChars.sameChars("aa", "aa")); // Same repeated characters
    }

    @Test
    void testSameCharsWithDifferentRepeatedCharacters() {
        assertFalse(SameChars.sameChars("aa", "bb")); // Different repeated characters
    }

    @Test
    void testSameCharsWithMixedCharacters() {
        assertFalse(SameChars.sameChars("abc", "abcd")); // Mixed characters, one extra
    }

    @Test
    void testSameCharsWithSameCharactersMixedCase() {
        assertFalse(SameChars.sameChars("abc", "ABC")); // Same characters but different case
    }

    @Test
    void testSameCharsWithLongerStringsSameCharacters() {
        assertTrue(SameChars.sameChars("abcde", "edcba")); // Longer strings with same characters
    }

    @Test
    void testSameCharsWithLongerStringsDifferentCharacters() {
        assertFalse(SameChars.sameChars("abcde", "abcfg")); // Longer strings with different characters
    }

    @Test
    void testSameCharsWithAllCharactersPresent() {
        assertTrue(SameChars.sameChars("abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba")); // All characters present
    }

    @Test
    void testSameCharsWithAllCharactersDifferent() {
        assertFalse(SameChars.sameChars("abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxy")); // All characters but one different
    }

    @Test
    void testSameCharsWithOneCharacterDifferentInLongStrings() {
        assertFalse(SameChars.sameChars("abcdefghijklmno", "abcdefghijklmnp")); // One character different
    }

    @Test
    void testSameCharsWithSameCharactersWithSpaces() {
        assertFalse(SameChars.sameChars("abc def", "fed cba")); // Spaces included
    }

    @Test
    void testSameCharsWithSpecialCharacters() {
        assertFalse(SameChars.sameChars("abc$", "abc#")); // Special characters included
    }

    @Test
    void testSameCharsWithBoundaryValues() {
        assertTrue(SameChars.sameChars("a", "a")); // Boundary case with single character
        assertFalse(SameChars.sameChars("a", "b")); // Boundary case with different single characters
        assertTrue(SameChars.sameChars("abc", "abc")); // Boundary case with same characters
        assertFalse(SameChars.sameChars("abc", "ab")); // Boundary case with missing character
    }

    @Test
    void testSameCharsWithNegativeValues() {
        // Since the original method does not handle negative values, we can test with invalid inputs
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            SameChars.sameChars("abc", "abc-"); // Invalid character
        });
    }
}