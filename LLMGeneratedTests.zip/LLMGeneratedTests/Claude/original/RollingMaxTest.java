package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RollingMaxTest {

    @Test
    void testRollingMaxWithIncreasingNumbers() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 3, 4, 2);
        List<Object> expected = Arrays.asList(1, 2, 3, 3, 3, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithEmptyList() {
        List<Object> input = Arrays.asList();
        List<Object> expected = Arrays.asList();
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithStrictlyIncreasingNumbers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4);
        List<Object> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithStrictlyDecreasingNumbers() {
        List<Object> input = Arrays.asList(4, 3, 2, 1);
        List<Object> expected = Arrays.asList(4, 4, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithMixedNumbers() {
        List<Object> input = Arrays.asList(3, 2, 3, 100, 3);
        List<Object> expected = Arrays.asList(3, 3, 3, 100, 100);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithInvalidInput() {
        List<Object> input = Arrays.asList(1, "two", 3);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RollingMax.rollingMax(input);
        });
        assertEquals("Invalid number type", exception.getMessage());
    }

    @Test
    void testRollingMaxWithNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3, -2, -4);
        List<Object> expected = Arrays.asList(-1, -1, -1, -1, -1);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithSingleElement() {
        List<Object> input = Arrays.asList(42);
        List<Object> expected = Arrays.asList(42);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithZeroValue() {
        List<Object> input = Arrays.asList(0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithBoundaryValues() {
        List<Object> input = Arrays.asList(-100, 0, 100);
        List<Object> expected = Arrays.asList(-100, 0, 100);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void testRollingMaxWithMultipleInvalidInputs() {
        List<Object> input = Arrays.asList(1, "two", 3, 4.5);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RollingMax.rollingMax(input);
        });
        assertEquals("Invalid number type", exception.getMessage());
    }
}