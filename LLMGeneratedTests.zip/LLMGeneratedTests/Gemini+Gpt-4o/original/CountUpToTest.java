package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class CountUpToTest {

    @Test
    void countUpTo_zero() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, CountUpTo.countUpTo(0));
    }

    @Test
    void countUpTo_one() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, CountUpTo.countUpTo(1));
    }

    @Test
    void countUpTo_two() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, CountUpTo.countUpTo(2));
    }

    @Test
    void countUpTo_three() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        assertEquals(expected, CountUpTo.countUpTo(3));
    }

    @Test
    void countUpTo_four() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        assertEquals(expected, CountUpTo.countUpTo(4));
    }

    @Test
    void countUpTo_five() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        assertEquals(expected, CountUpTo.countUpTo(5));
    }

    @Test
    void countUpTo_six() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        assertEquals(expected, CountUpTo.countUpTo(6));
    }

    @Test
    void countUpTo_seven() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        assertEquals(expected, CountUpTo.countUpTo(7));
    }

    @Test
    void countUpTo_eight() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        assertEquals(expected, CountUpTo.countUpTo(8));
    }

    @Test
    void countUpTo_nine() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        assertEquals(expected, CountUpTo.countUpTo(9));
    }

    @Test
    void countUpTo_ten() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        assertEquals(expected, CountUpTo.countUpTo(10));
    }

    @Test
    void countUpTo_eleven() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        assertEquals(expected, CountUpTo.countUpTo(11));
    }

    @Test
    void countUpTo_twelve() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        assertEquals(expected, CountUpTo.countUpTo(12));
    }

    @Test
    void countUpTo_thirteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        assertEquals(expected, CountUpTo.countUpTo(13));
    }

    @Test
    void countUpTo_fourteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        assertEquals(expected, CountUpTo.countUpTo(14));
    }

    @Test
    void countUpTo_fifteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        assertEquals(expected, CountUpTo.countUpTo(15));
    }

    @Test
    void countUpTo_sixteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        assertEquals(expected, CountUpTo.countUpTo(16));
    }

    @Test
    void countUpTo_seventeen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        assertEquals(expected, CountUpTo.countUpTo(17));
    }

    @Test
    void countUpTo_eighteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        assertEquals(expected, CountUpTo.countUpTo(18));
    }

    @Test
    void countUpTo_nineteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        assertEquals(expected, CountUpTo.countUpTo(19));
    }

    @Test
    void countUpTo_twenty() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        expected.add(19);
        assertEquals(expected, CountUpTo.countUpTo(20));
    }

    @Test
    void countUpTo_fortySeven() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        expected.add(19);
        expected.add(23);
        expected.add(29);
        expected.add(31);
        expected.add(37);
        expected.add(41);
        expected.add(43);
        assertEquals(expected, CountUpTo.countUpTo(47));
    }

    @Test
    void countUpTo_101() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        expected.add(19);
        expected.add(23);
        expected.add(29);
        expected.add(31);
        expected.add(37);
        expected.add(41);
        expected.add(43);
        expected.add(47);
        expected.add(53);
        expected.add(59);
        expected.add(61);
        expected.add(67);
        expected.add(71);
        expected.add(73);
        expected.add(79);
        expected.add(83);
        expected.add(89);
        expected.add(97);
        assertEquals(expected, CountUpTo.countUpTo(101));
    }
}