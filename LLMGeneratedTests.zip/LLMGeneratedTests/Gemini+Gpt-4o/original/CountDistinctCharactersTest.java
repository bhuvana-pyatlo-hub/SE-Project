package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountDistinctCharactersTest {

    @Test
    void testEmptyString() {
        assertEquals(0, CountDistinctCharacters.countDistinctCharacters(""));
    }

    @Test
    void testSingleCharacterString() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("a"));
    }

    @Test
    void testAllSameCharactersLowercase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aaaa"));
    }

    @Test
    void testAllSameCharactersUppercase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("AAAA"));
    }

    @Test
    void testAllSameCharactersMixedCase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aAaA"));
    }

    @Test
    void testDistinctCharactersLowercase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcde"));
    }

    @Test
    void testDistinctCharactersUppercase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("ABCDE"));
    }

    @Test
    void testDistinctCharactersMixedCase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("aBcDe"));
    }

    @Test
    void testStringWithDuplicatesLowercase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("aabbc"));
    }

    @Test
    void testStringWithDuplicatesUppercase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("AABBC"));
    }

    @Test
    void testStringWithDuplicatesMixedCase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("AaBbC"));
    }

    @Test
    void testStringWithMixedCaseAndDuplicates() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcdecadeCADE"));
    }

    @Test
    void testStringWithSpaces() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("a b c"));
    }

    @Test
    void testStringWithNumbers() {
        assertEquals(6, CountDistinctCharacters.countDistinctCharacters("a1b2c3"));
    }

    @Test
    void testStringWithSpecialCharacters() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("a!b@c"));
    }

    @Test
    void testStringWithMixedCharacters() {
        assertEquals(7, CountDistinctCharacters.countDistinctCharacters("a1B!c2D@"));
    }

    @Test
    void testStringWithRepeatedMixedCase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("Jerry jERRY JeRRRY"));
    }

    @Test
    void testStringWithLeadingAndTrailingSpaces() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("  ab  "));
    }

    @Test
    void testStringWithOnlySpaces() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("   "));
    }

    @Test
    void testStringWithUnicodeCharacters() {
        assertEquals(2, CountDistinctCharacters.countDistinctCharacters("你好"));
    }

    @Test
    void testStringWithMixedCaseUnicodeCharacters() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("你好a"));
    }

    @Test
    void testStringWithBoundaryValues() {
        assertEquals(2, CountDistinctCharacters.countDistinctCharacters("Aa")); // Boundary case
    }

    @Test
    void testStringWithMinimumValidInputs() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("1")); // Minimum valid input
    }

    @Test
    void testStringWithMaximumValidInputs() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("123")); // Maximum valid input
    }

    @Test
    void testStringWithNegativeValues() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("-1-2-3")); // Negative values
    }
}