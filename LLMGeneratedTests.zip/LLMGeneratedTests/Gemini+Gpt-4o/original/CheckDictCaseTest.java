package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CheckDictCaseTest {

    @Test
    void checkDictCase_emptyDict_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allLowercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("b", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allUppercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("A", "apple");
        dict.put("B", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCase_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_nonStringKey_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put(8, "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_nullInput_returnsFalse() {
        assertFalse(CheckDictCase.checkDictCase(null));
    }

    @Test
    void checkDictCase_notMapInput_returnsFalse() {
        assertFalse(CheckDictCase.checkDictCase("not a map"));
    }

    @Test
    void checkDictCase_oneLowercaseKey_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("p", "pineapple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_oneUppercaseKey_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("P", "pineapple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCaseAndNonString_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("A", "banana");
        dict.put(1, "orange");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_emptyStringKey_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("", "empty");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCaseWithEmptyString_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("", "empty");
        dict.put("A", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allLowercaseWithEmptyString_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("", "empty");
        dict.put("a", "apple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allUppercaseWithEmptyString_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("", "empty");
        dict.put("A", "apple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_specialCharactersLowercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "special");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_specialCharactersUppercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "special");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCaseSpecialCharacters_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "special");
        dict.put("A", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCaseSpecialCharacters2_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "special");
        dict.put("a", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_numbersAsKeys_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put(123, "number");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedStringAndNumberKeys_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put(123, "number");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }
}