package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CompareOneTest {

    @Test
    void compareOne_integer_and_float_a_greater() {
        assertEquals(1, CompareOne.compareOne(1, 0.5));
    }

    @Test
    void compareOne_integer_and_float_b_greater() {
        assertEquals(2.5, CompareOne.compareOne(1, 2.5));
    }

    @Test
    void compareOne_integer_and_float_equal() {
        assertNull(CompareOne.compareOne(1.0, 1));
    }

    @Test
    void compareOne_two_integers_a_greater() {
        assertEquals(2, CompareOne.compareOne(2, 1));
    }

    @Test
    void compareOne_two_integers_b_greater() {
        assertEquals(3, CompareOne.compareOne(2, 3));
    }

    @Test
    void compareOne_two_integers_equal() {
        assertNull(CompareOne.compareOne(5, 5));
    }

    @Test
    void compareOne_integer_and_string_a_greater() {
        assertEquals(1, CompareOne.compareOne(1, "0.5"));
    }

    @Test
    void compareOne_integer_and_string_b_greater() {
        assertEquals("2,3", CompareOne.compareOne(1, "2,3"));
    }

    @Test
    void compareOne_integer_and_string_equal() {
        assertNull(CompareOne.compareOne(1, "1"));
    }

    @Test
    void compareOne_two_strings_a_greater() {
        assertEquals("5,1", CompareOne.compareOne("5,1", "4"));
    }

    @Test
    void compareOne_two_strings_b_greater() {
        assertEquals("6", CompareOne.compareOne("5,1", "6"));
    }

    @Test
    void compareOne_two_strings_equal() {
        assertNull(CompareOne.compareOne("1", "1"));
    }

    @Test
    void compareOne_string_and_integer_a_greater() {
        assertEquals("2", CompareOne.compareOne("2", 1));
    }

    @Test
    void compareOne_string_and_integer_b_greater() {
        assertEquals(2, CompareOne.compareOne("1", 2));
    }

    @Test
    void compareOne_string_and_integer_equal() {
        assertNull(CompareOne.compareOne("1", 1));
    }

    @Test
    void compareOne_two_floats_a_greater() {
        assertEquals(2.5, CompareOne.compareOne(2.5, 1.5));
    }

    @Test
    void compareOne_two_floats_b_greater() {
        assertEquals(3.5, CompareOne.compareOne(2.5, 3.5));
    }

    @Test
    void compareOne_two_floats_equal() {
        assertNull(CompareOne.compareOne(2.5, 2.5));
    }

    @Test
    void compareOne_string_with_comma_and_float_a_greater() {
        assertEquals("2,5", CompareOne.compareOne("2,5", 1.5));
    }

    @Test
    void compareOne_string_with_comma_and_float_b_greater() {
        assertEquals(3.5, CompareOne.compareOne("2,5", 3.5));
    }

    @Test
    void compareOne_string_with_comma_and_float_equal() {
        assertNull(CompareOne.compareOne("2,5", 2.5));
    }

    @Test
    void compareOne_string_with_comma_and_string_with_dot_a_greater() {
        assertEquals("2,5", CompareOne.compareOne("2,5", "1.5"));
    }

    @Test
    void compareOne_string_with_comma_and_string_with_dot_b_greater() {
        assertEquals("3.5", CompareOne.compareOne("2,5", "3.5"));
    }

    @Test
    void compareOne_string_with_comma_and_string_with_dot_equal() {
        assertNull(CompareOne.compareOne("2,5", "2.5"));
    }

    @Test
    void compareOne_negative_values_a_greater() {
        assertEquals(-1, CompareOne.compareOne(-1, -2));
    }

    @Test
    void compareOne_negative_values_b_greater() {
        assertEquals(-1, CompareOne.compareOne(-2, -1));
    }

    @Test
    void compareOne_negative_values_equal() {
        assertNull(CompareOne.compareOne(-1, -1));
    }

    @Test
    void compareOne_zero_and_positive() {
        assertEquals(0, CompareOne.compareOne(0, 1));
    }

    @Test
    void compareOne_zero_and_negative() {
        assertEquals(0, CompareOne.compareOne(0, -1));
    }

    @Test
    void compareOne_zero_and_zero_equal() {
        assertNull(CompareOne.compareOne(0, 0));
    }
}