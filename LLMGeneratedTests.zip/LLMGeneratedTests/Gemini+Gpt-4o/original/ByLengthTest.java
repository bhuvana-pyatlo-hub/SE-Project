package original;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ByLengthTest {

    @Test
    void byLength_emptyArray() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_validInput() {
        List<Object> input = Arrays.asList(2, 1, 1, 4, 5, 8, 2, 3);
        List<Object> expected = Arrays.asList("Eight", "Five", "Four", "Three", "Two", "Two", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_invalidNumbers() {
        List<Object> input = Arrays.asList(1, -1, 55);
        List<Object> expected = Arrays.asList("One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_mixedValidAndInvalid() {
        List<Object> input = Arrays.asList(1, -1, 3, 2);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allValidNumbers() {
        List<Object> input = Arrays.asList(9, 4, 8);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Four");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyInvalidNumbers() {
        List<Object> input = Arrays.asList(-1, 10, 0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_duplicateValidNumbers() {
        List<Object> input = Arrays.asList(1, 1, 1, 1);
        List<Object> expected = Arrays.asList("One", "One", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_singleValidNumber() {
        List<Object> input = Arrays.asList(5);
        List<Object> expected = Arrays.asList("Five");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_singleInvalidNumber() {
        List<Object> input = Arrays.asList(10);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allNumbersSame() {
        List<Object> input = Arrays.asList(7, 7, 7, 7);
        List<Object> expected = Arrays.asList("Seven", "Seven", "Seven", "Seven");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_numbersInDescendingOrder() {
        List<Object> input = Arrays.asList(9, 8, 7, 6, 5, 4, 3, 2, 1);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_numbersInAscendingOrder() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_boundaryValuesOneAndNine() {
        List<Object> input = Arrays.asList(1, 9);
        List<Object> expected = Arrays.asList("Nine", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_zeroAndTenAreIgnored() {
        List<Object> input = Arrays.asList(0, 10);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyZero() {
        List<Object> input = Arrays.asList(0, 0, 0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyTen() {
        List<Object> input = Arrays.asList(10, 10, 10);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_mixedTypes() {
        List<Object> input = Arrays.asList(1, "hello", 2.5, 3);
        List<Object> expected = Arrays.asList("Three", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyStrings() {
        List<Object> input = Arrays.asList("one", "two", "three");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_largeInputList() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> expected = Arrays.asList("Nine", "Nine", "Eight", "Eight", "Seven", "Seven", "Six", "Six", "Five", "Five", "Four", "Four", "Three", "Three", "Two", "Two", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allValidNumbers_differentOrder() {
        List<Object> input = Arrays.asList(5, 1, 9, 3, 7);
        List<Object> expected = Arrays.asList("Nine", "Seven", "Five", "Three", "One");
        assertEquals(expected, ByLength.byLength(input));
    }
}