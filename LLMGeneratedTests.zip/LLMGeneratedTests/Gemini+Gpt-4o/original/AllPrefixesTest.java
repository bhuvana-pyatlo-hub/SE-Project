package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class AllPrefixesTest {

    @Test
    void testAllPrefixes_emptyString() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, AllPrefixes.allPrefixes(""));
    }

    @Test
    void testAllPrefixes_singleCharacter() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        assertEquals(expected, AllPrefixes.allPrefixes("a"));
    }

    @Test
    void testAllPrefixes_twoCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("ab");
        assertEquals(expected, AllPrefixes.allPrefixes("ab"));
    }

    @Test
    void testAllPrefixes_threeCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("ab");
        expected.add("abc");
        assertEquals(expected, AllPrefixes.allPrefixes("abc"));
    }

    @Test
    void testAllPrefixes_fourCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("ab");
        expected.add("abc");
        expected.add("abcd");
        assertEquals(expected, AllPrefixes.allPrefixes("abcd"));
    }

    @Test
    void testAllPrefixes_withNumbers() {
        List<Object> expected = new ArrayList<>();
        expected.add("1");
        expected.add("12");
        expected.add("123");
        assertEquals(expected, AllPrefixes.allPrefixes("123"));
    }

    @Test
    void testAllPrefixes_withSpecialCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("!");
        expected.add("!@");
        expected.add("!@#");
        assertEquals(expected, AllPrefixes.allPrefixes("!@#"));
    }

    @Test
    void testAllPrefixes_mixedCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("a1");
        expected.add("a1b");
        assertEquals(expected, AllPrefixes.allPrefixes("a1b"));
    }

    @Test
    void testAllPrefixes_longString() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("as");
        expected.add("asd");
        expected.add("asdf");
        expected.add("asdfg");
        expected.add("asdfgh");
        assertEquals(expected, AllPrefixes.allPrefixes("asdfgh"));
    }

    @Test
    void testAllPrefixes_sameCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("W");
        expected.add("WW");
        expected.add("WWW");
        assertEquals(expected, AllPrefixes.allPrefixes("WWW"));
    }

    @Test
    void testAllPrefixes_stringWithSpaces() {
        List<Object> expected = new ArrayList<>();
        expected.add(" ");
        expected.add(" a");
        expected.add(" a ");
        assertEquals(expected, AllPrefixes.allPrefixes(" a "));
    }

    @Test
    void testAllPrefixes_stringWithLeadingAndTrailingSpaces() {
        List<Object> expected = new ArrayList<>();
        expected.add(" ");
        expected.add(" a");
        expected.add(" ab");
        expected.add(" abc");
        expected.add(" abc ");
        assertEquals(expected, AllPrefixes.allPrefixes(" abc "));
    }

    @Test
    void testAllPrefixes_stringWithMultipleSpaces() {
        List<Object> expected = new ArrayList<>();
        expected.add(" ");
        expected.add("  ");
        expected.add("   ");
        assertEquals(expected, AllPrefixes.allPrefixes("   "));
    }

    @Test
    void testAllPrefixes_stringWithNewline() {
        List<Object> expected = new ArrayList<>();
        expected.add("\n");
        assertEquals(expected, AllPrefixes.allPrefixes("\n"));
    }

    @Test
    void testAllPrefixes_stringWithTab() {
        List<Object> expected = new ArrayList<>();
        expected.add("\t");
        assertEquals(expected, AllPrefixes.allPrefixes("\t"));
    }

    @Test
    void testAllPrefixes_stringWithUnicode() {
        List<Object> expected = new ArrayList<>();
        expected.add("ü");
        expected.add("üö");
        assertEquals(expected, AllPrefixes.allPrefixes("üö"));
    }

    @Test
    void testAllPrefixes_stringWithMixedUnicodeAndAscii() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("aü");
        assertEquals(expected, AllPrefixes.allPrefixes("aü"));
    }

    @Test
    void testAllPrefixes_stringWithEmoji() {
        List<Object> expected = new ArrayList<>();
        expected.add("😀");
        assertEquals(expected, AllPrefixes.allPrefixes("😀"));
    }

    @Test
    void testAllPrefixes_stringWithMultipleEmojis() {
        List<Object> expected = new ArrayList<>();
        expected.add("😀");
        expected.add("😀😀");
        assertEquals(expected, AllPrefixes.allPrefixes("😀😀"));
    }

    @Test
    void testAllPrefixes_stringWithEmojiAndText() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("a😀");
        assertEquals(expected, AllPrefixes.allPrefixes("a😀"));
    }
}