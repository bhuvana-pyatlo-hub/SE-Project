package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AntiShuffleTest {

    @Test
    void antiShuffle_emptyString() {
        assertEquals("", AntiShuffle.antiShuffle(""));
    }

    @Test
    void antiShuffle_singleWord() {
        assertEquals("ehllo", AntiShuffle.antiShuffle("hello"));
    }

    @Test
    void antiShuffle_multipleWords() {
        assertEquals("Hello !!!Wdlor", AntiShuffle.antiShuffle("Hello World!!!"));
    }

    @Test
    void antiShuffle_singleCharacterWord() {
        assertEquals("a", AntiShuffle.antiShuffle("a"));
    }

    @Test
    void antiShuffle_alreadySortedWord() {
        assertEquals("abcd", AntiShuffle.antiShuffle("abcd"));
    }

    @Test
    void antiShuffle_reverseSortedWord() {
        assertEquals("abcd", AntiShuffle.antiShuffle("dcba"));
    }

    @Test
    void antiShuffle_mixedCaseWord() {
        assertEquals("Hllo", AntiShuffle.antiShuffle("lHol"));
    }

    @Test
    void antiShuffle_wordWithNumbers() {
        assertEquals("123abc", AntiShuffle.antiShuffle("abc321"));
    }

    @Test
    void antiShuffle_wordWithSpecialCharacters() {
        assertEquals("!#$", AntiShuffle.antiShuffle("$#!"));
    }

    @Test
    void antiShuffle_sentenceWithPunctuation() {
        assertEquals(".Hi My aemn is Meirst .Rboot How aer ?ouy", AntiShuffle.antiShuffle("Hi. My name is Mister Robot. How are you?"));
    }

    @Test
    void antiShuffle_sentenceWithLeadingAndTrailingSpaces() {
        assertEquals("   ehllo   ", AntiShuffle.antiShuffle("   hello   "));
    }

    @Test
    void antiShuffle_sentenceWithMultipleSpacesBetweenWords() {
        assertEquals("ehllo   dlrow", AntiShuffle.antiShuffle("hello   world"));
    }

    @Test
    void antiShuffle_sentenceWithEmptyWords() {
        assertEquals("  ehllo ", AntiShuffle.antiShuffle("  hello "));
    }

    @Test
    void antiShuffle_wordWithRepeatedCharacters() {
        assertEquals("aaabbc", AntiShuffle.antiShuffle("abcaba"));
    }

    @Test
    void antiShuffle_wordWithOnlyRepeatedCharacters() {
        assertEquals("aaaaa", AntiShuffle.antiShuffle("aaaaa"));
    }

    @Test
    void antiShuffle_sentenceWithSingleLetterWords() {
        assertEquals("a b c", AntiShuffle.antiShuffle("a b c"));
    }

    @Test
    void antiShuffle_sentenceWithMixedCaseAndSpecialChars() {
        assertEquals("!!!Hdelor Wdlor", AntiShuffle.antiShuffle("Hello!!! World"));
    }

    @Test
    void antiShuffle_numbersOnly() {
        assertEquals("0123456789", AntiShuffle.antiShuffle("9876543210"));
    }

    @Test
    void antiShuffle_specialCharactersOnly() {
        assertEquals("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", AntiShuffle.antiShuffle("~}|{`_^]\\[@?>=<;:/.+*)('&%$#\"!"));
    }

    @Test
    void antiShuffle_longSentence() {
        assertEquals("aehllos Thsi is a olng tstneec.", AntiShuffle.antiShuffle("helloas This is a long sentence."));
    }

    @Test
    void antiShuffle_sentenceWithAllSpaces() {
        assertEquals("   ", AntiShuffle.antiShuffle("   "));
    }

    @Test
    void antiShuffle_sentenceWithOnlySpecialCharacters() {
        assertEquals("!@#$%^&*()", AntiShuffle.antiShuffle(")(*&^%$#@!"));
    }
}