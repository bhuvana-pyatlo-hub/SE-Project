package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class BfTest {

    @Test
    void bf_Jupiter_Neptune() {
        List<Object> expected = List.of("Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Jupiter", "Neptune"));
    }

    @Test
    void bf_Earth_Mercury() {
        List<Object> expected = List.of("Venus");
        assertEquals(expected, Bf.bf("Earth", "Mercury"));
    }

    @Test
    void bf_Mercury_Uranus() {
        List<Object> expected = List.of("Venus", "Earth", "Mars", "Jupiter", "Saturn");
        assertEquals(expected, Bf.bf("Mercury", "Uranus"));
    }

    @Test
    void bf_Neptune_Venus() {
        List<Object> expected = List.of("Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Neptune", "Venus"));
    }

    @Test
    void bf_Earth_Earth() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Earth", "Earth"));
    }

    @Test
    void bf_Mars_Earth() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Mars", "Earth"));
    }

    @Test
    void bf_Jupiter_Makemake() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Jupiter", "Makemake"));
    }

    @Test
    void bf_Mercury_Venus() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Mercury", "Venus"));
    }

    @Test
    void bf_Venus_Mercury() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Venus", "Mercury"));
    }

    @Test
    void bf_Mercury_Neptune() {
        List<Object> expected = List.of("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Mercury", "Neptune"));
    }

    @Test
    void bf_Neptune_Mercury() {
        List<Object> expected = List.of("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Neptune", "Mercury"));
    }

    @Test
    void bf_Uranus_Neptune() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Uranus", "Neptune"));
    }

    @Test
    void bf_Neptune_Uranus() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Neptune", "Uranus"));
    }

    @Test
    void bf_Earth_Jupiter() {
        List<Object> expected = List.of("Mars");
        assertEquals(expected, Bf.bf("Earth", "Jupiter"));
    }

    @Test
    void bf_Jupiter_Earth() {
        List<Object> expected = List.of("Mars");
        assertEquals(expected, Bf.bf("Jupiter", "Earth"));
    }

    @Test
    void bf_Saturn_Neptune() {
        List<Object> expected = List.of("Uranus");
        assertEquals(expected, Bf.bf("Saturn", "Neptune"));
    }

    @Test
    void bf_Neptune_Saturn() {
        List<Object> expected = List.of("Uranus");
        assertEquals(expected, Bf.bf("Neptune", "Saturn"));
    }

    @Test
    void bf_InvalidPlanet1_ValidPlanet2() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Pluto", "Earth"));
    }

    @Test
    void bf_ValidPlanet1_InvalidPlanet2() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Earth", "Pluto"));
    }

    @Test
    void bf_InvalidPlanet1_InvalidPlanet2() {
        List<Object> expected = List.of();
        assertEquals(expected, Bf.bf("Pluto", "Xena"));
    }

    @Test
    void bf_Mars_Saturn() {
        List<Object> expected = List.of("Jupiter");
        assertEquals(expected, Bf.bf("Mars", "Saturn"));
    }

    @Test
    void bf_Saturn_Mars() {
        List<Object> expected = List.of("Jupiter");
        assertEquals(expected, Bf.bf("Saturn", "Mars"));
    }
}