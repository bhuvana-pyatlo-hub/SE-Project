package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChooseNumTest {

    @Test
    void chooseNum_xLessThanY_evenInRange() {
        assertEquals(14, ChooseNum.chooseNum(12, 15));
    }

    @Test
    void chooseNum_xGreaterThanY_noEvenInRange() {
        assertEquals(-1, ChooseNum.chooseNum(13, 12));
    }

    @Test
    void chooseNum_xLessThanY_largeRange_evenInRange() {
        assertEquals(14, ChooseNum.chooseNum(33, 12354));
    }

    @Test
    void chooseNum_xGreaterThanY_noEvenInRange_largeNumbers() {
        assertEquals(-1, ChooseNum.chooseNum(5234, 5233));
    }

    @Test
    void chooseNum_xLessThanY_evenInRange2() {
        assertEquals(28, ChooseNum.chooseNum(6, 29));
    }

    @Test
    void chooseNum_xGreaterThanY_evenInRange3() {
        assertEquals(-1, ChooseNum.chooseNum(27, 10));
    }

    @Test
    void chooseNum_xEqualsY_odd() {
        assertEquals(-1, ChooseNum.chooseNum(7, 7));
    }

    @Test
    void chooseNum_xEqualsY_even() {
        assertEquals(546, ChooseNum.chooseNum(546, 546));
    }

    @Test
    void chooseNum_xLessThanY_noEvenInRange() {
        assertEquals(-1, ChooseNum.chooseNum(1, 3));
    }

    @Test
    void chooseNum_xLessThanY_onlyOddInRange() {
        assertEquals(-1, ChooseNum.chooseNum(11, 13));
    }

    @Test
    void chooseNum_xLessThanY_firstEven() {
        assertEquals(12, ChooseNum.chooseNum(12, 13));
    }

    @Test
    void chooseNum_xLessThanY_lastEven() {
        assertEquals(14, ChooseNum.chooseNum(13, 14));
    }

    @Test
    void chooseNum_xEqualsY_smallEven() {
        assertEquals(2, ChooseNum.chooseNum(2, 2));
    }

    @Test
    void chooseNum_xEqualsY_smallOdd() {
        assertEquals(-1, ChooseNum.chooseNum(3, 3));
    }

    @Test
    void chooseNum_xLessThanY_multipleEvens() {
        assertEquals(20, ChooseNum.chooseNum(16, 20));
    }

    @Test
    void chooseNum_xLessThanY_startOddEndEven() {
        assertEquals(20, ChooseNum.chooseNum(17, 20));
    }

    @Test
    void chooseNum_xLessThanY_startEvenEndOdd() {
        assertEquals(18, ChooseNum.chooseNum(16, 19));
    }

    @Test
    void chooseNum_xEqualsY_zero() {
        assertEquals(0, ChooseNum.chooseNum(0, 0));
    }

    @Test
    void chooseNum_xLessThanY_zeroInRange() {
        assertEquals(0, ChooseNum.chooseNum(-1, 0));
    }

    @Test
    void chooseNum_xLessThanY_negativeToPositive() {
        assertEquals(2, ChooseNum.chooseNum(-3, 2));
    }

    @Test
    void chooseNum_xLessThanY_onlyNegative() {
        assertEquals(-2, ChooseNum.chooseNum(-5, -2));
    }

    @Test
    void chooseNum_xLessThanY_noEvenNegative() {
        assertEquals(-1, ChooseNum.chooseNum(-5, -3));
    }

    @Test
    void chooseNum_xLessThanY_boundaryValues() {
        assertEquals(0, ChooseNum.chooseNum(-2, 0));
    }

    @Test
    void chooseNum_xLessThanY_negativeBoundary() {
        assertEquals(-2, ChooseNum.chooseNum(-2, -1));
    }
}