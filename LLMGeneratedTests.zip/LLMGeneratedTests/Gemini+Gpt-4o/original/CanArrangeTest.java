package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CanArrangeTest {

    @Test
    void canArrange_emptyList_returnsNegativeOne() {
        List<Object> arr = new ArrayList<>();
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_increasingList_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_decreasingList_returnsFirstViolationIndex() {
        List<Object> arr = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_singleElementList_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(1);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example1() {
        List<Object> arr = Arrays.asList(1, 2, 4, 3, 5);
        assertEquals(3, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example2() {
        List<Object> arr = Arrays.asList(1, 2, 3);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example3() {
        List<Object> arr = Arrays.asList(1, 4, 2, 5, 6, 7, 8, 9, 10);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example4() {
        List<Object> arr = Arrays.asList(4, 8, 5, 7, 3);
        assertEquals(4, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_mixedTypes_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(1, 2, "a", 3, 1);
        assertEquals(4, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_mixedTypes_noIntegerViolation_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(1, 2, "a", 3, 4);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_onlyStrings_returnsNegativeOne() {
        List<Object> arr = Arrays.asList("a", "b", "c");
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_firstElementViolates_returnsFirstViolationIndex() {
        List<Object> arr = Arrays.asList(5, 1, 2, 3, 4);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_lastElementViolates_returnsLastIndex() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 0);
        assertEquals(4, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_multipleViolations_returnsLastViolation() {
        List<Object> arr = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_allSameValue_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_alternatingValues_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(1, 5, 2, 5, 3);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_negativeValues_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_mixedPositiveNegative_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(1, 2, -1, 4, 5);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_onlyOneInteger_returnsNegativeOne() {
        List<Object> arr = Arrays.asList("a", "b", 1, "c");
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_integerAtBeginning_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(1, "a", "b", "c");
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_boundaryValues_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(100, 99, 101);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_boundaryNegativeValues_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(-100, -99, -101);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_zeroValue_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(0, 1, -1);
        assertEquals(2, CanArrange.canArrange(arr));
    }
}