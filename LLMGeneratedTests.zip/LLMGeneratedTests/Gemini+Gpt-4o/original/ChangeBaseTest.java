package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChangeBaseTest {

    @Test
    void changeBase_validInput_returnsCorrectBaseConversion() {
        assertEquals("22", ChangeBase.changeBase(8, 3));
    }

    @Test
    void changeBase_validInputBase2_returnsCorrectBaseConversion() {
        assertEquals("1000", ChangeBase.changeBase(8, 2));
    }

    @Test
    void changeBase_validInputBase2_returnsCorrectBaseConversion2() {
        assertEquals("111", ChangeBase.changeBase(7, 2));
    }

    @Test
    void changeBase_validInputBase3_returnsCorrectBaseConversion3() {
        assertEquals("100", ChangeBase.changeBase(9, 3));
    }

    @Test
    void changeBase_validInputBase2_returnsCorrectBaseConversionLarge() {
        assertEquals("11101010", ChangeBase.changeBase(234, 2));
    }

    @Test
    void changeBase_validInputPowerOf2Base2_returnsCorrectBaseConversion() {
        assertEquals("10000", ChangeBase.changeBase(16, 2));
    }

    @Test
    void changeBase_validInputSmallNumberBase3_returnsCorrectBaseConversion() {
        assertEquals("2", ChangeBase.changeBase(2, 3));
    }

    @Test
    void changeBase_validInputSmallNumberBase4_returnsCorrectBaseConversion() {
        assertEquals("3", ChangeBase.changeBase(3, 4));
    }

    @Test
    void changeBase_validInputSmallNumberBase5_returnsCorrectBaseConversion() {
        assertEquals("4", ChangeBase.changeBase(4, 5));
    }

    @Test
    void changeBase_validInputSmallNumberBase6_returnsCorrectBaseConversion() {
        assertEquals("5", ChangeBase.changeBase(5, 6));
    }

    @Test
    void changeBase_validInputSmallNumberBase7_returnsCorrectBaseConversion() {
        assertEquals("6", ChangeBase.changeBase(6, 7));
    }

    @Test
    void changeBase_validInputSmallNumberBase8_returnsCorrectBaseConversion() {
        assertEquals("7", ChangeBase.changeBase(7, 8));
    }

    @Test
    void changeBase_xEqualsBase_returnsCorrectBaseConversion() {
        assertEquals("10", ChangeBase.changeBase(8, 8));
    }

    @Test
    void changeBase_xLessThanBase_returnsCorrectBaseConversion() {
        assertEquals("1", ChangeBase.changeBase(1, 2));
    }

    @Test
    void changeBase_xEqualsOne_returnsOne() {
        assertEquals("1", ChangeBase.changeBase(1, 5));
    }

    @Test
    void changeBase_xEqualsZero_returnsEmptyString() {
        assertEquals("", ChangeBase.changeBase(0, 2));
    }

    @Test
    void changeBase_xIsSmall_returnsCorrectConversion() {
        assertEquals("11", ChangeBase.changeBase(3, 2));
    }

    @Test
    void changeBase_xIsSmallBaseIsLarge_returnsCorrectConversion() {
        assertEquals("2", ChangeBase.changeBase(2, 5));
    }

    @Test
    void changeBase_xIsMediumBaseIsSmall_returnsCorrectConversion() {
        assertEquals("1100100", ChangeBase.changeBase(100, 2));
    }

    @Test
    void changeBase_xIsMediumBaseIsMedium_returnsCorrectConversion() {
        assertEquals("144", ChangeBase.changeBase(100, 6));
    }

    @Test
    void changeBase_invalidBase_throwsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            ChangeBase.changeBase(10, 11);
        });
        assertEquals("Base must be less than 10", exception.getMessage());
    }

    @Test
    void changeBase_negativeInput_returnsCorrectBaseConversion() {
        assertEquals("Invalid input", ChangeBase.changeBase(-10, 2));
    }
}