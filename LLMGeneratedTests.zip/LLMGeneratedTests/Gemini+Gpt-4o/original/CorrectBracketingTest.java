package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketingTest {

    @Test
    void testEmptyString() {
        assertTrue(CorrectBracketing.correctBracketing(""));
    }

    @Test
    void testSimpleCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<>"));
    }

    @Test
    void testMultipleCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<<><>>"));
    }

    @Test
    void testComplexCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>"));
    }

    @Test
    void testLongCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>><<><><<>>>"));
    }

    @Test
    void testUnclosedBracketAtEnd() {
        assertFalse(CorrectBracketing.correctBracketing("<"));
    }

    @Test
    void testUnclosedBracketsAtEnd() {
        assertFalse(CorrectBracketing.correctBracketing("<<<<"));
    }

    @Test
    void testUnopenedBracketAtBeginning() {
        assertFalse(CorrectBracketing.correctBracketing(">"));
    }

    @Test
    void testUnopenedBracketsAtBeginning() {
        assertFalse(CorrectBracketing.correctBracketing(">>>>"));
    }

    @Test
    void testMixedUnbalancedBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("><<>"));
    }

    @Test
    void testUnclosedBracket() {
        assertFalse(CorrectBracketing.correctBracketing("<<>"));
    }

    @Test
    void testComplexUnbalancedBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>><<>"));
    }

    @Test
    void testComplexUnbalancedBrackets2() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>>><>"));
    }

    @Test
    void testLongUnbalancedBracketing() {
        assertFalse(CorrectBracketing.correctBracketing("<<<><>>>>"));
    }

    @Test
    void testSingleOpeningBracket() {
        assertFalse(CorrectBracketing.correctBracketing("<"));
    }

    @Test
    void testSingleClosingBracket() {
        assertFalse(CorrectBracketing.correctBracketing(">"));
    }

    @Test
    void testOpeningThenClosingThenOpening() {
        assertFalse(CorrectBracketing.correctBracketing("<>>"));
    }

    @Test
    void testClosingThenOpeningThenClosing() {
        assertFalse(CorrectBracketing.correctBracketing("><>"));
    }

    @Test
    void testManyOpeningThenManyClosing() {
        assertFalse(CorrectBracketing.correctBracketing("<<<>>>"));
    }

    @Test
    void testAlternatingUnbalanced() {
        assertFalse(CorrectBracketing.correctBracketing("><><><"));
    }

    @Test
    void testAlternatingUnbalanced2() {
        assertFalse(CorrectBracketing.correctBracketing("<><><>><"));
    }

    @Test
    void testSingleCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<>"));
    }

    @Test
    void testSingleCorrectBracketingWithExtra() {
        assertFalse(CorrectBracketing.correctBracketing("<><>><"));
    }
}