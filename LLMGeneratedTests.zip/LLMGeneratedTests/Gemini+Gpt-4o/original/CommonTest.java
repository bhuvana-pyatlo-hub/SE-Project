package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CommonTest {

    @Test
    void testCommon_emptyLists() {
        List<Integer> l1 = new ArrayList<>();
        List<Object> l2 = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l1Empty() {
        List<Integer> l1 = new ArrayList<>();
        List<Object> l2 = Arrays.asList(1, 2, 3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l2Empty() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_noCommonElements() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(4, 5, 6);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_someCommonElements() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(3, 4, 2);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_allElementsCommon() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_duplicateElementsInL1() {
        List<Integer> l1 = Arrays.asList(1, 2, 2, 3);
        List<Object> l2 = Arrays.asList(2, 3, 4);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_duplicateElementsInL2() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(2, 2, 3, 4);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_duplicateElementsInBothLists() {
        List<Integer> l1 = Arrays.asList(1, 2, 2, 3);
        List<Object> l2 = Arrays.asList(2, 2, 3, 4);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_mixedDataTypesInL2() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(1, "2", 3.0, 3);
        List<Object> expected = Arrays.asList(1, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_onlyNonIntegerObjectsInL2() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList("1", "2", "3");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_negativeNumbers() {
        List<Integer> l1 = Arrays.asList(-1, -2, 0, 1, 2);
        List<Object> l2 = Arrays.asList(-2, 0, 2, 3);
        List<Object> expected = Arrays.asList(-2, 0, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_zeroInLists() {
        List<Integer> l1 = Arrays.asList(0, 1, 2);
        List<Object> l2 = Arrays.asList(0, 2, 3);
        List<Object> expected = Arrays.asList(0, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l1ContainsNull() {
        List<Integer> l1 = new ArrayList<>();
        l1.add(1);
        l1.add(null);
        l1.add(2);
        List<Object> l2 = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l2ContainsNull() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = new ArrayList<>();
        l2.add(1);
        l2.add(null);
        l2.add(2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l1AndL2ContainNull() {
        List<Integer> l1 = new ArrayList<>();
        l1.add(1);
        l1.add(null);
        l1.add(2);
        List<Object> l2 = new ArrayList<>();
        l2.add(1);
        l2.add(null);
        l2.add(2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l1AndL2ContainSameObjectMultipleTimes() {
        List<Integer> l1 = Arrays.asList(1, 1, 2, 2, 3, 3);
        List<Object> l2 = Arrays.asList(1, 1, 2, 2, 3, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l1AndL2ContainSameObjectMultipleTimesAndDifferentObjects() {
        List<Integer> l1 = Arrays.asList(1, 1, 2, 2, 3, 3, 4);
        List<Object> l2 = Arrays.asList(1, 1, 2, 2, 3, 3, 5);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void testCommon_l2ContainsNonComparableObjects() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(1, "hello", 2, new Object(), 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }
}