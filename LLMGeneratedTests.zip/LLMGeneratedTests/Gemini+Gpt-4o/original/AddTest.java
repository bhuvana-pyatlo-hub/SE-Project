package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AddTest {

    @Test
    void testAddPositiveNumbers() {
        assertEquals(5, Add.add(2, 3));
    }

    @Test
    void testAddZeroAndPositive() {
        assertEquals(5, Add.add(0, 5));
    }

    @Test
    void testAddPositiveAndZero() {
        assertEquals(5, Add.add(5, 0));
    }

    @Test
    void testAddTwoZeros() {
        assertEquals(0, Add.add(0, 0));
    }

    @Test
    void testAddSmallPositiveNumbers() {
        assertEquals(2, Add.add(1, 1));
    }

    @Test
    void testAddBoundaryPositiveNumbers() {
        assertEquals(198, Add.add(99, 99));
    }

    @Test
    void testAddOne() {
        assertEquals(1, Add.add(0, 1));
    }

    @Test
    void testAddAnotherOne() {
        assertEquals(1, Add.add(1, 0));
    }

    @Test
    void testAddTwoSmallNumbers() {
        assertEquals(7, Add.add(3, 4));
    }

    @Test
    void testAddTwoMediumNumbers() {
        assertEquals(50, Add.add(20, 30));
    }

    @Test
    void testAddNearZero() {
        assertEquals(1, Add.add(1, 0));
    }

    @Test
    void testAddNearMax() {
        assertEquals(198, Add.add(99, 99));
    }

    @Test
    void testAddDifferentNumbers() {
        assertEquals(15, Add.add(5, 10));
    }

    @Test
    void testAddEqualNumbers() {
        assertEquals(20, Add.add(10, 10));
    }

    @Test
    void testAddSmallAndLarge() {
        assertEquals(100, Add.add(1, 99));
    }

    @Test
    void testAddLargeAndSmall() {
        assertEquals(100, Add.add(99, 1));
    }

    @Test
    void testAddNegativeAndPositive() {
        assertEquals(0, Add.add(-50, 50));
    }

    @Test
    void testAddNegativeNumbers() {
        assertEquals(-10, Add.add(-5, -5));
    }

    @Test
    void testAddNegativeAndZero() {
        assertEquals(-5, Add.add(-5, 0));
    }

    @Test
    void testAddZeroAndNegative() {
        assertEquals(-5, Add.add(0, -5));
    }

    @Test
    void testAddMaxNegativeValues() {
        assertEquals(-2, Add.add(-1, -1));
    }

    @Test
    void testAddMinNegativeValues() {
        assertEquals(-198, Add.add(-99, -99));
    }
}