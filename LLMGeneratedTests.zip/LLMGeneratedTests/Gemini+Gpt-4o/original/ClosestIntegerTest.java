package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClosestIntegerTest {

    @Test
    void closestInteger_positiveInteger() {
        assertEquals(10, ClosestInteger.closestInteger("10"));
    }

    @Test
    void closestInteger_positiveDecimalRoundUp() {
        assertEquals(15, ClosestInteger.closestInteger("14.5"));
    }

    @Test
    void closestInteger_negativeDecimalRoundDown() {
        assertEquals(-16, ClosestInteger.closestInteger("-15.5"));
    }

    @Test
    void closestInteger_positiveDecimalRoundDown() {
        assertEquals(15, ClosestInteger.closestInteger("15.3"));
    }

    @Test
    void closestInteger_zero() {
        assertEquals(0, ClosestInteger.closestInteger("0"));
    }

    @Test
    void closestInteger_positiveDecimalNearZeroRoundUp() {
        assertEquals(1, ClosestInteger.closestInteger("0.5"));
    }

    @Test
    void closestInteger_negativeDecimalNearZeroRoundDown() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.5"));
    }

    @Test
    void closestInteger_positiveDecimalSlightlyAboveInteger() {
        assertEquals(11, ClosestInteger.closestInteger("10.1"));
    }

    @Test
    void closestInteger_negativeDecimalSlightlyBelowInteger() {
        assertEquals(-10, ClosestInteger.closestInteger("-9.9"));
    }

    @Test
    void closestInteger_positiveDecimalExactlyHalf() {
        assertEquals(51, ClosestInteger.closestInteger("50.5"));
    }

    @Test
    void closestInteger_negativeDecimalExactlyHalf() {
        assertEquals(-51, ClosestInteger.closestInteger("-50.5"));
    }

    @Test
    void closestInteger_positiveIntegerNearMax() {
        assertEquals(100, ClosestInteger.closestInteger("100"));
    }

    @Test
    void closestInteger_negativeIntegerNearMin() {
        assertEquals(-100, ClosestInteger.closestInteger("-100"));
    }

    @Test
    void closestInteger_positiveDecimalSmallValue() {
        assertEquals(1, ClosestInteger.closestInteger("0.6"));
    }

    @Test
    void closestInteger_negativeDecimalSmallValue() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.6"));
    }

    @Test
    void closestInteger_positiveIntegerOne() {
        assertEquals(1, ClosestInteger.closestInteger("1"));
    }

    @Test
    void closestInteger_negativeIntegerOne() {
        assertEquals(-1, ClosestInteger.closestInteger("-1"));
    }

    @Test
    void closestInteger_positiveDecimalRoundUpToZero() {
        assertEquals(0, ClosestInteger.closestInteger("0.4"));
    }

    @Test
    void closestInteger_negativeDecimalRoundDownToZero() {
        assertEquals(0, ClosestInteger.closestInteger("-0.4"));
    }

    @Test
    void closestInteger_invalidInput() {
        assertThrows(NumberFormatException.class, () -> ClosestInteger.closestInteger("invalid"));
    }
}