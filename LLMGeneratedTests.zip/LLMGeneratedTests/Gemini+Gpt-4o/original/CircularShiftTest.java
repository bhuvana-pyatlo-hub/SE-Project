package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CircularShiftTest {

    @Test
    void circularShift_validInput_shiftLessThanLength() {
        assertEquals("21", CircularShift.circularShift(12, 1));
    }

    @Test
    void circularShift_validInput_shiftGreaterThanLength() {
        assertEquals("79", CircularShift.circularShift(97, 8));
    }

    @Test
    void circularShift_validInput_shiftEqualsLength() {
        assertEquals("12", CircularShift.circularShift(12, 2));
    }

    @Test
    void circularShift_validInput_singleDigitNumber() {
        assertEquals("5", CircularShift.circularShift(5, 1));
    }

    @Test
    void circularShift_validInput_zeroShift() {
        assertEquals("123", CircularShift.circularShift(123, 0));
    }

    @Test
    void circularShift_validInput_largeShift() {
        assertEquals("321", CircularShift.circularShift(123, 5));
    }

    @Test
    void circularShift_validInput_twoDigitNumber_shiftOne() {
        assertEquals("21", CircularShift.circularShift(12, 1));
    }

    @Test
    void circularShift_validInput_threeDigitNumber_shiftOne() {
        assertEquals("312", CircularShift.circularShift(123, 1));
    }

    @Test
    void circularShift_validInput_threeDigitNumber_shiftTwo() {
        assertEquals("231", CircularShift.circularShift(123, 2));
    }

    @Test
    void circularShift_validInput_fourDigitNumber_shiftOne() {
        assertEquals("4123", CircularShift.circularShift(1234, 1));
    }

    @Test
    void circularShift_validInput_fourDigitNumber_shiftTwo() {
        assertEquals("3412", CircularShift.circularShift(1234, 2));
    }

    @Test
    void circularShift_validInput_fourDigitNumber_shiftThree() {
        assertEquals("2341", CircularShift.circularShift(1234, 3));
    }

    @Test
    void circularShift_validInput_sameDigits() {
        assertEquals("11", CircularShift.circularShift(11, 1));
    }

    @Test
    void circularShift_validInput_sameDigits_largeShift() {
        assertEquals("11", CircularShift.circularShift(11, 101));
    }

    @Test
    void circularShift_validInput_boundaryShift_oneLessThanLength() {
        assertEquals("312", CircularShift.circularShift(123, 2));
    }

    @Test
    void circularShift_validInput_numberWithZeroes_shiftOne() {
        assertEquals("010", CircularShift.circularShift(100, 1));
    }

    @Test
    void circularShift_validInput_numberWithZeroes_shiftTwo() {
        assertEquals("001", CircularShift.circularShift(100, 2));
    }

    @Test
    void circularShift_validInput_numberWithZeroes_shiftGreaterThanLength() {
        assertEquals("001", CircularShift.circularShift(100, 8));
    }

    @Test
    void circularShift_validInput_numberWithZeroes_noShift() {
        assertEquals("100", CircularShift.circularShift(100, 0));
    }

    @Test
    void circularShift_validInput_negativeNumber() {
        assertEquals("01", CircularShift.circularShift(-10, 1));
    }

    @Test
    void circularShift_validInput_negativeNumber_largeShift() {
        assertEquals("01", CircularShift.circularShift(-10, 5));
    }

    @Test
    void circularShift_validInput_zeroInput() {
        assertEquals("0", CircularShift.circularShift(0, 1));
    }

    @Test
    void circularShift_invalidInput_shiftNegative() {
        assertEquals("123", CircularShift.circularShift(123, -1));
    }

    @Test
    void circularShift_invalidInput_shiftZero() {
        assertEquals("123", CircularShift.circularShift(123, 0));
    }
}