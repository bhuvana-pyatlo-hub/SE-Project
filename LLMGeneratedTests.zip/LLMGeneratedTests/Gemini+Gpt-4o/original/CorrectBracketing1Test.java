package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketing1Test {

    @Test
    void testCorrectBracketing_emptyString() {
        assertTrue(CorrectBracketing1.correctBracketing(""));
    }

    @Test
    void testCorrectBracketing_simpleCorrect() {
        assertTrue(CorrectBracketing1.correctBracketing("()"));
    }

    @Test
    void testCorrectBracketing_nestedCorrect() {
        assertTrue(CorrectBracketing1.correctBracketing("(()())"));
    }

    @Test
    void testCorrectBracketing_multipleCorrect() {
        assertTrue(CorrectBracketing1.correctBracketing("()()(()())()"));
    }

    @Test
    void testCorrectBracketing_complexCorrect() {
        assertTrue(CorrectBracketing1.correctBracketing("()()((()()())())(()()(()))"));
    }

    @Test
    void testCorrectBracketing_unclosedOpen() {
        assertFalse(CorrectBracketing1.correctBracketing("((()())))"));
    }

    @Test
    void testCorrectBracketing_unclosedClose() {
        assertFalse(CorrectBracketing1.correctBracketing(")(()"));
    }

    @Test
    void testCorrectBracketing_singleOpen() {
        assertFalse(CorrectBracketing1.correctBracketing("("));
    }

    @Test
    void testCorrectBracketing_multipleOpen() {
        assertFalse(CorrectBracketing1.correctBracketing("(((("));
    }

    @Test
    void testCorrectBracketing_singleClose() {
        assertFalse(CorrectBracketing1.correctBracketing(")"));
    }

    @Test
    void testCorrectBracketing_unclosedOpenAtEnd() {
        assertFalse(CorrectBracketing1.correctBracketing("(()"));
    }

    @Test
    void testCorrectBracketing_unclosedCloseInMiddle() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())())(()"));
    }

    @Test
    void testCorrectBracketing_unclosedCloseAtEnd() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())()))()"));
    }

    @Test
    void testCorrectBracketing_startsWithClose() {
        assertFalse(CorrectBracketing1.correctBracketing(")("));
    }

    @Test
    void testCorrectBracketing_onlyCloses() {
        assertFalse(CorrectBracketing1.correctBracketing("))))"));
    }

    @Test
    void testCorrectBracketing_alternating() {
        assertFalse(CorrectBracketing1.correctBracketing(")(()("));
    }

    @Test
    void testCorrectBracketing_boundaryValues() {
        assertTrue(CorrectBracketing1.correctBracketing("()()")); // Even number of brackets
        assertFalse(CorrectBracketing1.correctBracketing("()(()")); // Odd number of brackets
    }

    @Test
    void testCorrectBracketing_negativeValues() {
        assertFalse(CorrectBracketing1.correctBracketing(")(")); // Starts with close
        assertFalse(CorrectBracketing1.correctBracketing(")()(")); // Invalid sequence
    }
}