package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountUpperTest {

    @Test
    void countUpper_emptyString_returnsZero() {
        assertEquals(0, CountUpper.countUpper(""));
    }

    @Test
    void countUpper_noUppercaseVowels_returnsZero() {
        assertEquals(0, CountUpper.countUpper("abcdefg"));
    }

    @Test
    void countUpper_uppercaseVowelAtOddIndex_returnsZero() {
        assertEquals(0, CountUpper.countUpper("aE"));
    }

    @Test
    void countUpper_uppercaseVowelAtEvenIndex_returnsOne() {
        assertEquals(1, CountUpper.countUpper("A"));
    }

    @Test
    void countUpper_multipleUppercaseVowelsOnlyAtEvenIndices_returnsCorrectCount() {
        assertEquals(2, CountUpper.countUpper("AE"));
    }

    @Test
    void countUpper_multipleUppercaseVowelsAtEvenAndOddIndices_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AEa"));
    }

    @Test
    void countUpper_lowercaseVowelsAtEvenIndices_returnsZero() {
        assertEquals(0, CountUpper.countUpper("aeiou"));
    }

    @Test
    void countUpper_uppercaseConsonantsAtEvenIndices_returnsZero() {
        assertEquals(0, CountUpper.countUpper("BCDFG"));
    }

    @Test
    void countUpper_mixedCaseVowelsAndConsonants_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AbCdEf"));
    }

    @Test
    void countUpper_stringWithNumbersAndSymbols_returnsZero() {
        assertEquals(0, CountUpper.countUpper("123!@#"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelAndOtherCharacters_returnsOne() {
        assertEquals(1, CountUpper.countUpper("A123"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelAtEnd_returnsZero() {
        assertEquals(0, CountUpper.countUpper("abcE"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacterUppercaseVowel_returnsOne() {
        assertEquals(1, CountUpper.countUpper("A"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacterLowercaseVowel_returnsZero() {
        assertEquals(0, CountUpper.countUpper("a"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacterUppercaseConsonant_returnsZero() {
        assertEquals(0, CountUpper.countUpper("B"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacterLowercaseConsonant_returnsZero() {
        assertEquals(0, CountUpper.countUpper("b"));
    }

    @Test
    void countUpper_stringWithMultipleCharactersIncludingUppercaseVowels_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AxEyIz"));
    }

    @Test
    void countUpper_stringWithMultipleUppercaseVowelsAndOtherCharacters_returnsCorrectCount() {
        assertEquals(2, CountUpper.countUpper("AEIOU"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelsAndLowercaseVowels_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AaEeIiOoUu"));
    }

    @Test
    void countUpper_stringWithMixedCaseAndSymbols_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A!b@C#d$E%"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelAtEvenIndexAndConsonants_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A1B2C3D4"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelAtEvenIndexAndLowercaseVowel_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("Ae"));
    }

    @Test
    void countUpper_stringWithAllUppercaseVowelsAtEvenIndices_returnsCorrectCount() {
        assertEquals(3, CountUpper.countUpper("AEIOUAEIOU"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelAtFirstAndLastEvenIndex_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A1B2C3D4E"));
    }
}