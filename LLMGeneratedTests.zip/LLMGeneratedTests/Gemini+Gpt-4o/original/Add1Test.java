package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class Add1Test {

    @Test
    void testAdd_emptyList() {
        List<Integer> lst = Collections.emptyList();
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_singleElementList_oddIndex() {
        List<Integer> lst = Collections.singletonList(2);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_singleElementList_evenIndex() {
        List<Integer> lst = Collections.singletonList(3);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_twoElementsList_evenAtIndex1() {
        List<Integer> lst = Arrays.asList(1, 2);
        int result = Add1.add(lst);
        assertEquals(2, result);
    }

    @Test
    void testAdd_twoElementsList_oddAtIndex1() {
        List<Integer> lst = Arrays.asList(1, 3);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_noEvenAtOddIndices() {
        List<Integer> lst = Arrays.asList(1, 3, 5, 7, 9);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_someEvenAtOddIndices() {
        List<Integer> lst = Arrays.asList(1, 2, 3, 4, 5, 6);
        int result = Add1.add(lst);
        assertEquals(12, result);
    }

    @Test
    void testAdd_multipleElements_allEvenAtOddIndices() {
        List<Integer> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);
        int result = Add1.add(lst);
        assertEquals(20, result);
    }

    @Test
    void testAdd_multipleElements_mixedEvenOddAtOddIndices() {
        List<Integer> lst = Arrays.asList(1, 2, 3, 3, 5, 6, 7, 7);
        int result = Add1.add(lst);
        assertEquals(8, result);
    }

    @Test
    void testAdd_multipleElements_zeroAtOddIndex() {
        List<Integer> lst = Arrays.asList(1, 0, 3, 0, 5, 0);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_negativeNumbers() {
        List<Integer> lst = Arrays.asList(1, -2, 3, -4, 5, -6);
        int result = Add1.add(lst);
        assertEquals(-12, result);
    }

    @Test
    void testAdd_multipleElements_largeEvenNumbers() {
        List<Integer> lst = Arrays.asList(1, 100, 3, 200, 5, 300);
        int result = Add1.add(lst);
        assertEquals(600, result);
    }

    @Test
    void testAdd_multipleElements_allOddNumbers() {
        List<Integer> lst = Arrays.asList(1, 3, 5, 7, 9, 11);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_allEvenNumbers() {
        List<Integer> lst = Arrays.asList(2, 4, 6, 8, 10, 12);
        int result = Add1.add(lst);
        assertEquals(36, result);
    }

    @Test
    void testAdd_example1() {
        List<Integer> lst = Arrays.asList(4, 2, 6, 7);
        int result = Add1.add(lst);
        assertEquals(2, result);
    }

    @Test
    void testAdd_example2() {
        List<Integer> lst = Arrays.asList(4, 88);
        int result = Add1.add(lst);
        assertEquals(88, result);
    }

    @Test
    void testAdd_example3() {
        List<Integer> lst = Arrays.asList(4, 5, 6, 7, 2, 122);
        int result = Add1.add(lst);
        assertEquals(122, result);
    }

    @Test
    void testAdd_example4() {
        List<Integer> lst = Arrays.asList(4, 0, 6, 7);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_example5() {
        List<Integer> lst = Arrays.asList(4, 4, 6, 8);
        int result = Add1.add(lst);
        assertEquals(12, result);
    }

    @Test
    void testAdd_longListWithMixedValues() {
        List<Integer> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16);
        int result = Add1.add(lst);
        assertEquals(2 + 6 + 10 + 14, result);
    }

    @Test
    void testAdd_boundaryValues() {
        List<Integer> lst = Arrays.asList(-100, 0, 100, 2, -2, 4);
        int result = Add1.add(lst);
        assertEquals(6, result); // 2 + 4 from odd indices
    }

    @Test
    void testAdd_minimumValidInputs() {
        List<Integer> lst = Arrays.asList(0, 0);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_maximumValidInputs() {
        List<Integer> lst = Arrays.asList(100, 100, 100, 100);
        int result = Add1.add(lst);
        assertEquals(100, result); // Only the second element at index 1 is counted
    }
}