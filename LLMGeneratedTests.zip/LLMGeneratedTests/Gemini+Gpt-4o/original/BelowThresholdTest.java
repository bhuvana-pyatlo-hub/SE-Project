package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class BelowThresholdTest {

    @Test
    void testEmptyList() {
        List<Integer> list = Collections.emptyList();
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void testAllElementsBelowThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void testOneElementAboveThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3, 10, 5);
        assertFalse(BelowThreshold.belowThreshold(list, 9));
    }

    @Test
    void testAllElementsEqualThreshold() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5, 5);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void testAllElementsAboveThreshold() {
        List<Integer> list = Arrays.asList(10, 11, 12, 13, 14);
        assertFalse(BelowThreshold.belowThreshold(list, 9));
    }

    @Test
    void testSingleElementListBelowThreshold() {
        List<Integer> list = Collections.singletonList(5);
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void testSingleElementListAboveThreshold() {
        List<Integer> list = Collections.singletonList(10);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void testSingleElementListEqualToThreshold() {
        List<Integer> list = Collections.singletonList(5);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void testMixedValuesBelowAndAboveThreshold() {
        List<Integer> list = Arrays.asList(1, 5, 10, 2, 8);
        assertFalse(BelowThreshold.belowThreshold(list, 9));
    }

    @Test
    void testMixedValuesBelowAndEqualToThreshold() {
        List<Integer> list = Arrays.asList(1, 5, 9, 2, 8);
        assertFalse(BelowThreshold.belowThreshold(list, 9));
    }

    @Test
    void testThresholdIsZero() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertFalse(BelowThreshold.belowThreshold(list, 0));
    }

    @Test
    void testThresholdIsNegative() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(BelowThreshold.belowThreshold(list, -1));
    }

    @Test
    void testListWithNegativeNumbersBelowThreshold() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertTrue(BelowThreshold.belowThreshold(list, 0));
    }

    @Test
    void testListWithNegativeNumbersAboveThreshold() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertFalse(BelowThreshold.belowThreshold(list, -3));
    }

    @Test
    void testListWithZeroValueBelowThreshold() {
        List<Integer> list = Arrays.asList(0, 1, 2, 3, 4);
        assertTrue(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void testListWithZeroValueAboveThreshold() {
        List<Integer> list = Arrays.asList(0, 1, 2, 3, 4);
        assertFalse(BelowThreshold.belowThreshold(list, 1));
    }

    @Test
    void testListWithDuplicateValuesBelowThreshold() {
        List<Integer> list = Arrays.asList(1, 1, 1, 1, 1);
        assertTrue(BelowThreshold.belowThreshold(list, 2));
    }

    @Test
    void testListWithDuplicateValuesAboveThreshold() {
        List<Integer> list = Arrays.asList(2, 2, 2, 2, 2);
        assertFalse(BelowThreshold.belowThreshold(list, 2));
    }

    @Test
    void testListWithLargeThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertTrue(BelowThreshold.belowThreshold(list, 100));
    }

    @Test
    void testFirstElementAboveThreshold() {
        List<Integer> list = Arrays.asList(10, 1, 2, 3);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void testFirstElementEqualToThreshold() {
        List<Integer> list = Arrays.asList(5, 1, 2, 3);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void testLastElementAboveThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3, 10);
        assertFalse(BelowThreshold.belowThreshold(list, 9));
    }

    @Test
    void testLastElementEqualToThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3, 3);
        assertFalse(BelowThreshold.belowThreshold(list, 3));
    }
}