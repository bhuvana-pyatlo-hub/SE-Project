package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BelowZeroTest {

    @Test
    void belowZero_emptyList_returnsFalse() {
        List<Object> operations = new ArrayList<>();
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_allPositive_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2, 3);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_goesBelowZero_returnsTrue() {
        List<Object> operations = Arrays.asList(1, 2, -4, 5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_staysAboveZero_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2, -3, 1, 2, -3);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_goesBelowZeroThenAbove_returnsTrue() {
        List<Object> operations = Arrays.asList(1, 2, -4, 5, 6);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_alternatingPositiveNegative_returnsFalse() {
        List<Object> operations = Arrays.asList(1, -1, 2, -2, 5, -5, 4, -4);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_alternatingPositiveNegativeGoesBelow_returnsTrue() {
        List<Object> operations = Arrays.asList(1, -1, 2, -2, 5, -5, 4, -5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_initialNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(-1);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_onlyZeroes_returnsFalse() {
        List<Object> operations = Arrays.asList(0, 0, 0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedTypes_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(1, 2.0, -4, 5, 6.0);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedTypesNoBelowZero_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(1, 2.0, -2, 5, 1.0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_zeroBalanceThenNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(0, -1);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_zeroBalanceThenPositive_returnsFalse() {
        List<Object> operations = Arrays.asList(0, 1);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_onlyNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(-1, -2, -3);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_invalidInputType_throwsException() {
        List<Object> operations = Arrays.asList("invalid");
        assertThrows(IllegalArgumentException.class, () -> BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedValidAndInvalidInput_throwsException() {
        List<Object> operations = Arrays.asList(1, "invalid", 2);
        assertThrows(IllegalArgumentException.class, () -> BelowZero.belowZero(operations));
    }
}