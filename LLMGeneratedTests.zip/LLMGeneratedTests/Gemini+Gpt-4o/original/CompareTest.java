package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CompareTest {

    @Test
    void compare_emptyLists_returnsEmptyList() {
        List<Integer> game = new ArrayList<>();
        List<Integer> guess = new ArrayList<>();
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_equalLists_returnsListWithZeros() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_differentLists_returnsListWithDifferences() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(4, 5, 6);
        List<Integer> expected = Arrays.asList(3, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_mixedLists_returnsListWithMixedResults() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(1, 5, 0);
        List<Integer> expected = Arrays.asList(0, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_negativeNumbers_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(-1, -2, -3);
        List<Integer> guess = Arrays.asList(-4, -5, -6);
        List<Integer> expected = Arrays.asList(3, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_negativeAndPositiveNumbers_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(-1, 2, -3);
        List<Integer> guess = Arrays.asList(4, -5, 6);
        List<Integer> expected = Arrays.asList(5, 7, 9);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_zeroValues_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(0, 0, 0);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_sameSizeLists_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> guess = Arrays.asList(5, 4, 3, 2, 1);
        List<Integer> expected = Arrays.asList(4, 2, 0, 2, 4);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allZeros_returnsAllZeros() {
        List<Integer> game = Arrays.asList(0, 0, 0, 0, 0);
        List<Integer> guess = Arrays.asList(0, 0, 0, 0, 0);
        List<Integer> expected = Arrays.asList(0, 0, 0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_oneElementLists_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(5);
        List<Integer> guess = Arrays.asList(10);
        List<Integer> expected = Arrays.asList(5);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_oneElementLists_returnsZero() {
        List<Integer> game = Arrays.asList(5);
        List<Integer> guess = Arrays.asList(5);
        List<Integer> expected = Arrays.asList(0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_negativeGuesses_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(-1, -2, -3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_positiveGuesses_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(-1, -2, -3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_mixedPositiveNegative_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(1, -2, 3);
        List<Integer> guess = Arrays.asList(-1, 2, -3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allSameValues_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(5, 5, 5);
        List<Integer> guess = Arrays.asList(1, 1, 1);
        List<Integer> expected = Arrays.asList(4, 4, 4);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allSameValuesEqual_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(5, 5, 5);
        List<Integer> guess = Arrays.asList(5, 5, 5);
        List<Integer> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithZeroAndPositive_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(0, 1, 2);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithZeroAndNegative_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(0, -1, -2);
        List<Integer> guess = Arrays.asList(-1, -2, -3);
        List<Integer> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_nullLists_returnsEmptyList() {
        List<Integer> game = null;
        List<Integer> guess = null;
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, Compare.compare(new ArrayList<>(), new ArrayList<>()));
    }

    @Test
    void compare_validInput_returnsNonNullList() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> result = Compare.compare(game, guess);
        assertNotNull(result);
    }
}