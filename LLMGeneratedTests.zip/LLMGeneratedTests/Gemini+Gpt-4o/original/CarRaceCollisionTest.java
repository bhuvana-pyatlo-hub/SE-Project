package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarRaceCollisionTest {

    @Test
    void carRaceCollision_zeroCars() {
        assertEquals(0, CarRaceCollision.carRaceCollision(0));
    }

    @Test
    void carRaceCollision_oneCar() {
        assertEquals(1, CarRaceCollision.carRaceCollision(1));
    }

    @Test
    void carRaceCollision_twoCars() {
        assertEquals(4, CarRaceCollision.carRaceCollision(2));
    }

    @Test
    void carRaceCollision_threeCars() {
        assertEquals(9, CarRaceCollision.carRaceCollision(3));
    }

    @Test
    void carRaceCollision_fourCars() {
        assertEquals(16, CarRaceCollision.carRaceCollision(4));
    }

    @Test
    void carRaceCollision_fiveCars() {
        assertEquals(25, CarRaceCollision.carRaceCollision(5));
    }

    @Test
    void carRaceCollision_sixCars() {
        assertEquals(36, CarRaceCollision.carRaceCollision(6));
    }

    @Test
    void carRaceCollision_sevenCars() {
        assertEquals(49, CarRaceCollision.carRaceCollision(7));
    }

    @Test
    void carRaceCollision_eightCars() {
        assertEquals(64, CarRaceCollision.carRaceCollision(8));
    }

    @Test
    void carRaceCollision_nineCars() {
        assertEquals(81, CarRaceCollision.carRaceCollision(9));
    }

    @Test
    void carRaceCollision_tenCars() {
        assertEquals(100, CarRaceCollision.carRaceCollision(10));
    }

    @Test
    void carRaceCollision_elevenCars() {
        assertEquals(121, CarRaceCollision.carRaceCollision(11));
    }

    @Test
    void carRaceCollision_twelveCars() {
        assertEquals(144, CarRaceCollision.carRaceCollision(12));
    }

    @Test
    void carRaceCollision_thirteenCars() {
        assertEquals(169, CarRaceCollision.carRaceCollision(13));
    }

    @Test
    void carRaceCollision_fourteenCars() {
        assertEquals(196, CarRaceCollision.carRaceCollision(14));
    }

    @Test
    void carRaceCollision_fifteenCars() {
        assertEquals(225, CarRaceCollision.carRaceCollision(15));
    }

    @Test
    void carRaceCollision_sixteenCars() {
        assertEquals(256, CarRaceCollision.carRaceCollision(16));
    }

    @Test
    void carRaceCollision_seventeenCars() {
        assertEquals(289, CarRaceCollision.carRaceCollision(17));
    }

    @Test
    void carRaceCollision_eighteenCars() {
        assertEquals(324, CarRaceCollision.carRaceCollision(18));
    }

    @Test
    void carRaceCollision_nineteenCars() {
        assertEquals(361, CarRaceCollision.carRaceCollision(19));
    }

    @Test
    void carRaceCollision_twentyCars() {
        assertEquals(400, CarRaceCollision.carRaceCollision(20));
    }

    @Test
    void carRaceCollision_negativeCars() {
        assertThrows(IllegalArgumentException.class, () -> {
            CarRaceCollision.carRaceCollision(-1);
        });
    }

    @Test
    void carRaceCollision_largeInput() {
        assertEquals(44100, CarRaceCollision.carRaceCollision(210));
    }
}