package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ConcatenateTest {

    @Test
    void concatenate_emptyList_returnsEmptyString() {
        List<Object> emptyList = Collections.emptyList();
        assertEquals("", Concatenate.concatenate(emptyList));
    }

    @Test
    void concatenate_singleStringList_returnsSingleString() {
        List<Object> singleStringList = Collections.singletonList("hello");
        assertEquals("hello", Concatenate.concatenate(singleStringList));
    }

    @Test
    void concatenate_multipleStringsList_returnsConcatenatedString() {
        List<Object> multipleStringsList = Arrays.asList("a", "b", "c");
        assertEquals("abc", Concatenate.concatenate(multipleStringsList));
    }

    @Test
    void concatenate_listWithNull_returnsStringWithNull() {
        List<Object> listWithNull = Arrays.asList("a", null, "c");
        assertEquals("anullc", Concatenate.concatenate(listWithNull));
    }

    @Test
    void concatenate_listWithEmptyString_returnsStringWithEmptyString() {
        List<Object> listWithEmptyString = Arrays.asList("a", "", "c");
        assertEquals("ac", Concatenate.concatenate(listWithEmptyString));
    }

    @Test
    void concatenate_listWithNumbers_returnsConcatenatedString() {
        List<Object> listWithNumbers = Arrays.asList("a", 1, "c");
        assertEquals("a1c", Concatenate.concatenate(listWithNumbers));
    }

    @Test
    void concatenate_listWithSpecialCharacters_returnsConcatenatedString() {
        List<Object> listWithSpecialCharacters = Arrays.asList("a", "!", "c");
        assertEquals("a!c", Concatenate.concatenate(listWithSpecialCharacters));
    }

    @Test
    void concatenate_listWithMixedTypes_returnsConcatenatedString() {
        List<Object> listWithMixedTypes = Arrays.asList("a", 1, "c", true);
        assertEquals("a1ctrue", Concatenate.concatenate(listWithMixedTypes));
    }

    @Test
    void concatenate_longList_returnsConcatenatedString() {
        List<Object> longList = Arrays.asList("a", "b", "c", "d", "e", "f", "g");
        assertEquals("abcdefg", Concatenate.concatenate(longList));
    }

    @Test
    void concatenate_listWithLeadingAndTrailingSpaces_returnsConcatenatedString() {
        List<Object> listWithSpaces = Arrays.asList(" a", "b ", "c");
        assertEquals(" ab c", Concatenate.concatenate(listWithSpaces));
    }

    @Test
    void concatenate_listWithOnlySpaces_returnsConcatenatedString() {
        List<Object> listWithOnlySpaces = Arrays.asList(" ", " ", " ");
        assertEquals("   ", Concatenate.concatenate(listWithOnlySpaces));
    }

    @Test
    void concatenate_listWithUnicodeCharacters_returnsConcatenatedString() {
        List<Object> listWithUnicode = Arrays.asList("你好", "世界");
        assertEquals("你好世界", Concatenate.concatenate(listWithUnicode));
    }

    @Test
    void concatenate_listWithEmptyAndNull_returnsConcatenatedString() {
        List<Object> listWithEmptyAndNull = Arrays.asList("", null);
        assertEquals("null", Concatenate.concatenate(listWithEmptyAndNull));
    }

    @Test
    void concatenate_listWithIntegerObjects_returnsConcatenatedString() {
        List<Object> listWithIntegerObjects = Arrays.asList(1, 2, 3);
        assertEquals("123", Concatenate.concatenate(listWithIntegerObjects));
    }

    @Test
    void concatenate_listWithBooleanObjects_returnsConcatenatedString() {
        List<Object> listWithBooleanObjects = Arrays.asList(true, false);
        assertEquals("truefalse", Concatenate.concatenate(listWithBooleanObjects));
    }

    @Test
    void concatenate_listWithDoubleObjects_returnsConcatenatedString() {
        List<Object> listWithDoubleObjects = Arrays.asList(1.1, 2.2, 3.3);
        assertEquals("1.12.23.3", Concatenate.concatenate(listWithDoubleObjects));
    }

    @Test
    void concatenate_listWithObjectToStringOverride_returnsConcatenatedString() {
        class MyObject {
            @Override
            public String toString() {
                return "MyObject";
            }
        }
        List<Object> listWithCustomObject = Arrays.asList(new MyObject(), new MyObject());
        assertEquals("MyObjectMyObject", Concatenate.concatenate(listWithCustomObject));
    }

    @Test
    void concatenate_listWithEmptyStrings_returnsEmptyString() {
        List<Object> listWithEmptyStrings = Arrays.asList("", "");
        assertEquals("", Concatenate.concatenate(listWithEmptyStrings));
    }

    @Test
    void concatenate_listWithSingleCharacterStrings_returnsConcatenatedString() {
        List<Object> listWithSingleCharacters = Arrays.asList("a", "b", "c");
        assertEquals("abc", Concatenate.concatenate(listWithSingleCharacters));
    }

    @Test
    void concatenate_listWithNumbersAndStrings_returnsConcatenatedString() {
        List<Object> listWithNumbersAndStrings = Arrays.asList(1, "b", 3);
        assertEquals("1b3", Concatenate.concatenate(listWithNumbersAndStrings));
    }

    @Test
    void concatenate_listWithNegativeNumbers_returnsConcatenatedString() {
        List<Object> listWithNegativeNumbers = Arrays.asList(-1, -2, -3);
        assertEquals("-1-2-3", Concatenate.concatenate(listWithNegativeNumbers));
    }

    @Test
    void concatenate_listWithBoundaryValues_returnsConcatenatedString() {
        List<Object> listWithBoundaryValues = Arrays.asList(-100, 0, 100);
        assertEquals("-1000100", Concatenate.concatenate(listWithBoundaryValues));
    }
}