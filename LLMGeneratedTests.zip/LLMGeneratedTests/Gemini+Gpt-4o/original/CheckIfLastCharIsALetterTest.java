package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CheckIfLastCharIsALetterTest {

    @Test
    void checkIfLastCharIsALetter_emptyString_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(""));
    }

    @Test
    void checkIfLastCharIsALetter_singleLetter_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("A"));
    }

    @Test
    void checkIfLastCharIsALetter_singleDigit_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("1"));
    }

    @Test
    void checkIfLastCharIsALetter_applePie_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pie"));
    }

    @Test
    void checkIfLastCharIsALetter_applePiE_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e"));
    }

    @Test
    void checkIfLastCharIsALetter_applePiE_trailingSpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e "));
    }

    @Test
    void checkIfLastCharIsALetter_eeeee_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee"));
    }

    @Test
    void checkIfLastCharIsALetter_pumpkinPieTrailingSpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie "));
    }

    @Test
    void checkIfLastCharIsALetter_pumpkinPie1_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie 1"));
    }

    @Test
    void checkIfLastCharIsALetter_eeeeeE_trailingSpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee e "));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsDigit_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc 1"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsSpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc "));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsSpecialChar_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc !"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsLetter_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsNotLetter_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("ab c"));
    }

    @Test
    void checkIfLastCharIsALetter_singleLetterLowercase_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("a"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsDigit_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("ab1 c"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsSpecialChar_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("ab! c"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsSpace_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("ab c"));
    }

    @Test
    void checkIfLastCharIsALetter_longStringWithLastCharLetterAndSecondLastLetter_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("This is a long string abc"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsSpecialCharWithTrailingSpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World! "));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterWithMultipleSpaces_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Hello World  "));
    }
}