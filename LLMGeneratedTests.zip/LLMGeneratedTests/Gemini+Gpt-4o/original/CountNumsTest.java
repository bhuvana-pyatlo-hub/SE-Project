package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CountNumsTest {

    @Test
    void countNums_emptyList_returnsZero() {
        List<Object> arr = new ArrayList<>();
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_allZeros_returnsZero() {
        List<Object> arr = Arrays.asList(0, 0, 0);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_positiveNumbers_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(5, CountNums.countNums(arr));
    }

    @Test
    void countNums_negativeNumbersWithZeroSum_returnsZero() {
        List<Object> arr = Arrays.asList(-1, -2, -3);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_mixedPositiveAndNegative_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(1, -1, 2, -2, 3);
        assertEquals(3, CountNums.countNums(arr));
    }

    @Test
    void countNums_singleDigitPositive_returnsOne() {
        List<Object> arr = Arrays.asList(5);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void countNums_singleDigitNegative_returnsZero() {
        List<Object> arr = Arrays.asList(-5);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_twoDigitPositive_returnsOne() {
        List<Object> arr = Arrays.asList(12);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void countNums_twoDigitNegative_returnsZero() {
        List<Object> arr = Arrays.asList(-12);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_numberWithZeroDigit_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(10, 20, 30);
        assertEquals(3, CountNums.countNums(arr));
    }

    @Test
    void countNums_negativeNumberWithZeroDigit_returnsZero() {
        List<Object> arr = Arrays.asList(-10, -20, -30);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_mixedNumbersWithZeroDigit_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(10, -10, 20, -20, 30);
        assertEquals(3, CountNums.countNums(arr));
    }

    @Test
    void countNums_positiveNumberWithNegativeDigit_returnsOne() {
        List<Object> arr = Arrays.asList(21);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void countNums_negativeNumberWithNegativeDigit_returnsZero() {
        List<Object> arr = Arrays.asList(-21);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_numberWithRepeatingDigits_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(11, 22, 33);
        assertEquals(3, CountNums.countNums(arr));
    }

    @Test
    void countNums_negativeNumberWithRepeatingDigits_returnsZero() {
        List<Object> arr = Arrays.asList(-11, -22, -33);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_mixedNumbersWithRepeatingDigits_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(11, -11, 22, -22, 33);
        assertEquals(3, CountNums.countNums(arr));
    }

    @Test
    void countNums_zeroInList_returnsZeroIfOnlyZero() {
        List<Object> arr = Arrays.asList(0);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_zeroAndPositive_returnsOne() {
        List<Object> arr = Arrays.asList(0, 1);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void countNums_negativeAndZero_returnsZero() {
        List<Object> arr = Arrays.asList(-1, 0);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_mixedPositiveNegativeAndZero_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(1, -1, 0, 2, -2);
        assertEquals(2, CountNums.countNums(arr));
    }

    @Test
    void countNums_numberCloseToZero_returnsOne() {
        List<Object> arr = Arrays.asList(1);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void countNums_negativeNumberCloseToZero_returnsZero() {
        List<Object> arr = Arrays.asList(-1);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void countNums_boundaryValues_returnsCorrectCount() {
        List<Object> arr = Arrays.asList(-100, 0, 100);
        assertEquals(1, CountNums.countNums(arr));
    }
}