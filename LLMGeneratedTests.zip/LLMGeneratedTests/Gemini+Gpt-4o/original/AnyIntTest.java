package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AnyIntTest {

    @Test
    void anyInt_validIntegers_xEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(5, 2, 3));
    }

    @Test
    void anyInt_validIntegers_yEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(2, 5, 3));
    }

    @Test
    void anyInt_validIntegers_zEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(2, 3, 5));
    }

    @Test
    void anyInt_validIntegers_noSumEqualsOther() {
        assertFalse(AnyInt.anyInt(3, 2, 2));
    }

    @Test
    void anyInt_oneDouble_returnsFalse() {
        assertFalse(AnyInt.anyInt(3.6, 2, 1));
    }

    @Test
    void anyInt_twoDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(3.6, 2.2, 1));
    }

    @Test
    void anyInt_allDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(3.6, 2.2, 1.1));
    }

    @Test
    void anyInt_negativeNumbers_xEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(-4, 6, -10));
    }

    @Test
    void anyInt_negativeNumbers_yEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(6, -4, -10));
    }

    @Test
    void anyInt_negativeNumbers_zEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(6, -10, -4));
    }

    @Test
    void anyInt_zeroValues_xEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_zeroValues_yEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_zeroValues_zEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_oneZero_xEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(5, 5, 0));
    }

    @Test
    void anyInt_oneZero_yEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(5, 0, 5));
    }

    @Test
    void anyInt_oneZero_zEqualsSumOfOthers() {
        assertTrue(AnyInt.anyInt(0, 5, 5));
    }

    @Test
    void anyInt_negativeAndPositive_returnsTrue() {
        assertTrue(AnyInt.anyInt(3, -2, 5));
    }

    @Test
    void anyInt_sameValues_returnsFalse() {
        assertFalse(AnyInt.anyInt(2, 2, 2));
    }

    @Test
    void anyInt_invalidInputs() {
        assertFalse(AnyInt.anyInt(2.5, 2, 3));
        assertFalse(AnyInt.anyInt(1.5, 5, 3.5));
        assertFalse(AnyInt.anyInt(2.2, 2.2, 2.2));
    }
}