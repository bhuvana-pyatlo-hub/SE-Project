package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AddElementsTest {

    @Test
    void addElements_emptyArray_returnsZero() {
        List<Integer> arr = Arrays.asList();
        int k = 0;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsOne_elementLessThan100() {
        List<Integer> arr = Arrays.asList(50);
        int k = 1;
        int expected = 50;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsOne_elementGreaterThanOrEqualTo100() {
        List<Integer> arr = Arrays.asList(150);
        int k = 1;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsArrayLength_allElementsLessThan100() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 5;
        int expected = 15;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsArrayLength_allElementsGreaterThanOrEqualTo100() {
        List<Integer> arr = Arrays.asList(100, 200, 300, 400, 500);
        int k = 5;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsArrayLength_mixedElements() {
        List<Integer> arr = Arrays.asList(1, 100, 3, 200, 5);
        int k = 5;
        int expected = 9;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kLessThanArrayLength_allElementsLessThan100() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 3;
        int expected = 6;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kLessThanArrayLength_allElementsGreaterThanOrEqualTo100() {
        List<Integer> arr = Arrays.asList(100, 200, 300, 400, 500);
        int k = 3;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kLessThanArrayLength_mixedElements() {
        List<Integer> arr = Arrays.asList(1, 100, 3, 200, 5);
        int k = 3;
        int expected = 4;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsZero() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 0;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_negativeNumbersLessThan100() {
        List<Integer> arr = Arrays.asList(-1, -2, -3);
        int k = 3;
        int expected = -6;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_negativeAndPositiveNumbersLessThan100() {
        List<Integer> arr = Arrays.asList(-1, 2, -3);
        int k = 3;
        int expected = -2;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_allZeroes() {
        List<Integer> arr = Arrays.asList(0, 0, 0, 0, 0);
        int k = 5;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_mixedZeroesAndNonZeroes() {
        List<Integer> arr = Arrays.asList(0, 1, 0, 2, 0);
        int k = 5;
        int expected = 3;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_boundaryValue99() {
        List<Integer> arr = Arrays.asList(99);
        int k = 1;
        int expected = 99;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_boundaryValue100() {
        List<Integer> arr = Arrays.asList(100);
        int k = 1;
        int expected = 0;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_multipleElementsNearBoundary() {
        List<Integer> arr = Arrays.asList(98, 99, 100, 101);
        int k = 4;
        int expected = 197;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kGreaterThanArraySize() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 5;
        int expected = 6;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }

    @Test
    void addElements_kEqualsArraySize_negativeNumbers() {
        List<Integer> arr = Arrays.asList(-1, -2, -3);
        int k = 3;
        int expected = -6;
        int actual = AddElements.addElements(arr, k);
        assertEquals(expected, actual);
    }
}