package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SimplifyTest {

    @Test
    void simplify_validInput_true() {
        assertTrue(Simplify.simplify("1/5", "5/1"));
    }

    @Test
    void simplify_validInput_false() {
        assertFalse(Simplify.simplify("1/6", "2/1"));
    }

    @Test
    void simplify_validInput_true2() {
        assertTrue(Simplify.simplify("5/1", "3/1"));
    }

    @Test
    void simplify_validInput_false2() {
        assertFalse(Simplify.simplify("7/10", "10/2"));
    }

    @Test
    void simplify_validInput_true3() {
        assertTrue(Simplify.simplify("2/10", "50/10"));
    }

    @Test
    void simplify_validInput_true4() {
        assertTrue(Simplify.simplify("7/2", "4/2"));
    }

    @Test
    void simplify_validInput_true5() {
        assertTrue(Simplify.simplify("11/6", "6/1"));
    }

    @Test
    void simplify_validInput_false3() {
        assertFalse(Simplify.simplify("2/3", "5/2"));
    }

    @Test
    void simplify_validInput_false4() {
        assertFalse(Simplify.simplify("5/2", "3/5"));
    }

    @Test
    void simplify_validInput_true6() {
        assertTrue(Simplify.simplify("2/4", "8/4"));
    }

    @Test
    void simplify_validInput_true7() {
        assertTrue(Simplify.simplify("2/4", "4/2"));
    }

    @Test
    void simplify_validInput_false5() {
        assertFalse(Simplify.simplify("1/5", "1/5"));
    }

    @Test
    void simplify_smallNumbers_true() {
        assertTrue(Simplify.simplify("1/2", "2/1"));
    }

    @Test
    void simplify_smallNumbers_false() {
        assertFalse(Simplify.simplify("1/3", "2/1"));
    }

    @Test
    void simplify_sameFraction_true() {
        assertTrue(Simplify.simplify("2/2", "2/2"));
    }

    @Test
    void simplify_oneAsDenominator_true() {
        assertTrue(Simplify.simplify("5/1", "2/1"));
    }

    @Test
    void simplify_oneAsNumerator_true() {
        assertTrue(Simplify.simplify("1/5", "10/2"));
    }

    @Test
    void simplify_boundaryValues_true() {
        assertTrue(Simplify.simplify("100/1", "1/1"));
        assertTrue(Simplify.simplify("1/1", "100/1"));
    }

    @Test
    void simplify_boundaryValues_false() {
        assertFalse(Simplify.simplify("100/3", "1/1"));
    }

    @Test
    void simplify_negativeValues_false() {
        assertFalse(Simplify.simplify("-1/5", "5/1"));
    }

    @Test
    void simplify_zeroValues_false() {
        assertFalse(Simplify.simplify("0/1", "5/1"));
    }

    @Test
    void simplify_invalidInput_false() {
        assertThrows(NumberFormatException.class, () -> Simplify.simplify("invalid", "5/1"));
    }
}