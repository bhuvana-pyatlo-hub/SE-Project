package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AddElementsTest {

    @Test
    void testAddElements_emptyList() {
        List<Integer> arr = Arrays.asList();
        int k = 0;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsOne_singleDigit() {
        List<Integer> arr = Arrays.asList(5);
        int k = 1;
        assertEquals(5, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsOne_twoDigits() {
        List<Integer> arr = Arrays.asList(55);
        int k = 1;
        assertEquals(55, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsOne_threeDigits() {
        List<Integer> arr = Arrays.asList(555);
        int k = 1;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsArrLength_allSingleDigits() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 5;
        assertEquals(15, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsArrLength_allTwoDigits() {
        List<Integer> arr = Arrays.asList(11, 22, 33, 44, 55);
        int k = 5;
        assertEquals(165, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsArrLength_allThreeDigits() {
        List<Integer> arr = Arrays.asList(111, 222, 333, 444, 555);
        int k = 5;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsArrLength_mixedDigits() {
        List<Integer> arr = Arrays.asList(1, 22, 333, 4, 55);
        int k = 5;
        assertEquals(82, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kLessThanArrLength_allSingleDigits() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 3;
        assertEquals(6, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kLessThanArrLength_allTwoDigits() {
        List<Integer> arr = Arrays.asList(11, 22, 33, 44, 55);
        int k = 3;
        assertEquals(66, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kLessThanArrLength_allThreeDigits() {
        List<Integer> arr = Arrays.asList(111, 222, 333, 444, 555);
        int k = 3;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kLessThanArrLength_mixedDigits() {
        List<Integer> arr = Arrays.asList(1, 22, 333, 4, 55);
        int k = 3;
        assertEquals(23, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_negativeNumbers() {
        List<Integer> arr = Arrays.asList(-1, -22, -333, -4, -55);
        int k = 5;
        assertEquals(-82, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_mixedPositiveNegative() {
        List<Integer> arr = Arrays.asList(1, -22, 333, -4, 55);
        int k = 5;
        assertEquals(30, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_zeroValue() {
        List<Integer> arr = Arrays.asList(0, 0, 0, 0, 0);
        int k = 5;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kIsZero() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 0;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_boundaryValue99() {
        List<Integer> arr = Arrays.asList(99, 100, 101);
        int k = 3;
        assertEquals(99, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_allElementsGreaterThan100() {
        List<Integer> arr = Arrays.asList(100, 101, 102);
        int k = 3;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsArrLength_mixedDigits_includingZero() {
        List<Integer> arr = Arrays.asList(1, 22, 333, 0, 55);
        int k = 5;
        assertEquals(78, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kLessThanArrLength_includingZero() {
        List<Integer> arr = Arrays.asList(0, 1, 2, 3, 4);
        int k = 4;
        assertEquals(10, AddElements.addElements(arr, k));
    }
}