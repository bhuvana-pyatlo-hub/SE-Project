package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SumProductTest {

    @Test
    void sumProduct_emptyList_returnsZeroAndOne() {
        List<Object> numbers = new ArrayList<>();
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(0, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void sumProduct_singleElementList_returnsElementAndElement() {
        List<Object> numbers = Arrays.asList(5);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(5, result.get(0));
        assertEquals(5, result.get(1));
    }

    @Test
    void sumProduct_multipleElementsList_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(1, 2, 3, 4);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(10, result.get(0));
        assertEquals(24, result.get(1));
    }

    @Test
    void sumProduct_listWithZero_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(100, 0);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(100, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_listWithNegativeNumbers_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(-1, 2, -3);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(-2, result.get(0));
        assertEquals(6, result.get(1));
    }

    @Test
    void sumProduct_listWithMixedPositiveAndNegativeNumbers_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(5, -2, 3, -1);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(5, result.get(0));
        assertEquals(30, result.get(1));
    }

    @Test
    void sumProduct_listWithOnlyOneElement_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(7);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(7, result.get(0));
        assertEquals(7, result.get(1));
    }

    @Test
    void sumProduct_listWithAllOnes_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(1, 1, 1, 1, 1);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(5, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void sumProduct_listWithZeroesAndOnes_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(0, 1, 0, 1, 0);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(2, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_listWithNegativeAndZero_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(-5, 0, 2);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(-3, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_listWithOnlyNegativeNumbers_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(-1, -2, -3);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(-6, result.get(0));
        assertEquals(-6, result.get(1));
    }

    @Test
    void sumProduct_listWithDuplicateNumbers_returnsCorrectSumAndProduct() {
        List<Object> numbers = Arrays.asList(2, 2, 2, 2);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(8, result.get(0));
        assertEquals(16, result.get(1));
    }

    @Test
    void sumProduct_listWithNullElement_throwsIllegalArgumentException() {
        List<Object> numbers = new ArrayList<>();
        numbers.add(null);
        assertThrows(IllegalArgumentException.class, () -> SumProduct.sumProduct(numbers));
    }

    @Test
    void sumProduct_listWithNonIntegerElement_throwsIllegalArgumentException() {
        List<Object> numbers = new ArrayList<>();
        numbers.add("abc");
        assertThrows(IllegalArgumentException.class, () -> SumProduct.sumProduct(numbers));
    }
}