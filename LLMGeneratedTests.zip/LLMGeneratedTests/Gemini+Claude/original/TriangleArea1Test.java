package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TriangleArea1Test {

    @Test
    void triangleArea_validTriangle_returnsCorrectArea() {
        assertEquals(6.0, TriangleArea1.triangleArea(3, 4, 5));
    }

    @Test
    void triangleArea_invalidTriangle_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 10));
    }

    @Test
    void triangleArea_validTriangle_returnsCorrectArea2() {
        assertEquals(8.18, TriangleArea1.triangleArea(4, 8, 5));
    }

    @Test
    void triangleArea_validTriangle_returnsCorrectArea3() {
        assertEquals(1.73, TriangleArea1.triangleArea(2, 2, 2));
    }

    @Test
    void triangleArea_invalidTriangle_returnsNegativeOne2() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 3));
    }

    @Test
    void triangleArea_validTriangle_returnsCorrectArea4() {
        assertEquals(16.25, TriangleArea1.triangleArea(10, 5, 7));
    }

    @Test
    void triangleArea_invalidTriangle_returnsNegativeOne3() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 6, 3));
    }

    @Test
    void triangleArea_validTriangle_returnsCorrectArea5() {
        assertEquals(0.43, TriangleArea1.triangleArea(1, 1, 1));
    }

    @Test
    void triangleArea_invalidTriangle_returnsNegativeOne4() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 2, 10));
    }

    @Test
    void triangleArea_edgeCase_aPlusBEqualsC_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(5, 5, 10));
    }

    @Test
    void triangleArea_edgeCase_aPlusCEqualsB_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(5, 10, 5));
    }

    @Test
    void triangleArea_edgeCase_bPlusCEqualsA_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(10, 5, 5));
    }

    @Test
    void triangleArea_smallValues_validTriangle() {
        assertEquals(0.33, TriangleArea1.triangleArea(2, 2, 1));
    }

    @Test
    void triangleArea_smallValues_invalidTriangle() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 3));
    }

    @Test
    void triangleArea_zeroValue_invalidTriangle() {
        assertEquals(-1, TriangleArea1.triangleArea(0, 5, 5));
    }

    @Test
    void triangleArea_zeroValue_invalidTriangle2() {
        assertEquals(-1, TriangleArea1.triangleArea(5, 0, 5));
    }

    @Test
    void triangleArea_zeroValue_invalidTriangle3() {
        assertEquals(-1, TriangleArea1.triangleArea(5, 5, 0));
    }

    @Test
    void triangleArea_largerValues_validTriangle() {
        assertEquals(49.92, TriangleArea1.triangleArea(10, 12, 12));
    }

    @Test
    void triangleArea_largerValues_invalidTriangle() {
        assertEquals(-1, TriangleArea1.triangleArea(100, 1, 1));
    }

    @Test
    void triangleArea_equalSides_validTriangle() {
        assertEquals(27.71, TriangleArea1.triangleArea(8, 8, 8));
    }

    @Test
    void triangleArea_almostInvalid_aPlusBAlmostC() {
        assertEquals(0.99, TriangleArea1.triangleArea(2, 3, 4));
    }

    @Test
    void triangleArea_edgeCase_negativeValues_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(-1, 2, 3));
    }

    @Test
    void triangleArea_edgeCase_negativeAndZeroValues_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(-1, 0, 1));
    }

    @Test
    void triangleArea_edgeCase_allNegativeValues_returnsNegativeOne() {
        assertEquals(-1, TriangleArea1.triangleArea(-1, -2, -3));
    }
}