package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SplitWordsTest {

    @Test
    void splitWords_withSpaces_returnsListOfWords() {
        List<String> expected = Arrays.asList("Hello", "world!");
        assertEquals(expected, SplitWords.splitWords("Hello world!"));
    }

    @Test
    void splitWords_withCommas_returnsListOfWords() {
        List<String> expected = Arrays.asList("Hello", "world!");
        assertEquals(expected, SplitWords.splitWords("Hello,world!"));
    }

    @Test
    void splitWords_noSpacesOrCommas_returnsCountOfOddOrderedLowercaseLetters() {
        assertEquals(3, SplitWords.splitWords("abcdef"));
    }

    @Test
    void splitWords_emptyString_returnsZero() {
        assertEquals(0, SplitWords.splitWords(""));
    }

    @Test
    void splitWords_onlySpaces_returnsListOfEmptyStrings() {
        List<String> expected = Arrays.asList("", "", "");
        assertEquals(expected, SplitWords.splitWords("   "));
    }

    @Test
    void splitWords_onlyCommas_returnsListOfEmptyStrings() {
        List<String> expected = Arrays.asList("", "", "");
        assertEquals(expected, SplitWords.splitWords(",,"));
    }

    @Test
    void splitWords_mixedSpacesAndCommas_splitsOnSpacesFirst() {
        List<String> expected = Arrays.asList("Hello,world", "test");
        assertEquals(expected, SplitWords.splitWords("Hello,world test"));
    }

    @Test
    void splitWords_stringWithUppercaseLetters_countsOnlyLowercaseLetters() {
        assertEquals(1, SplitWords.splitWords("aBcDeF"));
    }

    @Test
    void splitWords_stringWithNumbers_countsOnlyLowercaseLetters() {
        assertEquals(3, SplitWords.splitWords("abc1def"));
    }

    @Test
    void splitWords_stringWithSpecialCharacters_countsOnlyLowercaseLetters() {
        assertEquals(3, SplitWords.splitWords("abc!def"));
    }

    @Test
    void splitWords_stringWithOnlyUppercaseLetters_returnsZero() {
        assertEquals(0, SplitWords.splitWords("ABCDEF"));
    }

    @Test
    void splitWords_stringWithOnlyNumbers_returnsZero() {
        assertEquals(0, SplitWords.splitWords("123456"));
    }

    @Test
    void splitWords_stringWithOnlySpecialCharacters_returnsZero() {
        assertEquals(0, SplitWords.splitWords("!@#$%^"));
    }

    @Test
    void splitWords_stringWithMixedCaseAndSpecialCharacters_countsLowercaseOdd() {
        assertEquals(1, SplitWords.splitWords("aB!cD@eF#"));
    }

    @Test
    void splitWords_stringWithSingleSpaceAtBeginning_splitsCorrectly() {
        List<String> expected = Arrays.asList("", "hello");
        assertEquals(expected, SplitWords.splitWords(" hello"));
    }

    @Test
    void splitWords_stringWithSingleCommaAtBeginning_splitsCorrectly() {
        List<String> expected = Arrays.asList("", "hello");
        assertEquals(expected, SplitWords.splitWords(",hello"));
    }

    @Test
    void splitWords_stringWithSingleSpaceAtEnd_splitsCorrectly() {
        List<String> expected = Arrays.asList("hello", "");
        assertEquals(expected, SplitWords.splitWords("hello "));
    }

    @Test
    void splitWords_stringWithSingleCommaAtEnd_splitsCorrectly() {
        List<String> expected = Arrays.asList("hello", "");
        assertEquals(expected, SplitWords.splitWords("hello,"));
    }

    @Test
    void splitWords_stringWithMultipleSpaces_splitsCorrectly() {
        List<String> expected = Arrays.asList("hello", "", "world");
        assertEquals(expected, SplitWords.splitWords("hello  world"));
    }

    @Test
    void splitWords_stringWithMultipleCommas_splitsCorrectly() {
        List<String> expected = Arrays.asList("hello", "", "world");
        assertEquals(expected, SplitWords.splitWords("hello,,world"));
    }

    @Test
    void splitWords_stringWithOnlyOneLowercaseLetterOddOrder() {
        assertEquals(1, SplitWords.splitWords("b"));
    }

    @Test
    void splitWords_stringWithOnlyOneLowercaseLetterEvenOrder() {
        assertEquals(0, SplitWords.splitWords("a"));
    }

    @Test
    void splitWords_stringWithOnlyLowercaseLettersOddOrder() {
        assertEquals(2, SplitWords.splitWords("aceg"));
    }

    @Test
    void splitWords_stringWithOnlyLowercaseLettersEvenOrder() {
        assertEquals(0, SplitWords.splitWords("bdfh"));
    }

    @Test
    void splitWords_stringWithLowercaseAndUppercaseLetters() {
        assertEquals(1, SplitWords.splitWords("aBcDeFg"));
    }

    @Test
    void splitWords_stringWithLowercaseAndNumbers() {
        assertEquals(2, SplitWords.splitWords("a1b2c3d4e5"));
    }

    @Test
    void splitWords_stringWithLowercaseAndSpecialCharacters() {
        assertEquals(2, SplitWords.splitWords("a!b@c#d$e%"));
    }

    @Test
    void splitWords_stringWithMixedCharactersAndSpaces() {
        assertEquals(1, SplitWords.splitWords("a b c d e f g h i j k l m n o p q r s t u v w x y z"));
    }
}