package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsPalindromeTest {

    @Test
    void isPalindrome_emptyString_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome(""));
    }

    @Test
    void isPalindrome_singleCharacterString_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("a"));
    }

    @Test
    void isPalindrome_simplePalindrome_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("aba"));
    }

    @Test
    void isPalindrome_longerPalindrome_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("aaaaa"));
    }

    @Test
    void isPalindrome_simpleNonPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("abc"));
    }

    @Test
    void isPalindrome_longerNonPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("zbcd"));
    }

    @Test
    void isPalindrome_palindromeWithEvenLength_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("abba"));
    }

    @Test
    void isPalindrome_nonPalindromeWithEvenLength_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("abcd"));
    }

    @Test
    void isPalindrome_palindromeWithDifferentCharacters_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("xywyx"));
    }

    @Test
    void isPalindrome_nonPalindromeWithDifferentCharacters_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("xywyz"));
    }

    @Test
    void isPalindrome_nonPalindromeNearPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("xywzx"));
    }

    @Test
    void isPalindrome_palindromeWithSpaces_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("abc cba"));
    }

    @Test
    void isPalindrome_palindromeWithMixedCase_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("AbBa"));
    }

    @Test
    void isPalindrome_palindromeWithNumbers_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("12321"));
    }

    @Test
    void isPalindrome_longPalindrome_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("racecar"));
    }

    @Test
    void isPalindrome_longNonPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("racecars"));
    }

    @Test
    void isPalindrome_almostPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("abca"));
    }

    @Test
    void isPalindrome_twoCharacterPalindrome_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("aa"));
    }

    @Test
    void isPalindrome_twoCharacterNonPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("ab"));
    }

    @Test
    void isPalindrome_palindromeWithSpecialCharacters_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("!@#@!"));
    }

    @Test
    void isPalindrome_numericPalindrome_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("121"));
    }

    @Test
    void isPalindrome_numericNonPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("123"));
    }

    @Test
    void isPalindrome_longNumericPalindrome_returnsTrue() {
        assertTrue(IsPalindrome.isPalindrome("1234321"));
    }

    @Test
    void isPalindrome_longNumericNonPalindrome_returnsFalse() {
        assertFalse(IsPalindrome.isPalindrome("1234567"));
    }
}