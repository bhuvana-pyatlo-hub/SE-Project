package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortArrayTest {

    @Test
    void sortArray_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_singleElement() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_example1() {
        List<Object> input = Arrays.asList(1, 5, 2, 3, 4);
        List<Object> expected = Arrays.asList(1, 2, 4, 3, 5);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_example2() {
        List<Object> input = Arrays.asList(1, 0, 2, 3, 4);
        List<Object> expected = Arrays.asList(0, 1, 2, 4, 3);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_duplicates() {
        List<Object> input = Arrays.asList(2, 5, 77, 4, 5, 3, 5, 7, 2, 3, 4);
        List<Object> expected = Arrays.asList(2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_differentNumberOfOnes() {
        List<Object> input = Arrays.asList(3, 6, 44, 12, 32, 5);
        List<Object> expected = Arrays.asList(32, 3, 5, 6, 12, 44);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_powersOfTwo() {
        List<Object> input = Arrays.asList(2, 4, 8, 16, 32);
        List<Object> expected = Arrays.asList(2, 4, 8, 16, 32);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_allZeros() {
        List<Object> input = Arrays.asList(0, 0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0, 0);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_allOnes() {
        List<Object> input = Arrays.asList(1, 1, 1, 1);
        List<Object> expected = Arrays.asList(1, 1, 1, 1);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_mixedOnesAndZeros() {
        List<Object> input = Arrays.asList(0, 1, 0, 1);
        List<Object> expected = Arrays.asList(0, 0, 1, 1);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_smallNumbers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
        List<Object> expected = Arrays.asList(1, 2, 4, 3, 5, 6, 7);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_numbersWithSameNumberOfOnes() {
        List<Object> input = Arrays.asList(3, 5, 6, 9, 10);
        List<Object> expected = Arrays.asList(3, 5, 6, 9, 10);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_boundaryValues() {
        List<Object> input = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7);
        List<Object> expected = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_allSameNumber() {
        List<Object> input = Arrays.asList(7, 7, 7, 7, 7);
        List<Object> expected = Arrays.asList(7, 7, 7, 7, 7);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_zeroAndOne() {
        List<Object> input = Arrays.asList(0, 1);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void sortArray_largerNumbersWithSameOnes() {
        List<Object> input = Arrays.asList(1023, 1022);
        List<Object> expected = Arrays.asList(1022, 1023);
        assertEquals(expected, SortArray.sortArray(input));
    }
}