package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SortNumbersTest {

    @Test
    void sortNumbers_emptyString() {
        assertEquals("", SortNumbers.sortNumbers(""));
    }

    @Test
    void sortNumbers_singleNumber() {
        assertEquals("three", SortNumbers.sortNumbers("three"));
    }

    @Test
    void sortNumbers_alreadySorted() {
        assertEquals("three five nine", SortNumbers.sortNumbers("three five nine"));
    }

    @Test
    void sortNumbers_unsorted() {
        assertEquals("zero four five seven eight nine", SortNumbers.sortNumbers("five zero four seven nine eight"));
    }

    @Test
    void sortNumbers_reverseSorted() {
        assertEquals("zero one two three four five six", SortNumbers.sortNumbers("six five four three two one zero"));
    }

    @Test
    void sortNumbers_mixedOrder() {
        assertEquals("one three five", SortNumbers.sortNumbers("three one five"));
    }

    @Test
    void sortNumbers_duplicateNumbers() {
        assertEquals("one one three", SortNumbers.sortNumbers("three one one"));
    }

    @Test
    void sortNumbers_allSameNumbers() {
        assertEquals("five five five", SortNumbers.sortNumbers("five five five"));
    }

    @Test
    void sortNumbers_zeroAndNine() {
        assertEquals("zero nine", SortNumbers.sortNumbers("nine zero"));
    }

    @Test
    void sortNumbers_oneAndEight() {
        assertEquals("one eight", SortNumbers.sortNumbers("eight one"));
    }

    @Test
    void sortNumbers_twoAndSeven() {
        assertEquals("seven two", SortNumbers.sortNumbers("two seven"));
    }

    @Test
    void sortNumbers_threeAndSix() {
        assertEquals("three six", SortNumbers.sortNumbers("six three"));
    }

    @Test
    void sortNumbers_fourAndFive() {
        assertEquals("four five", SortNumbers.sortNumbers("five four"));
    }

    @Test
    void sortNumbers_allNumbers() {
        assertEquals("zero one two three four five six seven eight nine", SortNumbers.sortNumbers("nine eight seven six five four three two one zero"));
    }

    @Test
    void sortNumbers_invalidInput_oneInvalid() {
        assertEquals("", SortNumbers.sortNumbers("invalid"));
    }

    @Test
    void sortNumbers_invalidInput_mixedValidInvalid() {
        assertEquals("five", SortNumbers.sortNumbers("five invalid"));
    }

    @Test
    void sortNumbers_invalidInput_multipleInvalid() {
        assertEquals("", SortNumbers.sortNumbers("invalid1 invalid2"));
    }

    @Test
    void sortNumbers_leadingAndTrailingSpaces() {
        assertEquals("one two", SortNumbers.sortNumbers(" one two "));
    }

    @Test
    void sortNumbers_multipleSpacesBetweenNumbers() {
        assertEquals("one two", SortNumbers.sortNumbers("one   two"));
    }

    @Test
    void sortNumbers_onlyInvalidInput() {
        assertEquals("", SortNumbers.sortNumbers("abc"));
    }

    @Test
    void sortNumbers_validAndInvalidInput() {
        assertEquals("one", SortNumbers.sortNumbers("one abc"));
    }

    @Test
    void sortNumbers_boundaryValues() {
        assertEquals("zero", SortNumbers.sortNumbers("zero"));
        assertEquals("nine", SortNumbers.sortNumbers("nine"));
    }

    @Test
    void sortNumbers_zeroAndNegative() {
        assertEquals("zero", SortNumbers.sortNumbers("zero -1"));
    }

    @Test
    void sortNumbers_negativeInput() {
        assertEquals("", SortNumbers.sortNumbers("-1"));
    }
}