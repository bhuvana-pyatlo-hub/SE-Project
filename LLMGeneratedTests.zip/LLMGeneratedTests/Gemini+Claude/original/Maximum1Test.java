package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Maximum1Test {

    @Test
    void maximum_emptyArray_returnsEmptyList() {
        List<Integer> arr = new ArrayList<>();
        int k = 3;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_kIsZero_returnsEmptyList() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 0;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_nEqualsK_returnsSortedList() {
        List<Integer> arr = Arrays.asList(-3, -4, 5);
        int k = 3;
        List<Object> expected = Arrays.asList(-4, -3, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_nLessThanK_returnsSortedList() {
        List<Integer> arr = Arrays.asList(4, -4);
        int k = 3;
        List<Object> expected = Arrays.asList(-4, 4);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example1() {
        List<Integer> arr = Arrays.asList(-3, -4, 5);
        int k = 3;
        List<Object> expected = Arrays.asList(-4, -3, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example2() {
        List<Integer> arr = Arrays.asList(4, -4, 4);
        int k = 2;
        List<Object> expected = Arrays.asList(4, 4);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example3() {
        List<Integer> arr = Arrays.asList(-3, 2, 1, 2, -1, -2, 1);
        int k = 1;
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase1() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        int k = 2;
        List<Object> expected = Arrays.asList(9, 10);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase2() {
        List<Integer> arr = Arrays.asList(-123, 20, 0, 1, 2, -3);
        int k = 4;
        List<Object> expected = Arrays.asList(0, 1, 2, 20);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase3() {
        List<Integer> arr = Arrays.asList(5, 15, 0, 3, -13, -8, 0);
        int k = 7;
        List<Object> expected = Arrays.asList(-13, -8, 0, 0, 3, 5, 15);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase4() {
        List<Integer> arr = Arrays.asList(-1, 0, 2, 5, 3, -10);
        int k = 2;
        List<Object> expected = Arrays.asList(3, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase5() {
        List<Integer> arr = Arrays.asList(1, 0, 5, -7);
        int k = 1;
        List<Object> expected = Arrays.asList(5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase6() {
        List<Integer> arr = Arrays.asList(4, -4);
        int k = 2;
        List<Object> expected = Arrays.asList(-4, 4);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase7() {
        List<Integer> arr = Arrays.asList(-10, 10);
        int k = 2;
        List<Object> expected = Arrays.asList(-10, 10);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_testCase8() {
        List<Integer> arr = Arrays.asList(1, 2, 3, -23, 243, -400, 0);
        int k = 0;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_kEqualsArraySize() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 3;
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_kIsOne() {
        List<Integer> arr = Arrays.asList(5, 2, 8, 1, 9);
        int k = 1;
        List<Object> expected = Arrays.asList(9);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_allNegativeNumbers() {
        List<Integer> arr = Arrays.asList(-1, -5, -2, -8, -3);
        int k = 3;
        List<Object> expected = Arrays.asList(-3, -2, -1);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_duplicateValues() {
        List<Integer> arr = Arrays.asList(2, 2, 2, 2, 2);
        int k = 3;
        List<Object> expected = Arrays.asList(2, 2, 2);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_arrayWithZeroes() {
        List<Integer> arr = Arrays.asList(0, 0, 0, 0, 0);
        int k = 3;
        List<Object> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }
}