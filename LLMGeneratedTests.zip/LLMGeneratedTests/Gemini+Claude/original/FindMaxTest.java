package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FindMaxTest {

    @Test
    void findMax_nullList_returnsNull() {
        assertNull(FindMax.findMax(null));
    }

    @Test
    void findMax_emptyList_returnsNull() {
        assertNull(FindMax.findMax(Collections.emptyList()));
    }

    @Test
    void findMax_singleWordList_returnsWord() {
        List<String> words = Collections.singletonList("word");
        assertEquals("word", FindMax.findMax(words));
    }

    @Test
    void findMax_multipleWordsDifferentUniqueCounts_returnsMaxUnique() {
        List<String> words = Arrays.asList("name", "of", "string");
        assertEquals("string", FindMax.findMax(words));
    }

    @Test
    void findMax_multipleWordsSameUniqueCounts_returnsLexicographicallyFirst() {
        List<String> words = Arrays.asList("name", "enam", "game");
        assertEquals("enam", FindMax.findMax(words));
    }

    @Test
    void findMax_repeatedCharacters_returnsCorrectMax() {
        List<String> words = Arrays.asList("aaaaaaa", "bb", "cc");
        assertEquals("aaaaaaa", FindMax.findMax(words));
    }

    @Test
    void findMax_sameUniqueCountLexicographicalOrder_returnsFirst() {
        List<String> words = Arrays.asList("abc", "cba");
        assertEquals("abc", FindMax.findMax(words));
    }

    @Test
    void findMax_complexList_returnsCorrectMax() {
        List<String> words = Arrays.asList("play", "this", "game", "of", "footbott");
        assertEquals("footbott", FindMax.findMax(words));
    }

    @Test
    void findMax_anotherComplexList_returnsCorrectMax() {
        List<String> words = Arrays.asList("we", "are", "gonna", "rock");
        assertEquals("gonna", FindMax.findMax(words));
    }

    @Test
    void findMax_yetAnotherComplexList_returnsCorrectMax() {
        List<String> words = Arrays.asList("we", "are", "a", "mad", "nation");
        assertEquals("nation", FindMax.findMax(words));
    }

    @Test
    void findMax_listWithRepeatedWord_returnsCorrectMax() {
        List<String> words = Arrays.asList("play", "play", "play");
        assertEquals("play", FindMax.findMax(words));
    }

    @Test
    void findMax_singleCharacterWord_returnsWord() {
        List<String> words = Collections.singletonList("b");
        assertEquals("b", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithSameUniqueCount_returnsLexicographicallySmaller() {
        List<String> words = Arrays.asList("xyz", "abc", "def");
        assertEquals("abc", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithSameUniqueCountAndSameLexicographicalValue_returnsFirst() {
        List<String> words = Arrays.asList("abc", "abc", "def");
        assertEquals("abc", FindMax.findMax(words));
    }

    @Test
    void findMax_emptyStringInList_returnsEmptyStringIfFirst() {
        List<String> words = Arrays.asList("", "abc");
        assertEquals("", FindMax.findMax(words));
    }

    @Test
    void findMax_emptyStringInList_returnsOtherStringIfEmptyStringIsNotFirst() {
        List<String> words = Arrays.asList("abc", "");
        assertEquals("abc", FindMax.findMax(words));
    }

    @Test
    void findMax_listWithOnlyEmptyString_returnsEmptyString() {
        List<String> words = Collections.singletonList("");
        assertEquals("", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithSpecialCharacters_returnsCorrectMax() {
        List<String> words = Arrays.asList("!@#", "$%^", "&*(");
        assertEquals("!@#", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithMixedCase_returnsCorrectMax() {
        List<String> words = Arrays.asList("AbC", "abc");
        assertEquals("AbC", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithNumbers_returnsCorrectMax() {
        List<String> words = Arrays.asList("123", "abc");
        assertEquals("abc", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithDifferentLengths_returnsCorrectMax() {
        List<String> words = Arrays.asList("a", "ab", "abc", "abcd");
        assertEquals("abcd", FindMax.findMax(words));
    }

    @Test
    void findMax_wordsWithNegativeAndZeroLength_returnsCorrectMax() {
        List<String> words = Arrays.asList("", "a", "ab", "abc", "abcd");
        assertEquals("abcd", FindMax.findMax(words));
    }
}