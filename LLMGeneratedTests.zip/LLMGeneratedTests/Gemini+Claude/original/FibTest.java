package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FibTest {

    @Test
    void fib_zero() {
        assertEquals(1, Fib.fib(0));
    }

    @Test
    void fib_one() {
        assertEquals(1, Fib.fib(1));
    }

    @Test
    void fib_two() {
        assertEquals(1, Fib.fib(2));
    }

    @Test
    void fib_three() {
        assertEquals(2, Fib.fib(3));
    }

    @Test
    void fib_four() {
        assertEquals(3, Fib.fib(4));
    }

    @Test
    void fib_five() {
        assertEquals(5, Fib.fib(5));
    }

    @Test
    void fib_six() {
        assertEquals(8, Fib.fib(6));
    }

    @Test
    void fib_seven() {
        assertEquals(13, Fib.fib(7));
    }

    @Test
    void fib_eight() {
        assertEquals(21, Fib.fib(8));
    }

    @Test
    void fib_nine() {
        assertEquals(34, Fib.fib(9));
    }

    @Test
    void fib_ten() {
        assertEquals(55, Fib.fib(10));
    }

    @Test
    void fib_eleven() {
        assertEquals(89, Fib.fib(11));
    }

    @Test
    void fib_twelve() {
        assertEquals(144, Fib.fib(12));
    }

    @Test
    void fib_thirteen() {
        assertEquals(233, Fib.fib(13));
    }

    @Test
    void fib_fourteen() {
        assertEquals(377, Fib.fib(14));
    }

    @Test
    void fib_fifteen() {
        assertEquals(610, Fib.fib(15));
    }

    @Test
    void fib_sixteen() {
        assertEquals(987, Fib.fib(16));
    }

    @Test
    void fib_seventeen() {
        assertEquals(1597, Fib.fib(17));
    }

    @Test
    void fib_eighteen() {
        assertEquals(2584, Fib.fib(18));
    }

    @Test
    void fib_nineteen() {
        assertEquals(4181, Fib.fib(19));
    }

    @Test
    void fib_negative() {
        assertThrows(IllegalArgumentException.class, () -> Fib.fib(-1));
    }

    @Test
    void fib_boundary() {
        assertEquals(1, Fib.fib(0));
        assertEquals(1, Fib.fib(1));
    }
}