package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsPrimeTest {

    @Test
    void isPrime_numberLessThanOrEqualToOne_returnsFalse() {
        assertFalse(IsPrime.isPrime(1));
        assertFalse(IsPrime.isPrime(0));
        assertFalse(IsPrime.isPrime(-1));
    }

    @Test
    void isPrime_numberIsTwo_returnsTrue() {
        assertTrue(IsPrime.isPrime(2));
    }

    @Test
    void isPrime_numberIsThree_returnsTrue() {
        assertTrue(IsPrime.isPrime(3));
    }

    @Test
    void isPrime_numberIsFive_returnsTrue() {
        assertTrue(IsPrime.isPrime(5));
    }

    @Test
    void isPrime_numberIsSeven_returnsTrue() {
        assertTrue(IsPrime.isPrime(7));
    }

    @Test
    void isPrime_numberIsEleven_returnsTrue() {
        assertTrue(IsPrime.isPrime(11));
    }

    @Test
    void isPrime_numberIsThirteen_returnsTrue() {
        assertTrue(IsPrime.isPrime(13));
    }

    @Test
    void isPrime_numberIsSeventeen_returnsTrue() {
        assertTrue(IsPrime.isPrime(17));
    }

    @Test
    void isPrime_numberIsNineteen_returnsTrue() {
        assertTrue(IsPrime.isPrime(19));
    }

    @Test
    void isPrime_numberIsTwentyThree_returnsTrue() {
        assertTrue(IsPrime.isPrime(23));
    }

    @Test
    void isPrime_numberIsTwentyNine_returnsTrue() {
        assertTrue(IsPrime.isPrime(29));
    }

    @Test
    void isPrime_numberIsFour_returnsFalse() {
        assertFalse(IsPrime.isPrime(4));
    }

    @Test
    void isPrime_numberIsSix_returnsFalse() {
        assertFalse(IsPrime.isPrime(6));
    }

    @Test
    void isPrime_numberIsEight_returnsFalse() {
        assertFalse(IsPrime.isPrime(8));
    }

    @Test
    void isPrime_numberIsNine_returnsFalse() {
        assertFalse(IsPrime.isPrime(9));
    }

    @Test
    void isPrime_numberIsTen_returnsFalse() {
        assertFalse(IsPrime.isPrime(10));
    }

    @Test
    void isPrime_numberIsTwelve_returnsFalse() {
        assertFalse(IsPrime.isPrime(12));
    }

    @Test
    void isPrime_numberIsTwentyFive_returnsFalse() {
        assertFalse(IsPrime.isPrime(25));
    }

    @Test
    void isPrime_numberIsFortyNine_returnsFalse() {
        assertFalse(IsPrime.isPrime(49));
    }

    @Test
    void isPrime_numberIsEightyOne_returnsFalse() {
        assertFalse(IsPrime.isPrime(81));
    }

    @Test
    void isPrime_numberIsOneHundred_returnsFalse() {
        assertFalse(IsPrime.isPrime(100));
    }

    @Test
    void isPrime_numberIsNegativeFifty_returnsFalse() {
        assertFalse(IsPrime.isPrime(-50));
    }

    @Test
    void isPrime_numberIsNegativeTwentyThree_returnsFalse() {
        assertFalse(IsPrime.isPrime(-23));
    }

    @Test
    void isPrime_numberIsNegativeOne_returnsFalse() {
        assertFalse(IsPrime.isPrime(-1));
    }
}