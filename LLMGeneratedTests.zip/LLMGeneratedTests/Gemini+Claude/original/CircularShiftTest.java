package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CircularShiftTest {

    @Test
    void circularShift_validInput_shiftLessThanLength() {
        assertEquals("21", CircularShift.circularShift(12, 1));
    }

    @Test
    void circularShift_validInput_shiftGreaterThanLength() {
        assertEquals("79", CircularShift.circularShift(97, 8));
    }

    @Test
    void circularShift_validInput_shiftEqualsLength() {
        assertEquals("12", CircularShift.circularShift(12, 2));
    }

    @Test
    void circularShift_singleDigit_shiftZero() {
        assertEquals("5", CircularShift.circularShift(5, 0));
    }

    @Test
    void circularShift_singleDigit_shiftGreaterThanLength() {
        assertEquals("5", CircularShift.circularShift(5, 1));
    }

    @Test
    void circularShift_twoDigit_shiftZero() {
        assertEquals("12", CircularShift.circularShift(12, 0));
    }

    @Test
    void circularShift_threeDigit_shiftOne() {
        assertEquals("001", CircularShift.circularShift(100, 2));
    }

    @Test
    void circularShift_threeDigit_shiftTwo() {
        assertEquals("010", CircularShift.circularShift(100, 1));
    }

    @Test
    void circularShift_threeDigit_shiftThree() {
        assertEquals("001", CircularShift.circularShift(100, 2));
    }

    @Test
    void circularShift_twoDigit_shiftGreaterThanLength() {
        assertEquals("21", CircularShift.circularShift(12, 5));
    }

    @Test
    void circularShift_zeroValue_shiftZero() {
        assertEquals("0", CircularShift.circularShift(0, 0));
    }

    @Test
    void circularShift_zeroValue_shiftOne() {
        assertEquals("0", CircularShift.circularShift(0, 1));
    }

    @Test
    void circularShift_smallNumber_shiftGreaterThanLength() {
        assertEquals("321", CircularShift.circularShift(123, 5));
    }

    @Test
    void circularShift_smallNumber_shiftLessThanLength() {
        assertEquals("312", CircularShift.circularShift(123, 1));
    }

    @Test
    void circularShift_sameDigits_shiftOne() {
        assertEquals("11", CircularShift.circularShift(11, 1));
    }

    @Test
    void circularShift_sameDigits_shiftGreaterThanLength() {
        assertEquals("11", CircularShift.circularShift(11, 101));
    }

    @Test
    void circularShift_boundaryValue_shiftOneLessThanLength() {
        assertEquals("912345678", CircularShift.circularShift(123456789, 8));
    }

    @Test
    void circularShift_boundaryValue_shiftEqualsLength() {
        assertEquals("123456789", CircularShift.circularShift(123456789, 9));
    }

    @Test
    void circularShift_boundaryValue_shiftZero() {
        assertEquals("123456789", CircularShift.circularShift(123456789, 0));
    }

    @Test
    void circularShift_boundaryValue_shiftGreaterThanLength() {
        assertEquals("987654321", CircularShift.circularShift(123456789, 10));
    }

    @Test
    void circularShift_twoDigitNumber_shiftOne() {
        assertEquals("21", CircularShift.circularShift(12, 1));
    }
}