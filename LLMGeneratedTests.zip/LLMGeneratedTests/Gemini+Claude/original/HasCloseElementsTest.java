package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HasCloseElementsTest {

    @Test
    void hasCloseElements_emptyList_returnsFalse() {
        List<Double> numbers = Collections.emptyList();
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_singleElementList_returnsFalse() {
        List<Double> numbers = Collections.singletonList(1.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_noCloseElements_returnsFalse() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_closeElements_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.0, 2.8, 3.0, 4.0, 5.0, 2.0);
        Double threshold = 0.3;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_closeElementsNearEnd_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2);
        Double threshold = 0.3;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_noCloseElementsSmallThreshold_returnsFalse() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2);
        Double threshold = 0.05;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_closeElementsLargeThreshold_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0);
        Double threshold = 0.95;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_noCloseElementsSlightlyLargerThreshold_returnsFalse() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0);
        Double threshold = 0.8;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_duplicateCloseElements_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.0);
        Double threshold = 0.1;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_allElementsClose_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1);
        Double threshold = 1.0;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_allElementsNotClose_returnsFalse() {
        List<Double> numbers = Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_negativeNumbers_returnsTrue() {
        List<Double> numbers = Arrays.asList(-1.0, -1.2, 0.0);
        Double threshold = 0.3;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_negativeNumbers_returnsFalse() {
        List<Double> numbers = Arrays.asList(-1.0, -2.0, 0.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_mixedPositiveNegative_returnsTrue() {
        List<Double> numbers = Arrays.asList(-1.0, 0.5, 1.0);
        Double threshold = 1.6;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_mixedPositiveNegative_returnsFalse() {
        List<Double> numbers = Arrays.asList(-1.0, 0.5, 1.0);
        Double threshold = 0.4;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_zeroThreshold_returnsTrueIfEqual() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 1.0);
        Double threshold = 0.0;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_zeroThreshold_returnsFalseIfNotEqual() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0);
        Double threshold = 0.0;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_sameElements_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.0, 1.0, 1.0);
        Double threshold = 0.1;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_largeList_returnsTrue() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 1.1);
        Double threshold = 0.2;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void hasCloseElements_largeList_returnsFalse() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0);
        Double threshold = 0.2;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }
}