package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AddTest {

    @Test
    void testAddPositiveNumbers() {
        assertEquals(5, Add.add(2, 3));
    }

    @Test
    void testAddZeroAndPositive() {
        assertEquals(5, Add.add(0, 5));
    }

    @Test
    void testAddPositiveAndZero() {
        assertEquals(5, Add.add(5, 0));
    }

    @Test
    void testAddTwoZeros() {
        assertEquals(0, Add.add(0, 0));
    }

    @Test
    void testAddSmallPositiveNumbers() {
        assertEquals(2, Add.add(1, 1));
    }

    @Test
    void testAddMediumPositiveNumbers() {
        assertEquals(50, Add.add(20, 30));
    }

    @Test
    void testAddPositiveAndNegative() {
        assertEquals(2, Add.add(5, -3));
    }

    @Test
    void testAddNegativeAndPositive() {
        assertEquals(2, Add.add(-3, 5));
    }

    @Test
    void testAddTwoNegativeNumbers() {
        assertEquals(-5, Add.add(-2, -3));
    }

    @Test
    void testAddZeroAndNegative() {
        assertEquals(-5, Add.add(0, -5));
    }

    @Test
    void testAddNegativeAndZero() {
        assertEquals(-5, Add.add(-5, 0));
    }

    @Test
    void testAddSmallNegativeNumbers() {
        assertEquals(-2, Add.add(-1, -1));
    }

    @Test
    void testAddMediumNegativeNumbers() {
        assertEquals(-50, Add.add(-20, -30));
    }

    @Test
    void testAddBoundaryValues() {
        assertEquals(0, Add.add(100, -100));
        assertEquals(0, Add.add(-100, 100));
    }

    @Test
    void testAddMaxAndMinValues() {
        assertEquals(0, Add.add(100, -100));
        assertEquals(0, Add.add(-100, 100));
        assertEquals(100, Add.add(100, 0));
        assertEquals(-100, Add.add(0, -100));
    }

    @Test
    void testAddNegativeBoundaryValues() {
        assertEquals(-200, Add.add(-100, -100));
    }
}