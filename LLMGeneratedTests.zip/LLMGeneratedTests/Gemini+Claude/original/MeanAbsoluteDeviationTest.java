package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MeanAbsoluteDeviationTest {

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad2() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0);
        double expected = 1.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad3() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        double expected = 1.2;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_negativeNumbers() {
        List<Double> numbers = Arrays.asList(-1.0, -2.0, -3.0);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_mixedNumbers() {
        List<Double> numbers = Arrays.asList(-1.0, 2.0, -3.0, 4.0);
        double expected = 2.5;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_zeroValues() {
        List<Double> numbers = Arrays.asList(0.0, 0.0, 0.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_decimalValues() {
        List<Double> numbers = Arrays.asList(1.5, 2.5, 3.5);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_smallValues() {
        List<Double> numbers = Arrays.asList(0.1, 0.2, 0.3);
        double expected = 0.06666666666666667;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_duplicateValues() {
        List<Double> numbers = Arrays.asList(1.0, 1.0, 1.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_singleValue() {
        List<Double> numbers = Collections.singletonList(5.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_negativeAndPositive() {
        List<Double> numbers = Arrays.asList(-5.0, 5.0);
        double expected = 5.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_largeRange() {
        List<Double> numbers = Arrays.asList(-100.0, 100.0);
        double expected = 100.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_smallRange() {
        List<Double> numbers = Arrays.asList(0.1, 0.2);
        double expected = 0.04999999999999999;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_zeroAndPositive() {
        List<Double> numbers = Arrays.asList(0.0, 5.0);
        double expected = 2.5;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_zeroAndNegative() {
        List<Double> numbers = Arrays.asList(0.0, -5.0);
        double expected = 2.5;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_allSameNegative() {
        List<Double> numbers = Arrays.asList(-1.0, -1.0, -1.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_allSamePositive() {
        List<Double> numbers = Arrays.asList(1.0, 1.0, 1.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMad_alternatingPositiveNegative() {
        List<Double> numbers = Arrays.asList(1.0, -1.0, 1.0, -1.0);
        double expected = 1.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.00000000000001);
    }
}