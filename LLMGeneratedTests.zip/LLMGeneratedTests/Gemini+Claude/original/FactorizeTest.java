package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FactorizeTest {

    @Test
    void factorize_1() {
        assertEquals(Collections.emptyList(), Factorize.factorize(1));
    }

    @Test
    void factorize_2() {
        assertEquals(Collections.singletonList(2), Factorize.factorize(2));
    }

    @Test
    void factorize_3() {
        assertEquals(Collections.singletonList(3), Factorize.factorize(3));
    }

    @Test
    void factorize_4() {
        assertEquals(Arrays.asList(2, 2), Factorize.factorize(4));
    }

    @Test
    void factorize_5() {
        assertEquals(Collections.singletonList(5), Factorize.factorize(5));
    }

    @Test
    void factorize_6() {
        assertEquals(Arrays.asList(2, 3), Factorize.factorize(6));
    }

    @Test
    void factorize_7() {
        assertEquals(Collections.singletonList(7), Factorize.factorize(7));
    }

    @Test
    void factorize_8() {
        assertEquals(Arrays.asList(2, 2, 2), Factorize.factorize(8));
    }

    @Test
    void factorize_9() {
        assertEquals(Arrays.asList(3, 3), Factorize.factorize(9));
    }

    @Test
    void factorize_10() {
        assertEquals(Arrays.asList(2, 5), Factorize.factorize(10));
    }

    @Test
    void factorize_12() {
        assertEquals(Arrays.asList(2, 2, 3), Factorize.factorize(12));
    }

    @Test
    void factorize_14() {
        assertEquals(Arrays.asList(2, 7), Factorize.factorize(14));
    }

    @Test
    void factorize_15() {
        assertEquals(Arrays.asList(3, 5), Factorize.factorize(15));
    }

    @Test
    void factorize_16() {
        assertEquals(Arrays.asList(2, 2, 2, 2), Factorize.factorize(16));
    }

    @Test
    void factorize_18() {
        assertEquals(Arrays.asList(2, 3, 3), Factorize.factorize(18));
    }

    @Test
    void factorize_20() {
        assertEquals(Arrays.asList(2, 2, 5), Factorize.factorize(20));
    }

    @Test
    void factorize_21() {
        assertEquals(Arrays.asList(3, 7), Factorize.factorize(21));
    }

    @Test
    void factorize_22() {
        assertEquals(Arrays.asList(2, 11), Factorize.factorize(22));
    }

    @Test
    void factorize_24() {
        assertEquals(Arrays.asList(2, 2, 2, 3), Factorize.factorize(24));
    }

    @Test
    void factorize_25() {
        assertEquals(Arrays.asList(5, 5), Factorize.factorize(25));
    }

    @Test
    void factorize_27() {
        assertEquals(Arrays.asList(3, 3, 3), Factorize.factorize(27));
    }

    @Test
    void factorize_28() {
        assertEquals(Arrays.asList(2, 2, 7), Factorize.factorize(28));
    }

    @Test
    void factorize_30() {
        assertEquals(Arrays.asList(2, 3, 5), Factorize.factorize(30));
    }

    @Test
    void factorize_35() {
        assertEquals(Arrays.asList(5, 7), Factorize.factorize(35));
    }

    @Test
    void factorize_36() {
        assertEquals(Arrays.asList(2, 2, 3, 3), Factorize.factorize(36));
    }

    @Test
    void factorize_49() {
        assertEquals(Arrays.asList(7, 7), Factorize.factorize(49));
    }

    @Test
    void factorize_57() {
        assertEquals(Arrays.asList(3, 19), Factorize.factorize(57));
    }

    @Test
    void factorize_70() {
        assertEquals(Arrays.asList(2, 5, 7), Factorize.factorize(70));
    }

    @Test
    void factorize_81() {
        assertEquals(Arrays.asList(3, 3, 3, 3), Factorize.factorize(81));
    }

    @Test
    void factorize_100() {
        assertEquals(Arrays.asList(2, 2, 5, 5), Factorize.factorize(100));
    }
}