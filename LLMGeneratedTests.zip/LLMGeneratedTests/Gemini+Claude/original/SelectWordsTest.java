package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SelectWordsTest {

    @Test
    void selectWords_emptyString_returnsEmptyList() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("", 4));
    }

    @Test
    void selectWords_singleWord_matchesConsonantCount() {
        assertEquals(Collections.singletonList("world"), SelectWords.selectWords("world", 4));
    }

    @Test
    void selectWords_singleWord_noMatchConsonantCount() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("world", 3));
    }

    @Test
    void selectWords_multipleWords_someMatchConsonantCount() {
        assertEquals(Arrays.asList("Mary", "lamb"), SelectWords.selectWords("Mary had a little lamb", 3));
    }

    @Test
    void selectWords_multipleWords_noMatchConsonantCount() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("simple white space", 2));
    }

    @Test
    void selectWords_multipleWords_allMatchConsonantCount() {
        assertEquals(Arrays.asList("Uncle"), SelectWords.selectWords("Uncle sam", 3));
    }

    @Test
    void selectWords_wordsWithUpperCase_matchesConsonantCount() {
        assertEquals(Collections.singletonList("Uncle"), SelectWords.selectWords("Uncle sam", 3));
    }

    @Test
    void selectWords_wordsWithVowelsOnly_noMatch() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("aeiou", 1));
    }

    @Test
    void selectWords_wordsWithConsonantsOnly_matches() {
        assertEquals(Collections.singletonList("bcdfgh"), SelectWords.selectWords("bcdfgh", 6));
    }

    @Test
    void selectWords_wordsWithMixedCase_matches() {
        assertEquals(Collections.singletonList("WoRlD"), SelectWords.selectWords("WoRlD", 4));
    }

    @Test
    void selectWords_wordsWithZeroConsonants_matchesZero() {
        assertEquals(Collections.singletonList("a"), SelectWords.selectWords("a", 0));
    }

    @Test
    void selectWords_multipleWords_zeroConsonants() {
        assertEquals(Arrays.asList("a", "e"), SelectWords.selectWords("a e i o u", 0));
    }

    @Test
    void selectWords_multipleWords_someMatchZeroConsonants() {
        assertEquals(Arrays.asList("a", "b"), SelectWords.selectWords("a b c d e f", 0));
    }

    @Test
    void selectWords_singleWord_oneConsonant() {
        assertEquals(Collections.singletonList("b"), SelectWords.selectWords("b", 1));
    }

    @Test
    void selectWords_multipleWords_oneConsonant() {
        assertEquals(Arrays.asList("b", "c", "d", "f"), SelectWords.selectWords("a b c d e f", 1));
    }

    @Test
    void selectWords_mixedCaseVowels_noMatch() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("AEIOU", 1));
    }

    @Test
    void selectWords_mixedCaseVowels_matchesZero() {
        assertEquals(Collections.singletonList("AEIOU"), SelectWords.selectWords("AEIOU", 0));
    }

    @Test
    void selectWords_longString_someMatch() {
        String longString = "This is a very long string with many words and some that match";
        List<Object> expected = Arrays.asList("string", "words", "match");
        assertEquals(expected, SelectWords.selectWords(longString, 4));
    }

    @Test
    void selectWords_stringWithLeadingAndTrailingSpaces() {
        assertEquals(Collections.singletonList("world"), SelectWords.selectWords("  world  ", 4));
    }

    @Test
    void selectWords_stringWithMultipleSpacesBetweenWords() {
        assertEquals(Collections.singletonList("world"), SelectWords.selectWords("Hello   world", 4));
    }

    @Test
    void selectWords_boundaryValues() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("a", 2)); // Boundary case with 1 letter
        assertEquals(Collections.singletonList("b"), SelectWords.selectWords("b", 1)); // Boundary case with 1 consonant
        assertEquals(Collections.emptyList(), SelectWords.selectWords("a", 1)); // Boundary case with 1 vowel
    }

    @Test
    void selectWords_negativeInput() {
        assertEquals(Collections.emptyList(), SelectWords.selectWords("word", -1)); // Invalid negative input
    }
}