package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HistogramTest {

    @Test
    void histogram_emptyString_returnsEmptyMap() {
        Map<String, Integer> expected = new HashMap<>();
        assertEquals(expected, Histogram.histogram(""));
    }

    @Test
    void histogram_nullString_returnsEmptyMap() {
        Map<String, Integer> expected = new HashMap<>();
        assertEquals(expected, Histogram.histogram(null));
    }

    @Test
    void histogram_singleLetter_returnsMapWithLetterAndCountOne() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        assertEquals(expected, Histogram.histogram("a"));
    }

    @Test
    void histogram_multipleLettersDifferentCounts_returnsMapWithMaxCount() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("b", 4);
        assertEquals(expected, Histogram.histogram("b b b b a"));
    }

    @Test
    void histogram_multipleLettersSameCounts_returnsMapWithAllLettersAndCount() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b b a"));
    }

    @Test
    void histogram_multipleLettersSameCountsDifferentOrder_returnsCorrectMap() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b c a b"));
    }

    @Test
    void histogram_multipleLettersAllUnique_returnsMapWithAllLettersCountOne() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        expected.put("c", 1);
        expected.put("d", 1);
        expected.put("g", 1);
        assertEquals(expected, Histogram.histogram("a b c d g"));
    }

    @Test
    void histogram_multipleLettersAllUniqueShort_returnsMapWithAllLettersCountOne() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("r", 1);
        expected.put("t", 1);
        expected.put("g", 1);
        assertEquals(expected, Histogram.histogram("r t g"));
    }

    @Test
    void histogram_singleLetterMultipleTimes_returnsMapWithLetterAndCount() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("b", 4);
        assertEquals(expected, Histogram.histogram("b b b b"));
    }

    @Test
    void histogram_singleLetterMultipleTimesWithSpace_returnsMapWithLetterAndCount() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("b", 4);
        assertEquals(expected, Histogram.histogram("b b b b "));
    }

    @Test
    void histogram_multipleLettersMixedCounts_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("c", 3);
        assertEquals(expected, Histogram.histogram("a b c c c a b"));
    }

    @Test
    void histogram_multipleLettersMixedCounts2_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 3);
        assertEquals(expected, Histogram.histogram("a a a b b c"));
    }

    @Test
    void histogram_multipleLettersMixedCounts3_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 3);
        assertEquals(expected, Histogram.histogram("a a a b c d"));
    }

    @Test
    void histogram_multipleLettersMixedCounts4_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 3);
        assertEquals(expected, Histogram.histogram("a a a b b"));
    }

    @Test
    void histogram_multipleLettersMixedCounts5_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 3);
        assertEquals(expected, Histogram.histogram("a a a b"));
    }

    @Test
    void histogram_multipleLettersMixedCounts6_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 3);
        assertEquals(expected, Histogram.histogram("a a a"));
    }

    @Test
    void histogram_multipleLettersMixedCounts7_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        expected.put("c", 1);
        assertEquals(expected, Histogram.histogram("a b c"));
    }

    @Test
    void histogram_multipleLettersMixedCounts8_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        assertEquals(expected, Histogram.histogram("a b"));
    }

    @Test
    void histogram_multipleLettersMixedCounts9_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        assertEquals(expected, Histogram.histogram("a"));
    }

    @Test
    void histogram_multipleLettersMixedCounts10_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        assertEquals(expected, Histogram.histogram(" "));
    }

    @Test
    void histogram_multipleLettersMixedCounts11_returnsMapWithMaxCountLetters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b a b"));
    }

    @Test
    void histogram_boundaryValues_returnsCorrectCounts() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("x", 1);
        expected.put("y", 1);
        expected.put("z", 1);
        assertEquals(expected, Histogram.histogram("x y z"));
    }

    @Test
    void histogram_negativeAndZeroValues_returnsCorrectCounts() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b a b"));
    }
}