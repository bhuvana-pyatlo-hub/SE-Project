package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StrangeSortListTest {

    @Test
    void strangeSortList_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_singleElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_twoElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_fourElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 4, 2, 3));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_fiveElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 5, 2, 4, 3));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_sixElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 6, 2, 5, 3, 4));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_sevenElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 7, 2, 6, 3, 5, 4));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_eightElementList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 8, 2, 7, 3, 6, 4, 5));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_duplicateElements() {
        List<Object> input = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_negativeAndPositiveElements() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 2, 2, 2, 5, 5, -5, -5));
        List<Object> expected = new ArrayList<>(Arrays.asList(-5, 5, -5, 5, 0, 2, 2, 2));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_mixedPositiveNegativeZero() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, 0, 1, 2, -2));
        List<Object> expected = new ArrayList<>(Arrays.asList(-2, 2, -1, 1, 0));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_allZeros() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 0, 0, 0));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 0, 0, 0));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_mixedTypes() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, "a", 4, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 5, 2, 4));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_onlyStrings() {
        List<Object> input = new ArrayList<>(Arrays.asList("a", "b", "c"));
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }

    @Test
    void strangeSortList_listWithNulls() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, null, 3, 4, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 5, 3, 4));
        assertEquals(expected, StrangeSortList.strangeSortList(input));
    }
}