package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SearchTest {

    @Test
    void search_emptyList_returnsNegativeOne() {
        List<Integer> lst = Arrays.asList();
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_singleElementListGreaterThanTen_returnsNegativeOne() {
        List<Integer> lst = Arrays.asList(10);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_singleElementListLessThanTen_returnsOne() {
        List<Integer> lst = Arrays.asList(1);
        int result = Search.search(lst);
        assertEquals(1, result);
    }

    @Test
    void search_example1() {
        List<Integer> lst = Arrays.asList(4, 1, 2, 2, 3, 1);
        int result = Search.search(lst);
        assertEquals(2, result);
    }

    @Test
    void search_example2() {
        List<Integer> lst = Arrays.asList(1, 2, 2, 3, 3, 3, 4, 4, 4);
        int result = Search.search(lst);
        assertEquals(3, result);
    }

    @Test
    void search_example3() {
        List<Integer> lst = Arrays.asList(5, 5, 4, 4, 4);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_example4() {
        List<Integer> lst = Arrays.asList(5, 5, 5, 5, 1);
        int result = Search.search(lst);
        assertEquals(1, result);
    }

    @Test
    void search_example5() {
        List<Integer> lst = Arrays.asList(4, 1, 4, 1, 4, 4);
        int result = Search.search(lst);
        assertEquals(4, result);
    }

    @Test
    void search_example6() {
        List<Integer> lst = Arrays.asList(3, 3);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_example7() {
        List<Integer> lst = Arrays.asList(8, 8, 8, 8, 8, 8, 8, 8);
        int result = Search.search(lst);
        assertEquals(8, result);
    }

    @Test
    void search_example8() {
        List<Integer> lst = Arrays.asList(2, 3, 3, 2, 2);
        int result = Search.search(lst);
        assertEquals(2, result);
    }

    @Test
    void search_example9() {
        List<Integer> lst = Arrays.asList(2, 3, 3, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
        int result = Search.search(lst);
        assertEquals(1, result);
    }

    @Test
    void search_example10() {
        List<Integer> lst = Arrays.asList(3, 2, 8, 2);
        int result = Search.search(lst);
        assertEquals(2, result);
    }

    @Test
    void search_example11() {
        List<Integer> lst = Arrays.asList(6, 7, 1, 8, 8, 10, 5, 8, 5, 3, 10);
        int result = Search.search(lst);
        assertEquals(1, result);
    }

    @Test
    void search_example12() {
        List<Integer> lst = Arrays.asList(8, 8, 3, 6, 5, 6, 4);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_example13() {
        List<Integer> lst = Arrays.asList(1);
        int result = Search.search(lst);
        assertEquals(1, result);
    }

    @Test
    void search_example14() {
        List<Integer> lst = Arrays.asList(1, 1);
        int result = Search.search(lst);
        assertEquals(1, result);
    }

    @Test
    void search_all_elements_greater_than_10_returns_negative_one() {
        List<Integer> lst = Arrays.asList(11, 12, 13);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_list_with_only_zeros_returns_negative_one() {
        List<Integer> lst = Arrays.asList(0, 0, 0);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }

    @Test
    void search_list_with_mixed_valid_and_invalid_numbers() {
        List<Integer> lst = Arrays.asList(1, 2, 2, 12, 0);
        int result = Search.search(lst);
        assertEquals(2, result);
    }

    @Test
    void search_list_with_all_same_numbers_less_than_10() {
        List<Integer> lst = Arrays.asList(5, 5, 5, 5, 5);
        int result = Search.search(lst);
        assertEquals(5, result);
    }

    @Test
    void search_list_with_numbers_close_to_10() {
        List<Integer> lst = Arrays.asList(9, 9, 9, 9, 9, 9, 9, 9, 9);
        int result = Search.search(lst);
        assertEquals(9, result);
    }

    @Test
    void search_list_with_negative_numbers_returns_negative_one() {
        List<Integer> lst = Arrays.asList(-1, -2, -3);
        int result = Search.search(lst);
        assertEquals(-1, result);
    }
}