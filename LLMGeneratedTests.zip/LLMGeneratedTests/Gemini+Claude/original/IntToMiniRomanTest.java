package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IntToMiniRomanTest {

    @Test
    void intToMiniRoman_1() {
        assertEquals("i", IntToMiniRoman.intToMiniRoman(1));
    }

    @Test
    void intToMiniRoman_2() {
        assertEquals("ii", IntToMiniRoman.intToMiniRoman(2));
    }

    @Test
    void intToMiniRoman_3() {
        assertEquals("iii", IntToMiniRoman.intToMiniRoman(3));
    }

    @Test
    void intToMiniRoman_4() {
        assertEquals("iv", IntToMiniRoman.intToMiniRoman(4));
    }

    @Test
    void intToMiniRoman_5() {
        assertEquals("v", IntToMiniRoman.intToMiniRoman(5));
    }

    @Test
    void intToMiniRoman_6() {
        assertEquals("vi", IntToMiniRoman.intToMiniRoman(6));
    }

    @Test
    void intToMiniRoman_7() {
        assertEquals("vii", IntToMiniRoman.intToMiniRoman(7));
    }

    @Test
    void intToMiniRoman_8() {
        assertEquals("viii", IntToMiniRoman.intToMiniRoman(8));
    }

    @Test
    void intToMiniRoman_9() {
        assertEquals("ix", IntToMiniRoman.intToMiniRoman(9));
    }

    @Test
    void intToMiniRoman_10() {
        assertEquals("x", IntToMiniRoman.intToMiniRoman(10));
    }

    @Test
    void intToMiniRoman_14() {
        assertEquals("xiv", IntToMiniRoman.intToMiniRoman(14));
    }

    @Test
    void intToMiniRoman_15() {
        assertEquals("xv", IntToMiniRoman.intToMiniRoman(15));
    }

    @Test
    void intToMiniRoman_19() {
        assertEquals("xix", IntToMiniRoman.intToMiniRoman(19));
    }

    @Test
    void intToMiniRoman_40() {
        assertEquals("xl", IntToMiniRoman.intToMiniRoman(40));
    }

    @Test
    void intToMiniRoman_41() {
        assertEquals("xli", IntToMiniRoman.intToMiniRoman(41));
    }

    @Test
    void intToMiniRoman_42() {
        assertEquals("xlii", IntToMiniRoman.intToMiniRoman(42));
    }

    @Test
    void intToMiniRoman_43() {
        assertEquals("xliii", IntToMiniRoman.intToMiniRoman(43));
    }

    @Test
    void intToMiniRoman_44() {
        assertEquals("xliv", IntToMiniRoman.intToMiniRoman(44));
    }

    @Test
    void intToMiniRoman_50() {
        assertEquals("l", IntToMiniRoman.intToMiniRoman(50));
    }

    @Test
    void intToMiniRoman_90() {
        assertEquals("xc", IntToMiniRoman.intToMiniRoman(90));
    }

    @Test
    void intToMiniRoman_100() {
        assertEquals("c", IntToMiniRoman.intToMiniRoman(100));
    }

    @Test
    void intToMiniRoman_400() {
        assertEquals("cd", IntToMiniRoman.intToMiniRoman(400));
    }

    @Test
    void intToMiniRoman_500() {
        assertEquals("d", IntToMiniRoman.intToMiniRoman(500));
    }

    @Test
    void intToMiniRoman_900() {
        assertEquals("cm", IntToMiniRoman.intToMiniRoman(900));
    }

    @Test
    void intToMiniRoman_1000() {
        assertEquals("m", IntToMiniRoman.intToMiniRoman(1000));
    }

    @Test
    void intToMiniRoman_152() {
        assertEquals("clii", IntToMiniRoman.intToMiniRoman(152));
    }

    @Test
    void intToMiniRoman_251() {
        assertEquals("ccli", IntToMiniRoman.intToMiniRoman(251));
    }

    @Test
    void intToMiniRoman_426() {
        assertEquals("cdxxvi", IntToMiniRoman.intToMiniRoman(426));
    }

    @Test
    void intToMiniRoman_532() {
        assertEquals("dxxxii", IntToMiniRoman.intToMiniRoman(532));
    }

    @Test
    void intToMiniRoman_994() {
        assertEquals("cmxciv", IntToMiniRoman.intToMiniRoman(994));
    }
}