package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GetMaxTriplesTest {

    @Test
    void getMaxTriples_nEquals1_returns0() {
        assertEquals(0, GetMaxTriples.getMaxTriples(1));
    }

    @Test
    void getMaxTriples_nEquals2_returns0() {
        assertEquals(0, GetMaxTriples.getMaxTriples(2));
    }

    @Test
    void getMaxTriples_nEquals3_returns0() {
        assertEquals(0, GetMaxTriples.getMaxTriples(3));
    }

    @Test
    void getMaxTriples_nEquals4_returns0() {
        assertEquals(0, GetMaxTriples.getMaxTriples(4));
    }

    @Test
    void getMaxTriples_nEquals5_returns1() {
        assertEquals(1, GetMaxTriples.getMaxTriples(5));
    }

    @Test
    void getMaxTriples_nEquals6_returns4() {
        assertEquals(4, GetMaxTriples.getMaxTriples(6));
    }

    @Test
    void getMaxTriples_nEquals7_returns10() {
        assertEquals(10, GetMaxTriples.getMaxTriples(7));
    }

    @Test
    void getMaxTriples_nEquals8_returns20() {
        assertEquals(20, GetMaxTriples.getMaxTriples(8));
    }

    @Test
    void getMaxTriples_nEquals9_returns35() {
        assertEquals(35, GetMaxTriples.getMaxTriples(9));
    }

    @Test
    void getMaxTriples_nEquals10_returns56() {
        assertEquals(56, GetMaxTriples.getMaxTriples(10));
    }

    @Test
    void getMaxTriples_nEquals11_returns83() {
        assertEquals(83, GetMaxTriples.getMaxTriples(11));
    }

    @Test
    void getMaxTriples_nEquals12_returns116() {
        assertEquals(116, GetMaxTriples.getMaxTriples(12));
    }

    @Test
    void getMaxTriples_nEquals13_returns156() {
        assertEquals(156, GetMaxTriples.getMaxTriples(13));
    }

    @Test
    void getMaxTriples_nEquals14_returns203() {
        assertEquals(203, GetMaxTriples.getMaxTriples(14));
    }

    @Test
    void getMaxTriples_nEquals15_returns258() {
        assertEquals(258, GetMaxTriples.getMaxTriples(15));
    }

    @Test
    void getMaxTriples_nEquals16_returns321() {
        assertEquals(321, GetMaxTriples.getMaxTriples(16));
    }

    @Test
    void getMaxTriples_nEquals17_returns392() {
        assertEquals(392, GetMaxTriples.getMaxTriples(17));
    }

    @Test
    void getMaxTriples_nEquals18_returns471() {
        assertEquals(471, GetMaxTriples.getMaxTriples(18));
    }

    @Test
    void getMaxTriples_nEquals19_returns558() {
        assertEquals(558, GetMaxTriples.getMaxTriples(19));
    }

    @Test
    void getMaxTriples_nEquals20_returns653() {
        assertEquals(653, GetMaxTriples.getMaxTriples(20));
    }
}