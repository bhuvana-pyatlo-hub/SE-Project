package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class XOrYTest {

    @Test
    void xOrY_nIsOne_returnsY() {
        assertEquals(5, XOrY.xOrY(1, 3, 5));
    }

    @Test
    void xOrY_nIsTwo_returnsX() {
        assertEquals(3, XOrY.xOrY(2, 3, 5));
    }

    @Test
    void xOrY_nIsThree_returnsX() {
        assertEquals(3, XOrY.xOrY(3, 3, 5));
    }

    @Test
    void xOrY_nIsFour_returnsY() {
        assertEquals(5, XOrY.xOrY(4, 3, 5));
    }

    @Test
    void xOrY_nIsFive_returnsX() {
        assertEquals(3, XOrY.xOrY(5, 3, 5));
    }

    @Test
    void xOrY_nIsSix_returnsY() {
        assertEquals(5, XOrY.xOrY(6, 3, 5));
    }

    @Test
    void xOrY_nIsSeven_returnsX() {
        assertEquals(3, XOrY.xOrY(7, 3, 5));
    }

    @Test
    void xOrY_nIsEight_returnsY() {
        assertEquals(5, XOrY.xOrY(8, 3, 5));
    }

    @Test
    void xOrY_nIsNine_returnsY() {
        assertEquals(5, XOrY.xOrY(9, 3, 5));
    }

    @Test
    void xOrY_nIsTen_returnsY() {
        assertEquals(5, XOrY.xOrY(10, 3, 5));
    }

    @Test
    void xOrY_nIsEleven_returnsX() {
        assertEquals(3, XOrY.xOrY(11, 3, 5));
    }

    @Test
    void xOrY_nIsTwelve_returnsY() {
        assertEquals(5, XOrY.xOrY(12, 3, 5));
    }

    @Test
    void xOrY_nIsThirteen_returnsX() {
        assertEquals(3, XOrY.xOrY(13, 3, 5));
    }

    @Test
    void xOrY_nIsFourteen_returnsY() {
        assertEquals(5, XOrY.xOrY(14, 3, 5));
    }

    @Test
    void xOrY_nIsFifteen_returnsY() {
        assertEquals(5, XOrY.xOrY(15, 3, 5));
    }

    @Test
    void xOrY_nIsSixteen_returnsY() {
        assertEquals(5, XOrY.xOrY(16, 3, 5));
    }

    @Test
    void xOrY_nIsSeventeen_returnsX() {
        assertEquals(3, XOrY.xOrY(17, 3, 5));
    }

    @Test
    void xOrY_nIsEighteen_returnsY() {
        assertEquals(5, XOrY.xOrY(18, 3, 5));
    }

    @Test
    void xOrY_nIsNineteen_returnsX() {
        assertEquals(3, XOrY.xOrY(19, 3, 5));
    }

    @Test
    void xOrY_nIsTwenty_returnsY() {
        assertEquals(5, XOrY.xOrY(20, 3, 5));
    }

    @Test
    void xOrY_xIsNegative_returnsCorrectValue() {
        assertEquals(-3, XOrY.xOrY(7, -3, 5));
    }

    @Test
    void xOrY_yIsNegative_returnsCorrectValue() {
        assertEquals(-5, XOrY.xOrY(4, 3, -5));
    }

    @Test
    void xOrY_xAndYAreNegative_returnsCorrectValue() {
        assertEquals(-3, XOrY.xOrY(7, -3, -5));
    }

    @Test
    void xOrY_xIsZero_returnsCorrectValue() {
        assertEquals(0, XOrY.xOrY(7, 0, 5));
    }

    @Test
    void xOrY_yIsZero_returnsCorrectValue() {
        assertEquals(0, XOrY.xOrY(4, 3, 0));
    }

    @Test
    void xOrY_xAndYAreZero_returnsCorrectValue() {
        assertEquals(0, XOrY.xOrY(7, 0, 0));
    }

    @Test
    void xOrY_nIsNegative_returnsY() {
        assertEquals(5, XOrY.xOrY(-5, 3, 5));
    }

    @Test
    void xOrY_nIsBoundaryNegative_returnsY() {
        assertEquals(5, XOrY.xOrY(-1, 3, 5));
    }

    @Test
    void xOrY_nIsBoundaryPositive_returnsY() {
        assertEquals(5, XOrY.xOrY(0, 3, 5));
    }
}