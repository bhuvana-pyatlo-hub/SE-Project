package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class GetPositiveTest {

    @Test
    void testGetPositive_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_allNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3, -4, -5);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_allPositiveNumbers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_mixedPositiveAndNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, 2, -3, 4, -5, 6);
        List<Object> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_withZero() {
        List<Object> input = Arrays.asList(-1, 0, 1, -2, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_singlePositiveNumber() {
        List<Object> input = Arrays.asList(5);
        List<Object> expected = Arrays.asList(5);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_singleNegativeNumber() {
        List<Object> input = Arrays.asList(-5);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyZero() {
        List<Object> input = Arrays.asList(0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_mixedTypes() {
        List<Object> input = Arrays.asList(1, "hello", -2, 3.14, 4, true, -5);
        List<Object> expected = Arrays.asList(1, 4);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyStrings() {
        List<Object> input = Arrays.asList("hello", "world");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyDoubles() {
        List<Object> input = Arrays.asList(1.1, 2.2, 3.3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyBooleans() {
        List<Object> input = Arrays.asList(true, false);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_positiveNumberAtBeginning() {
        List<Object> input = Arrays.asList(5, -1, -2);
        List<Object> expected = Arrays.asList(5);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_positiveNumberAtEnd() {
        List<Object> input = Arrays.asList(-1, -2, 5);
        List<Object> expected = Arrays.asList(5);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_multiplePositiveNumbersTogether() {
        List<Object> input = Arrays.asList(1, 2, 3, -1, -2);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_multipleNegativeNumbersTogether() {
        List<Object> input = Arrays.asList(-1, -2, -3, 1, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_zeroBetweenPositiveNumbers() {
        List<Object> input = Arrays.asList(1, 0, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_zeroBetweenNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, 0, -2);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_boundaryValues() {
        List<Object> input = Arrays.asList(-100, 0, 100);
        List<Object> expected = Arrays.asList(100);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_largeNegativeNumbers() {
        List<Object> input = Arrays.asList(-100, -200, -300);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }
}