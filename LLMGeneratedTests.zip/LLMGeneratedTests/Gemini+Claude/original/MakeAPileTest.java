package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MakeAPileTest {

    @Test
    void makeAPile_positiveEvenNumber_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(4, 6, 8, 10);
        assertEquals(expected, MakeAPile.makeAPile(4));
    }

    @Test
    void makeAPile_positiveOddNumber_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(3, 5, 7);
        assertEquals(expected, MakeAPile.makeAPile(3));
    }

    @Test
    void makeAPile_nIsOne_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, MakeAPile.makeAPile(1));
    }

    @Test
    void makeAPile_nIsTwo_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(2, 4);
        assertEquals(expected, MakeAPile.makeAPile(2));
    }

    @Test
    void makeAPile_nIsZero_returnsEmptyList() {
        List<Integer> expected = Arrays.asList(0);
        assertEquals(expected, MakeAPile.makeAPile(0));
    }

    @Test
    void makeAPile_nIsNegative_returnsEmptyList() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, MakeAPile.makeAPile(-1));
    }

    @Test
    void makeAPile_nIsFive_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(5, 7, 9, 11, 13);
        assertEquals(expected, MakeAPile.makeAPile(5));
    }

    @Test
    void makeAPile_nIsSix_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(6, 8, 10, 12, 14, 16);
        assertEquals(expected, MakeAPile.makeAPile(6));
    }

    @Test
    void makeAPile_nIsEight_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(8, 10, 12, 14, 16, 18, 20, 22);
        assertEquals(expected, MakeAPile.makeAPile(8));
    }

    @Test
    void makeAPile_nIsSeven_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(7, 9, 11, 13, 15, 17, 19);
        assertEquals(expected, MakeAPile.makeAPile(7));
    }

    @Test
    void makeAPile_nIsTen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(10, 12, 14, 16, 18, 20, 22, 24, 26, 28);
        assertEquals(expected, MakeAPile.makeAPile(10));
    }

    @Test
    void makeAPile_nIsEleven_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31);
        assertEquals(expected, MakeAPile.makeAPile(11));
    }

    @Test
    void makeAPile_nIsTwelve_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34);
        assertEquals(expected, MakeAPile.makeAPile(12));
    }

    @Test
    void makeAPile_nIsThirteen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37);
        assertEquals(expected, MakeAPile.makeAPile(13));
    }

    @Test
    void makeAPile_nIsFourteen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40);
        assertEquals(expected, MakeAPile.makeAPile(14));
    }

    @Test
    void makeAPile_nIsFifteen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43);
        assertEquals(expected, MakeAPile.makeAPile(15));
    }

    @Test
    void makeAPile_nIsSixteen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46);
        assertEquals(expected, MakeAPile.makeAPile(16));
    }

    @Test
    void makeAPile_nIsSeventeen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49);
        assertEquals(expected, MakeAPile.makeAPile(17));
    }

    @Test
    void makeAPile_nIsEighteen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52);
        assertEquals(expected, MakeAPile.makeAPile(18));
    }

    @Test
    void makeAPile_nIsNineteen_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55);
        assertEquals(expected, MakeAPile.makeAPile(19));
    }
}