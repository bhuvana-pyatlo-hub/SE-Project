package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SumToNTest {

    @Test
    void sumToN_positiveNumber_returnsCorrectSum() {
        assertEquals(15, SumToN.sumToN(5));
    }

    @Test
    void sumToN_anotherPositiveNumber_returnsCorrectSum() {
        assertEquals(55, SumToN.sumToN(10));
    }

    @Test
    void sumToN_one_returnsOne() {
        assertEquals(1, SumToN.sumToN(1));
    }

    @Test
    void sumToN_six_returnsTwentyOne() {
        assertEquals(21, SumToN.sumToN(6));
    }

    @Test
    void sumToN_eleven_returnsSixtySix() {
        assertEquals(66, SumToN.sumToN(11));
    }

    @Test
    void sumToN_thirty_returnsFourHundredSixtyFive() {
        assertEquals(465, SumToN.sumToN(30));
    }

    @Test
    void sumToN_hundred_returnsFiveThousandFifty() {
        assertEquals(5050, SumToN.sumToN(100));
    }

    @Test
    void sumToN_zero_returnsZero() {
        assertEquals(0, SumToN.sumToN(0));
    }

    @Test
    void sumToN_two_returnsThree() {
        assertEquals(3, SumToN.sumToN(2));
    }

    @Test
    void sumToN_three_returnsSix() {
        assertEquals(6, SumToN.sumToN(3));
    }

    @Test
    void sumToN_four_returnsTen() {
        assertEquals(10, SumToN.sumToN(4));
    }

    @Test
    void sumToN_seven_returnsTwentyEight() {
        assertEquals(28, SumToN.sumToN(7));
    }

    @Test
    void sumToN_eight_returnsThirtySix() {
        assertEquals(36, SumToN.sumToN(8));
    }

    @Test
    void sumToN_nine_returnsFortyFive() {
        assertEquals(45, SumToN.sumToN(9));
    }

    @Test
    void sumToN_twelve_returnsSeventyEight() {
        assertEquals(78, SumToN.sumToN(12));
    }

    @Test
    void sumToN_thirteen_returnsNinetyOne() {
        assertEquals(91, SumToN.sumToN(13));
    }

    @Test
    void sumToN_fourteen_returnsOneHundredFive() {
        assertEquals(105, SumToN.sumToN(14));
    }

    @Test
    void sumToN_fifteen_returnsOneHundredTwenty() {
        assertEquals(120, SumToN.sumToN(15));
    }

    @Test
    void sumToN_sixteen_returnsOneHundredThirtySix() {
        assertEquals(136, SumToN.sumToN(16));
    }

    @Test
    void sumToN_seventeen_returnsOneHundredFiftyThree() {
        assertEquals(153, SumToN.sumToN(17));
    }

    @Test
    void sumToN_negativeNumber_returnsZero() {
        assertEquals(0, SumToN.sumToN(-1));
    }

    @Test
    void sumToN_boundaryNegativeNumber_returnsZero() {
        assertEquals(0, SumToN.sumToN(-100));
    }

    @Test
    void sumToN_boundaryPositiveNumber_returnsCorrectSum() {
        assertEquals(5050, SumToN.sumToN(100));
    }
}