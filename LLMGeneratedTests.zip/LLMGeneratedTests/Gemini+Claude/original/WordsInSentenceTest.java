package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class WordsInSentenceTest {

    @Test
    void wordsInSentence_emptySentence() {
        assertEquals("", WordsInSentence.wordsInSentence(""));
    }

    @Test
    void wordsInSentence_singleWordPrimeLength() {
        assertEquals("is", WordsInSentence.wordsInSentence("is"));
    }

    @Test
    void wordsInSentence_singleWordNonPrimeLength() {
        assertEquals("", WordsInSentence.wordsInSentence("here"));
    }

    @Test
    void wordsInSentence_multipleWordsSomePrime() {
        assertEquals("go for", WordsInSentence.wordsInSentence("lets go for swimming"));
    }

    @Test
    void wordsInSentence_multipleWordsAllPrime() {
        assertEquals("Hi am Hussein", WordsInSentence.wordsInSentence("Hi I am Hussein"));
    }

    @Test
    void wordsInSentence_multipleWordsNonePrime() {
        assertEquals("", WordsInSentence.wordsInSentence("the a on"));
    }

    @Test
    void wordsInSentence_sentenceWithLeadingAndTrailingSpaces() {
        assertEquals("is", WordsInSentence.wordsInSentence("  is  "));
    }

    @Test
    void wordsInSentence_sentenceWithMultipleSpacesBetweenWords() {
        assertEquals("is", WordsInSentence.wordsInSentence("This   is  a  test"));
    }

    @Test
    void wordsInSentence_sentenceWithOnlySpaces() {
        assertEquals("", WordsInSentence.wordsInSentence("   "));
    }

    @Test
    void wordsInSentence_sentenceWithBoundaryLength() {
        String longSentence = "a ".repeat(49).trim(); // Length 98, close to 100
        assertEquals(longSentence, WordsInSentence.wordsInSentence(longSentence));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthTwo() {
        assertEquals("go", WordsInSentence.wordsInSentence("go"));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthThree() {
        assertEquals("for", WordsInSentence.wordsInSentence("for"));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthFive() {
        assertEquals("", WordsInSentence.wordsInSentence("hello"));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthSeven() {
        assertEquals("", WordsInSentence.wordsInSentence("testing"));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthEleven() {
        assertEquals("", WordsInSentence.wordsInSentence("completely"));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthOne() {
        assertEquals("I", WordsInSentence.wordsInSentence("I"));
    }

    @Test
    void wordsInSentence_sentenceWithWordLengthZero() {
        assertEquals("", WordsInSentence.wordsInSentence(""));
    }

    @Test
    void wordsInSentence_sentenceWithMultiplePrimeLengthWords() {
        assertEquals("go for it", WordsInSentence.wordsInSentence("go for it"));
    }

    @Test
    void wordsInSentence_sentenceWithNoPrimeLengthWords() {
        assertEquals("", WordsInSentence.wordsInSentence("the a on"));
    }

    @Test
    void wordsInSentence_sentenceWithMixedPrimeAndNonPrimeLengthWords() {
        assertEquals("is", WordsInSentence.wordsInSentence("This is a test"));
    }

    @Test
    void wordsInSentence_longSentenceWithPrimeWords() {
        assertEquals("is", WordsInSentence.wordsInSentence("This is a very long test"));
    }

    @Test
    void wordsInSentence_sentenceWithNegativeLengthWords() {
        assertEquals("", WordsInSentence.wordsInSentence("negative -1"));
    }

    @Test
    void wordsInSentence_sentenceWithZeroLengthWords() {
        assertEquals("", WordsInSentence.wordsInSentence("0"));
    }

    @Test
    void wordsInSentence_sentenceWithAllWordsPrimeLength() {
        assertEquals("I am", WordsInSentence.wordsInSentence("I am"));
    }
}