package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetRowTest {

    @Test
    void getRow_emptyList_returnsEmptyList() {
        List<Object> lst = new ArrayList<>();
        int x = 1;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_noMatchingX_returnsEmptyList() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6)
        );
        int x = 7;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_singleMatch_returnsCorrectCoordinate() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6)
        );
        int x = 5;
        List<Object> expected = new ArrayList<>();
        List<Object> coord = new ArrayList<>();
        coord.add(1);
        coord.add(1);
        expected.add(coord);
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_multipleMatches_returnsSortedCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 1),
                Arrays.asList(1, 5, 6),
                Arrays.asList(7, 1, 8)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(2);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(0);
        coord2.add(0);
        expected.add(coord2);

        List<Object> coord3 = new ArrayList<>();
        coord3.add(1);
        coord3.add(0);
        expected.add(coord3);

        List<Object> coord4 = new ArrayList<>();
        coord4.add(2);
        coord4.add(1);
        expected.add(coord4);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_emptyRows_returnsEmptyList() {
        List<Object> lst = Arrays.asList(
                new ArrayList<>(),
                new ArrayList<>()
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsZero_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(0, 1, 2),
                Arrays.asList(3, 0, 5)
        );
        int x = 0;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(0);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(1);
        coord2.add(1);
        expected.add(coord2);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsLastElement_returnsCorrectCoordinate() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6)
        );
        int x = 6;
        List<Object> expected = new ArrayList<>();
        List<Object> coord = new ArrayList<>();
        coord.add(1);
        coord.add(2);
        expected.add(coord);
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsFirstElement_returnsCorrectCoordinate() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();
        List<Object> coord = new ArrayList<>();
        coord.add(0);
        coord.add(0);
        expected.add(coord);
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_sameRowMultipleMatches_sortsByColumnDescending() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 1, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(2);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(0);
        coord2.add(1);
        expected.add(coord2);

        List<Object> coord3 = new ArrayList<>();
        coord3.add(0);
        coord3.add(0);
        expected.add(coord3);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_multipleRowsAndColumns_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 1, 6),
                Arrays.asList(7, 8, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(0);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(1);
        coord2.add(1);
        expected.add(coord2);

        List<Object> coord3 = new ArrayList<>();
        coord3.add(2);
        coord3.add(2);
        expected.add(coord3);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsNegative_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(-1, 2, 3),
                Arrays.asList(4, -1, 6)
        );
        int x = -1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(0);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(1);
        coord2.add(1);
        expected.add(coord2);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_largeXValue_returnsEmptyListIfNoMatch() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6)
        );
        int x = 1000;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xExistsOnlyInOneRow_returnsCorrectCoordinate() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        int x = 5;
        List<Object> expected = new ArrayList<>();
        List<Object> coord = new ArrayList<>();
        coord.add(1);
        coord.add(1);
        expected.add(coord);
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xExistsInFirstAndLastRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(0);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(2);
        coord2.add(2);
        expected.add(coord2);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xExistsMultipleTimesInDifferentRows_returnsSortedCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 1),
                Arrays.asList(4, 1, 6),
                Arrays.asList(1, 8, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(2);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(0);
        coord2.add(0);
        expected.add(coord2);

        List<Object> coord3 = new ArrayList<>();
        coord3.add(1);
        coord3.add(1);
        expected.add(coord3);

        List<Object> coord4 = new ArrayList<>();
        coord4.add(2);
        coord4.add(2);
        expected.add(coord4);

        List<Object> coord5 = new ArrayList<>();
        coord5.add(2);
        coord5.add(0);
        expected.add(coord5);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentAtStartAndEndOfEachRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 1),
                Arrays.asList(1, 5, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(2);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(0);
        coord2.add(0);
        expected.add(coord2);

        List<Object> coord3 = new ArrayList<>();
        coord3.add(1);
        coord3.add(2);
        expected.add(coord3);

        List<Object> coord4 = new ArrayList<>();
        coord4.add(1);
        coord4.add(0);
        expected.add(coord4);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentInAllRowsAndColumns_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 1, 1),
                Arrays.asList(1, 1, 1),
                Arrays.asList(1, 1, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(2);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(0);
        coord2.add(1);
        expected.add(coord2);

        List<Object> coord3 = new ArrayList<>();
        coord3.add(0);
        coord3.add(0);
        expected.add(coord3);

        List<Object> coord4 = new ArrayList<>();
        coord4.add(1);
        coord4.add(2);
        expected.add(coord4);

        List<Object> coord5 = new ArrayList<>();
        coord5.add(1);
        coord5.add(1);
        expected.add(coord5);

        List<Object> coord6 = new ArrayList<>();
        coord6.add(1);
        coord6.add(0);
        expected.add(coord6);

        List<Object> coord7 = new ArrayList<>();
        coord7.add(2);
        coord7.add(2);
        expected.add(coord7);

        List<Object> coord8 = new ArrayList<>();
        coord8.add(2);
        coord8.add(1);
        expected.add(coord8);

        List<Object> coord9 = new ArrayList<>();
        coord9.add(2);
        coord9.add(0);
        expected.add(coord9);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentOnlyInLastRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(2, 3, 4),
                Arrays.asList(5, 6, 7),
                Arrays.asList(8, 9, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(2);
        coord1.add(2);
        expected.add(coord1);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentOnlyInFirstRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(0);
        expected.add(coord1);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentInFirstAndSecondRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 1, 6),
                Arrays.asList(7, 8, 9)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(0);
        coord1.add(0);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(1);
        coord2.add(1);
        expected.add(coord2);

        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentInSecondAndThirdRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(
                Arrays.asList(2, 3, 4),
                Arrays.asList(5, 1, 7),
                Arrays.asList(8, 9, 1)
        );
        int x = 1;
        List<Object> expected = new ArrayList<>();

        List<Object> coord1 = new ArrayList<>();
        coord1.add(1);
        coord1.add(1);
        expected.add(coord1);

        List<Object> coord2 = new ArrayList<>();
        coord2.add(2);
        coord2.add(2);
        expected.add(coord2);

        assertEquals(expected, GetRow.getRow(lst, x));
    }
}