package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringXorTest {

    @Test
    void stringXor_equalStrings_returnsZeroString() {
        assertEquals("000", StringXor.stringXor("111", "111"));
    }

    @Test
    void stringXor_differentStrings_returnsCorrectXor() {
        assertEquals("101", StringXor.stringXor("010", "111"));
    }

    @Test
    void stringXor_emptyStrings_returnsEmptyString() {
        assertEquals("", StringXor.stringXor("", ""));
    }

    @Test
    void stringXor_oneStringEmpty_returnsEmptyString() {
        assertEquals("", StringXor.stringXor("101", ""));
    }

    @Test
    void stringXor_anotherStringEmpty_returnsEmptyString() {
        assertEquals("", StringXor.stringXor("", "101"));
    }

    @Test
    void stringXor_singleBitStrings_returnsCorrectXor() {
        assertEquals("0", StringXor.stringXor("1", "1"));
    }

    @Test
    void stringXor_singleBitStringsDifferent_returnsCorrectXor() {
        assertEquals("1", StringXor.stringXor("0", "1"));
    }

    @Test
    void stringXor_longerStrings_returnsCorrectXor() {
        assertEquals("010010", StringXor.stringXor("111000", "101010"));
    }

    @Test
    void stringXor_allZeros_returnsZeroString() {
        assertEquals("0000", StringXor.stringXor("0000", "0000"));
    }

    @Test
    void stringXor_allOnes_returnsZeroString() {
        assertEquals("0000", StringXor.stringXor("1111", "1111"));
    }

    @Test
    void stringXor_alternatingBits_returnsCorrectXor() {
        assertEquals("1010", StringXor.stringXor("0101", "1111"));
    }

    @Test
    void stringXor_alternatingBits2_returnsCorrectXor() {
        assertEquals("1010", StringXor.stringXor("1010", "0000"));
    }

    @Test
    void stringXor_sameLengthDifferentValues_returnsCorrectXor() {
        assertEquals("1111", StringXor.stringXor("0000", "1111"));
    }

    @Test
    void stringXor_boundaryCase_returnsCorrectXor() {
        assertEquals("0", StringXor.stringXor("0", "0"));
    }

    @Test
    void stringXor_boundaryCase2_returnsCorrectXor() {
        assertEquals("0", StringXor.stringXor("1", "1"));
    }

    @Test
    void stringXor_mixedValues_returnsCorrectXor() {
        assertEquals("1101", StringXor.stringXor("0100", "1001"));
    }

    @Test
    void stringXor_longerMixedValues_returnsCorrectXor() {
        assertEquals("1010101", StringXor.stringXor("0101010", "1111111"));
    }

    @Test
    void stringXor_anotherLongerMixedValues_returnsCorrectXor() {
        assertEquals("1111111", StringXor.stringXor("0000000", "1111111"));
    }

    @Test
    void stringXor_complexValues_returnsCorrectXor() {
        assertEquals("101101", StringXor.stringXor("010010", "111111"));
    }

    @Test
    void stringXor_complexValues2_returnsCorrectXor() {
        assertEquals("110011", StringXor.stringXor("001100", "111111"));
    }

    @Test
    void stringXor_boundaryValues_returnsCorrectXor() {
        assertEquals("0", StringXor.stringXor("0", "1"));
        assertEquals("1", StringXor.stringXor("1", "0"));
    }

    @Test
    void stringXor_maximumLengthStrings_returnsCorrectXor() {
        assertEquals("111111111111111111", StringXor.stringXor("111111111111111111", "000000000000000000"));
    }
}