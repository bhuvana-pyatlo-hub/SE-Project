package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ValidDateTest {

    @Test
    void validDate_validDate_returnsTrue() {
        assertTrue(ValidDate.validDate("03-11-2000"));
    }

    @Test
    void validDate_invalidDate_returnsFalse() {
        assertFalse(ValidDate.validDate("15-01-2012"));
    }

    @Test
    void validDate_invalidDateZeroDay_returnsFalse() {
        assertFalse(ValidDate.validDate("04-0-2040"));
    }

    @Test
    void validDate_validDate2_returnsTrue() {
        assertTrue(ValidDate.validDate("06-04-2020"));
    }

    @Test
    void validDate_invalidFormat_returnsFalse() {
        assertFalse(ValidDate.validDate("06/04/2020"));
    }

    @Test
    void validDate_emptyString_returnsFalse() {
        assertFalse(ValidDate.validDate(""));
    }

    @Test
    void validDate_invalidDay31ForApril_returnsFalse() {
        assertFalse(ValidDate.validDate("04-31-3000"));
    }

    @Test
    void validDate_validDateJune6_returnsTrue() {
        assertTrue(ValidDate.validDate("06-06-2005"));
    }

    @Test
    void validDate_invalidDay31ForFebruary_returnsFalse() {
        assertFalse(ValidDate.validDate("02-30-2000"));
    }

    @Test
    void validDate_validDateApril12_returnsTrue() {
        assertTrue(ValidDate.validDate("04-12-2003"));
    }

    @Test
    void validDate_invalidFormatNoDashes_returnsFalse() {
        assertFalse(ValidDate.validDate("04122003"));
    }

    @Test
    void validDate_invalidFormatYearFirst_returnsFalse() {
        assertFalse(ValidDate.validDate("20030412"));
    }

    @Test
    void validDate_invalidFormatShort_returnsFalse() {
        assertFalse(ValidDate.validDate("2003-04"));
    }

    @Test
    void validDate_invalidFormatShort2_returnsFalse() {
        assertFalse(ValidDate.validDate("2003-04-12"));
    }

    @Test
    void validDate_invalidFormatShort3_returnsFalse() {
        assertFalse(ValidDate.validDate("04-2003"));
    }

    @Test
    void validDate_monthLessThan1_returnsFalse() {
        assertFalse(ValidDate.validDate("00-01-2023"));
    }

    @Test
    void validDate_monthGreaterThan12_returnsFalse() {
        assertFalse(ValidDate.validDate("13-01-2023"));
    }

    @Test
    void validDate_februaryDayGreaterThan29_returnsFalse() {
        assertFalse(ValidDate.validDate("02-30-2023"));
    }

    @Test
    void validDate_aprilDayGreaterThan30_returnsFalse() {
        assertFalse(ValidDate.validDate("04-31-2023"));
    }

    @Test
    void validDate_juneDayGreaterThan30_returnsFalse() {
        assertFalse(ValidDate.validDate("06-31-2023"));
    }

    @Test
    void validDate_septemberDayGreaterThan30_returnsFalse() {
        assertFalse(ValidDate.validDate("09-31-2023"));
    }

    @Test
    void validDate_novemberDayGreaterThan30_returnsFalse() {
        assertFalse(ValidDate.validDate("11-31-2023"));
    }

    @Test
    void validDate_januaryDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("01-32-2023"));
    }

    @Test
    void validDate_marchDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("03-32-2023"));
    }

    @Test
    void validDate_mayDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("05-32-2023"));
    }

    @Test
    void validDate_julyDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("07-32-2023"));
    }

    @Test
    void validDate_augustDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("08-32-2023"));
    }

    @Test
    void validDate_octoberDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("10-32-2023"));
    }

    @Test
    void validDate_decemberDayGreaterThan31_returnsFalse() {
        assertFalse(ValidDate.validDate("12-32-2023"));
    }

    @Test
    void validDate_validLeapYearFebruary29_returnsTrue() {
        assertTrue(ValidDate.validDate("02-29-2024"));
    }

    @Test
    void validDate_invalidNonLeapYearFebruary29_returnsFalse() {
        assertFalse(ValidDate.validDate("02-29-2023"));
    }

    @Test
    void validDate_validDateSingleDigitMonthDay_returnsTrue() {
        assertTrue(ValidDate.validDate("01-01-2023"));
    }

    @Test
    void validDate_invalidDateTooShort_returnsFalse() {
        assertFalse(ValidDate.validDate("1-1-2023"));
    }

    @Test
    void validDate_invalidDateWithLeadingZeros_returnsFalse() {
        assertFalse(ValidDate.validDate("01-01-2023"));
    }

    @Test
    void validDate_invalidDateWithExtraCharacters_returnsFalse() {
        assertFalse(ValidDate.validDate("03-11-2000!"));
    }
}