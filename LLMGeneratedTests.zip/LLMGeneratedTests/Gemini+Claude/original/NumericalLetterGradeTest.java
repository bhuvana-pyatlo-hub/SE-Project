package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class NumericalLetterGradeTest {

    @Test
    void numericalLetterGrade_emptyList_returnsEmptyList() {
        List<Number> grades = Collections.emptyList();
        List<String> expected = Collections.emptyList();
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeAPlus_returnsAPlus() {
        List<Number> grades = Collections.singletonList(4.0);
        List<String> expected = Collections.singletonList("A+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeA_returnsA() {
        List<Number> grades = Collections.singletonList(3.8);
        List<String> expected = Collections.singletonList("A");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeAMinus_returnsAMinus() {
        List<Number> grades = Collections.singletonList(3.4);
        List<String> expected = Collections.singletonList("A-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeBPlus_returnsBPlus() {
        List<Number> grades = Collections.singletonList(3.1);
        List<String> expected = Collections.singletonList("B+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeB_returnsB() {
        List<Number> grades = Collections.singletonList(2.8);
        List<String> expected = Collections.singletonList("B");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeBMinus_returnsBMinus() {
        List<Number> grades = Collections.singletonList(2.4);
        List<String> expected = Collections.singletonList("B-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeCPlus_returnsCPlus() {
        List<Number> grades = Collections.singletonList(2.1);
        List<String> expected = Collections.singletonList("C+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeC_returnsC() {
        List<Number> grades = Collections.singletonList(1.8);
        List<String> expected = Collections.singletonList("C");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeCMinus_returnsCMinus() {
        List<Number> grades = Collections.singletonList(1.4);
        List<String> expected = Collections.singletonList("C-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeDPlus_returnsDPlus() {
        List<Number> grades = Collections.singletonList(1.1);
        List<String> expected = Collections.singletonList("D+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeD_returnsD() {
        List<Number> grades = Collections.singletonList(0.8);
        List<String> expected = Collections.singletonList("D");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeDMinus_returnsDMinus() {
        List<Number> grades = Collections.singletonList(0.1);
        List<String> expected = Collections.singletonList("D-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_singleGradeE_returnsE() {
        List<Number> grades = Collections.singletonList(0.0);
        List<String> expected = Collections.singletonList("E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_multipleGrades_returnsCorrectLetterGrades() {
        List<Number> grades = Arrays.asList(4.0, 3.8, 3.4, 3.1, 2.8, 2.4, 2.1, 1.8, 1.4, 1.1, 0.8, 0.1, 0.0);
        List<String> expected = Arrays.asList("A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_boundaryValues_returnsCorrectLetterGrades() {
        List<Number> grades = Arrays.asList(4.0, 3.71, 3.31, 3.01, 2.71, 2.31, 2.01, 1.71, 1.31, 1.01, 0.71, 0.01, 0.0);
        List<String> expected = Arrays.asList("A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_integerValues_returnsCorrectLetterGrades() {
        List<Number> grades = Arrays.asList(4, 3, 2, 1, 0);
        List<String> expected = Arrays.asList("A+", "B+", "C+", "D+", "E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_mixedTypes_returnsCorrectLetterGrades() {
        List<Number> grades = Arrays.asList(4.0f, 3.8d, 3.4, 3, 2.8f, 2.4d, 2.1, 1, 0.8f, 0.1d, 0);
        List<String> expected = Arrays.asList("A+", "A", "A-", "B+", "B", "B-", "C+", "D", "D", "D-", "E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_negativeGrade_returnsE() {
        List<Number> grades = Collections.singletonList(-0.1);
        List<String> expected = Collections.singletonList("E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_zeroGrade_returnsE() {
        List<Number> grades = Collections.singletonList(0);
        List<String> expected = Collections.singletonList("E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow4_returnsA() {
        List<Number> grades = Collections.singletonList(3.999);
        List<String> expected = Collections.singletonList("A");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow3_7_returnsA_() {
        List<Number> grades = Collections.singletonList(3.699);
        List<String> expected = Collections.singletonList("A-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow3_3_returnsB_Plus() {
        List<Number> grades = Collections.singletonList(3.299);
        List<String> expected = Collections.singletonList("B+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow2_7_returnsB() {
        List<Number> grades = Collections.singletonList(2.699);
        List<String> expected = Collections.singletonList("B");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow2_3_returnsBMinus() {
        List<Number> grades = Collections.singletonList(2.299);
        List<String> expected = Collections.singletonList("B-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow2_0_returnsCPlus() {
        List<Number> grades = Collections.singletonList(2.0 - 0.01);
        List<String> expected = Collections.singletonList("C+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow1_7_returnsC() {
        List<Number> grades = Collections.singletonList(1.699);
        List<String> expected = Collections.singletonList("C");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow1_3_returnsCMinus() {
        List<Number> grades = Collections.singletonList(1.299);
        List<String> expected = Collections.singletonList("C-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow1_0_returnsDPlus() {
        List<Number> grades = Collections.singletonList(1.0 - 0.01);
        List<String> expected = Collections.singletonList("D+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow0_7_returnsD() {
        List<Number> grades = Collections.singletonList(0.699);
        List<String> expected = Collections.singletonList("D");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void numericalLetterGrade_gradeJustBelow0_0_returnsDMinus() {
        List<Number> grades = Collections.singletonList(0.0 - 0.01);
        List<String> expected = Collections.singletonList("D-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }
}