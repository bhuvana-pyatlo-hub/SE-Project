package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarRaceCollisionTest {

    @Test
    void carRaceCollision_zeroValue() {
        assertEquals(0, CarRaceCollision.carRaceCollision(0));
    }

    @Test
    void carRaceCollision_oneValue() {
        assertEquals(1, CarRaceCollision.carRaceCollision(1));
    }

    @Test
    void carRaceCollision_twoValue() {
        assertEquals(4, CarRaceCollision.carRaceCollision(2));
    }

    @Test
    void carRaceCollision_threeValue() {
        assertEquals(9, CarRaceCollision.carRaceCollision(3));
    }

    @Test
    void carRaceCollision_fourValue() {
        assertEquals(16, CarRaceCollision.carRaceCollision(4));
    }

    @Test
    void carRaceCollision_fiveValue() {
        assertEquals(25, CarRaceCollision.carRaceCollision(5));
    }

    @Test
    void carRaceCollision_sixValue() {
        assertEquals(36, CarRaceCollision.carRaceCollision(6));
    }

    @Test
    void carRaceCollision_sevenValue() {
        assertEquals(49, CarRaceCollision.carRaceCollision(7));
    }

    @Test
    void carRaceCollision_eightValue() {
        assertEquals(64, CarRaceCollision.carRaceCollision(8));
    }

    @Test
    void carRaceCollision_nineValue() {
        assertEquals(81, CarRaceCollision.carRaceCollision(9));
    }

    @Test
    void carRaceCollision_tenValue() {
        assertEquals(100, CarRaceCollision.carRaceCollision(10));
    }

    @Test
    void carRaceCollision_elevenValue() {
        assertEquals(121, CarRaceCollision.carRaceCollision(11));
    }

    @Test
    void carRaceCollision_twelveValue() {
        assertEquals(144, CarRaceCollision.carRaceCollision(12));
    }

    @Test
    void carRaceCollision_thirteenValue() {
        assertEquals(169, CarRaceCollision.carRaceCollision(13));
    }

    @Test
    void carRaceCollision_fourteenValue() {
        assertEquals(196, CarRaceCollision.carRaceCollision(14));
    }

    @Test
    void carRaceCollision_fifteenValue() {
        assertEquals(225, CarRaceCollision.carRaceCollision(15));
    }

    @Test
    void carRaceCollision_sixteenValue() {
        assertEquals(256, CarRaceCollision.carRaceCollision(16));
    }

    @Test
    void carRaceCollision_seventeenValue() {
        assertEquals(289, CarRaceCollision.carRaceCollision(17));
    }

    @Test
    void carRaceCollision_eighteenValue() {
        assertEquals(324, CarRaceCollision.carRaceCollision(18));
    }

    @Test
    void carRaceCollision_nineteenValue() {
        assertEquals(361, CarRaceCollision.carRaceCollision(19));
    }

    @Test
    void carRaceCollision_twentyValue() {
        assertEquals(400, CarRaceCollision.carRaceCollision(20));
    }
}