package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UniqueDigitsTest {

    @Test
    void uniqueDigits_emptyList() {
        List<Integer> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_singleElement_noEvenDigit() {
        List<Integer> input = Arrays.asList(15);
        List<Object> expected = Arrays.asList(15);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_singleElement_evenDigit() {
        List<Integer> input = Arrays.asList(14);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_multipleElements_mixedEvenAndOdd() {
        List<Integer> input = Arrays.asList(15, 33, 1422, 1);
        List<Object> expected = Arrays.asList(1, 15, 33);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_multipleElements_allEvenDigits() {
        List<Integer> input = Arrays.asList(152, 323, 1422, 10);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_multipleElements_allOddDigits() {
        List<Integer> input = Arrays.asList(15, 33, 1, 5);
        List<Object> expected = Arrays.asList(1, 5, 15, 33);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_multipleElements_someOddSomeEven() {
        List<Integer> input = Arrays.asList(12345, 2033, 111, 151);
        List<Object> expected = Arrays.asList(111, 151);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_unsortedOddDigits() {
        List<Integer> input = Arrays.asList(135, 103, 31);
        List<Object> expected = Arrays.asList(31, 135);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_zero() {
        List<Integer> input = Arrays.asList(0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_negativeNumbers() {
        List<Integer> input = Arrays.asList(-15, -33, -1422, -1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_duplicateOddNumbers() {
        List<Integer> input = Arrays.asList(1, 1, 3, 3, 5, 5);
        List<Object> expected = Arrays.asList(1, 1, 3, 3, 5, 5);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_singleDigitOdd() {
        List<Integer> input = Arrays.asList(1, 3, 5, 7, 9);
        List<Object> expected = Arrays.asList(1, 3, 5, 7, 9);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_singleDigitEven() {
        List<Integer> input = Arrays.asList(0, 2, 4, 6, 8);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_allSameOddNumber() {
        List<Integer> input = Arrays.asList(11, 11, 11);
        List<Object> expected = Arrays.asList(11, 11, 11);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_numberEndingInZero() {
        List<Integer> input = Arrays.asList(10, 30, 50);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_numberStartingAndEndingWithOdd() {
        List<Integer> input = Arrays.asList(121, 343, 565);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_largeOddNumber() {
        List<Integer> input = Arrays.asList(13579);
        List<Object> expected = Arrays.asList(13579);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_largeEvenNumber() {
        List<Integer> input = Arrays.asList(24680);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_mixedLargeAndSmall() {
        List<Integer> input = Arrays.asList(1, 1234, 13579, 2);
        List<Object> expected = Arrays.asList(1, 13579);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void uniqueDigits_numbersWithLeadingZeros() {
        List<Integer> input = Arrays.asList(1, 1, 1);
        List<Object> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }
}