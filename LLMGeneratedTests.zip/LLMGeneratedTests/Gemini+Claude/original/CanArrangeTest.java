package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CanArrangeTest {

    @Test
    void canArrange_emptyList_returnsNegativeOne() {
        List<Object> arr = new ArrayList<>();
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_singleElementList_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(1);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_increasingOrder_returnsNegativeOne() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_decreasingOrder_returnsOne() {
        List<Object> arr = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example1() {
        List<Object> arr = Arrays.asList(1, 2, 4, 3, 5);
        assertEquals(3, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example2() {
        List<Object> arr = Arrays.asList(1, 2, 3);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example3() {
        List<Object> arr = Arrays.asList(1, 4, 2, 5, 6, 7, 8, 9, 10);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_example4() {
        List<Object> arr = Arrays.asList(4, 8, 5, 7, 3);
        assertEquals(4, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_mixedTypes_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(1, 2, "a", 3, 1);
        assertEquals(4, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_allStrings_returnsNegativeOne() {
        List<Object> arr = Arrays.asList("a", "b", "c");
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_firstElementInvalid_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList("a", 2, 1);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_lastElementInvalid_returnsCorrectIndex() {
        List<Object> arr = Arrays.asList(1, 2, 1, "a");
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_onlyInvalidElements_returnsNegativeOne() {
        List<Object> arr = Arrays.asList("a", "b", "c", "d");
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_boundaryCase_firstTwoElementsEqual() {
        List<Object> arr = Arrays.asList(2, 2, 1);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_boundaryCase_lastTwoElementsEqual() {
        List<Object> arr = Arrays.asList(1, 2, 2);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_multipleDecreasingPoints_returnsLargestIndex() {
        List<Object> arr = Arrays.asList(5, 4, 3, 6, 2, 1);
        assertEquals(5, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithZero() {
        List<Object> arr = Arrays.asList(1, 2, 0, 4, 5);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithNegativeNumbers() {
        List<Object> arr = Arrays.asList(1, 2, -1, 4, 5);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithMixedPositiveNegativeZero() {
        List<Object> arr = Arrays.asList(-1, 0, -2, 1, 2);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_boundaryCase_firstElementNegative() {
        List<Object> arr = Arrays.asList(-1, 0, 1);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_boundaryCase_lastElementNegative() {
        List<Object> arr = Arrays.asList(1, 0, -1);
        assertEquals(2, CanArrange.canArrange(arr));
    }
}