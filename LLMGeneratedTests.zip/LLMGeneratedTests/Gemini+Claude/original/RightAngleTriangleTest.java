package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RightAngleTriangleTest {

    @Test
    void rightAngleTriangle_validRightTriangle_returnsTrue() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(3, 4, 5));
    }

    @Test
    void rightAngleTriangle_invalidTriangle_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 2, 3));
    }

    @Test
    void rightAngleTriangle_validRightTriangle_returnsTrue2() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(10, 6, 8));
    }

    @Test
    void rightAngleTriangle_notRightTriangle_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(2, 2, 2));
    }

    @Test
    void rightAngleTriangle_validRightTriangle_returnsTrue3() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(7, 24, 25));
    }

    @Test
    void rightAngleTriangle_notRightTriangle_returnsFalse2() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(10, 5, 7));
    }

    @Test
    void rightAngleTriangle_validRightTriangle_returnsTrue4() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(5, 12, 13));
    }

    @Test
    void rightAngleTriangle_validRightTriangle_returnsTrue5() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(15, 8, 17));
    }

    @Test
    void rightAngleTriangle_validRightTriangle_returnsTrue6() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(48, 55, 73));
    }

    @Test
    void rightAngleTriangle_notRightTriangle_returnsFalse3() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 1, 1));
    }

    @Test
    void rightAngleTriangle_notRightTriangle_returnsFalse4() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(2, 2, 10));
    }

    @Test
    void rightAngleTriangle_aEqualsB_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(5, 5, 6));
    }

    @Test
    void rightAngleTriangle_bEqualsC_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(6, 5, 5));
    }

    @Test
    void rightAngleTriangle_aEqualsC_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(5, 6, 5));
    }

    @Test
    void rightAngleTriangle_aIsLargestAndRight_returnsTrue() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(5, 3, 4));
    }

    @Test
    void rightAngleTriangle_bIsLargestAndRight_returnsTrue() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(4, 5, 3));
    }

    @Test
    void rightAngleTriangle_cIsLargestAndRight_returnsTrue() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(3, 4, 5));
    }

    @Test
    void rightAngleTriangle_aIsLargestAndNotRight_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(6, 3, 4));
    }

    @Test
    void rightAngleTriangle_bIsLargestAndNotRight_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 6, 4));
    }

    @Test
    void rightAngleTriangle_cIsLargestAndNotRight_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 4, 6));
    }

    @Test
    void rightAngleTriangle_smallValues_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 1, 2));
    }

    @Test
    void rightAngleTriangle_negativeValues_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(-3, -4, -5));
    }

    @Test
    void rightAngleTriangle_zeroValues_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(0, 0, 0));
    }

    @Test
    void rightAngleTriangle_boundaryValues_returnsTrue() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(1, 1, (int) Math.sqrt(2)));
    }

    @Test
    void rightAngleTriangle_boundaryValuesNotRight_returnsFalse() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 1, 3));
    }
}