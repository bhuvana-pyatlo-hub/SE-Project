package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PrimeLengthTest {

    @Test
    void primeLength_emptyString_returnsFalse() {
        assertFalse(PrimeLength.primeLength(""));
    }

    @Test
    void primeLength_singleCharacterString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("M"));
    }

    @Test
    void primeLength_stringLengthTwo_returnsTrue() {
        assertTrue(PrimeLength.primeLength("HI"));
    }

    @Test
    void primeLength_stringLengthThree_returnsTrue() {
        assertTrue(PrimeLength.primeLength("wow"));
    }

    @Test
    void primeLength_stringLengthFive_returnsTrue() {
        assertTrue(PrimeLength.primeLength("Hello"));
    }

    @Test
    void primeLength_stringLengthSeven_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdcba"));
    }

    @Test
    void primeLength_stringLengthFour_returnsFalse() {
        assertFalse(PrimeLength.primeLength("gogo"));
    }

    @Test
    void primeLength_stringLengthSix_returnsFalse() {
        assertFalse(PrimeLength.primeLength("orange"));
    }

    @Test
    void primeLength_stringLengthEight_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefgh"));
    }

    @Test
    void primeLength_stringLengthNine_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghi"));
    }

    @Test
    void primeLength_stringLengthTen_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghij"));
    }

    @Test
    void primeLength_stringLengthEleven_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijk"));
    }

    @Test
    void primeLength_stringLengthTwelve_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijkl"));
    }

    @Test
    void primeLength_stringLengthThirteen_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklm"));
    }

    @Test
    void primeLength_stringLengthFourteen_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmn"));
    }

    @Test
    void primeLength_stringLengthFifteen_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmno"));
    }

    @Test
    void primeLength_stringLengthSixteen_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnop"));
    }

    @Test
    void primeLength_stringLengthSeventeen_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopq"));
    }

    @Test
    void primeLength_stringLengthEighteen_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqr"));
    }

    @Test
    void primeLength_stringLengthNineteen_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrs"));
    }

    @Test
    void primeLength_stringLengthTwenty_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqrst"));
    }

    @Test
    void primeLength_stringLengthTwentyOne_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrstu"));
    }

    @Test
    void primeLength_stringLengthTwentyTwo_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqrstuv"));
    }

    @Test
    void primeLength_stringLengthTwentyThree_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrstuvw"));
    }

    @Test
    void primeLength_stringLengthTwentyFour_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqrstuvwx"));
    }

    @Test
    void primeLength_stringLengthTwentyFive_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqrstuvwxy"));
    }

    @Test
    void primeLength_stringLengthTwentySix_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqrstuvwxyz"));
    }
}