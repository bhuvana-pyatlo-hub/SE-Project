package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LargestSmallestIntegersTest {

    @Test
    void testEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testOnlyZero() {
        List<Object> input = Arrays.asList(0);
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testOnlyPositiveIntegers() {
        List<Object> input = Arrays.asList(2, 4, 1, 3, 5, 7);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testOnlyNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -3, -5, -6);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testMixedIntegers() {
        List<Object> input = Arrays.asList(1, 3, 2, 4, 5, 6, -2);
        List<Integer> expected = Arrays.asList(-2, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testMixedIntegersWithZero() {
        List<Object> input = Arrays.asList(1, 3, 2, 4, 5, 6, -2, 0);
        List<Integer> expected = Arrays.asList(-2, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testLargestNegativeAndSmallestPositiveFarApart() {
        List<Object> input = Arrays.asList(7, 3, 8, 4, 9, 2, 5, -9);
        List<Integer> expected = Arrays.asList(-9, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testDuplicateNegativeIntegers() {
        List<Object> input = Arrays.asList(-6, -4, -4, -3, 1);
        List<Integer> expected = Arrays.asList(-3, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testDuplicatePositiveIntegers() {
        List<Object> input = Arrays.asList(1, 1, 2, 3, -1);
        List<Integer> expected = Arrays.asList(-1, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testLargeNegativeAndSmallPositive() {
        List<Object> input = Arrays.asList(-6, -4, -4, -3, -100, 1);
        List<Integer> expected = Arrays.asList(-3, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testAllSamePositiveInteger() {
        List<Object> input = Arrays.asList(5, 5, 5, 5);
        List<Integer> expected = Arrays.asList(null, 5);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testAllSameNegativeInteger() {
        List<Object> input = Arrays.asList(-2, -2, -2, -2);
        List<Integer> expected = Arrays.asList(-2, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testSinglePositiveInteger() {
        List<Object> input = Arrays.asList(5);
        List<Integer> expected = Arrays.asList(null, 5);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testSingleNegativeInteger() {
        List<Object> input = Arrays.asList(-5);
        List<Integer> expected = Arrays.asList(-5, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testPositiveAndNegativeCloseToZero() {
        List<Object> input = Arrays.asList(-1, 1);
        List<Integer> expected = Arrays.asList(-1, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testPositiveAndNegativeFarFromZero() {
        List<Object> input = Arrays.asList(-100, 100);
        List<Integer> expected = Arrays.asList(-100, 100);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testMultipleNegativesAndOnePositive() {
        List<Object> input = Arrays.asList(-5, -10, -2, 1);
        List<Integer> expected = Arrays.asList(-2, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testMultiplePositivesAndOneNegative() {
        List<Object> input = Arrays.asList(5, 10, 2, -1);
        List<Integer> expected = Arrays.asList(-1, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testZeroWithPositives() {
        List<Object> input = Arrays.asList(0, 1, 2, 3);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testZeroWithNegatives() {
        List<Object> input = Arrays.asList(0, -1, -2, -3);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void testNegativeAndPositiveWithSameMagnitude() {
        List<Object> input = Arrays.asList(-50, 50);
        List<Integer> expected = Arrays.asList(-50, 50);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }
}