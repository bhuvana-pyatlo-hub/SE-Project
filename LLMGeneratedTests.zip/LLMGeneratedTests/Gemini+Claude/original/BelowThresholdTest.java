package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class BelowThresholdTest {

    @Test
    void testBelowThreshold_emptyList() {
        List<Integer> list = Collections.emptyList();
        int threshold = 10;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_allBelow() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        int threshold = 10;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_oneAbove() {
        List<Integer> list = Arrays.asList(1, 2, 10, 4);
        int threshold = 10;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_allEqual() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5);
        int threshold = 5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_allAbove() {
        List<Integer> list = Arrays.asList(10, 11, 12, 13);
        int threshold = 5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_mixedValues() {
        List<Integer> list = Arrays.asList(1, 5, 10, 15);
        int threshold = 8;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_largeThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        int threshold = 100;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_negativeValues() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4);
        int threshold = 0;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_negativeThreshold() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        int threshold = -1;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_mixedNegativeAndPositive() {
        List<Integer> list = Arrays.asList(-1, 2, -3, 4);
        int threshold = 0;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_singleElementList_below() {
        List<Integer> list = Collections.singletonList(5);
        int threshold = 10;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_singleElementList_above() {
        List<Integer> list = Collections.singletonList(10);
        int threshold = 5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_singleElementList_equal() {
        List<Integer> list = Collections.singletonList(5);
        int threshold = 5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_firstElementAbove() {
        List<Integer> list = Arrays.asList(10, 1, 2, 3);
        int threshold = 5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_lastElementAbove() {
        List<Integer> list = Arrays.asList(1, 2, 3, 10);
        int threshold = 5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_thresholdEqualToMax() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        int threshold = 4;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_allNegative_thresholdNegative() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4);
        int threshold = -5;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_allNegative_thresholdZero() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4);
        int threshold = 0;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_largeList_allBelow() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        int threshold = 100;
        assertTrue(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_largeList_oneAbove() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 100);
        int threshold = 50;
        assertFalse(BelowThreshold.belowThreshold(list, threshold));
    }

    @Test
    void testBelowThreshold_boundaryValues() {
        List<Integer> list = Arrays.asList(-100, 0, 100);
        assertTrue(BelowThreshold.belowThreshold(list, 101));
        assertFalse(BelowThreshold.belowThreshold(list, 100));
        assertFalse(BelowThreshold.belowThreshold(list, -1));
    }
}