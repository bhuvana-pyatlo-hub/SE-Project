package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountUpperTest {

    @Test
    void countUpper_emptyString_returnsZero() {
        assertEquals(0, CountUpper.countUpper(""));
    }

    @Test
    void countUpper_noUppercaseVowels_returnsZero() {
        assertEquals(0, CountUpper.countUpper("abcdefg"));
    }

    @Test
    void countUpper_uppercaseVowelAtOddIndex_returnsZero() {
        assertEquals(0, CountUpper.countUpper("aE"));
    }

    @Test
    void countUpper_uppercaseVowelAtEvenIndex_returnsOne() {
        assertEquals(1, CountUpper.countUpper("AE"));
    }

    @Test
    void countUpper_multipleUppercaseVowelsAtEvenIndices_returnsCorrectCount() {
        assertEquals(2, CountUpper.countUpper("AEIO"));
    }

    @Test
    void countUpper_uppercaseVowelsMixedWithOtherCharacters_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A1E2I3O4U"));
    }

    @Test
    void countUpper_lowercaseVowelsAtEvenIndices_returnsZero() {
        assertEquals(0, CountUpper.countUpper("aeiou"));
    }

    @Test
    void countUpper_uppercaseConsonantsAtEvenIndices_returnsZero() {
        assertEquals(0, CountUpper.countUpper("BCDFG"));
    }

    @Test
    void countUpper_mixedCaseVowelsAndConsonants_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AbCdEf"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacter_uppercaseVowel_returnsOne() {
        assertEquals(1, CountUpper.countUpper("A"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacter_lowercaseVowel_returnsZero() {
        assertEquals(0, CountUpper.countUpper("a"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacter_uppercaseConsonant_returnsZero() {
        assertEquals(0, CountUpper.countUpper("B"));
    }

    @Test
    void countUpper_stringWithOnlyOneCharacter_lowercaseConsonant_returnsZero() {
        assertEquals(0, CountUpper.countUpper("b"));
    }

    @Test
    void countUpper_stringWithMultipleCharacters_onlyUppercaseVowelsAtOddIndices_returnsZero() {
        assertEquals(0, CountUpper.countUpper("bEbEb"));
    }

    @Test
    void countUpper_stringWithMultipleCharacters_uppercaseVowelsAtEvenAndOddIndices_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AEbEb"));
    }

    @Test
    void countUpper_stringWithNumbersAndSpecialCharacters_returnsZero() {
        assertEquals(0, CountUpper.countUpper("123!@#"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelsAndNumbers_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A123"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelsAndSpecialCharacters_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A!@#"));
    }

    @Test
    void countUpper_stringWithMixedCaseVowelsAndSpecialCharacters_returnsCorrectCount() {
        assertEquals(0, CountUpper.countUpper("a!@#"));
    }

    @Test
    void countUpper_stringWithMixedCaseVowelsAndNumbers_returnsCorrectCount() {
        assertEquals(0, CountUpper.countUpper("a123"));
    }

    @Test
    void countUpper_longStringWithManyCharacters_returnsCorrectCount() {
        assertEquals(5, CountUpper.countUpper("A1E2I3O4U5A6E7I8O9U0"));
    }

    @Test
    void countUpper_uppercaseVowelAtBoundaryIndex_returnsOne() {
        assertEquals(1, CountUpper.countUpper("A"));
    }

    @Test
    void countUpper_uppercaseVowelAtLastEvenIndex_returnsOne() {
        assertEquals(1, CountUpper.countUpper("aA"));
    }

    @Test
    void countUpper_uppercaseVowelAtLastOddIndex_returnsZero() {
        assertEquals(0, CountUpper.countUpper("Aa"));
    }

    @Test
    void countUpper_stringWithAllUppercaseVowels_returnsCorrectCount() {
        assertEquals(3, CountUpper.countUpper("AEIOUAEIOU"));
    }

    @Test
    void countUpper_stringWithUppercaseAndLowercaseVowels_returnsCorrectCount() {
        assertEquals(2, CountUpper.countUpper("AeIoU"));
    }
}