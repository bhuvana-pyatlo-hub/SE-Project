package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DecimalToBinaryTest {

    @Test
    void decimalToBinary_zero() {
        assertEquals("db0db", DecimalToBinary.decimalToBinary(0));
    }

    @Test
    void decimalToBinary_one() {
        assertEquals("db1db", DecimalToBinary.decimalToBinary(1));
    }

    @Test
    void decimalToBinary_two() {
        assertEquals("db10db", DecimalToBinary.decimalToBinary(2));
    }

    @Test
    void decimalToBinary_three() {
        assertEquals("db11db", DecimalToBinary.decimalToBinary(3));
    }

    @Test
    void decimalToBinary_four() {
        assertEquals("db100db", DecimalToBinary.decimalToBinary(4));
    }

    @Test
    void decimalToBinary_five() {
        assertEquals("db101db", DecimalToBinary.decimalToBinary(5));
    }

    @Test
    void decimalToBinary_six() {
        assertEquals("db110db", DecimalToBinary.decimalToBinary(6));
    }

    @Test
    void decimalToBinary_seven() {
        assertEquals("db111db", DecimalToBinary.decimalToBinary(7));
    }

    @Test
    void decimalToBinary_eight() {
        assertEquals("db1000db", DecimalToBinary.decimalToBinary(8));
    }

    @Test
    void decimalToBinary_nine() {
        assertEquals("db1001db", DecimalToBinary.decimalToBinary(9));
    }

    @Test
    void decimalToBinary_ten() {
        assertEquals("db1010db", DecimalToBinary.decimalToBinary(10));
    }

    @Test
    void decimalToBinary_fifteen() {
        assertEquals("db1111db", DecimalToBinary.decimalToBinary(15));
    }

    @Test
    void decimalToBinary_sixteen() {
        assertEquals("db10000db", DecimalToBinary.decimalToBinary(16));
    }

    @Test
    void decimalToBinary_thirtyTwo() {
        assertEquals("db100000db", DecimalToBinary.decimalToBinary(32));
    }

    @Test
    void decimalToBinary_sixtyThree() {
        assertEquals("db111111db", DecimalToBinary.decimalToBinary(63));
    }

    @Test
    void decimalToBinary_sixtyFour() {
        assertEquals("db1000000db", DecimalToBinary.decimalToBinary(64));
    }

    @Test
    void decimalToBinary_oneHundred() {
        assertEquals("db1100100db", DecimalToBinary.decimalToBinary(100));
    }

    @Test
    void decimalToBinary_oneHundredThree() {
        assertEquals("db1100111db", DecimalToBinary.decimalToBinary(103));
    }

    @Test
    void decimalToBinary_negativeValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            DecimalToBinary.decimalToBinary(-1);
        });
    }

    @Test
    void decimalToBinary_boundaryValue() {
        assertEquals("db1db", DecimalToBinary.decimalToBinary(1));
        assertEquals("db0db", DecimalToBinary.decimalToBinary(0));
    }
}