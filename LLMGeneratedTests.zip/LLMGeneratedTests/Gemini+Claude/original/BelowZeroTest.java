package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BelowZeroTest {

    @Test
    void belowZero_emptyList_returnsFalse() {
        List<Object> operations = Collections.emptyList();
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_positiveOperations_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2, 3);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_belowZeroOnce_returnsTrue() {
        List<Object> operations = Arrays.asList(1, 2, -4, 5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_belowZeroMultipleTimes_returnsTrue() {
        List<Object> operations = Arrays.asList(1, -2, 1, -3, 1, -4);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_neverBelowZero_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2, -3, 1, 2, -3);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedTypes_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(1, 2.0, -4, 5.0);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_onlyDoubles_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(1.0, 2.0, -0.5, -3.0);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_onlyIntegers_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(1, 2, -1, -2);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_zeroBalance_returnsFalse() {
        List<Object> operations = Arrays.asList(1, -1, 2, -2, 5, -5, 4, -4);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_almostZeroBalance_returnsTrue() {
        List<Object> operations = Arrays.asList(1, -1, 2, -2, 5, -5, 4, -5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_smallPositiveThenLargeNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(10, -100);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_smallPositiveThenSmallNegative_returnsFalse() {
        List<Object> operations = Arrays.asList(10, -5);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedPositiveAndNegative_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(5, -2, 3, -1, 2, -4);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_allZeroes_returnsFalse() {
        List<Object> operations = Arrays.asList(0, 0, 0, 0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_doubleAndIntegerMix_returnsCorrectResult() {
        List<Object> operations = Arrays.asList(1.5, 2, -4.5, 5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_initialNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(-1);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_multipleNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(-1, -2, -3);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_positiveThenNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(1, -2);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_invalidInputType_throwsException() {
        List<Object> operations = new ArrayList<>();
        operations.add("invalid");

        assertThrows(IllegalArgumentException.class, () -> BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_boundaryNegativeInput_returnsTrue() {
        List<Object> operations = Arrays.asList(-1, 1);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_boundaryPositiveInput_returnsFalse() {
        List<Object> operations = Arrays.asList(1, -1);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_largeNegativeInput_returnsTrue() {
        List<Object> operations = Arrays.asList(-100);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_largePositiveThenNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(100, -200);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_largePositiveThenSmallNegative_returnsFalse() {
        List<Object> operations = Arrays.asList(200, -100);
        assertFalse(BelowZero.belowZero(operations));
    }
}