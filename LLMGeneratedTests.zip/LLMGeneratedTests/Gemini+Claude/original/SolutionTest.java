package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class SolutionTest {

    @Test
    void testEmptyList() {
        List<Integer> emptyList = Collections.emptyList();
        assertEquals(0, Solution.solution(emptyList));
    }

    @Test
    void testSingleOddElementAtEvenPosition() {
        List<Integer> list = Collections.singletonList(5);
        assertEquals(5, Solution.solution(list));
    }

    @Test
    void testSingleEvenElementAtEvenPosition() {
        List<Integer> list = Collections.singletonList(4);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testOddElementAtOddPosition() {
        List<Integer> list = Arrays.asList(2, 3);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testEvenElementAtEvenPosition() {
        List<Integer> list = Arrays.asList(4, 5);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testMultipleElementsMixedOddEven() {
        List<Integer> list = Arrays.asList(5, 8, 7, 1);
        assertEquals(12, Solution.solution(list));
    }

    @Test
    void testAllOddElements() {
        List<Integer> list = Arrays.asList(3, 3, 3, 3, 3);
        assertEquals(9, Solution.solution(list));
    }

    @Test
    void testAllEvenElements() {
        List<Integer> list = Arrays.asList(30, 24, 32);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testOddAndEvenElements() {
        List<Integer> list = Arrays.asList(30, 13, 24, 321);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testTwoOddElementsAtEvenPositions() {
        List<Integer> list = Arrays.asList(5, 9);
        assertEquals(5, Solution.solution(list));
    }

    @Test
    void testTwoEvenElementsAtEvenPositions() {
        List<Integer> list = Arrays.asList(2, 4, 8);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testOddAndEvenElementsMixedPositions() {
        List<Integer> list = Arrays.asList(30, 13, 23, 32);
        assertEquals(23, Solution.solution(list));
    }

    @Test
    void testOddAndEvenElementsMixedPositions2() {
        List<Integer> list = Arrays.asList(3, 13, 2, 9);
        assertEquals(3, Solution.solution(list));
    }

    @Test
    void testListWithZeroes() {
        List<Integer> list = Arrays.asList(0, 1, 0, 3, 0, 5);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testListWithNegativeOddAndEvenNumbers() {
        List<Integer> list = Arrays.asList(-1, 2, -3, 4, -5, 6);
        assertEquals(-1 + -3 + -5, Solution.solution(list));
    }

    @Test
    void testListWithOnlyNegativeEvenNumbers() {
        List<Integer> list = Arrays.asList(-2, -4, -6, -8);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testListWithOnlyNegativeOddNumbers() {
        List<Integer> list = Arrays.asList(-1, -3, -5, -7);
        assertEquals(-1 + -5, Solution.solution(list));
    }

    @Test
    void testListWithMixedPositiveAndNegativeOddNumbers() {
        List<Integer> list = Arrays.asList(1, 2, -3, 4, 5, 6, -7, 8);
        assertEquals(1 + 5 + -7, Solution.solution(list));
    }

    @Test
    void testListWithMinimumOddNumber() {
        List<Integer> list = Arrays.asList(1);
        assertEquals(1, Solution.solution(list));
    }

    @Test
    void testListWithMaximumOddNumber() {
        List<Integer> list = Arrays.asList(99);
        assertEquals(99, Solution.solution(list));
    }

    @Test
    void testListWithMinimumEvenNumber() {
        List<Integer> list = Arrays.asList(0);
        assertEquals(0, Solution.solution(list));
    }

    @Test
    void testListWithMaximumEvenNumber() {
        List<Integer> list = Arrays.asList(100);
        assertEquals(0, Solution.solution(list));
    }
}