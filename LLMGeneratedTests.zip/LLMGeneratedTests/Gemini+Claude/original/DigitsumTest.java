package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DigitsumTest {

    @Test
    void digitSum_emptyString() {
        assertEquals(0, Digitsum.digitSum(""));
    }

    @Test
    void digitSum_noUpperCase() {
        assertEquals(0, Digitsum.digitSum("abcdefg"));
    }

    @Test
    void digitSum_singleUpperCase() {
        assertEquals(65, Digitsum.digitSum("A"));
    }

    @Test
    void digitSum_singleLowerCase() {
        assertEquals(0, Digitsum.digitSum("a"));
    }

    @Test
    void digitSum_mixedCase() {
        assertEquals(131, Digitsum.digitSum("abAB"));
    }

    @Test
    void digitSum_mixedCase2() {
        assertEquals(67, Digitsum.digitSum("abcCd"));
    }

    @Test
    void digitSum_mixedCase3() {
        assertEquals(69, Digitsum.digitSum("helloE"));
    }

    @Test
    void digitSum_mixedCase4() {
        assertEquals(131, Digitsum.digitSum("woArBld"));
    }

    @Test
    void digitSum_mixedCase5() {
        assertEquals(153, Digitsum.digitSum("aAaaaXa"));
    }

    @Test
    void digitSum_withSpaces() {
        assertEquals(151, Digitsum.digitSum(" How are yOu?"));
    }

    @Test
    void digitSum_multipleUpperCase() {
        assertEquals(327, Digitsum.digitSum("You arE Very Smart"));
    }

    @Test
    void digitSum_onlyUpperCase() {
        assertEquals(195, Digitsum.digitSum("ABC"));
    }

    @Test
    void digitSum_numbersAndUpperCase() {
        assertEquals(65, Digitsum.digitSum("123A456"));
    }

    @Test
    void digitSum_numbersAndLowerCase() {
        assertEquals(0, Digitsum.digitSum("123a456"));
    }

    @Test
    void digitSum_specialCharacters() {
        assertEquals(0, Digitsum.digitSum("!@#$%^"));
    }

    @Test
    void digitSum_specialAndUpperCase() {
        assertEquals(65, Digitsum.digitSum("!@#$A%^"));
    }

    @Test
    void digitSum_boundaryA() {
        assertEquals(65, Digitsum.digitSum("A"));
    }

    @Test
    void digitSum_boundaryZ() {
        assertEquals(90, Digitsum.digitSum("Z"));
    }

    @Test
    void digitSum_nearBoundaryA() {
        assertEquals(0, Digitsum.digitSum("`"));
    }

    @Test
    void digitSum_nearBoundaryZ() {
        assertEquals(0, Digitsum.digitSum("["));
    }

    @Test
    void digitSum_longStringWithUpperCase() {
        assertEquals(65 + 66 + 67, Digitsum.digitSum("ThisIsALongStringABC"));
    }

    @Test
    void digitSum_stringWithOnlySpecialCharacters() {
        assertEquals(0, Digitsum.digitSum("!@#$%^&*()_+=-`~[]\\{}|;':\",./<>?"));
    }

    @Test
    void digitSum_mixedCaseWithNumbers() {
        assertEquals(131, Digitsum.digitSum("1A2B3C4D"));
    }

    @Test
    void digitSum_upperAndLowerCaseMixed() {
        assertEquals(0, Digitsum.digitSum("abcde"));
    }

    @Test
    void digitSum_upperCaseWithSpaces() {
        assertEquals(130, Digitsum.digitSum(" A B C "));
    }
}