package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsSimplePowerTest {

    @Test
    void isSimplePower_xIsOne_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 4));
    }

    @Test
    void isSimplePower_nIsOne_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(3, 1));
    }

    @Test
    void isSimplePower_validSimplePower_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(8, 2));
    }

    @Test
    void isSimplePower_invalidSimplePower_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(3, 2));
    }

    @Test
    void isSimplePower_xEqualsN_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(2, 2));
    }

    @Test
    void isSimplePower_xIsSmallerThanN_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(2, 3));
    }

    @Test
    void isSimplePower_xIsSixteenNIsTwo_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(16, 2));
    }

    @Test
    void isSimplePower_xIsFourNIsTwo_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(4, 2));
    }

    @Test
    void isSimplePower_xIsNineNIsThree_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(9, 3));
    }

    @Test
    void isSimplePower_xIsSixteenNIsFour_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(16, 4));
    }

    @Test
    void isSimplePower_xIsTwentyFourNIsTwo_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(24, 2));
    }

    @Test
    void isSimplePower_xIsOneTwentyEightNIsFour_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(128, 4));
    }

    @Test
    void isSimplePower_xIsTwelveNIsSix_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(12, 6));
    }

    @Test
    void isSimplePower_xIsOneNIsOne_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 1));
    }

    @Test
    void isSimplePower_xIsOneNIsTwelve_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 12));
    }

    @Test
    void isSimplePower_xIsSmallAndValid_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(27, 3));
    }

    @Test
    void isSimplePower_xIsSmallAndInvalid_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(10, 3));
    }

    @Test
    void isSimplePower_xIsBoundaryValue_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(64, 8));
    }

    @Test
    void isSimplePower_xIsCloseToBoundaryValue_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(63, 8));
    }

    @Test
    void isSimplePower_xIsZero_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(0, 2));
    }

    @Test
    void isSimplePower_xIsNegative_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(-8, 2));
    }

    @Test
    void isSimplePower_nIsNegative_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(8, -2));
    }

    @Test
    void isSimplePower_xIsNegativeNIsNegative_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(-8, -2));
    }
}