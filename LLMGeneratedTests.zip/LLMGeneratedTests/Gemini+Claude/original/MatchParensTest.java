package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MatchParensTest {

    @Test
    void matchParens_s1s2Good() {
        List<String> lst = Arrays.asList("()(", ")");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_bothBad() {
        List<String> lst = Arrays.asList(")", ")");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_complexBad() {
        List<String> lst = Arrays.asList("(()(())", "())())");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s2s1Good() {
        List<String> lst = Arrays.asList(")())", "(()(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Good_complex() {
        List<String> lst = Arrays.asList("(())))", "(()())((");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad() {
        List<String> lst = Arrays.asList("()", "())");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Good2() {
        List<String> lst = Arrays.asList("(()(", "()))()");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_bothBad2() {
        List<String> lst = Arrays.asList("((((", "((())");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_bothBad3() {
        List<String> lst = Arrays.asList(")(()", "(()(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_bothBad4() {
        List<String> lst = Arrays.asList(")(", ")(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Good3() {
        List<String> lst = Arrays.asList("(", ")");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s2s1Good2() {
        List<String> lst = Arrays.asList(")", "(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_emptyStrings() {
        List<String> lst = Arrays.asList("", "");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_emptyString_s1() {
        List<String> lst = Arrays.asList("", "()");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_emptyString_s2() {
        List<String> lst = Arrays.asList("()", "");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_singleOpenParen_s1() {
        List<String> lst = Arrays.asList("(", "");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_singleCloseParen_s1() {
        List<String> lst = Arrays.asList(")", "");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_singleOpenParen_s2() {
        List<String> lst = Arrays.asList("", "(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_singleCloseParen_s2() {
        List<String> lst = Arrays.asList("", ")");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_balanced_s1() {
        List<String> lst = Arrays.asList("()", "");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_balanced_s2() {
        List<String> lst = Arrays.asList("", "()");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }
}