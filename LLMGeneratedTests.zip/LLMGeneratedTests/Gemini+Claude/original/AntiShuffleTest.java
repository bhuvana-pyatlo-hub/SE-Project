package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AntiShuffleTest {

    @Test
    void antiShuffle_emptyString() {
        assertEquals("", AntiShuffle.antiShuffle(""));
    }

    @Test
    void antiShuffle_singleWord_alreadySorted() {
        assertEquals("abcd", AntiShuffle.antiShuffle("abcd"));
    }

    @Test
    void antiShuffle_singleWord_unsorted() {
        assertEquals("ehllo", AntiShuffle.antiShuffle("hello"));
    }

    @Test
    void antiShuffle_multipleWords() {
        assertEquals("Hello !!!Wdlor", AntiShuffle.antiShuffle("Hello World!!!"));
    }

    @Test
    void antiShuffle_multipleWords_withPunctuation() {
        assertEquals(".Hi My aemn is Meirst .Rboot How aer ?ouy", AntiShuffle.antiShuffle("Hi. My name is Mister Robot. How are you?"));
    }

    @Test
    void antiShuffle_singleWord_numbers() {
        assertEquals("0123", AntiShuffle.antiShuffle("1203"));
    }

    @Test
    void antiShuffle_singleWord_mixedCase() {
        assertEquals("Hllo", AntiShuffle.antiShuffle("lHol"));
    }

    @Test
    void antiShuffle_singleWord_specialCharacters() {
        assertEquals("!!!", AntiShuffle.antiShuffle("!!!"));
    }

    @Test
    void antiShuffle_multipleSpaces() {
        assertEquals("   ", AntiShuffle.antiShuffle("   "));
    }

    @Test
    void antiShuffle_leadingAndTrailingSpaces() {
        assertEquals("  ehllo  ", AntiShuffle.antiShuffle("  hello  "));
    }

    @Test
    void antiShuffle_numbersAndLetters() {
        assertEquals("0123abde", AntiShuffle.antiShuffle("ab12de03"));
    }

    @Test
    void antiShuffle_singleCharacter() {
        assertEquals("a", AntiShuffle.antiShuffle("a"));
    }

    @Test
    void antiShuffle_singleWord_sameCharacters() {
        assertEquals("aaaa", AntiShuffle.antiShuffle("aaaa"));
    }

    @Test
    void antiShuffle_mixedCaseAndNumbers() {
        assertEquals("0123AHllo", AntiShuffle.antiShuffle("lH12oA3l0"));
    }

    @Test
    void antiShuffle_wordWithSpaceInside() {
        assertEquals("  ", AntiShuffle.antiShuffle("  "));
    }

    @Test
    void antiShuffle_wordWithOnlySpecialChars() {
        assertEquals("!@#", AntiShuffle.antiShuffle("@!#"));
    }

    @Test
    void antiShuffle_longString() {
        assertEquals(" aaaaaabbbbbbccccccccddddddddeeeeeeeeffffffffgggggggg", AntiShuffle.antiShuffle(" aaaaaabbbbbbccccccccddddddddeeeeeeeeffffffffgggggggg"));
    }

    @Test
    void antiShuffle_stringWithTabs() {
        assertEquals("\tehlllo", AntiShuffle.antiShuffle("\thello"));
    }

    @Test
    void antiShuffle_stringWithNewline() {
        assertEquals("\nehllo", AntiShuffle.antiShuffle("\nhello"));
    }

    @Test
    void antiShuffle_stringWithMixedWhitespace() {
        assertEquals(" \t\nehllo", AntiShuffle.antiShuffle(" \t\nhello"));
    }

    @Test
    void antiShuffle_singleWord_withEmptySpaces() {
        assertEquals(" ", AntiShuffle.antiShuffle(" "));
    }

    @Test
    void antiShuffle_multipleWords_withLeadingSpaces() {
        assertEquals("  a  b  ", AntiShuffle.antiShuffle("  a  b  "));
    }

    @Test
    void antiShuffle_singleWord_withSpecialChars() {
        assertEquals("!@#", AntiShuffle.antiShuffle("#@!"));
    }
}