package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ByLengthTest {

    @Test
    void byLength_emptyArray() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_validInput() {
        List<Object> input = Arrays.asList(2, 1, 1, 4, 5, 8, 2, 3);
        List<Object> expected = Arrays.asList("Eight", "Five", "Four", "Three", "Two", "Two", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_mixedInput() {
        List<Object> input = Arrays.asList(1, -1, 55);
        List<Object> expected = Arrays.asList("One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_mixedInput2() {
        List<Object> input = Arrays.asList(1, -1, 3, 2);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_validInput2() {
        List<Object> input = Arrays.asList(9, 4, 8);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Four");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyNumbersGreaterThanNine() {
        List<Object> input = Arrays.asList(10, 11, 12);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_numbersOutsideRangeInterspersed() {
        List<Object> input = Arrays.asList(1, 10, 2, -1, 3, 11);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allSameNumber() {
        List<Object> input = Arrays.asList(5, 5, 5, 5);
        List<Object> expected = Arrays.asList("Five", "Five", "Five", "Five");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_oneNumber() {
        List<Object> input = Arrays.asList(7);
        List<Object> expected = Arrays.asList("Seven");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_zeroInList() {
        List<Object> input = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList("Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_stringInList() {
        List<Object> input = Arrays.asList(1, "hello", 2);
        List<Object> expected = Arrays.asList("Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_doubleInList() {
        List<Object> input = Arrays.asList(1, 2.5, 2);
        List<Object> expected = Arrays.asList("Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_boundaryValuesOneAndNine() {
        List<Object> input = Arrays.asList(1, 9);
        List<Object> expected = Arrays.asList("Nine", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_multipleNines() {
        List<Object> input = Arrays.asList(9, 9, 9);
        List<Object> expected = Arrays.asList("Nine", "Nine", "Nine");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_multipleOnes() {
        List<Object> input = Arrays.asList(1, 1, 1);
        List<Object> expected = Arrays.asList("One", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allNumbersFromOneToNine() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_largeListWithMixedValues() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -1, "test", 2.5, 1, 2, 3);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Three", "Two", "Two", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyZero() {
        List<Object> input = Arrays.asList(0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyString() {
        List<Object> input = Arrays.asList("test");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }
}