package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortedListSumTest {

    @Test
    void sortedListSum_emptyList() {
        List<String> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_allOddLengthStrings() {
        List<String> input = Arrays.asList("a", "bbb", "ccccc");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_allEvenLengthStrings() {
        List<String> input = Arrays.asList("aa", "bbbb", "cccccc");
        List<Object> expected = Arrays.asList("aa", "bbbb", "cccccc");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_mixedEvenAndOddLengthStrings() {
        List<String> input = Arrays.asList("a", "bb", "ccc", "dddd");
        List<Object> expected = Arrays.asList("bb", "dddd");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_duplicateEvenLengthStrings() {
        List<String> input = Arrays.asList("aa", "bb", "aa", "bb");
        List<Object> expected = Arrays.asList("aa", "aa", "bb", "bb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsOfSameLength_sortedAlphabetically() {
        List<String> input = Arrays.asList("cd", "ab", "ef");
        List<Object> expected = Arrays.asList("ab", "cd", "ef");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsOfDifferentLength_sortedByLength() {
        List<String> input = Arrays.asList("abcd", "aa", "bbbb", "cc");
        List<Object> expected = Arrays.asList("aa", "cc", "abcd", "bbbb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsOfSameAndDifferentLength_sortedCorrectly() {
        List<String> input = Arrays.asList("abcde", "aa", "bbbb", "cc", "ab");
        List<Object> expected = Arrays.asList("aa", "ab", "cc", "bbbb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_emptyStringInList() {
        List<String> input = Arrays.asList("");
        List<Object> expected = Arrays.asList("");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_emptyStringAndOtherStrings() {
        List<String> input = Arrays.asList("", "aa", "a");
        List<Object> expected = Arrays.asList("", "aa");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithNumbers() {
        List<String> input = Arrays.asList("12", "1", "1234");
        List<Object> expected = Arrays.asList("12", "1234");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithSpecialCharacters() {
        List<String> input = Arrays.asList("!@", "#$%^", "&*");
        List<Object> expected = Arrays.asList("!@", "&*", "#$%^");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_mixedCaseStrings_sameLength() {
        List<String> input = Arrays.asList("AI", "ai", "au");
        List<Object> expected = Arrays.asList("AI", "ai", "au");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_mixedCaseStrings_differentLength() {
        List<String> input = Arrays.asList("AI", "a", "auau");
        List<Object> expected = Arrays.asList("AI", "auau");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example1() {
        List<String> input = Arrays.asList("aa", "a", "aaa");
        List<Object> expected = Arrays.asList("aa");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example2() {
        List<String> input = Arrays.asList("ab", "a", "aaa", "cd");
        List<Object> expected = Arrays.asList("ab", "cd");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example3() {
        List<String> input = Arrays.asList("school", "AI", "asdf", "b");
        List<Object> expected = Arrays.asList("AI", "asdf", "school");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example4() {
        List<String> input = Arrays.asList("d", "b", "c", "a");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example5() {
        List<String> input = Arrays.asList("d", "dcba", "abcd", "a");
        List<Object> expected = Arrays.asList("abcd", "dcba");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example6() {
        List<String> input = Arrays.asList("a", "b", "b", "c", "c", "a");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_example7() {
        List<String> input = Arrays.asList("aaaa", "bbbb", "dd", "cc");
        List<Object> expected = Arrays.asList("cc", "dd", "aaaa", "bbbb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_boundaryValues() {
        List<String> input = Arrays.asList("a", "bb", "ccc", "dddd", "ee");
        List<Object> expected = Arrays.asList("bb", "ee", "dddd");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }
}