package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IntersperseTest {

    @Test
    void intersperse_emptyList_returnsEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_singleElementList_returnsSameList() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_twoElementList_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, 2);
        List<Object> expected = Arrays.asList(1, 4, 2);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_threeElementList_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, 4, 2, 4, 3);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_fourElementList_returnsIntersperseList() {
        List<Object> input = Arrays.asList(5, 6, 3, 2);
        List<Object> expected = Arrays.asList(5, 8, 6, 8, 3, 8, 2);
        assertEquals(expected, Intersperse.intersperse(input, 8));
    }

    @Test
    void intersperse_sameElements_returnsIntersperseList() {
        List<Object> input = Arrays.asList(2, 2, 2);
        List<Object> expected = Arrays.asList(2, 2, 2, 2, 2);
        assertEquals(expected, Intersperse.intersperse(input, 2));
    }

    @Test
    void intersperse_delimiterZero_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, 0, 2, 0, 3);
        assertEquals(expected, Intersperse.intersperse(input, 0));
    }

    @Test
    void intersperse_negativeDelimiter_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, -1, 2, -1, 3);
        assertEquals(expected, Intersperse.intersperse(input, -1));
    }

    @Test
    void intersperse_listWithZero_returnsIntersperseList() {
        List<Object> input = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(0, 4, 1, 4, 2);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_listWithNegativeNumbers_returnsIntersperseList() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(-1, 4, -2, 4, -3);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_listWithMixedNumbers_returnsIntersperseList() {
        List<Object> input = Arrays.asList(-1, 0, 1);
        List<Object> expected = Arrays.asList(-1, 4, 0, 4, 1);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_listWithSameDelimiterValue_returnsIntersperseList() {
        List<Object> input = Arrays.asList(5, 5, 5);
        List<Object> expected = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(expected, Intersperse.intersperse(input, 5));
    }

    @Test
    void intersperse_longerList_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 4, 2, 4, 3, 4, 4, 4, 5);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_listWithDuplicateValues_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, 2, 2, 3);
        List<Object> expected = Arrays.asList(1, 4, 2, 4, 2, 4, 3);
        assertEquals(expected, Intersperse.intersperse(input, 4));
    }

    @Test
    void intersperse_listWithNegativeAndLargeValues_returnsIntersperseList() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(-1, -4, -2, -4, -3);
        assertEquals(expected, Intersperse.intersperse(input, -4));
    }

    @Test
    void intersperse_listWithMixedValuesAndNegativeDelimiter_returnsIntersperseList() {
        List<Object> input = Arrays.asList(1, -2, 3);
        List<Object> expected = Arrays.asList(1, -4, -2, -4, 3);
        assertEquals(expected, Intersperse.intersperse(input, -4));
    }

    @Test
    void intersperse_listWithZeroAndNegativeDelimiter_returnsIntersperseList() {
        List<Object> input = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(0, -4, 1, -4, 2);
        assertEquals(expected, Intersperse.intersperse(input, -4));
    }
}