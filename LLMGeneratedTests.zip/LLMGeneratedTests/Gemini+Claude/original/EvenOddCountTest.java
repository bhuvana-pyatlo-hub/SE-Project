package original;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class EvenOddCountTest {

    @Test
    void evenOddCount_positiveNumberWithEvenAndOddDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(123);
        assertEquals(Arrays.asList(1, 2), result);
    }

    @Test
    void evenOddCount_negativeNumberWithEvenAndOddDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(-12);
        assertEquals(Arrays.asList(1, 1), result);
    }

    @Test
    void evenOddCount_singleDigitEvenNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(2);
        assertEquals(Arrays.asList(1, 0), result);
    }

    @Test
    void evenOddCount_singleDigitOddNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(7);
        assertEquals(Arrays.asList(0, 1), result);
    }

    @Test
    void evenOddCount_zero() {
        List<Integer> result = EvenOddCount.evenOddCount(0);
        assertEquals(Arrays.asList(1, 0), result);
    }

    @Test
    void evenOddCount_negativeSingleDigitEvenNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-2);
        assertEquals(Arrays.asList(1, 0), result);
    }

    @Test
    void evenOddCount_negativeSingleDigitOddNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-7);
        assertEquals(Arrays.asList(0, 1), result);
    }

    @Test
    void evenOddCount_positiveNumberWithOnlyEvenDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(2468);
        assertEquals(Arrays.asList(4, 0), result);
    }

    @Test
    void evenOddCount_positiveNumberWithOnlyOddDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(13579);
        assertEquals(Arrays.asList(0, 5), result);
    }

    @Test
    void evenOddCount_negativeNumberWithOnlyEvenDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(-2468);
        assertEquals(Arrays.asList(4, 0), result);
    }

    @Test
    void evenOddCount_negativeNumberWithOnlyOddDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(-13579);
        assertEquals(Arrays.asList(0, 5), result);
    }

    @Test
    void evenOddCount_positiveNumberWithMixedEvenAndOddDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(346211);
        assertEquals(Arrays.asList(3, 3), result);
    }

    @Test
    void evenOddCount_negativeNumberWithMixedEvenAndOddDigits() {
        List<Integer> result = EvenOddCount.evenOddCount(-345821);
        assertEquals(Arrays.asList(3, 3), result);
    }

    @Test
    void evenOddCount_negativeNumberWithMixedEvenAndOddDigits2() {
        List<Integer> result = EvenOddCount.evenOddCount(-45347);
        assertEquals(Arrays.asList(2, 3), result);
    }

    @Test
    void evenOddCount_positiveNumberStartingWithZero() {
        List<Integer> result = EvenOddCount.evenOddCount(204);
        assertEquals(Arrays.asList(3, 0), result);
    }

    @Test
    void evenOddCount_negativeNumberStartingWithZero() {
        List<Integer> result = EvenOddCount.evenOddCount(-204);
        assertEquals(Arrays.asList(3, 0), result);
    }

    @Test
    void evenOddCount_numberEndingWithZero() {
        List<Integer> result = EvenOddCount.evenOddCount(120);
        assertEquals(Arrays.asList(2, 1), result);
    }

    @Test
    void evenOddCount_negativeNumberEndingWithZero() {
        List<Integer> result = EvenOddCount.evenOddCount(-120);
        assertEquals(Arrays.asList(2, 1), result);
    }

    @Test
    void evenOddCount_numberWithMultipleZeros() {
        List<Integer> result = EvenOddCount.evenOddCount(102040);
        assertEquals(Arrays.asList(4, 2), result);
    }

    @Test
    void evenOddCount_negativeNumberWithMultipleZeros() {
        List<Integer> result = EvenOddCount.evenOddCount(-102040);
        assertEquals(Arrays.asList(4, 2), result);
    }
}