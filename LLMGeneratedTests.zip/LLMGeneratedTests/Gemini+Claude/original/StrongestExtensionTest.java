package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class StrongestExtensionTest {

    @Test
    void strongestExtension_example1() {
        List<String> extensions = Arrays.asList("SErviNGSliCes", "Cheese", "StuFfed");
        assertEquals("Slices.SErviNGSliCes", StrongestExtension.strongestExtension("Slices", extensions));
    }

    @Test
    void strongestExtension_example2() {
        List<String> extensions = Arrays.asList("AA", "Be", "CC");
        assertEquals("my_class.AA", StrongestExtension.strongestExtension("my_class", extensions));
    }

    @Test
    void strongestExtension_example3() {
        List<String> extensions = Arrays.asList("tEN", "niNE", "eIGHt8OKe");
        assertEquals("Watashi.eIGHt8OKe", StrongestExtension.strongestExtension("Watashi", extensions));
    }

    @Test
    void strongestExtension_example4() {
        List<String> extensions = Arrays.asList("nani", "NazeDa", "YEs.WeCaNe", "32145tggg");
        assertEquals("Boku123.YEs.WeCaNe", StrongestExtension.strongestExtension("Boku123", extensions));
    }

    @Test
    void strongestExtension_example5() {
        List<String> extensions = Arrays.asList("t", "eMptY", "nothing", "zeR00", "NuLl__", "123NoooneB321");
        assertEquals("__YESIMHERE.NuLl__", StrongestExtension.strongestExtension("__YESIMHERE", extensions));
    }

    @Test
    void strongestExtension_example6() {
        List<String> extensions = Arrays.asList("Ta", "TAR", "t234An", "cosSo");
        assertEquals("K.TAR", StrongestExtension.strongestExtension("K", extensions));
    }

    @Test
    void strongestExtension_example7() {
        List<String> extensions = Arrays.asList("Tab", "123", "781345", "-_-");
        assertEquals("__HAHA.123", StrongestExtension.strongestExtension("__HAHA", extensions));
    }

    @Test
    void strongestExtension_example8() {
        List<String> extensions = Arrays.asList("HhAas", "okIWILL123", "WorkOut", "Fails", "-_-");
        assertEquals("YameRore.okIWILL123", StrongestExtension.strongestExtension("YameRore", extensions));
    }

    @Test
    void strongestExtension_example9() {
        List<String> extensions = Arrays.asList("Die", "NowW", "Wow", "WoW");
        assertEquals("finNNalLLly.WoW", StrongestExtension.strongestExtension("finNNalLLly", extensions));
    }

    @Test
    void strongestExtension_example10() {
        List<String> extensions = Arrays.asList("Bb", "91245");
        assertEquals("_.Bb", StrongestExtension.strongestExtension("_", extensions));
    }

    @Test
    void strongestExtension_example11() {
        List<String> extensions = Arrays.asList("671235", "Bb");
        assertEquals("Sp.671235", StrongestExtension.strongestExtension("Sp", extensions));
    }

    @Test
    void strongestExtension_emptyList() {
        List<String> extensions = new ArrayList<>();
        assertEquals("", StrongestExtension.strongestExtension("Empty", extensions));
    }

    @Test
    void strongestExtension_sameStrengthFirstWins() {
        List<String> extensions = Arrays.asList("AA", "BB", "CC");
        assertEquals("Same.AA", StrongestExtension.strongestExtension("Same", extensions));
    }

    @Test
    void strongestExtension_allLowerCase() {
        List<String> extensions = Arrays.asList("abc", "def", "ghi");
        assertEquals("Lower.abc", StrongestExtension.strongestExtension("Lower", extensions));
    }

    @Test
    void strongestExtension_allUpperCase() {
        List<String> extensions = Arrays.asList("ABC", "DEF", "GHI");
        assertEquals("Upper.ABC", StrongestExtension.strongestExtension("Upper", extensions));
    }

    @Test
    void strongestExtension_mixedCase() {
        List<String> extensions = Arrays.asList("AbC", "DeF", "GhI");
        assertEquals("Mixed.AbC", StrongestExtension.strongestExtension("Mixed", extensions));
    }

    @Test
    void strongestExtension_numbersAndSymbols() {
        List<String> extensions = Arrays.asList("123", "!@#", "$%^");
        assertEquals("Symbols.123", StrongestExtension.strongestExtension("Symbols", extensions));
    }

    @Test
    void strongestExtension_emptyStringExtension() {
        List<String> extensions = Arrays.asList("", "abc");
        assertEquals("EmptyExt..", StrongestExtension.strongestExtension("EmptyExt", extensions));
    }

    @Test
    void strongestExtension_extensionWithOnlyNumbers() {
        List<String> extensions = Arrays.asList("12345", "67890");
        assertEquals("Numbers.12345", StrongestExtension.strongestExtension("Numbers", extensions));
    }

    @Test
    void strongestExtension_extensionWithOnlySymbols() {
        List<String> extensions = Arrays.asList("!@#$%", "^&*()");
        assertEquals("SymbolsOnly.!@#$%", StrongestExtension.strongestExtension("SymbolsOnly", extensions));
    }

    @Test
    void strongestExtension_classNameEmpty() {
        List<String> extensions = Arrays.asList("abc", "def");
        assertEquals(".abc", StrongestExtension.strongestExtension("", extensions));
    }

    @Test
    void strongestExtension_nullClassName() {
        List<String> extensions = Arrays.asList("abc", "def");
        assertThrows(NullPointerException.class, () -> StrongestExtension.strongestExtension(null, extensions));
    }

    @Test
    void strongestExtension_nullExtensionList() {
        assertThrows(NullPointerException.class, () -> StrongestExtension.strongestExtension("Test", null));
    }

    @Test
    void strongestExtension_mixedStrength() {
        List<String> extensions = Arrays.asList("aBc", "ABc", "AbC");
        assertEquals("MixedStrength.ABc", StrongestExtension.strongestExtension("MixedStrength", extensions));
    }

    @Test
    void strongestExtension_longExtensionNames() {
        List<String> extensions = Arrays.asList("ThisIsALongExtensionName", "AnotherLongExtensionName");
        assertEquals("LongNames.ThisIsALongExtensionName", StrongestExtension.strongestExtension("LongNames", extensions));
    }

    @Test
    void strongestExtension_boundaryValues() {
        List<String> extensions = Arrays.asList("A", "b", "C", "d");
        assertEquals("Boundary.A", StrongestExtension.strongestExtension("Boundary", extensions));
    }

    @Test
    void strongestExtension_negativeValues() {
        List<String> extensions = Arrays.asList("abc", "defg", "hij");
        assertEquals("Negative.abc", StrongestExtension.strongestExtension("Negative", extensions));
    }
}