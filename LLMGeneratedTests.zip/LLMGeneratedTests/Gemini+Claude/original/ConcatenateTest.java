package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ConcatenateTest {

    @Test
    void concatenate_emptyList_returnsEmptyString() {
        List<Object> emptyList = Collections.emptyList();
        assertEquals("", Concatenate.concatenate(emptyList));
    }

    @Test
    void concatenate_singleStringList_returnsString() {
        List<Object> singleStringList = Collections.singletonList("hello");
        assertEquals("hello", Concatenate.concatenate(singleStringList));
    }

    @Test
    void concatenate_multipleStringsList_returnsConcatenatedString() {
        List<Object> multipleStringsList = Arrays.asList("a", "b", "c");
        assertEquals("abc", Concatenate.concatenate(multipleStringsList));
    }

    @Test
    void concatenate_listWithNull_returnsStringWithNullString() {
        List<Object> listWithNull = Arrays.asList("a", null, "c");
        assertEquals("anullc", Concatenate.concatenate(listWithNull));
    }

    @Test
    void concatenate_listWithEmptyString_returnsString() {
        List<Object> listWithEmptyString = Arrays.asList("a", "", "c");
        assertEquals("ac", Concatenate.concatenate(listWithEmptyString));
    }

    @Test
    void concatenate_listWithNumbers_returnsStringWithNumbers() {
        List<Object> listWithNumbers = Arrays.asList("a", 1, "c");
        assertEquals("a1c", Concatenate.concatenate(listWithNumbers));
    }

    @Test
    void concatenate_listWithSpecialCharacters_returnsStringWithSpecialCharacters() {
        List<Object> listWithSpecialCharacters = Arrays.asList("a", "!", "c");
        assertEquals("a!c", Concatenate.concatenate(listWithSpecialCharacters));
    }

    @Test
    void concatenate_listWithMixedTypes_returnsStringWithMixedTypes() {
        List<Object> listWithMixedTypes = Arrays.asList("a", 1, true, "c");
        assertEquals("a1truec", Concatenate.concatenate(listWithMixedTypes));
    }

    @Test
    void concatenate_longList_returnsConcatenatedString() {
        List<Object> longList = Arrays.asList("a", "b", "c", "d", "e", "f", "g");
        assertEquals("abcdefg", Concatenate.concatenate(longList));
    }

    @Test
    void concatenate_listWithLeadingAndTrailingSpaces_returnsStringWithSpaces() {
        List<Object> listWithSpaces = Arrays.asList(" a", "b ", " c");
        assertEquals(" ab  c", Concatenate.concatenate(listWithSpaces));
    }

    @Test
    void concatenate_listWithOnlySpaces_returnsStringWithSpaces() {
        List<Object> listWithOnlySpaces = Arrays.asList(" ", "  ", "   ");
        assertEquals("    ", Concatenate.concatenate(listWithOnlySpaces));
    }

    @Test
    void concatenate_listWithUnicodeCharacters_returnsStringWithUnicodeCharacters() {
        List<Object> listWithUnicode = Arrays.asList("你好", "世界");
        assertEquals("你好世界", Concatenate.concatenate(listWithUnicode));
    }

    @Test
    void concatenate_listWithEmptyStringsOnly_returnsEmptyString() {
        List<Object> listWithEmptyStringsOnly = Arrays.asList("", "", "");
        assertEquals("", Concatenate.concatenate(listWithEmptyStringsOnly));
    }

    @Test
    void concatenate_listWithBooleanValues_returnsConcatenatedString() {
        List<Object> listWithBooleanValues = Arrays.asList(true, false, true);
        assertEquals("truefalsetrue", Concatenate.concatenate(listWithBooleanValues));
    }

    @Test
    void concatenate_listWithIntegerValues_returnsConcatenatedString() {
        List<Object> listWithIntegerValues = Arrays.asList(1, 2, 3);
        assertEquals("123", Concatenate.concatenate(listWithIntegerValues));
    }

    @Test
    void concatenate_listWithDoubleValues_returnsConcatenatedString() {
        List<Object> listWithDoubleValues = Arrays.asList(1.1, 2.2, 3.3);
        assertEquals("1.12.23.3", Concatenate.concatenate(listWithDoubleValues));
    }

    @Test
    void concatenate_listWithMixedNumericTypes_returnsConcatenatedString() {
        List<Object> listWithMixedNumericTypes = Arrays.asList(1, 2.2, 3L);
        assertEquals("12.23", Concatenate.concatenate(listWithMixedNumericTypes));
    }

    @Test
    void concatenate_listWithObjectToStringOverride_returnsConcatenatedString() {
        List<Object> listWithObjectToStringOverride = new ArrayList<>();
        listWithObjectToStringOverride.add(new Object() {
            @Override
            public String toString() {
                return "CustomObject";
            }
        });
        listWithObjectToStringOverride.add("b");
        assertEquals("CustomObjectb", Concatenate.concatenate(listWithObjectToStringOverride));
    }

    @Test
    void concatenate_listWithMultipleNulls_returnsStringWithMultipleNullStrings() {
        List<Object> listWithMultipleNulls = Arrays.asList(null, null, null);
        assertEquals("nullnullnull", Concatenate.concatenate(listWithMultipleNulls));
    }

    @Test
    void concatenate_listWithLargeString_returnsConcatenatedString() {
        String largeString = "ThisIsAVeryLongString";
        List<Object> listWithLargeString = Arrays.asList("a", largeString, "b");
        assertEquals("aThisIsAVeryLongStringb", Concatenate.concatenate(listWithLargeString));
    }

    @Test
    void concatenate_listWithNegativeNumbers_returnsConcatenatedString() {
        List<Object> listWithNegativeNumbers = Arrays.asList(-1, -2, -3);
        assertEquals("-1-2-3", Concatenate.concatenate(listWithNegativeNumbers));
    }

    @Test
    void concatenate_listWithBoundaryValues_returnsConcatenatedString() {
        List<Object> listWithBoundaryValues = Arrays.asList(-100, 0, 100);
        assertEquals("-1000100", Concatenate.concatenate(listWithBoundaryValues));
    }
}