package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MonotonicTest {

    @Test
    void monotonic_singleElementList_returnsTrue() {
        List<Integer> list = Arrays.asList(5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_increasingList_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_decreasingList_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 4, 3, 2, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_constantList_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5, 5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_increasingThenDecreasing_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 2, 1);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_decreasingThenIncreasing_returnsFalse() {
        List<Integer> list = Arrays.asList(5, 4, 3, 4, 5);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_emptyList_returnsTrue() {
        List<Integer> list = new ArrayList<>();
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_increasingWithEqualElements_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3, 4);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_decreasingWithEqualElements_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 4, 4, 3, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_firstTwoElementsEqual_increasing_returnsTrue() {
        List<Integer> list = Arrays.asList(2, 2, 3, 4, 5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_firstTwoElementsEqual_decreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 5, 4, 3, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_firstTwoElementsEqual_notMonotonic_returnsFalse() {
        List<Integer> list = Arrays.asList(2, 2, 3, 1, 2);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_negativeNumbers_increasing_returnsTrue() {
        List<Integer> list = Arrays.asList(-5, -4, -3, -2, -1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_negativeNumbers_decreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_mixedPositiveNegative_increasing_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, 0, 1, 2, 3);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_mixedPositiveNegative_decreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(3, 2, 1, 0, -1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_mixedPositiveNegative_notMonotonic_returnsFalse() {
        List<Integer> list = Arrays.asList(-1, 0, 1, -2, 3);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_twoElements_increasing_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_twoElements_decreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(2, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_twoElements_equal_returnsTrue() {
        List<Integer> list = Arrays.asList(2, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_longList_alternating_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 5, 2, 6, 3, 7, 4, 8);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_boundaryValues_returnsTrue() {
        List<Integer> list = Arrays.asList(-100, 0, 100);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_boundaryValues_decreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(100, 0, -100);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_boundaryValues_notMonotonic_returnsFalse() {
        List<Integer> list = Arrays.asList(100, -100, 0);
        assertFalse(Monotonic.monotonic(list));
    }
}