package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SolveTest {

    @Test
    void solve_emptyString() {
        assertEquals("", Solve.solve(""));
    }

    @Test
    void solve_onlyNumbers() {
        assertEquals("4321", Solve.solve("1234"));
    }

    @Test
    void solve_onlyLowercaseLetters() {
        assertEquals("AB", Solve.solve("ab"));
    }

    @Test
    void solve_onlyUppercaseLetters() {
        assertEquals("ab", Solve.solve("AB"));
    }

    @Test
    void solve_mixedCaseLetters() {
        assertEquals("aSdF", Solve.solve("AsDf"));
    }

    @Test
    void solve_specialCharactersAndLetters() {
        assertEquals("#A@c", Solve.solve("#a@C"));
    }

    @Test
    void solve_specialCharactersNumbersAndLetters() {
        assertEquals("#aSDFw^45", Solve.solve("#AsdfW^45"));
    }

    @Test
    void solve_specialCharactersAndNumbers() {
        assertEquals("2@6#", Solve.solve("#6@2"));
    }

    @Test
    void solve_specialCharactersLettersMixedCase() {
        assertEquals("#$A^d", Solve.solve("#$a^D"));
    }

    @Test
    void solve_specialCharactersLowercaseLetters() {
        assertEquals("#CCC", Solve.solve("#ccc"));
    }

    @Test
    void solve_singleLowercaseLetter() {
        assertEquals("A", Solve.solve("a"));
    }

    @Test
    void solve_singleUppercaseLetter() {
        assertEquals("a", Solve.solve("A"));
    }

    @Test
    void solve_singleNumber() {
        assertEquals("1", Solve.solve("1"));
    }

    @Test
    void solve_singleSpecialCharacter() {
        assertEquals("#", Solve.solve("#"));
    }

    @Test
    void solve_stringWithSpaces() {
        assertEquals(" ", Solve.solve(" "));
    }

    @Test
    void solve_stringWithLeadingAndTrailingSpaces() {
        assertEquals("   ", Solve.solve("   "));
    }

    @Test
    void solve_mixedCaseWithNumbersAndSymbols() {
        assertEquals("1a2B3c", Solve.solve("1A2b3C"));
    }

    @Test
    void solve_stringWithOnlySpecialCharacters() {
        assertEquals("!@#$", Solve.solve("$#@!"));
    }

    @Test
    void solve_stringWithMixedSpecialCharactersAndNumbers() {
        assertEquals("9@8#7$6%", Solve.solve("%$#@9876"));
    }

    @Test
    void solve_stringWithNoLetters() {
        assertEquals("!@#$", Solve.solve("$#@!"));
    }

    @Test
    void solve_stringWithOnlyUppercaseLetters() {
        assertEquals("abc", Solve.solve("ABC"));
    }

    @Test
    void solve_stringWithOnlyLowercaseLetters() {
        assertEquals("ABC", Solve.solve("abc"));
    }

    @Test
    void solve_stringWithMixedLettersAndNumbers() {
        assertEquals("1A2b3C", Solve.solve("1a2B3c"));
    }

    @Test
    void solve_stringWithBoundaryValues() {
        assertEquals("!@#$%^&*()", Solve.solve(")(*&^%$#@!"));
    }
}