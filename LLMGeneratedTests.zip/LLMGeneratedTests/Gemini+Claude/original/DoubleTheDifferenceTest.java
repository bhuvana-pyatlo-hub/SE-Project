package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DoubleTheDifferenceTest {

    @Test
    void testEmptyList() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Collections.emptyList()));
    }

    @Test
    void testNullList() {
        List<Object> list = null;
        try {
            DoubleTheDifference.doubleTheDifference(list);
        } catch (NullPointerException e) {
            // Expected exception
        }
    }

    @Test
    void testSingleOddPositiveNumber() {
        assertEquals(25, DoubleTheDifference.doubleTheDifference(Arrays.asList(5)));
    }

    @Test
    void testSingleEvenNumber() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(4)));
    }

    @Test
    void testSingleNegativeNumber() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(-5)));
    }

    @Test
    void testSingleZero() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(0)));
    }

    @Test
    void testMixedOddAndEvenNumbers() {
        assertEquals(10, DoubleTheDifference.doubleTheDifference(Arrays.asList(1, 3, 2, 0)));
    }

    @Test
    void testOnlyNegativeNumbers() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(-1, -2, -3)));
    }

    @Test
    void testOddNegativeAndPositiveNumbers() {
        assertEquals(82, DoubleTheDifference.doubleTheDifference(Arrays.asList(-1, 9, 1)));
    }

    @Test
    void testMixedTypes() {
        List<Object> list = new ArrayList<>();
        list.add(1);
        list.add(2.5);
        list.add(3);
        list.add("hello");
        list.add(5);
        assertEquals(1 + 9 + 25, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testOnlyNonIntegerObjects() {
        List<Object> list = Arrays.asList("a", "b", "c");
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testZeroAndPositiveOdd() {
        assertEquals(25, DoubleTheDifference.doubleTheDifference(Arrays.asList(0, 5)));
    }

    @Test
    void testNegativeAndZero() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(-1, 0)));
    }

    @Test
    void testLargeListWithMixedValues() {
        List<Object> list = new ArrayList<>();
        for (int i = -5; i <= 5; i++) {
            list.add(i);
        }
        assertEquals(1 + 9 + 25, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithNullObject() {
        List<Object> list = new ArrayList<>();
        list.add(1);
        list.add(null);
        list.add(3);
        assertEquals(1 + 9, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithZeroAndOne() {
        assertEquals(1, DoubleTheDifference.doubleTheDifference(Arrays.asList(0, 1)));
    }

    @Test
    void testListWithOnlyOneNegativeOddNumber() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(-1)));
    }

    @Test
    void testListWithOnePositiveOddNumber() {
        assertEquals(1, DoubleTheDifference.doubleTheDifference(Arrays.asList(1)));
    }

    @Test
    void testListWithNegativeOddNumber() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(-3)));
    }

    @Test
    void testListWithPositiveEvenNumber() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(2)));
    }

    @Test
    void testListWithPositiveOddAndEvenNumbers() {
        assertEquals(25, DoubleTheDifference.doubleTheDifference(Arrays.asList(1, 2, 3, 4, 5)));
    }

    @Test
    void testListWithMixedNegativeOddAndPositiveEvenNumbers() {
        assertEquals(0, DoubleTheDifference.doubleTheDifference(Arrays.asList(-1, 2, -3, 4)));
    }
}