package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringToMd5Test {

    @Test
    void stringToMd5_emptyString_returnsNull() {
        assertNull(StringToMd5.stringToMd5(""));
    }

    @Test
    void stringToMd5_helloWorld_returnsCorrectMd5() {
        assertEquals("3e25960a79dbc69b674cd4ec67a72c62", StringToMd5.stringToMd5("Hello world"));
    }

    @Test
    void stringToMd5_abc_returnsCorrectMd5() {
        assertEquals("900150983cd24fb0d6963f7d28e17f72", StringToMd5.stringToMd5("abc"));
    }

    @Test
    void stringToMd5_password_returnsCorrectMd5() {
        assertEquals("5f4dcc3b5aa765d61d8327deb882cf99", StringToMd5.stringToMd5("password"));
    }

    @Test
    void stringToMd5_singleCharacter_returnsCorrectMd5() {
        assertEquals("c4ca4238a0b923820dcc509a6f75849b", StringToMd5.stringToMd5("a"));
    }

    @Test
    void stringToMd5_numberString_returnsCorrectMd5() {
        assertEquals("b10a8db164e0754105b7a99be72e3fe5", StringToMd5.stringToMd5("12345"));
    }

    @Test
    void stringToMd5_specialCharacters_returnsCorrectMd5() {
        assertEquals("e4d909c290d0fb1ca068ffaddf22cbd0", StringToMd5.stringToMd5("!@#$%^"));
    }

    @Test
    void stringToMd5_mixedCase_returnsCorrectMd5() {
        assertEquals("b1946ac92492d2347c6235b4d2611184", StringToMd5.stringToMd5("HeLlO"));
    }

    @Test
    void stringToMd5_stringWithSpaces_returnsCorrectMd5() {
        assertEquals("0ef78513b0cb8cef12743f5aeb35f888", StringToMd5.stringToMd5("A B C"));
    }

    @Test
    void stringToMd5_stringWithLeadingAndTrailingSpaces_returnsCorrectMd5() {
        assertEquals("a14d3037a3418980676380824490941a", StringToMd5.stringToMd5("  test  "));
    }

    @Test
    void stringToMd5_stringWithUnicodeCharacters_returnsCorrectMd5() {
        assertEquals("b695927627296966668469472636b968", StringToMd5.stringToMd5("你好世界"));
    }

    @Test
    void stringToMd5_stringWithNumbersAndLetters_returnsCorrectMd5() {
        assertEquals("92172610509837d059a724a2f0865462", StringToMd5.stringToMd5("test1234"));
    }

    @Test
    void stringToMd5_stringWithOnlyNumbers_returnsCorrectMd5() {
        assertEquals("827ccb0eea8a706c34c719474f84b77c", StringToMd5.stringToMd5("1234"));
    }

    @Test
    void stringToMd5_stringWithOnlyLetters_returnsCorrectMd5() {
        assertEquals("0cbc6611f5540bd0809a388dc95a615b", StringToMd5.stringToMd5("test"));
    }

    @Test
    void stringToMd5_stringWithMixedCaseAndNumbers_returnsCorrectMd5() {
        assertEquals("712988f954910433780c75444822f659", StringToMd5.stringToMd5("TeSt1234"));
    }

    @Test
    void stringToMd5_stringWithRepeatingCharacters_returnsCorrectMd5() {
        assertEquals("1a79a4d60de6718e8e5b326e338ae539", StringToMd5.stringToMd5("aaaa"));
    }

    @Test
    void stringToMd5_stringWithControlCharacters_returnsCorrectMd5() {
        assertEquals("734905d6c19a553a44209a6631a3344b", StringToMd5.stringToMd5("\n\t\r"));
    }

    @Test
    void stringToMd5_stringWithNullCharacter_returnsCorrectMd5() {
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", StringToMd5.stringToMd5("\0"));
    }

    @Test
    void stringToMd5_longString_returnsCorrectMd5() {
        String longString = "This is a very long string to test the MD5 hashing function.";
        assertEquals("59296769475554218474841405440266", StringToMd5.stringToMd5(longString));
    }
}