package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ProdSignsTest {

    @Test
    void prodSigns_emptyArray_returnsNull() {
        List<Object> arr = Collections.emptyList();
        assertNull(ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_positiveNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, 3);
        assertEquals(6, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_negativeNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(-1, -2, -3);
        assertEquals(-6, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_mixedNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, -2, 3);
        assertEquals(-6, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_zeroInArray_returnsZero() {
        List<Object> arr = Arrays.asList(1, 0, 3);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_onlyZeroes_returnsZero() {
        List<Object> arr = Arrays.asList(0, 0, 0);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_singlePositiveNumber_returnsCorrectSum() {
        List<Object> arr = Collections.singletonList(5);
        assertEquals(5, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_singleNegativeNumber_returnsCorrectSum() {
        List<Object> arr = Collections.singletonList(-5);
        assertEquals(-5, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_singleZero_returnsZero() {
        List<Object> arr = Collections.singletonList(0);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_multiplePositiveNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_multipleNegativeNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(-15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_mixedPositiveAndNegativeNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, -2, 3, -4, 5);
        assertEquals(3, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_mixedNumbersWithZero_returnsZero() {
        List<Object> arr = Arrays.asList(1, -2, 0, -4, 5);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example1() {
        List<Object> arr = Arrays.asList(1, 2, 2, -4);
        assertEquals(-9, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example2() {
        List<Object> arr = Arrays.asList(0, 1);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example3() {
        List<Object> arr = Arrays.asList(1, 1, 1, 2, 3, -1, 1);
        assertEquals(-10, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example4() {
        List<Object> arr = Arrays.asList(2, 4, 1, 2, -1, -1, 9);
        assertEquals(20, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example5() {
        List<Object> arr = Arrays.asList(-1, 1, -1, 1);
        assertEquals(4, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example6() {
        List<Object> arr = Arrays.asList(-1, 1, 1, 1);
        assertEquals(-4, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_example7() {
        List<Object> arr = Arrays.asList(-1, 1, 1, 0);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_nonIntegerValues_areIgnored() {
        List<Object> arr = new ArrayList<>();
        arr.add(1);
        arr.add("string");
        arr.add(2);
        arr.add(3.14);
        arr.add(-1);
        assertEquals(-4, ProdSigns.prodSigns(arr));
    }
}