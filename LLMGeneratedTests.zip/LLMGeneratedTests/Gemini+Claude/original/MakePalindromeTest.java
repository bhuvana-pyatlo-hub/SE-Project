package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MakePalindromeTest {

    @Test
    void makePalindrome_emptyString() {
        assertEquals("", MakePalindrome.makePalindrome(""));
    }

    @Test
    void makePalindrome_singleCharacter() {
        assertEquals("x", MakePalindrome.makePalindrome("x"));
    }

    @Test
    void makePalindrome_simplePalindrome() {
        assertEquals("xyx", MakePalindrome.makePalindrome("xyx"));
    }

    @Test
    void makePalindrome_cat() {
        assertEquals("catac", MakePalindrome.makePalindrome("cat"));
    }

    @Test
    void makePalindrome_cata() {
        assertEquals("catac", MakePalindrome.makePalindrome("cata"));
    }

    @Test
    void makePalindrome_xyz() {
        assertEquals("xyzyx", MakePalindrome.makePalindrome("xyz"));
    }

    @Test
    void makePalindrome_jerry() {
        assertEquals("jerryrrej", MakePalindrome.makePalindrome("jerry"));
    }

    @Test
    void makePalindrome_level() {
        assertEquals("level", MakePalindrome.makePalindrome("level"));
    }

    @Test
    void makePalindrome_rotor() {
        assertEquals("rotor", MakePalindrome.makePalindrome("rotor"));
    }

    @Test
    void makePalindrome_madam() {
        assertEquals("madam", MakePalindrome.makePalindrome("madam"));
    }

    @Test
    void makePalindrome_racecar() {
        assertEquals("racecar", MakePalindrome.makePalindrome("racecar"));
    }

    @Test
    void makePalindrome_noon() {
        assertEquals("noon", MakePalindrome.makePalindrome("noon"));
    }

    @Test
    void makePalindrome_deified() {
        assertEquals("deified", MakePalindrome.makePalindrome("deified"));
    }

    @Test
    void makePalindrome_refer() {
        assertEquals("refer", MakePalindrome.makePalindrome("refer"));
    }

    @Test
    void makePalindrome_test1() {
        assertEquals("abaaba", MakePalindrome.makePalindrome("aba"));
    }

    @Test
    void makePalindrome_test2() {
        assertEquals("ababa", MakePalindrome.makePalindrome("ab"));
    }

    @Test
    void makePalindrome_test3() {
        assertEquals("abcba", MakePalindrome.makePalindrome("abc"));
    }

    @Test
    void makePalindrome_test4() {
        assertEquals("abcdedcba", MakePalindrome.makePalindrome("abcdedc"));
    }

    @Test
    void makePalindrome_test5() {
        assertEquals("abcdaabcba", MakePalindrome.makePalindrome("abcdaabc"));
    }

    @Test
    void makePalindrome_longString() {
        assertEquals("abcdefgfedcba", MakePalindrome.makePalindrome("abcdefgfedcb"));
    }

    @Test
    void makePalindrome_invalidInput() {
        assertNull(MakePalindrome.makePalindrome(null));
    }

    @Test
    void makePalindrome_boundaryNegative() {
        assertEquals("a", MakePalindrome.makePalindrome("a"));
    }

    @Test
    void makePalindrome_boundaryNegativeTwoChars() {
        assertEquals("aa", MakePalindrome.makePalindrome("aa"));
    }

    @Test
    void makePalindrome_boundaryPositive() {
        assertEquals("aba", MakePalindrome.makePalindrome("ab"));
    }

    @Test
    void makePalindrome_boundaryPositiveMax() {
        assertEquals("a", MakePalindrome.makePalindrome("a"));
    }
}