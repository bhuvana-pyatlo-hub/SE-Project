package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FileNameCheckTest {

    @Test
    void fileNameCheck_validTxtFile() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("example.txt"));
    }

    @Test
    void fileNameCheck_invalidStartWithNumber() {
        assertEquals("No", FileNameCheck.fileNameCheck("1example.dll"));
    }

    @Test
    void fileNameCheck_invalidExtension() {
        assertEquals("No", FileNameCheck.fileNameCheck("s1sdf3.asd"));
    }

    @Test
    void fileNameCheck_validSingleLetterName() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("K.dll"));
    }

    @Test
    void fileNameCheck_validMultipleDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("MY16FILE3.exe"));
    }

    @Test
    void fileNameCheck_invalidTooManyDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("His12FILE94.exe"));
    }

    @Test
    void fileNameCheck_invalidStartWithUnderscore() {
        assertEquals("No", FileNameCheck.fileNameCheck("_Y.txt"));
    }

    @Test
    void fileNameCheck_invalidStartWithSpecialChar() {
        assertEquals("No", FileNameCheck.fileNameCheck("?aREYA.exe"));
    }

    @Test
    void fileNameCheck_invalidStartWithSlash() {
        assertEquals("No", FileNameCheck.fileNameCheck("/this_is_valid.dll"));
    }

    @Test
    void fileNameCheck_invalidExtensionWow() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_valid.wow"));
    }

    @Test
    void fileNameCheck_validTxt() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("this_is_valid.txt"));
    }

    @Test
    void fileNameCheck_invalidExtensionTxtexe() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_valid.txtexe"));
    }

    @Test
    void fileNameCheck_invalidSpecialCharsAndExtension() {
        assertEquals("No", FileNameCheck.fileNameCheck("#this2_i4s_5valid.ten"));
    }

    @Test
    void fileNameCheck_invalidSpecialCharsAndExe() {
        assertEquals("No", FileNameCheck.fileNameCheck("@this1_is6_valid.exe"));
    }

    @Test
    void fileNameCheck_invalidMultipleDots() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_12valid.6exe4.txt"));
    }

    @Test
    void fileNameCheck_invalidMultipleDots2() {
        assertEquals("No", FileNameCheck.fileNameCheck("all.exe.txt"));
    }

    @Test
    void fileNameCheck_validDigitsAndUnderscore() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("I563_No.exe"));
    }

    @Test
    void fileNameCheck_validDigitsInName() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("Is3youfault.txt"));
    }

    @Test
    void fileNameCheck_validSpecialCharsInName() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("no_one#knows.dll"));
    }

    @Test
    void fileNameCheck_invalidStartWithNumberAndTooManyDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("1I563_Yes3.exe"));
    }

    @Test
    void fileNameCheck_invalidExtensionTxtt() {
        assertEquals("No", FileNameCheck.fileNameCheck("I563_Yes3.txtt"));
    }

    @Test
    void fileNameCheck_invalidDoubleDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("final..txt"));
    }

    @Test
    void fileNameCheck_invalidNoExtension() {
        assertEquals("No", FileNameCheck.fileNameCheck("final132"));
    }

    @Test
    void fileNameCheck_invalidNoNameBeforeDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("_f4indsartal132."));
    }

    @Test
    void fileNameCheck_invalidEmptyName() {
        assertEquals("No", FileNameCheck.fileNameCheck(".txt"));
    }

    @Test
    void fileNameCheck_invalidEmptyName2() {
        assertEquals("No", FileNameCheck.fileNameCheck("s."));
    }

    @Test
    void fileNameCheck_validExeFile() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("valid.exe"));
    }

    @Test
    void fileNameCheck_validDllFile() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("valid.dll"));
    }

    @Test
    void fileNameCheck_validThreeDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("abc123def.txt"));
    }

    @Test
    void fileNameCheck_invalidThreeDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("abc1234def.txt"));
    }

    @Test
    void fileNameCheck_invalidOnlyDigitsBeforeDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("123.txt"));
    }

    @Test
    void fileNameCheck_invalidOnlySpecialCharsBeforeDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("!@#.dll"));
    }

    @Test
    void fileNameCheck_validBoundaryCase() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("abc1.txt"));
    }

    @Test
    void fileNameCheck_invalidBoundaryCase() {
        assertEquals("No", FileNameCheck.fileNameCheck("abc1234.txt"));
    }

    @Test
    void fileNameCheck_emptyFileName() {
        assertEquals("No", FileNameCheck.fileNameCheck("a.abc"));
    }
}