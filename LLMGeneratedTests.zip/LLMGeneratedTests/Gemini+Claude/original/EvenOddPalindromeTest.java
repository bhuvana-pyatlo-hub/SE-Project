package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EvenOddPalindromeTest {

    @Test
    void evenOddPalindrome_nIs1_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(0, 1);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(1));
    }

    @Test
    void evenOddPalindrome_nIs2_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(1, 1);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(2));
    }

    @Test
    void evenOddPalindrome_nIs3_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(3));
    }

    @Test
    void evenOddPalindrome_nIs4_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(2, 2);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(4));
    }

    @Test
    void evenOddPalindrome_nIs5_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(2, 3);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(5));
    }

    @Test
    void evenOddPalindrome_nIs9_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(4, 5);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(9));
    }

    @Test
    void evenOddPalindrome_nIs10_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(4, 6);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(10));
    }

    @Test
    void evenOddPalindrome_nIs12_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(4, 6);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(12));
    }

    @Test
    void evenOddPalindrome_nIs19_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(4, 6);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(19));
    }

    @Test
    void evenOddPalindrome_nIs25_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(5, 6);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(25));
    }

    @Test
    void evenOddPalindrome_nIs63_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(6, 8);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(63));
    }

    @Test
    void evenOddPalindrome_nIs100_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(8, 11);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(100));
    }

    @Test
    void evenOddPalindrome_nIs123_returnsCorrectCounts() {
        List<Integer> expected = Arrays.asList(8, 13);
        assertEquals(expected, EvenOddPalindrome.evenOddPalindrome(123));
    }

    @Test
    void isPalindrome_singleDigit_returnsTrue() {
        assertTrue(EvenOddPalindrome.isPalindrome(5));
    }

    @Test
    void isPalindrome_twoDigitPalindrome_returnsTrue() {
        assertTrue(EvenOddPalindrome.isPalindrome(11));
    }

    @Test
    void isPalindrome_twoDigitNotPalindrome_returnsFalse() {
        assertFalse(EvenOddPalindrome.isPalindrome(12));
    }

    @Test
    void isPalindrome_threeDigitPalindrome_returnsTrue() {
        assertTrue(EvenOddPalindrome.isPalindrome(121));
    }

    @Test
    void isPalindrome_threeDigitNotPalindrome_returnsFalse() {
        assertFalse(EvenOddPalindrome.isPalindrome(123));
    }

    @Test
    void isPalindrome_fourDigitPalindrome_returnsTrue() {
        assertTrue(EvenOddPalindrome.isPalindrome(1221));
    }

    @Test
    void isPalindrome_fourDigitNotPalindrome_returnsFalse() {
        assertFalse(EvenOddPalindrome.isPalindrome(1234));
    }
}