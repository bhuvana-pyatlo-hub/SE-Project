package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortThirdTest {

    @Test
    void sortThird_emptyList() {
        List<Integer> input = new ArrayList<>();
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_singleElementNotDivisibleByThree() {
        List<Integer> input = Arrays.asList(1);
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_singleElementDivisibleByThree() {
        List<Integer> input = Arrays.asList(3);
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_twoElements() {
        List<Integer> input = Arrays.asList(1, 2);
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_threeElementsUnsorted() {
        List<Integer> input = Arrays.asList(3, 2, 1);
        List<Integer> expected = Arrays.asList(3, 2, 1);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_threeElementsSorted() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleOfThreeElementsUnsorted() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4, 8, 9);
        List<Integer> expected = Arrays.asList(3, 6, 3, 4, 8, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleOfThreeElementsSorted() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5, 6);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5, 6);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_sevenElements() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4, 8, 9, 2);
        List<Integer> expected = Arrays.asList(2, 6, 3, 4, 8, 9, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_tenElements() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1);
        List<Integer> expected = Arrays.asList(1, 3, -5, 2, -3, 3, 5, 0, 123, 9);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_tenElementsWithNegative() {
        List<Integer> input = Arrays.asList(5, 8, -12, 4, 23, 2, 3, 11, 12, -10);
        List<Integer> expected = Arrays.asList(-12, 8, -12, 3, 23, 2, 4, 11, 5, -10);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_duplicateValuesAtDivisibleByThreeIndices() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4, 8, 9, 2);
        List<Integer> expected = Arrays.asList(2, 6, 3, 4, 8, 9, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_allIndicesDivisibleByThree() {
        List<Integer> input = Arrays.asList(9, 6, 3);
        List<Integer> expected = Arrays.asList(3, 6, 9);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_longerListWithMixedValues() {
        List<Integer> input = Arrays.asList(5, 6, 9, 4, 8, 3, 2, 1, 0, -5, 10, 15);
        List<Integer> expected = Arrays.asList(0, 6, 9, 2, 8, 3, 4, 1, 5, -5, 10, 15);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_negativeAndPositiveNumbers() {
        List<Integer> input = Arrays.asList(-3, 1, 6, -9, 2, 3, 0, 4, 8);
        List<Integer> expected = Arrays.asList(-9, 1, 6, -3, 2, 3, 0, 4, 8);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_listWithZeroes() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8);
        List<Integer> expected = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_allSameValues() {
        List<Integer> input = Arrays.asList(3, 3, 3, 3, 3, 3, 3, 3, 3);
        List<Integer> expected = Arrays.asList(3, 3, 3, 3, 3, 3, 3, 3, 3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_listWithOnlyIndicesDivisibleByThree() {
        List<Integer> input = Arrays.asList(6, 7, 8, 9, 10, 11, 12, 13, 14);
        List<Integer> expected = Arrays.asList(6, 7, 8, 9, 10, 11, 12, 13, 14);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_listWithNegativeAndPositiveValues() {
        List<Integer> input = Arrays.asList(-1, 2, -3, 4, 5, 6, -7, 8, 9);
        List<Integer> expected = Arrays.asList(-7, 2, -3, -1, 5, 6, 4, 8, 9);
        assertEquals(expected, SortThird.sortThird(input));
    }
}