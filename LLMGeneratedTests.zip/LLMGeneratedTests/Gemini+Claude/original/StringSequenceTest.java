package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringSequenceTest {

    @Test
    void stringSequence_zero() {
        assertEquals("0", StringSequence.stringSequence(0));
    }

    @Test
    void stringSequence_one() {
        assertEquals("0 1", StringSequence.stringSequence(1));
    }

    @Test
    void stringSequence_two() {
        assertEquals("0 1 2", StringSequence.stringSequence(2));
    }

    @Test
    void stringSequence_three() {
        assertEquals("0 1 2 3", StringSequence.stringSequence(3));
    }

    @Test
    void stringSequence_four() {
        assertEquals("0 1 2 3 4", StringSequence.stringSequence(4));
    }

    @Test
    void stringSequence_five() {
        assertEquals("0 1 2 3 4 5", StringSequence.stringSequence(5));
    }

    @Test
    void stringSequence_six() {
        assertEquals("0 1 2 3 4 5 6", StringSequence.stringSequence(6));
    }

    @Test
    void stringSequence_seven() {
        assertEquals("0 1 2 3 4 5 6 7", StringSequence.stringSequence(7));
    }

    @Test
    void stringSequence_eight() {
        assertEquals("0 1 2 3 4 5 6 7 8", StringSequence.stringSequence(8));
    }

    @Test
    void stringSequence_nine() {
        assertEquals("0 1 2 3 4 5 6 7 8 9", StringSequence.stringSequence(9));
    }

    @Test
    void stringSequence_ten() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10", StringSequence.stringSequence(10));
    }

    @Test
    void stringSequence_eleven() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11", StringSequence.stringSequence(11));
    }

    @Test
    void stringSequence_twelve() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12", StringSequence.stringSequence(12));
    }

    @Test
    void stringSequence_thirteen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13", StringSequence.stringSequence(13));
    }

    @Test
    void stringSequence_fourteen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14", StringSequence.stringSequence(14));
    }

    @Test
    void stringSequence_fifteen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15", StringSequence.stringSequence(15));
    }

    @Test
    void stringSequence_sixteen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16", StringSequence.stringSequence(16));
    }

    @Test
    void stringSequence_seventeen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17", StringSequence.stringSequence(17));
    }

    @Test
    void stringSequence_eighteen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18", StringSequence.stringSequence(18));
    }

    @Test
    void stringSequence_nineteen() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19", StringSequence.stringSequence(19));
    }

    @Test
    void stringSequence_twenty() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20", StringSequence.stringSequence(20));
    }
}