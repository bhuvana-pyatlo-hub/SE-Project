package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CheckIfLastCharIsALetterTest {

    @Test
    void checkIfLastCharIsALetter_emptyString_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(""));
    }

    @Test
    void checkIfLastCharIsALetter_singleLetter_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("A"));
    }

    @Test
    void checkIfLastCharIsALetter_singleLetterLowercase_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("a"));
    }

    @Test
    void checkIfLastCharIsALetter_applePie_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pie"));
    }

    @Test
    void checkIfLastCharIsALetter_applePiE_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e"));
    }

    @Test
    void checkIfLastCharIsALetter_applePiESpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e "));
    }

    @Test
    void checkIfLastCharIsALetter_eeeee_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee"));
    }

    @Test
    void checkIfLastCharIsALetter_pumpkinPieSpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie "));
    }

    @Test
    void checkIfLastCharIsALetter_pumpkinPie1_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie 1"));
    }

    @Test
    void checkIfLastCharIsALetter_eeeeeESpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee e "));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsDigit_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("test 1"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsSpecialCharacter_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("test !"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsLetter_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("ab"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsNotLetter_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("a b"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsSpace_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("a "));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsDigit_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("1 a"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsSpecialChar_returnsTrue() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("! a"));
    }

    @Test
    void checkIfLastCharIsALetter_stringWithOnlySpace_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(" "));
    }

    @Test
    void checkIfLastCharIsALetter_stringWithMultipleSpaces_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("   "));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsLetterLongString_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abcdefg"));
    }

    @Test
    void checkIfLastCharIsALetter_lastCharIsLetterSecondLastIsLetterWithSpaces_returnsFalse() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("abc def g"));
    }
}