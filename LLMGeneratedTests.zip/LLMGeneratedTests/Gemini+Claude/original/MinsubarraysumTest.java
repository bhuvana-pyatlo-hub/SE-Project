package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MinsubarraysumTest {

    @Test
    void minSubArraySum_singleElementPositive() {
        List<Object> nums = Arrays.asList(7);
        assertEquals(7, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_singleElementNegative() {
        List<Object> nums = Arrays.asList(-10);
        assertEquals(-10, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_positiveAndNegative() {
        List<Object> nums = Arrays.asList(1, -1);
        assertEquals(-1, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_allPositive() {
        List<Object> nums = Arrays.asList(2, 3, 4, 1, 2, 4);
        assertEquals(1, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_allNegative() {
        List<Object> nums = Arrays.asList(-1, -2, -3);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_mixedPositiveNegative() {
        List<Object> nums = Arrays.asList(-1, -2, -3, 2, -10);
        assertEquals(-14, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_zero() {
        List<Object> nums = Arrays.asList(0);
        assertEquals(0, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_zeroAndPositive() {
        List<Object> nums = Arrays.asList(0, 10, 20);
        assertEquals(0, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_mixedNegativePositiveNegative() {
        List<Object> nums = Arrays.asList(-1, -2, -3, 10, -5);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_positiveNegativeNegativeNegativePositiveNegative() {
        List<Object> nums = Arrays.asList(100, -1, -2, -3, 10, -5);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_positivePositivePositivePositivePositivePositive() {
        List<Object> nums = Arrays.asList(10, 11, 13, 8, 3, 4);
        assertEquals(3, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_positiveNegativePositiveNegativeZeroNegative() {
        List<Object> nums = Arrays.asList(100, -33, 32, -1, 0, -2);
        assertEquals(-33, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_allZeros() {
        List<Object> nums = Arrays.asList(0, 0, 0);
        assertEquals(0, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_negativeZeroNegative() {
        List<Object> nums = Arrays.asList(-1, 0, -1);
        assertEquals(-2, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_positiveNegativePositive() {
        List<Object> nums = Arrays.asList(1, -2, 1);
        assertEquals(-2, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_negativePositiveNegative() {
        List<Object> nums = Arrays.asList(-5, 10, -2);
        assertEquals(-7, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_multipleNegativeValues() {
        List<Object> nums = Arrays.asList(-1, -1, -1, -1);
        assertEquals(-4, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minSubArraySum_largePositiveAndNegative() {
        List<Object> nums = Arrays.asList(100, -100);
        assertEquals(-100, Minsubarraysum.minsubarraysum(nums));
    }
}