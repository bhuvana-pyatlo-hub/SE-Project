package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SpecialfilterTest {

    @Test
    void specialfilter_emptyList_returnsZero() {
        List<Object> nums = Collections.emptyList();
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_singleElementLessThanOrEqualToTen_returnsZero() {
        List<Object> nums = Collections.singletonList(5);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_singleElementGreaterThanTenButNotOddDigits_returnsZero() {
        List<Object> nums = Collections.singletonList(24);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_singleElementGreaterThanTenAndOddDigits_returnsOne() {
        List<Object> nums = Collections.singletonList(15);
        assertEquals(1, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(15, -73, 14, -15);
        assertEquals(1, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements2_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(33, -2, -3, 45, 21, 109);
        assertEquals(2, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements3_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(43, -12, 93, 125, 121, 109);
        assertEquals(4, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements4_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(71, -2, -33, 75, 21, 19);
        assertEquals(3, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_singleDigitNumber_returnsZero() {
        List<Object> nums = Collections.singletonList(1);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_allNumbersLessThanOrEqualToTen_returnsZero() {
        List<Object> nums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_allNumbersGreaterThanTenButNotOddDigits_returnsZero() {
        List<Object> nums = Arrays.asList(22, 24, 46, 68, 80);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_allNumbersGreaterThanTenAndOddDigits_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(11, 13, 31, 33, 55, 57, 75, 77, 99, 91);
        assertEquals(10, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_mixedNumbers_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(5, 15, 24, 33, 46, 55);
        assertEquals(3, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_negativeNumbers_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(-15, -24, -33, -46, -55);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_zeroInList_returnsZero() {
        List<Object> nums = Arrays.asList(0, 1, 2, 3);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_numberEndingInZero_returnsZero() {
        List<Object> nums = Collections.singletonList(10);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_numberWithSameFirstAndLastDigitOdd_returnsOne() {
        List<Object> nums = Collections.singletonList(11);
        assertEquals(1, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_largeNumberWithOddDigits_returnsOne() {
        List<Object> nums = Collections.singletonList(123456789);
        assertEquals(1, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_largeNumberWithoutOddDigits_returnsZero() {
        List<Object> nums = Collections.singletonList(24680);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_numberStartingWithZero_returnsZero() {
        List<Object> nums = Collections.singletonList(15); // 015 is treated as 15
        assertEquals(1, Specialfilter.specialfilter(nums));
    }
}