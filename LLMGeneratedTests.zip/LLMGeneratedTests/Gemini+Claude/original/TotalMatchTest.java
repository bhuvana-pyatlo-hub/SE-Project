package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TotalMatchTest {

    @Test
    void totalMatch_emptyLists_returnsFirstList() {
        List<Object> list1 = new ArrayList<>();
        List<Object> list2 = new ArrayList<>();
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1Shorter_returnsList1() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hi", "hi", "admin", "project");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2Shorter_returnsList2() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hI", "Hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1EqualsList2_returnsList1() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hI", "hi", "hii");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1SingleElement_returnsList1() {
        List<Object> list1 = Collections.singletonList("4");
        List<Object> list2 = Arrays.asList("1", "2", "3", "4", "5");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2Empty_returnsList1() {
        List<Object> list1 = Collections.singletonList("this");
        List<Object> list2 = new ArrayList<>();
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1Empty_returnsList1() {
        List<Object> list1 = new ArrayList<>();
        List<Object> list2 = Collections.singletonList("this");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1ContainsNonString_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", 123, "admin");
        List<Object> list2 = Arrays.asList("hI", "hi", "hii");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2ContainsNonString_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hI", 456, "hi", "hii");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_bothListsContainNonString_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", 123, "admin");
        List<Object> list2 = Arrays.asList("hI", 456, "hi", "hii");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_emptyStringInList1_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("", "admin");
        List<Object> list2 = Arrays.asList("hI", "hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_emptyStringInList2_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("", "hi", "hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_emptyStringInBothLists_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("", "admin");
        List<Object> list2 = Arrays.asList("", "hi", "hi");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_nullInList1_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(null, "admin");
        List<Object> list2 = Arrays.asList("hi", "hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_nullInList2_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList(null, "hi", "hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_nullInBothLists_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(null, "admin");
        List<Object> list2 = Arrays.asList(null, "hi", "hi");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1AllNull_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(null, null);
        List<Object> list2 = Arrays.asList("hi", "hi");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2AllNull_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList(null, null);
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_bothListsAllNull_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(null, null);
        List<Object> list2 = Arrays.asList(null, null);
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1LongerStrings_returnsList2() {
        List<Object> list1 = Arrays.asList("abcdefgh", "ijklmnop");
        List<Object> list2 = Arrays.asList("abc", "def", "ghi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1LongerThanList2WithSameLength_returnsList1() {
        List<Object> list1 = Arrays.asList("abc", "def");
        List<Object> list2 = Arrays.asList("gh", "ij");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }
}