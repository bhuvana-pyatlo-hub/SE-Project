package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FilterBySubstringTest {

    @Test
    void testFilterBySubstring_emptyList() {
        List<Object> inputList = new ArrayList<>();
        String substring = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringPresent() {
        List<Object> inputList = Arrays.asList("abc", "bacd", "cde", "array");
        String substring = "a";
        List<Object> expected = Arrays.asList("abc", "bacd", "array");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringNotFound() {
        List<Object> inputList = Arrays.asList("abc", "bacd", "cde", "array");
        String substring = "john";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_multipleOccurrences() {
        List<Object> inputList = Arrays.asList("xxx", "asd", "xxy", "john doe", "xxxAAA", "xxx");
        String substring = "xxx";
        List<Object> expected = Arrays.asList("xxx", "xxxAAA", "xxx");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_overlappingSubstrings() {
        List<Object> inputList = Arrays.asList("xxx", "asd", "aaaxxy", "john doe", "xxxAAA", "xxx");
        String substring = "xx";
        List<Object> expected = Arrays.asList("xxx", "aaaxxy", "xxxAAA", "xxx");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringAtBeginningAndEnd() {
        List<Object> inputList = Arrays.asList("grunt", "trumpet", "prune", "gruesome");
        String substring = "run";
        List<Object> expected = Arrays.asList("grunt", "prune");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_emptySubstring() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "";
        List<Object> expected = Arrays.asList("abc", "def", "ghi");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_listWithNulls() {
        List<Object> inputList = Arrays.asList("abc", null, "def", null);
        String substring = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_listWithEmptyStrings() {
        List<Object> inputList = Arrays.asList("abc", "", "def", "");
        String substring = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringIsEqualToInput() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "abc";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringIsLongerThanInput() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "abcdefgh";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_caseSensitive() {
        List<Object> inputList = Arrays.asList("abc", "Abc", "aBC");
        String substring = "aBc";
        List<Object> expected = Arrays.asList("aBC");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_numbersInList() {
        List<Object> inputList = Arrays.asList("123", "456", "789");
        String substring = "2";
        List<Object> expected = Arrays.asList("123");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_specialCharacters() {
        List<Object> inputList = Arrays.asList("!@#", "$%^", "&*(");
        String substring = "@";
        List<Object> expected = Arrays.asList("!@#");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_mixedTypes() {
        List<Object> inputList = Arrays.asList("abc", 123, "def", 456);
        String substring = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_mixedTypesNumbers() {
        List<Object> inputList = Arrays.asList("abc", 123, "def", 456);
        String substring = "2";
        List<Object> expected = Arrays.asList(123);
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_longList() {
        List<Object> inputList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            inputList.add("string" + i);
        }
        String substring = "string5";
        List<Object> expected = Arrays.asList("string5");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_noMatchInLongList() {
        List<Object> inputList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            inputList.add("string" + i);
        }
        String substring = "nomatch";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringAtEnd() {
        List<Object> inputList = Arrays.asList("abcdef", "ghijkl", "mnopqr");
        String substring = "ef";
        List<Object> expected = Arrays.asList("abcdef");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testFilterBySubstring_substringAtStart() {
        List<Object> inputList = Arrays.asList("abcdef", "ghijkl", "mnopqr");
        String substring = "ab";
        List<Object> expected = Arrays.asList("abcdef");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }
}