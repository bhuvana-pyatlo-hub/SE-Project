package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class ParseMusicTest {

    @Test
    void parseMusic_emptyString() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ParseMusic.parseMusic(""));
    }

    @Test
    void parseMusic_onlyWholeNotes() {
        List<Object> expected = List.of(4, 4, 4, 4);
        assertEquals(expected, ParseMusic.parseMusic("o o o o"));
    }

    @Test
    void parseMusic_onlyQuarterNotes() {
        List<Object> expected = List.of(1, 1, 1, 1);
        assertEquals(expected, ParseMusic.parseMusic(".| .| .| .|"));
    }

    @Test
    void parseMusic_onlyHalfNotes() {
        List<Object> expected = List.of(2, 2, 2);
        assertEquals(expected, ParseMusic.parseMusic("o| o| o|"));
    }

    @Test
    void parseMusic_mixedNotes1() {
        List<Object> expected = List.of(2, 2, 1, 1, 4, 4, 4, 4);
        assertEquals(expected, ParseMusic.parseMusic("o| o| .| .| o o o o"));
    }

    @Test
    void parseMusic_mixedNotes2() {
        List<Object> expected = List.of(2, 1, 2, 1, 4, 2, 4, 2);
        assertEquals(expected, ParseMusic.parseMusic("o| .| o| .| o o| o o|"));
    }

    @Test
    void parseMusic_example1() {
        List<Object> expected = List.of(4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4);
        assertEquals(expected, ParseMusic.parseMusic("o o| .| o| o| .| .| .| .| o o"));
    }

    @Test
    void parseMusic_singleWholeNote() {
        List<Object> expected = List.of(4);
        assertEquals(expected, ParseMusic.parseMusic("o"));
    }

    @Test
    void parseMusic_singleHalfNote() {
        List<Object> expected = List.of(2);
        assertEquals(expected, ParseMusic.parseMusic("o|"));
    }

    @Test
    void parseMusic_singleQuarterNote() {
        List<Object> expected = List.of(1);
        assertEquals(expected, ParseMusic.parseMusic(".|"));
    }

    @Test
    void parseMusic_wholeNoteFollowedByHalfNote() {
        List<Object> expected = List.of(4, 2);
        assertEquals(expected, ParseMusic.parseMusic("o o|"));
    }

    @Test
    void parseMusic_halfNoteFollowedByWholeNote() {
        List<Object> expected = List.of(2, 4);
        assertEquals(expected, ParseMusic.parseMusic("o| o"));
    }

    @Test
    void parseMusic_quarterNoteFollowedByWholeNote() {
        List<Object> expected = List.of(1, 4);
        assertEquals(expected, ParseMusic.parseMusic(".| o"));
    }

    @Test
    void parseMusic_wholeNoteFollowedByQuarterNote() {
        List<Object> expected = List.of(4, 1);
        assertEquals(expected, ParseMusic.parseMusic("o .|"));
    }

    @Test
    void parseMusic_halfNoteFollowedByQuarterNote() {
        List<Object> expected = List.of(2, 1);
        assertEquals(expected, ParseMusic.parseMusic("o| .|"));
    }

    @Test
    void parseMusic_quarterNoteFollowedByHalfNote() {
        List<Object> expected = List.of(1, 2);
        assertEquals(expected, ParseMusic.parseMusic(".| o|"));
    }

    @Test
    void parseMusic_multipleSpaces() {
        List<Object> expected = List.of(4, 4, 4);
        assertEquals(expected, ParseMusic.parseMusic("o  o   o"));
    }

    @Test
    void parseMusic_leadingAndTrailingSpaces() {
        List<Object> expected = List.of(4, 2, 1);
        assertEquals(expected, ParseMusic.parseMusic(" o o| .| "));
    }

    @Test
    void parseMusic_consecutiveHalfNotes() {
        List<Object> expected = List.of(2, 2, 2);
        assertEquals(expected, ParseMusic.parseMusic("o| o| o|"));
    }

    @Test
    void parseMusic_consecutiveQuarterNotes() {
        List<Object> expected = List.of(1, 1, 1);
        assertEquals(expected, ParseMusic.parseMusic(".| .| .|"));
    }

    @Test
    void parseMusic_onlySpaces() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ParseMusic.parseMusic("   "));
    }

    @Test
    void parseMusic_oFollowedBySomethingElse() {
        List<Object> expected = List.of(4);
        assertEquals(expected, ParseMusic.parseMusic("o "));
    }

    @Test
    void parseMusic_halfNoteFollowedBySpaces() {
        List<Object> expected = List.of(2);
        assertEquals(expected, ParseMusic.parseMusic("o|   "));
    }

    @Test
    void parseMusic_wholeNoteFollowedBySpaces() {
        List<Object> expected = List.of(4);
        assertEquals(expected, ParseMusic.parseMusic("o    "));
    }

    @Test
    void parseMusic_invalidInput() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ParseMusic.parseMusic("x y z"));
    }
}