package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FTest {

    @Test
    void testF_emptyList() {
        assertEquals(Collections.emptyList(), F.f(0));
    }

    @Test
    void testF_singleElementOdd() {
        assertEquals(Collections.singletonList(1), F.f(1));
    }

    @Test
    void testF_twoElementsOddEven() {
        assertEquals(Arrays.asList(1, 2), F.f(2));
    }

    @Test
    void testF_threeElementsOddEvenOdd() {
        assertEquals(Arrays.asList(1, 2, 6), F.f(3));
    }

    @Test
    void testF_fourElementsOddEvenOddEven() {
        assertEquals(Arrays.asList(1, 2, 6, 24), F.f(4));
    }

    @Test
    void testF_fiveElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15), F.f(5));
    }

    @Test
    void testF_sixElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720), F.f(6));
    }

    @Test
    void testF_sevenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28), F.f(7));
    }

    @Test
    void testF_eightElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320), F.f(8));
    }

    @Test
    void testF_nineElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45), F.f(9));
    }

    @Test
    void testF_tenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800), F.f(10));
    }

    @Test
    void testF_elevenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66), F.f(11));
    }

    @Test
    void testF_twelveElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600), F.f(12));
    }

    @Test
    void testF_thirteenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91), F.f(13));
    }

    @Test
    void testF_fourteenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912), F.f(14));
    }

    @Test
    void testF_fifteenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120), F.f(15));
    }

    @Test
    void testF_sixteenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278984), F.f(16));
    }

    @Test
    void testF_seventeenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278984, 153), F.f(17));
    }

    @Test
    void testF_eighteenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278984, 153, 640237370), F.f(18));
    }

    @Test
    void testF_nineteenElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278984, 153, 640237370, 190), F.f(19));
    }

    @Test
    void testF_twentyElements() {
        assertEquals(Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278984, 153, 640237370, 190, -2102132736), F.f(20));
    }

    @Test
    void testF_negativeInput() {
        assertEquals(Collections.emptyList(), F.f(-1));
    }
}