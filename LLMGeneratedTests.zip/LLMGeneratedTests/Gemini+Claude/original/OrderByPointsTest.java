package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OrderByPointsTest {

    @Test
    void orderByPoints_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_singleElement() {
        List<Object> input = new ArrayList<>(Arrays.asList(5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_positiveNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 11, 2, 22));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 11, 22));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_negativeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, -11, -2, -22));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -2, -11, -22));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_mixedPositiveNegative() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 11, -1, -11));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 1, -11, 11));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_sameDigitSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 10, 2, 20));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 10, 20));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_zero() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1, -1));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 0, 1));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_boundaryValues() {
        List<Object> input = new ArrayList<>(Arrays.asList(-100, 0, 100));
        List<Object> expected = new ArrayList<>(Arrays.asList(-100, 0, 100));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_duplicateNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 1, 2, 2));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 1, 2, 2));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_duplicateNumbersWithDifferentSigns() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, -1, 1, -1));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 1, -1, 1));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_allSameNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_allSameNegativeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(-5, -5, -5, -5));
        List<Object> expected = new ArrayList<>(Arrays.asList(-5, -5, -5, -5));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 11, -1, -11, -12));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -11, 1, -12, 11));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList2() {
        List<Object> input = new ArrayList<>(Arrays.asList(1234, 423, 463, 145, 2, 423, 423, 53, 6, 37, 3457, 3, 56, 0, 46));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 2, 3, 6, 53, 423, 423, 423, 1234, 145, 37, 46, 56, 463, 3457));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList3() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, -11, -32, 43, 54, -98, 2, -3));
        List<Object> expected = new ArrayList<>(Arrays.asList(-3, -32, -98, -11, 1, 2, 43, 54));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList4() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 10, 2, 11, 3, 4, 5, 6, 7, 8, 9));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList5() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 6, 6, -76, -21, 23, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(-76, -21, 0, 4, 23, 6, 6));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_largeListWithDuplicates() {
        List<Object> input = new ArrayList<>(Arrays.asList(10, 10, 1, 10, 1, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 1, 1, 10, 10, 10));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }
}