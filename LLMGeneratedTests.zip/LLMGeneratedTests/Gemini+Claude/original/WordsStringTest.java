package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WordsStringTest {

    @Test
    void wordsString_emptyString() {
        List<Object> expected = Arrays.asList(new String[0]);
        assertEquals(expected, WordsString.wordsString(""));
    }

    @Test
    void wordsString_singleWord() {
        List<Object> expected = Arrays.asList("Hello");
        assertEquals(expected, WordsString.wordsString("Hello"));
    }

    @Test
    void wordsString_multipleWordsCommaSeparated() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One,two,three"));
    }

    @Test
    void wordsString_multipleWordsSpaceSeparated() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One two three"));
    }

    @Test
    void wordsString_multipleWordsCommaAndSpaceSeparated() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One, two, three"));
    }

    @Test
    void wordsString_multipleWordsMixedSeparators() {
        List<Object> expected = Arrays.asList("One", "two", "three", "four");
        assertEquals(expected, WordsString.wordsString("One, two,three four"));
    }

    @Test
    void wordsString_leadingAndTrailingSpaces() {
        List<Object> expected = Arrays.asList("One", "two");
        assertEquals(expected, WordsString.wordsString("  One,two  "));
    }

    @Test
    void wordsString_multipleConsecutiveCommas() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One,,two,three"));
    }

    @Test
    void wordsString_multipleConsecutiveSpaces() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One  two   three"));
    }

    @Test
    void wordsString_mixedConsecutiveSeparators() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One,  two,   three"));
    }

    @Test
    void wordsString_commaAtBeginningAndEnd() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString(",One,two,three,"));
    }

    @Test
    void wordsString_spaceAtBeginningAndEnd() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString(" One two three "));
    }

    @Test
    void wordsString_numbersAndLetters() {
        List<Object> expected = Arrays.asList("One1", "two2", "three3");
        assertEquals(expected, WordsString.wordsString("One1,two2,three3"));
    }

    @Test
    void wordsString_specialCharacters() {
        List<Object> expected = Arrays.asList("One!", "two@", "three#");
        assertEquals(expected, WordsString.wordsString("One!,two@,three#"));
    }

    @Test
    void wordsString_longString() {
        List<Object> expected = Arrays.asList("This", "is", "a", "very", "long", "string");
        assertEquals(expected, WordsString.wordsString("This,is,a,very,long,string"));
    }

    @Test
    void wordsString_stringWithOnlyCommas() {
        List<Object> expected = Arrays.asList(new String[0]);
        assertEquals(expected, WordsString.wordsString(",,,,,"));
    }

    @Test
    void wordsString_stringWithOnlySpaces() {
        List<Object> expected = Arrays.asList(new String[0]);
        assertEquals(expected, WordsString.wordsString("     "));
    }

    @Test
    void wordsString_stringWithCommasAndSpacesOnly() {
        List<Object> expected = Arrays.asList(new String[0]);
        assertEquals(expected, WordsString.wordsString(", , ,  "));
    }

    @Test
    void wordsString_singleComma() {
        List<Object> expected = Arrays.asList(new String[0]);
        assertEquals(expected, WordsString.wordsString(","));
    }

    @Test
    void wordsString_singleSpace() {
        List<Object> expected = Arrays.asList(new String[0]);
        assertEquals(expected, WordsString.wordsString(" "));
    }

    @Test
    void wordsString_wordsWithInternalSpaces() {
        List<Object> expected = Arrays.asList("Hello", "World");
        assertEquals(expected, WordsString.wordsString("Hello, World"));
    }

    @Test
    void wordsString_multipleEmptyWords() {
        List<Object> expected = Arrays.asList("One", "two", "three");
        assertEquals(expected, WordsString.wordsString("One,, ,two,three"));
    }
}