package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RemoveVowelsTest {

    @Test
    void removeVowels_emptyString() {
        assertEquals("", RemoveVowels.removeVowels(""));
    }

    @Test
    void removeVowels_noVowels() {
        assertEquals("bcdfgh", RemoveVowels.removeVowels("bcdfgh"));
    }

    @Test
    void removeVowels_allVowelsLowercase() {
        assertEquals("", RemoveVowels.removeVowels("aeiou"));
    }

    @Test
    void removeVowels_allVowelsUppercase() {
        assertEquals("", RemoveVowels.removeVowels("AEIOU"));
    }

    @Test
    void removeVowels_mixedCaseVowels() {
        assertEquals("", RemoveVowels.removeVowels("aEiOu"));
    }

    @Test
    void removeVowels_mixedCaseVowelsAndConsonants() {
        assertEquals("bcdfg", RemoveVowels.removeVowels("aEbIcOdUg"));
    }

    @Test
    void removeVowels_stringWithNumbers() {
        assertEquals("12345", RemoveVowels.removeVowels("a1e2i3o4u5"));
    }

    @Test
    void removeVowels_stringWithSpecialCharacters() {
        assertEquals("!@#$%", RemoveVowels.removeVowels("a!e@i#o$u%"));
    }

    @Test
    void removeVowels_stringWithWhitespace() {
        assertEquals("  ", RemoveVowels.removeVowels("a e i o u"));
    }

    @Test
    void removeVowels_stringWithNewline() {
        assertEquals("bcd\nfgh", RemoveVowels.removeVowels("abcd\nefgh"));
    }

    @Test
    void removeVowels_stringWithTabs() {
        assertEquals("bcd\tfgh", RemoveVowels.removeVowels("abcd\tefgh"));
    }

    @Test
    void removeVowels_stringWithMixedVowelsAndConsonants() {
        assertEquals("Hll, Wrd!", RemoveVowels.removeVowels("Hello, World!"));
    }

    @Test
    void removeVowels_stringWithOnlyOneVowelLowercase() {
        assertEquals("", RemoveVowels.removeVowels("a"));
    }

    @Test
    void removeVowels_stringWithOnlyOneVowelUppercase() {
        assertEquals("", RemoveVowels.removeVowels("A"));
    }

    @Test
    void removeVowels_stringWithOnlyOneConsonant() {
        assertEquals("b", RemoveVowels.removeVowels("b"));
    }

    @Test
    void removeVowels_stringWithLeadingAndTrailingVowels() {
        assertEquals("bcd", RemoveVowels.removeVowels("aebcdi"));
    }

    @Test
    void removeVowels_stringWithConsecutiveVowels() {
        assertEquals("bcd", RemoveVowels.removeVowels("aaeioubcd"));
    }

    @Test
    void removeVowels_stringWithConsecutiveConsonants() {
        assertEquals("bcdfgh", RemoveVowels.removeVowels("bcdfgh"));
    }

    @Test
    void removeVowels_stringWithVowelsAtTheEnd() {
        assertEquals("bcd", RemoveVowels.removeVowels("bcdaeiou"));
    }

    @Test
    void removeVowels_stringWithVowelsInTheMiddle() {
        assertEquals("bcd", RemoveVowels.removeVowels("baeioucd"));
    }

    @Test
    void removeVowels_mixedCaseStringWithVowelsAndConsonants() {
        assertEquals("Hll Wrd", RemoveVowels.removeVowels("Hello World"));
    }

    @Test
    void removeVowels_stringWithRepeatedVowels() {
        assertEquals("bcdf", RemoveVowels.removeVowels("baaeeiioouuf"));
    }

    @Test
    void removeVowels_boundaryCaseWithSingleCharacter() {
        assertEquals("b", RemoveVowels.removeVowels("b"));
        assertEquals("", RemoveVowels.removeVowels("a"));
    }

    @Test
    void removeVowels_boundaryCaseWithTwoCharacters() {
        assertEquals("b", RemoveVowels.removeVowels("ba"));
        assertEquals("b", RemoveVowels.removeVowels("ab"));
        assertEquals("", RemoveVowels.removeVowels("ae"));
    }

    @Test
    void removeVowels_boundaryCaseWithThreeCharacters() {
        assertEquals("b", RemoveVowels.removeVowels("aab"));
        assertEquals("bc", RemoveVowels.removeVowels("abc"));
        assertEquals("", RemoveVowels.removeVowels("aei"));
    }
}