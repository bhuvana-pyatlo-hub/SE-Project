package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class OddCountTest {

    @Test
    void oddCount_emptyList() {
        List<String> input = Collections.emptyList();
        List<String> expected = Collections.emptyList();
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_singleString_noOddDigits() {
        List<String> input = Collections.singletonList("2468");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_singleString_allOddDigits() {
        List<String> input = Collections.singletonList("13579");
        List<String> expected = Collections.singletonList("the number of odd elements 5n the str5ng 5 of the 5nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_singleString_mixedOddEvenDigits() {
        List<String> input = Collections.singletonList("12345");
        List<String> expected = Collections.singletonList("the number of odd elements 3n the str3ng 3 of the 3nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_varyingOddDigitCounts() {
        List<String> input = Arrays.asList("123", "456", "789");
        List<String> expected = Arrays.asList(
                "the number of odd elements 2n the str2ng 2 of the 2nput.",
                "the number of odd elements 2n the str2ng 2 of the 2nput.",
                "the number of odd elements 2n the str2ng 2 of the 2nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_emptyString() {
        List<String> input = Arrays.asList("", "1", "12");
        List<String> expected = Arrays.asList(
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_singleString_singleOddDigit() {
        List<String> input = Collections.singletonList("1");
        List<String> expected = Collections.singletonList("the number of odd elements 1n the str1ng 1 of the 1nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_singleString_singleEvenDigit() {
        List<String> input = Collections.singletonList("2");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_allEmpty() {
        List<String> input = Arrays.asList("", "", "");
        List<String> expected = Arrays.asList(
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithLeadingZero() {
        List<String> input = Collections.singletonList("0123");
        List<String> expected = Collections.singletonList("the number of odd elements 2n the str2ng 2 of the 2nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithMultipleLeadingZeros() {
        List<String> input = Collections.singletonList("0001");
        List<String> expected = Collections.singletonList("the number of odd elements 1n the str1ng 1 of the 1nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_sameOddCount() {
        List<String> input = Arrays.asList("13", "31", "55");
        List<String> expected = Arrays.asList(
                "the number of odd elements 2n the str2ng 2 of the 2nput.",
                "the number of odd elements 2n the str2ng 2 of the 2nput.",
                "the number of odd elements 2n the str2ng 2 of the 2nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithOnlyZero() {
        List<String> input = Collections.singletonList("0");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_oneDigitEach() {
        List<String> input = Arrays.asList("1", "2", "3");
        List<String> expected = Arrays.asList(
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithAllEvenDigits() {
        List<String> input = Collections.singletonList("24680");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithAllOddDigits() {
        List<String> input = Collections.singletonList("13579");
        List<String> expected = Collections.singletonList("the number of odd elements 5n the str5ng 5 of the 5nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_mixedLengths() {
        List<String> input = Arrays.asList("1", "12", "123");
        List<String> expected = Arrays.asList(
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 2n the str2ng 2 of the 2nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_sameLength() {
        List<String> input = Arrays.asList("12", "34", "56");
        List<String> expected = Arrays.asList(
                "the number of odd elements 1n the str1ng 1 of the 1nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput.",
                "the number of odd elements 0n the str0ng 0 of the 0nput."
        );
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_largeOddCount() {
        List<String> input = Collections.singletonList("1111111111");
        List<String> expected = Collections.singletonList("the number of odd elements 10n the str10ng 10 of the 10nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }
}