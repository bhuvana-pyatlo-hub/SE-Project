package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SameCharsTest {

    @Test
    void sameChars_bothEmpty() {
        assertTrue(SameChars.sameChars("", ""));
    }

    @Test
    void sameChars_firstEmpty() {
        assertTrue(SameChars.sameChars("", ""));
    }

    @Test
    void sameChars_secondEmpty() {
        assertTrue(SameChars.sameChars("abc", ""));
    }

    @Test
    void sameChars_sameCharsPresent() {
        assertTrue(SameChars.sameChars("abc", "cba"));
    }

    @Test
    void sameChars_sameCharsPresentWithDuplicates() {
        assertTrue(SameChars.sameChars("aabbcc", "abc"));
    }

    @Test
    void sameChars_differentChars() {
        assertFalse(SameChars.sameChars("abc", "abd"));
    }

    @Test
    void sameChars_differentCharsWithDuplicates() {
        assertFalse(SameChars.sameChars("aabbcc", "abdd"));
    }

    @Test
    void sameChars_firstLonger() {
        assertTrue(SameChars.sameChars("abc", "abc"));
    }

    @Test
    void sameChars_secondLonger() {
        assertTrue(SameChars.sameChars("abc", "abc"));
    }

    @Test
    void sameChars_firstLongerDifferentChars() {
        assertFalse(SameChars.sameChars("abcdefg", "abch"));
    }

    @Test
    void sameChars_secondLongerDifferentChars() {
        assertFalse(SameChars.sameChars("abc", "abchdefg"));
    }

    @Test
    void sameChars_sameCharsRepeated() {
        assertTrue(SameChars.sameChars("aaaa", "a"));
    }

    @Test
    void sameChars_differentCharsRepeated() {
        assertFalse(SameChars.sameChars("aaaa", "b"));
    }

    @Test
    void sameChars_boundaryCaseAllCharsPresent() {
        assertTrue(SameChars.sameChars("abcdefghijklmnopqrstuvwxyz", "abc"));
    }

    @Test
    void sameChars_boundaryCaseAllCharsPresentDifferentOrder() {
        assertTrue(SameChars.sameChars("abcdefghijklmnopqrstuvwxyz", "zyx"));
    }

    @Test
    void sameChars_boundaryCaseAllCharsPresentWithExtra() {
        assertFalse(SameChars.sameChars("abcdefghijklmnopqrstuvwxyz", "abca"));
    }

    @Test
    void sameChars_singleCharMatch() {
        assertTrue(SameChars.sameChars("a", "a"));
    }

    @Test
    void sameChars_singleCharNoMatch() {
        assertFalse(SameChars.sameChars("a", "b"));
    }

    @Test
    void sameChars_sameCharsMultipleOccurrences() {
        assertTrue(SameChars.sameChars("aabbcc", "abc"));
    }

    @Test
    void sameChars_differentCharsMultipleOccurrences() {
        assertFalse(SameChars.sameChars("aabbcc", "abd"));
    }

    @Test
    void sameChars_sameCharsMixedCase() {
        assertFalse(SameChars.sameChars("aBc", "abc"));
    }

    @Test
    void sameChars_sameCharsWithNumbers() {
        assertFalse(SameChars.sameChars("a1c", "abc"));
    }

    @Test
    void sameChars_boundaryCaseWithNegativeValues() {
        assertFalse(SameChars.sameChars("abc", "abc-"));
    }

    @Test
    void sameChars_boundaryCaseWithSpecialChars() {
        assertFalse(SameChars.sameChars("abc", "abc!"));
    }
}