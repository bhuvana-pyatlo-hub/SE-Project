package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChangeBaseTest {

    @Test
    void testChangeBase_8_to_3() {
        assertEquals("22", ChangeBase.changeBase(8, 3));
    }

    @Test
    void testChangeBase_8_to_2() {
        assertEquals("1000", ChangeBase.changeBase(8, 2));
    }

    @Test
    void testChangeBase_7_to_2() {
        assertEquals("111", ChangeBase.changeBase(7, 2));
    }

    @Test
    void testChangeBase_9_to_3() {
        assertEquals("100", ChangeBase.changeBase(9, 3));
    }

    @Test
    void testChangeBase_234_to_2() {
        assertEquals("11101010", ChangeBase.changeBase(234, 2));
    }

    @Test
    void testChangeBase_16_to_2() {
        assertEquals("10000", ChangeBase.changeBase(16, 2));
    }

    @Test
    void testChangeBase_2_to_3() {
        assertEquals("2", ChangeBase.changeBase(2, 3));
    }

    @Test
    void testChangeBase_3_to_4() {
        assertEquals("3", ChangeBase.changeBase(3, 4));
    }

    @Test
    void testChangeBase_4_to_5() {
        assertEquals("4", ChangeBase.changeBase(4, 5));
    }

    @Test
    void testChangeBase_5_to_6() {
        assertEquals("5", ChangeBase.changeBase(5, 6));
    }

    @Test
    void testChangeBase_6_to_7() {
        assertEquals("6", ChangeBase.changeBase(6, 7));
    }

    @Test
    void testChangeBase_7_to_8() {
        assertEquals("7", ChangeBase.changeBase(7, 8));
    }

    @Test
    void testChangeBase_0_to_2() {
        assertEquals("", ChangeBase.changeBase(0, 2));
    }

    @Test
    void testChangeBase_1_to_2() {
        assertEquals("1", ChangeBase.changeBase(1, 2));
    }

    @Test
    void testChangeBase_10_to_3() {
        assertEquals("101", ChangeBase.changeBase(10, 3));
    }

    @Test
    void testChangeBase_15_to_4() {
        assertEquals("33", ChangeBase.changeBase(15, 4));
    }

    @Test
    void testChangeBase_100_to_10() {
        assertEquals("100", ChangeBase.changeBase(100, 10));
    }

    @Test
    void testChangeBase_99_to_8() {
        assertEquals("143", ChangeBase.changeBase(99, 8));
    }

    @Test
    void testChangeBase_123_to_5() {
        assertEquals("443", ChangeBase.changeBase(123, 5));
    }

    @Test
    void testChangeBase_1000_to_2() {
        assertEquals("1111101000", ChangeBase.changeBase(1000, 2));
    }

    @Test
    void testChangeBase_negativeValue() {
        assertThrows(IllegalArgumentException.class, () -> ChangeBase.changeBase(-1, 2));
    }

    @Test
    void testChangeBase_invalidBase() {
        assertThrows(IllegalArgumentException.class, () -> ChangeBase.changeBase(10, 11));
    }

    @Test
    void testChangeBase_zeroBase() {
        assertThrows(IllegalArgumentException.class, () -> ChangeBase.changeBase(10, 0));
    }
}