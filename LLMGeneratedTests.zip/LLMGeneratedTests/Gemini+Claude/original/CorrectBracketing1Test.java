package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketing1Test {

    @Test
    void testEmptyString() {
        assertTrue(CorrectBracketing1.correctBracketing(""));
    }

    @Test
    void testSingleOpenBracket() {
        assertFalse(CorrectBracketing1.correctBracketing("("));
    }

    @Test
    void testSingleCloseBracket() {
        assertFalse(CorrectBracketing1.correctBracketing(")"));
    }

    @Test
    void testSimpleCorrectBracketing() {
        assertTrue(CorrectBracketing1.correctBracketing("()"));
    }

    @Test
    void testSimpleIncorrectBracketing() {
        assertFalse(CorrectBracketing1.correctBracketing(")("));
    }

    @Test
    void testNestedCorrectBracketing() {
        assertTrue(CorrectBracketing1.correctBracketing("(())"));
    }

    @Test
    void testNestedIncorrectBracketing() {
        assertFalse(CorrectBracketing1.correctBracketing("(()"));
    }

    @Test
    void testMultipleCorrectBracketing() {
        assertTrue(CorrectBracketing1.correctBracketing("()()"));
    }

    @Test
    void testMultipleIncorrectBracketing() {
        assertFalse(CorrectBracketing1.correctBracketing("())("));
    }

    @Test
    void testComplexCorrectBracketing() {
        assertTrue(CorrectBracketing1.correctBracketing("(()(()))"));
    }

    @Test
    void testComplexIncorrectBracketing() {
        assertFalse(CorrectBracketing1.correctBracketing("(()(()))("));
    }

    @Test
    void testStartingWithCloseBracket() {
        assertFalse(CorrectBracketing1.correctBracketing(")(()"));
    }

    @Test
    void testEndingWithOpenBracket() {
        assertFalse(CorrectBracketing1.correctBracketing("(()("));
    }

    @Test
    void testOnlyOpenBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("((((("));
    }

    @Test
    void testOnlyCloseBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing(")))))"));
    }

    @Test
    void testBalancedBrackets() {
        assertTrue(CorrectBracketing1.correctBracketing("((()))"));
    }

    @Test
    void testUnbalancedBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("((())"));
    }

    @Test
    void testAlternatingBracketsIncorrect() {
        assertFalse(CorrectBracketing1.correctBracketing(")(()("));
    }

    @Test
    void testCorrectBracketingWithWhitespace() {
        assertTrue(CorrectBracketing1.correctBracketing("()"));
    }

    @Test
    void testLongCorrectBracketing() {
        assertTrue(CorrectBracketing1.correctBracketing("()()(()())()"));
    }

    @Test
    void testLongIncorrectBracketing() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())()))()"));
    }

    @Test
    void testComplexUnbalancedBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("(()())(()"));
    }

    @Test
    void testMultipleNestedCorrectBracketing() {
        assertTrue(CorrectBracketing1.correctBracketing("(((())))"));
    }

    @Test
    void testMultipleNestedIncorrectBracketing() {
        assertFalse(CorrectBracketing1.correctBracketing("(((()))"));
    }
}