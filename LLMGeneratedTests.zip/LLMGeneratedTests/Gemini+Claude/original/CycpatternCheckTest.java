package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CycpatternCheckTest {

    @Test
    void cycpatternCheck_emptyA_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("", "abc"));
    }

    @Test
    void cycpatternCheck_emptyB_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abc", ""));
    }

    @Test
    void cycpatternCheck_bothEmpty_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("", ""));
    }

    @Test
    void cycpatternCheck_bLongerThanA_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("ab", "abcd"));
    }

    @Test
    void cycpatternCheck_noMatch_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abcd", "abd"));
    }

    @Test
    void cycpatternCheck_exactMatch_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("hello", "ell"));
    }

    @Test
    void cycpatternCheck_rotationMatch_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abab", "baa"));
    }

    @Test
    void cycpatternCheck_noRotationMatch_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("efef", "eeff"));
    }

    @Test
    void cycpatternCheck_rotationMatch2_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("himenss", "simen"));
    }

    @Test
    void cycpatternCheck_xyzw_xyw_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("xyzw", "xyw"));
    }

    @Test
    void cycpatternCheck_yello_ell_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("yello", "ell"));
    }

    @Test
    void cycpatternCheck_whattup_ptut_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("whattup", "ptut"));
    }

    @Test
    void cycpatternCheck_efef_fee_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("efef", "fee"));
    }

    @Test
    void cycpatternCheck_abab_aabb_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abab", "aabb"));
    }

    @Test
    void cycpatternCheck_winemtt_tinem_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("winemtt", "tinem"));
    }

    @Test
    void cycpatternCheck_singleCharMatch_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abc", "a"));
    }

    @Test
    void cycpatternCheck_singleCharNoMatch_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abc", "d"));
    }

    @Test
    void cycpatternCheck_sameString_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abc", "abc"));
    }

    @Test
    void cycpatternCheck_aEqualsB_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("a", "a"));
    }

    @Test
    void cycpatternCheck_minimumValidInputs_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("a", "a"));
    }

    @Test
    void cycpatternCheck_boundaryValues_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("a", "b"));
    }

    @Test
    void cycpatternCheck_negativeValues_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abc", "-d"));
    }

    @Test
    void cycpatternCheck_zeroValues_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abc", "0"));
    }

    @Test
    void cycpatternCheck_longStrings_returnsFalse() {
        String a = "abcdefghijklmnopqrstuvwxyz";
        String b = "zyxwvutsrqponmlkjihgfedcba";
        assertFalse(CycpatternCheck.cycpatternCheck(a, b));
    }

    @Test
    void cycpatternCheck_longStringsRotationMatch_returnsTrue() {
        String a = "abcdefghijklmnopqrstuvwxyz";
        String b = "wxyzabcdefghijklmnopqrstuv";
        assertTrue(CycpatternCheck.cycpatternCheck(a, b));
    }
}