package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortEvenTest {

    @Test
    void sortEven_emptyList() {
        List<Integer> input = new ArrayList<>();
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_singleElementList_evenIndex() {
        List<Integer> input = new ArrayList<>(List.of(2));
        List<Integer> expected = new ArrayList<>(List.of(2));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_singleElementList_oddIndex() {
        List<Integer> input = new ArrayList<>(List.of(1));
        List<Integer> expected = new ArrayList<>(List.of(1));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_twoElementList() {
        List<Integer> input = new ArrayList<>(List.of(2, 1));
        List<Integer> expected = new ArrayList<>(List.of(2, 1));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_threeElementList() {
        List<Integer> input = new ArrayList<>(List.of(3, 2, 1));
        List<Integer> expected = new ArrayList<>(List.of(1, 2, 3));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_fourElementList() {
        List<Integer> input = new ArrayList<>(List.of(4, 3, 2, 1));
        List<Integer> expected = new ArrayList<>(List.of(2, 3, 4, 1));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_alreadySortedEvenIndices() {
        List<Integer> input = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        List<Integer> expected = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_reverseSortedEvenIndices() {
        List<Integer> input = new ArrayList<>(List.of(5, 2, 3, 4, 1, 6));
        List<Integer> expected = new ArrayList<>(List.of(1, 2, 3, 4, 3, 6));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_duplicateEvenIndices() {
        List<Integer> input = new ArrayList<>(List.of(2, 1, 2, 3, 1, 4));
        List<Integer> expected = new ArrayList<>(List.of(1, 1, 1, 3, 2, 4));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_negativeNumbers() {
        List<Integer> input = new ArrayList<>(List.of(-1, 2, -3, 4, -5, 6));
        List<Integer> expected = new ArrayList<>(List.of(-5, 2, -3, 4, -1, 6));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_mixedPositiveNegativeZero() {
        List<Integer> input = new ArrayList<>(List.of(0, 1, -1, 2, 3, 4));
        List<Integer> expected = new ArrayList<>(List.of(-1, 1, 0, 2, 3, 4));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_largeList() {
        List<Integer> input = new ArrayList<>(Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10));
        List<Integer> expected = new ArrayList<>(Arrays.asList(-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_allEvenIndices() {
        List<Integer> input = new ArrayList<>(Arrays.asList(2, 1, 4, 3, 6, 5));
        List<Integer> expected = new ArrayList<>(Arrays.asList(2, 1, 4, 3, 6, 5));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_allOddIndices() {
        List<Integer> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6));
        List<Integer> expected = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_sameValuesAtEvenIndices() {
        List<Integer> input = new ArrayList<>(Arrays.asList(2, 1, 2, 3, 2, 5));
        List<Integer> expected = new ArrayList<>(Arrays.asList(2, 1, 2, 3, 2, 5));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_alternatingPositiveNegative() {
        List<Integer> input = new ArrayList<>(Arrays.asList(1, -2, 3, -4, 5, -6));
        List<Integer> expected = new ArrayList<>(Arrays.asList(1, -2, 3, -4, 5, -6));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_boundaryZeroAndOne() {
        List<Integer> input = new ArrayList<>(Arrays.asList(0, 1, 1, 0));
        List<Integer> expected = new ArrayList<>(Arrays.asList(0, 1, 1, 0));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_listWithOnlyEvenIndices() {
        List<Integer> input = new ArrayList<>(Arrays.asList(2, 4, 6, 8));
        List<Integer> expected = new ArrayList<>(Arrays.asList(2, 4, 6, 8));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_listWithOnlyOddIndices() {
        List<Integer> input = new ArrayList<>(Arrays.asList(1, 3, 5, 7));
        List<Integer> expected = new ArrayList<>(Arrays.asList(1, 3, 5, 7));
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void sortEven_listWithSameEvenNumbers() {
        List<Integer> input = new ArrayList<>(Arrays.asList(2, 1, 2, 3, 2, 5));
        List<Integer> expected = new ArrayList<>(Arrays.asList(2, 1, 2, 3, 2, 5));
        assertEquals(expected, SortEven.sortEven(input));
    }
}