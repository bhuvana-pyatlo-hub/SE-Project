package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class MoveOneBallTest {

    @Test
    void moveOneBall_emptyList_returnsTrue() {
        assertTrue(MoveOneBall.moveOneBall(Collections.emptyList()));
    }

    @Test
    void moveOneBall_sortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_rotatedSortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(3, 4, 5, 1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_unsortedList_returnsFalse() {
        List<Object> arr = Arrays.asList(3, 5, 4, 1, 2);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_singleElementList_returnsTrue() {
        List<Object> arr = Arrays.asList(5);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementSortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementUnsortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(2, 1);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_almostSortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 4, 3, 5);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_negativeNumbersSorted_returnsTrue() {
        List<Object> arr = Arrays.asList(-3, -2, -1, 0, 1);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_negativeNumbersUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(-3, -1, -2, 0, 1);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_mixedPositiveNegativeSorted_returnsTrue() {
        List<Object> arr = Arrays.asList(-2, -1, 0, 1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_mixedPositiveNegativeUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(-2, 0, -1, 1, 2);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_zeroes_returnsTrue() {
        List<Object> arr = Arrays.asList(0, 0, 0, 0, 0);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_zeroesUnsorted_returnsTrue() {
        List<Object> arr = Arrays.asList(0, 0, 1, 0, 0);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_longListSorted_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_longListUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5, 7, 6, 8, 9, 10);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementNegativeList_returnsTrue() {
        List<Object> arr = Arrays.asList(-1, -2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementNegativeUnsortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(-2, -1);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementWithZeroList_returnsTrue() {
        List<Object> arr = Arrays.asList(0, -1);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementWithZeroUnsortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(-1, 0);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }
}