package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChooseNumTest {

    @Test
    void chooseNum_xLessThanY_evenInRange() {
        assertEquals(14, ChooseNum.chooseNum(12, 15));
    }

    @Test
    void chooseNum_xGreaterThanY_noEvenInRange() {
        assertEquals(-1, ChooseNum.chooseNum(13, 12));
    }

    @Test
    void chooseNum_xLessThanY_largeRange_evenInRange() {
        assertEquals(98, ChooseNum.chooseNum(33, 98));
    }

    @Test
    void chooseNum_xGreaterThanY_noRange() {
        assertEquals(-1, ChooseNum.chooseNum(5234, 5233));
    }

    @Test
    void chooseNum_xLessThanY_evenInRange1() {
        assertEquals(28, ChooseNum.chooseNum(6, 29));
    }

    @Test
    void chooseNum_xGreaterThanY_noEven() {
        assertEquals(-1, ChooseNum.chooseNum(27, 10));
    }

    @Test
    void chooseNum_xEqualsY_odd() {
        assertEquals(-1, ChooseNum.chooseNum(7, 7));
    }

    @Test
    void chooseNum_xEqualsY_even() {
        assertEquals(546, ChooseNum.chooseNum(546, 546));
    }

    @Test
    void chooseNum_xLessThanY_noEvenInRange() {
        assertEquals(-1, ChooseNum.chooseNum(1, 3));
    }

    @Test
    void chooseNum_xLessThanY_onlyOddInRange() {
        assertEquals(-1, ChooseNum.chooseNum(11, 11));
    }

    @Test
    void chooseNum_xLessThanY_onlyOneEvenInRange() {
        assertEquals(12, ChooseNum.chooseNum(12, 12));
    }

    @Test
    void chooseNum_xLessThanY_multipleEvensInRange() {
        assertEquals(20, ChooseNum.chooseNum(16, 20));
    }

    @Test
    void chooseNum_xLessThanY_evenAtStart() {
        assertEquals(10, ChooseNum.chooseNum(10, 15));
    }

    @Test
    void chooseNum_xLessThanY_evenAtEnd() {
        assertEquals(20, ChooseNum.chooseNum(17, 20));
    }

    @Test
    void chooseNum_xLessThanY_evenInMiddle() {
        assertEquals(18, ChooseNum.chooseNum(17, 19));
    }

    @Test
    void chooseNum_xEqualsY_smallEven() {
        assertEquals(2, ChooseNum.chooseNum(2, 2));
    }

    @Test
    void chooseNum_xEqualsY_smallOdd() {
        assertEquals(-1, ChooseNum.chooseNum(1, 1));
    }

    @Test
    void chooseNum_xLessThanY_smallRangeWithEven() {
        assertEquals(4, ChooseNum.chooseNum(3, 4));
    }

    @Test
    void chooseNum_xLessThanY_smallRangeNoEven() {
        assertEquals(-1, ChooseNum.chooseNum(3, 3));
    }

    @Test
    void chooseNum_xLessThanY_largerRangeWithEven() {
        assertEquals(98, ChooseNum.chooseNum(95, 98));
    }

    @Test
    void chooseNum_xLessThanY_evenAtStartBoundary() {
        assertEquals(0, ChooseNum.chooseNum(0, 5));
    }

    @Test
    void chooseNum_xLessThanY_negativeRange() {
        assertEquals(-2, ChooseNum.chooseNum(-5, -2));
    }

    @Test
    void chooseNum_xLessThanY_negativeOnly() {
        assertEquals(-4, ChooseNum.chooseNum(-4, -1));
    }

    @Test
    void chooseNum_xLessThanY_zeroBoundary() {
        assertEquals(0, ChooseNum.chooseNum(-1, 0));
    }
}