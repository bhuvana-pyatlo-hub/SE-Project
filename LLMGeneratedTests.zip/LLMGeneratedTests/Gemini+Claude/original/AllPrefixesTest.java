package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;

class AllPrefixesTest {

    @Test
    void testAllPrefixes_emptyString() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, AllPrefixes.allPrefixes(""));
    }

    @Test
    void testAllPrefixes_singleCharacter() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        assertEquals(expected, AllPrefixes.allPrefixes("a"));
    }

    @Test
    void testAllPrefixes_shortString() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("ab");
        expected.add("abc");
        assertEquals(expected, AllPrefixes.allPrefixes("abc"));
    }

    @Test
    void testAllPrefixes_longerString() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("as");
        expected.add("asd");
        expected.add("asdf");
        expected.add("asdfg");
        expected.add("asdfgh");
        assertEquals(expected, AllPrefixes.allPrefixes("asdfgh"));
    }

    @Test
    void testAllPrefixes_stringWithSameCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("W");
        expected.add("WW");
        expected.add("WWW");
        assertEquals(expected, AllPrefixes.allPrefixes("WWW"));
    }

    @Test
    void testAllPrefixes_stringWithNumbers() {
        List<Object> expected = new ArrayList<>();
        expected.add("1");
        expected.add("12");
        expected.add("123");
        assertEquals(expected, AllPrefixes.allPrefixes("123"));
    }

    @Test
    void testAllPrefixes_stringWithSpecialCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("!");
        expected.add("!@");
        expected.add("!@#");
        assertEquals(expected, AllPrefixes.allPrefixes("!@#"));
    }

    @Test
    void testAllPrefixes_stringWithMixedCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("a1");
        expected.add("a1!");
        assertEquals(expected, AllPrefixes.allPrefixes("a1!"));
    }

    @Test
    void testAllPrefixes_stringWithWhitespace() {
        List<Object> expected = new ArrayList<>();
        expected.add(" ");
        expected.add(" a");
        expected.add(" a ");
        assertEquals(expected, AllPrefixes.allPrefixes(" a "));
    }

    @Test
    void testAllPrefixes_stringWithLeadingWhitespace() {
        List<Object> expected = new ArrayList<>();
        expected.add(" ");
        expected.add(" a");
        assertEquals(expected, AllPrefixes.allPrefixes(" a"));
    }

    @Test
    void testAllPrefixes_stringWithTrailingWhitespace() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("a ");
        assertEquals(expected, AllPrefixes.allPrefixes("a "));
    }

    @Test
    void testAllPrefixes_stringWithMultipleWhitespaces() {
        List<Object> expected = new ArrayList<>();
        expected.add(" ");
        expected.add("  ");
        expected.add("   ");
        assertEquals(expected, AllPrefixes.allPrefixes("   "));
    }

    @Test
    void testAllPrefixes_stringWithUnicodeCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("ü");
        expected.add("üö");
        expected.add("üöä");
        assertEquals(expected, AllPrefixes.allPrefixes("üöä"));
    }

    @Test
    void testAllPrefixes_stringWithNumbersAndLetters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("a2");
        expected.add("a2b");
        assertEquals(expected, AllPrefixes.allPrefixes("a2b"));
    }

    @Test
    void testAllPrefixes_stringWithSymbolsAndNumbers() {
        List<Object> expected = new ArrayList<>();
        expected.add("$");
        expected.add("$1");
        expected.add("$1%");
        assertEquals(expected, AllPrefixes.allPrefixes("$1%"));
    }

    @Test
    void testAllPrefixes_stringWithMixedCaseLetters() {
        List<Object> expected = new ArrayList<>();
        expected.add("A");
        expected.add("Ab");
        expected.add("AbC");
        assertEquals(expected, AllPrefixes.allPrefixes("AbC"));
    }

    @Test
    void testAllPrefixes_stringWithRepeatingCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("aa");
        expected.add("aaa");
        expected.add("aaaa");
        assertEquals(expected, AllPrefixes.allPrefixes("aaaa"));
    }

    @Test
    void testAllPrefixes_stringWithDifferentRepeatingCharacters() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("ab");
        expected.add("aba");
        expected.add("abab");
        assertEquals(expected, AllPrefixes.allPrefixes("abab"));
    }

    @Test
    void testAllPrefixes_stringWithNumbersAndSymbols() {
        List<Object> expected = new ArrayList<>();
        expected.add("1");
        expected.add("1$");
        expected.add("1$2");
        assertEquals(expected, AllPrefixes.allPrefixes("1$2"));
    }

    @Test
    void testAllPrefixes_stringWithLongPrefix() {
        List<Object> expected = new ArrayList<>();
        expected.add("l");
        expected.add("lo");
        expected.add("lon");
        expected.add("long");
        assertEquals(expected, AllPrefixes.allPrefixes("long"));
    }
}