package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RollingMaxTest {

    @Test
    void rollingMax_emptyList() {
        List<Object> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_increasingList() {
        List<Object> input = Arrays.asList(1, 2, 3, 4);
        List<Object> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_decreasingList() {
        List<Object> input = Arrays.asList(4, 3, 2, 1);
        List<Object> expected = Arrays.asList(4, 4, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_mixedList() {
        List<Object> input = Arrays.asList(3, 2, 3, 100, 3);
        List<Object> expected = Arrays.asList(3, 3, 3, 100, 100);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_exampleList() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 3, 4, 2);
        List<Object> expected = Arrays.asList(1, 2, 3, 3, 3, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_singleElementList() {
        List<Object> input = Collections.singletonList(5);
        List<Object> expected = Collections.singletonList(5);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_duplicateElements() {
        List<Object> input = Arrays.asList(2, 2, 2, 2);
        List<Object> expected = Arrays.asList(2, 2, 2, 2);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_negativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3, -4);
        List<Object> expected = Arrays.asList(-1, -1, -1, -1);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_mixedPositiveNegative() {
        List<Object> input = Arrays.asList(-1, 2, -3, 4);
        List<Object> expected = Arrays.asList(-1, 2, 2, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_zeroValues() {
        List<Object> input = Arrays.asList(0, 0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0, 0);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_mixedZeroPositiveNegative() {
        List<Object> input = Arrays.asList(-1, 0, 2, -3, 4, 0);
        List<Object> expected = Arrays.asList(-1, 0, 2, 2, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_allSameNumber() {
        List<Object> input = Arrays.asList(7, 7, 7, 7, 7);
        List<Object> expected = Arrays.asList(7, 7, 7, 7, 7);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_alternatingNumbers() {
        List<Object> input = Arrays.asList(1, 5, 1, 5, 1);
        List<Object> expected = Arrays.asList(1, 5, 5, 5, 5);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_firstElementIsMax() {
        List<Object> input = Arrays.asList(10, 1, 2, 3);
        List<Object> expected = Arrays.asList(10, 10, 10, 10);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_lastElementIsMax() {
        List<Object> input = Arrays.asList(1, 2, 3, 10);
        List<Object> expected = Arrays.asList(1, 2, 3, 10);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_middleElementIsMax() {
        List<Object> input = Arrays.asList(1, 10, 2, 3);
        List<Object> expected = Arrays.asList(1, 10, 10, 10);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_invalidInputType() {
        List<Object> input = Arrays.asList(1, "a", 3);
        assertThrows(IllegalArgumentException.class, () -> RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_onlyInvalidInputType() {
        List<Object> input = Arrays.asList("a", "b", "c");
        assertThrows(IllegalArgumentException.class, () -> RollingMax.rollingMax(input));
    }
}