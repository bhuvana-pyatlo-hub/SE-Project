package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HexKeyTest {

    @Test
    void hexKey_emptyString() {
        assertEquals(0, HexKey.hexKey(""));
    }

    @Test
    void hexKey_nullInput() {
        assertEquals(0, HexKey.hexKey(null));
    }

    @Test
    void hexKey_singlePrimeHexDigit() {
        assertEquals(1, HexKey.hexKey("2"));
    }

    @Test
    void hexKey_singleNonPrimeHexDigit() {
        assertEquals(0, HexKey.hexKey("0"));
    }

    @Test
    void hexKey_multiplePrimeHexDigits() {
        assertEquals(2, HexKey.hexKey("23"));
    }

    @Test
    void hexKey_mixedPrimeAndNonPrimeHexDigits() {
        assertEquals(3, HexKey.hexKey("12345"));
    }

    @Test
    void hexKey_allPrimeHexDigits() {
        assertEquals(6, HexKey.hexKey("2357BD"));
    }

    @Test
    void hexKey_allNonPrimeHexDigits() {
        assertEquals(0, HexKey.hexKey("014689ACEF"));
    }

    @Test
    void hexKey_longStringWithPrimeHexDigits() {
        assertEquals(6, HexKey.hexKey("123456789ABCDEF0"));
    }

    @Test
    void hexKey_longStringWithoutPrimeHexDigits() {
        assertEquals(0, HexKey.hexKey("014689ACEF014689ACEF"));
    }

    @Test
    void hexKey_stringWithNonHexCharacters() {
        assertEquals(2, HexKey.hexKey("2x3y"));
    }

    @Test
    void hexKey_stringWithLowercaseHexCharacters() {
        assertEquals(0, HexKey.hexKey("abcdef"));
    }

    @Test
    void hexKey_stringWithMixedCaseHexCharacters() {
        assertEquals(1, HexKey.hexKey("aBcDeF"));
    }

    @Test
    void hexKey_stringWithNumbersAndLetters() {
        assertEquals(4, HexKey.hexKey("1A2B3C4D5E6F"));
    }

    @Test
    void hexKey_stringWithOnlyPrimeNumbers() {
        assertEquals(4, HexKey.hexKey("2357"));
    }

    @Test
    void hexKey_stringWithOnlyPrimeLetters() {
        assertEquals(2, HexKey.hexKey("BD"));
    }

    @Test
    void hexKey_stringWithRepeatedPrimeNumbers() {
        assertEquals(4, HexKey.hexKey("2222"));
    }

    @Test
    void hexKey_stringWithRepeatedPrimeLetters() {
        assertEquals(4, HexKey.hexKey("BBBB"));
    }

    @Test
    void hexKey_stringWithMixedRepeatedPrimeDigitsAndLetters() {
        assertEquals(6, HexKey.hexKey("22BB2B"));
    }

    @Test
    void hexKey_stringWithLeadingAndTrailingSpaces() {
        assertEquals(1, HexKey.hexKey("  2  "));
    }

    @Test
    void hexKey_stringWithInternalSpaces() {
        assertEquals(1, HexKey.hexKey("1 2 3"));
    }

    @Test
    void hexKey_objectInput() {
        Object input = "23";
        assertEquals(2, HexKey.hexKey(input));
    }

    @Test
    void hexKey_integerInput() {
        Integer input = 23;
        assertEquals(2, HexKey.hexKey(input));
    }

    @Test
    void hexKey_boundaryValues() {
        assertEquals(0, HexKey.hexKey("1")); // Just below the first prime
        assertEquals(1, HexKey.hexKey("2")); // First prime
        assertEquals(1, HexKey.hexKey("3")); // Second prime
        assertEquals(0, HexKey.hexKey("4")); // Just above the second prime
        assertEquals(1, HexKey.hexKey("5")); // Third prime
        assertEquals(1, HexKey.hexKey("7")); // Fourth prime
        assertEquals(1, HexKey.hexKey("B")); // Fifth prime
        assertEquals(1, HexKey.hexKey("D")); // Sixth prime
    }
}