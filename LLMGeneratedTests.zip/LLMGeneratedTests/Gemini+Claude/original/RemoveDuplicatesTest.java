package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class RemoveDuplicatesTest {

    @Test
    void testRemoveDuplicates_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_noDuplicates() {
        List<Object> input = Arrays.asList(1, 2, 3, 4);
        List<Object> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_singleDuplicate() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 4);
        List<Object> expected = Arrays.asList(1, 3, 4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_multipleDuplicates() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 4, 3, 5);
        List<Object> expected = Arrays.asList(1, 4, 5);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_allDuplicates() {
        List<Object> input = Arrays.asList(1, 1, 1, 1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_mixedDataTypes() {
        List<Object> input = Arrays.asList(1, "a", 2, "a", 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_onlyStrings() {
        List<Object> input = Arrays.asList("a", "b", "c", "b", "d");
        List<Object> expected = Arrays.asList("a", "c", "d");
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_duplicateStrings() {
        List<Object> input = Arrays.asList("a", "a", "b", "c");
        List<Object> expected = Arrays.asList("b", "c");
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_singleElementList() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_twoElementList_noDuplicates() {
        List<Object> input = Arrays.asList(1, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_twoElementList_duplicates() {
        List<Object> input = Arrays.asList(1, 1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithNull() {
        List<Object> input = Arrays.asList(1, null, 2, null, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithOnlyNulls() {
        List<Object> input = Arrays.asList(null, null, null);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithOneNull() {
        List<Object> input = Arrays.asList(null);
        List<Object> expected = Arrays.asList(null);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithIntegerAndStringDuplicates() {
        List<Object> input = Arrays.asList(1, "a", 1, "b", "a");
        List<Object> expected = Arrays.asList("b");
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithSameIntegerAndString() {
        List<Object> input = Arrays.asList(1, "1", 1, "1");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_longListWithDuplicates() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        List<Object> expected = Arrays.asList(6, 7, 8, 9, 10);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithZeroAndNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, 0, 1, -1, 0, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithConsecutiveDuplicates() {
        List<Object> input = Arrays.asList(1, 1, 2, 2, 3, 3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithDuplicatesAtBeginningAndEnd() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 1);
        List<Object> expected = Arrays.asList(2, 3, 4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3, -2, -4);
        List<Object> expected = Arrays.asList(-1, -3, -4);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }

    @Test
    void testRemoveDuplicates_listWithMixedNegativeAndPositiveNumbers() {
        List<Object> input = Arrays.asList(-1, 0, 1, -1, 0, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, RemoveDuplicates.removeDuplicates(input));
    }
}