package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketingTest {

    @Test
    void correctBracketing_emptyString_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing(""));
    }

    @Test
    void correctBracketing_validSinglePair_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing("<>"));
    }

    @Test
    void correctBracketing_validMultiplePairs_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing("<<>>"));
    }

    @Test
    void correctBracketing_validNestedPairs_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing("<><>"));
    }

    @Test
    void correctBracketing_unclosedOpening_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<"));
    }

    @Test
    void correctBracketing_unclosedClosing_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing(">"));
    }

    @Test
    void correctBracketing_unclosedOpeningMultiple_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<<<"));
    }

    @Test
    void correctBracketing_unclosedClosingMultiple_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing(">>>"));
    }

    @Test
    void correctBracketing_invalidOrder_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("><"));
    }

    @Test
    void correctBracketing_invalidOrderMultiple_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing(">><<"));
    }

    @Test
    void correctBracketing_mixedValidAndInvalid_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<<>"));
    }

    @Test
    void correctBracketing_complexValid_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing("<<><>>"));
    }

    @Test
    void correctBracketing_complexInvalid_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<<<><>>>>"));
    }

    @Test
    void correctBracketing_longValidString_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>"));
    }

    @Test
    void correctBracketing_longInvalidString_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>>><>"));
    }

    @Test
    void correctBracketing_longValidString2_returnsTrue() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<<><><>><>><<><><<>>>"));
    }

    @Test
    void correctBracketing_longInvalidString2_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>><<>"));
    }

    @Test
    void correctBracketing_onlyOpenBrackets_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("<<<<<<<<<<"));
    }

    @Test
    void correctBracketing_onlyCloseBrackets_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing(">>>>>>>>>>"));
    }

    @Test
    void correctBracketing_alternatingInvalid_returnsFalse() {
        assertFalse(CorrectBracketing.correctBracketing("><><><><"));
    }
}