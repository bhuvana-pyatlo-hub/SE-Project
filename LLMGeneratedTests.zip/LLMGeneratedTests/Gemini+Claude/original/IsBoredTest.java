package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsBoredTest {

    @Test
    void isBored_emptyString_returnsZero() {
        assertEquals(0, IsBored.isBored(""));
    }

    @Test
    void isBored_noSentences_returnsZero() {
        assertEquals(0, IsBored.isBored("Hello world"));
    }

    @Test
    void isBored_singleSentenceNotStartingWithI_returnsZero() {
        assertEquals(0, IsBored.isBored("The sky is blue."));
    }

    @Test
    void isBored_singleSentenceStartingWithI_returnsOne() {
        assertEquals(1, IsBored.isBored("I love this weather."));
    }

    @Test
    void isBored_multipleSentencesOneStartingWithI_returnsOne() {
        assertEquals(1, IsBored.isBored("The sky is blue. I love this weather."));
    }

    @Test
    void isBored_multipleSentencesMultipleStartingWithI_returnsCorrectCount() {
        assertEquals(2, IsBored.isBored("I feel good today. I will be productive."));
    }

    @Test
    void isBored_sentenceStartingWithIAndExclamationMark_returnsOne() {
        assertEquals(1, IsBored.isBored("I love It !"));
    }

    @Test
    void isBored_sentenceStartingWithIAndQuestionMark_returnsOne() {
        assertEquals(1, IsBored.isBored("I am confused?"));
    }

    @Test
    void isBored_sentenceStartingWithLowercaseI_returnsZero() {
        assertEquals(0, IsBored.isBored("i am confused?"));
    }

    @Test
    void isBored_sentenceStartingWithIWithExtraSpaces_returnsOne() {
        assertEquals(1, IsBored.isBored("I   am confused?"));
    }

    @Test
    void isBored_multipleSentencesWithEmptySentences_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("I feel good today.. I will be productive."));
    }

    @Test
    void isBored_multipleSentencesWithEmptySentencesAndSpaces_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("I feel good today.   . I will be productive."));
    }

    @Test
    void isBored_sentenceWithOnlyI_returnsOne() {
        assertEquals(1, IsBored.isBored("I."));
    }

    @Test
    void isBored_sentenceWithOnlyIAndSpaces_returnsOne() {
        assertEquals(1, IsBored.isBored("I   ."));
    }

    @Test
    void isBored_sentenceWithIAsSecondWord_returnsZero() {
        assertEquals(0, IsBored.isBored("You and I are going for a walk."));
    }

    @Test
    void isBored_sentenceWithIAsSecondWordAndExclamationMark_returnsZero() {
        assertEquals(0, IsBored.isBored("You and I are going for a walk!"));
    }

    @Test
    void isBored_sentenceWithIAsSecondWordAndQuestionMark_returnsZero() {
        assertEquals(0, IsBored.isBored("You and I are going for a walk?"));
    }

    @Test
    void isBored_multipleSentencesWithConsecutiveDelimiters_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("I am here... I am there."));
    }

    @Test
    void isBored_multipleSentencesWithMixedDelimiters_returnsCorrectCount() {
        assertEquals(2, IsBored.isBored("I am here! I am there?"));
    }

    @Test
    void isBored_sentenceWithLeadingAndTrailingSpaces_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("  I am here.  "));
    }

    @Test
    void isBored_sentenceWithOnlyDelimiters_returnsZero() {
        assertEquals(0, IsBored.isBored("..."));
    }

    @Test
    void isBored_sentenceWithOnlySpaces_returnsZero() {
        assertEquals(0, IsBored.isBored("   "));
    }

    @Test
    void isBored_multipleSentencesWithOnlyI_returnsOne() {
        assertEquals(1, IsBored.isBored("I. I. I."));
    }

    @Test
    void isBored_sentenceWithIInDifferentCases_returnsZero() {
        assertEquals(0, IsBored.isBored("I am here. i am not."));
    }
}