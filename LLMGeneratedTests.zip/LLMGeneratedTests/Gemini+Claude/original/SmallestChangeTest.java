package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SmallestChangeTest {

    @Test
    void smallestChange_emptyList_returnsZero() {
        List<Integer> arr = Collections.emptyList();
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_singleElementList_returnsZero() {
        List<Integer> arr = Collections.singletonList(1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_twoElementPalindrome_returnsZero() {
        List<Integer> arr = Arrays.asList(1, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_twoElementNonPalindrome_returnsOne() {
        List<Integer> arr = Arrays.asList(1, 2);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_threeElementPalindrome_returnsZero() {
        List<Integer> arr = Arrays.asList(1, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_threeElementNonPalindrome_returnsOne() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_fourElementPalindrome_returnsZero() {
        List<Integer> arr = Arrays.asList(1, 2, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_fourElementNonPalindrome_returnsOne() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 1);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_fourElementNonPalindrome_returnsTwo() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4);
        assertEquals(2, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example1() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 5, 4, 7, 9, 6);
        assertEquals(4, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example2() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 3, 2, 2);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example3() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example4() {
        List<Integer> arr = Arrays.asList(3, 1, 1, 3);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_longerList_returnsCorrectCount() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_longerListNonPalindrome_returnsCorrectCount() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 100);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_allDifferentElements() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(2, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_almostPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 2, 4);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_alternatingPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 1, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_alternatingNonPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 1, 2, 3);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_longNonPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertEquals(5, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_boundaryValues() {
        List<Integer> arr = Arrays.asList(-100, 0, 100, 0, -100);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_boundaryValuesNonPalindrome() {
        List<Integer> arr = Arrays.asList(-100, 0, 100, 1, -100);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }
}