package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsNestedTest {

    @Test
    void isNested_emptyString_returnsFalse() {
        assertFalse(IsNested.isNested(""));
    }

    @Test
    void isNested_singleOpenBracket_returnsFalse() {
        assertFalse(IsNested.isNested("["));
    }

    @Test
    void isNested_singleCloseBracket_returnsFalse() {
        assertFalse(IsNested.isNested("]"));
    }

    @Test
    void isNested_simpleValidBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[]"));
    }

    @Test
    void isNested_simpleNestedBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[]]"));
    }

    @Test
    void isNested_multipleSimpleBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[][]"));
    }

    @Test
    void isNested_complexNestedBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[[[]]]]"));
    }

    @Test
    void isNested_unbalancedBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[[]"));
    }

    @Test
    void isNested_unbalancedBrackets2_returnsFalse() {
        assertFalse(IsNested.isNested("[]]"));
    }

    @Test
    void isNested_complexUnbalancedBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[]]]]]]][[[[[]"));
    }

    @Test
    void isNested_nestedAndSimpleBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[][]]"));
    }

    @Test
    void isNested_nestedAndSimpleBrackets2_returnsTrue() {
        assertTrue(IsNested.isNested("[[]][["));
    }

    @Test
    void isNested_multipleNestedBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[][][[]]"));
    }

    @Test
    void isNested_onlyOpeningBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[[[[[[[["));
    }

    @Test
    void isNested_onlyClosingBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("]]]]]]]]"));
    }

    @Test
    void isNested_longValidNestedBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[[[[[]]]]]]"));
    }

    @Test
    void isNested_longInvalidNestedBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[[[[[[]]]]]"));
    }

    @Test
    void isNested_alternatingBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("][][]["));
    }

    @Test
    void isNested_nestedWithExtraClosing_returnsFalse() {
        assertFalse(IsNested.isNested("[[]]]]]]]]]]"));
    }

    @Test
    void isNested_nestedWithExtraOpening_returnsFalse() {
        assertFalse(IsNested.isNested("[[[[[[[[[[]"));
    }

    @Test
    void isNested_validNestedWithExtraBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[[]]][[]]"));
    }

    @Test
    void isNested_nestedWithMultiplePairs_returnsTrue() {
        assertTrue(IsNested.isNested("[[[]]][[[]]]"));
    }

    @Test
    void isNested_nestedWithOnlyOnePair_returnsFalse() {
        assertFalse(IsNested.isNested("[[]][][]"));
    }

    @Test
    void isNested_nestedWithNoPairs_returnsFalse() {
        assertFalse(IsNested.isNested("[[[]]][[]][][]"));
    }
}