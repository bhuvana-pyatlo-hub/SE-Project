package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClosestIntegerTest {

    @Test
    void closestInteger_positiveInteger() {
        assertEquals(10, ClosestInteger.closestInteger("10"));
    }

    @Test
    void closestInteger_positiveDecimalRoundUp() {
        assertEquals(15, ClosestInteger.closestInteger("14.5"));
    }

    @Test
    void closestInteger_negativeDecimalRoundDown() {
        assertEquals(-16, ClosestInteger.closestInteger("-15.5"));
    }

    @Test
    void closestInteger_positiveDecimalRoundDown() {
        assertEquals(15, ClosestInteger.closestInteger("15.3"));
    }

    @Test
    void closestInteger_zero() {
        assertEquals(0, ClosestInteger.closestInteger("0"));
    }

    @Test
    void closestInteger_positiveDecimalNearZeroRoundDown() {
        assertEquals(0, ClosestInteger.closestInteger("0.4"));
    }

    @Test
    void closestInteger_positiveDecimalNearZeroRoundUp() {
        assertEquals(1, ClosestInteger.closestInteger("0.5"));
    }

    @Test
    void closestInteger_negativeDecimalNearZeroRoundUp() {
        assertEquals(0, ClosestInteger.closestInteger("-0.4"));
    }

    @Test
    void closestInteger_negativeDecimalNearZeroRoundDown() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.5"));
    }

    @Test
    void closestInteger_negativeInteger() {
        assertEquals(-10, ClosestInteger.closestInteger("-10"));
    }

    @Test
    void closestInteger_positiveSmallDecimal() {
        assertEquals(1, ClosestInteger.closestInteger("0.6"));
    }

    @Test
    void closestInteger_negativeSmallDecimal() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.6"));
    }

    @Test
    void closestInteger_positiveIntegerString() {
        assertEquals(50, ClosestInteger.closestInteger("50"));
    }

    @Test
    void closestInteger_negativeIntegerString() {
        assertEquals(-50, ClosestInteger.closestInteger("-50"));
    }

    @Test
    void closestInteger_positiveLargeDecimalRoundUp() {
        assertEquals(99, ClosestInteger.closestInteger("98.5"));
    }

    @Test
    void closestInteger_positiveLargeDecimalRoundDown() {
        assertEquals(98, ClosestInteger.closestInteger("98.4"));
    }

    @Test
    void closestInteger_negativeLargeDecimalRoundUp() {
        assertEquals(-98, ClosestInteger.closestInteger("-97.5"));
    }

    @Test
    void closestInteger_negativeLargeDecimalRoundDown() {
        assertEquals(-99, ClosestInteger.closestInteger("-98.6"));
    }

    @Test
    void closestInteger_positiveOne() {
        assertEquals(1, ClosestInteger.closestInteger("1"));
    }

    @Test
    void closestInteger_negativeOne() {
        assertEquals(-1, ClosestInteger.closestInteger("-1"));
    }

    @Test
    void closestInteger_positiveDecimalExactlyHalf() {
        assertEquals(2, ClosestInteger.closestInteger("1.5"));
    }

    @Test
    void closestInteger_negativeDecimalExactlyHalf() {
        assertEquals(-2, ClosestInteger.closestInteger("-1.5"));
    }

    @Test
    void closestInteger_invalidInput() {
        assertThrows(NumberFormatException.class, () -> ClosestInteger.closestInteger("invalid"));
    }

    @Test
    void closestInteger_emptyString() {
        assertThrows(NumberFormatException.class, () -> ClosestInteger.closestInteger(""));
    }

    @Test
    void closestInteger_nullInput() {
        assertThrows(NullPointerException.class, () -> ClosestInteger.closestInteger(null));
    }
}