package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MedianTest {

    @Test
    void median_emptyList() {
        List<Integer> list = new ArrayList<>();
        try {
            Median.median(list);
        } catch (IndexOutOfBoundsException e) {
            assertEquals(IndexOutOfBoundsException.class, e.getClass());
        }
    }

    @Test
    void median_singleElementList() {
        List<Integer> list = Arrays.asList(5);
        assertEquals(5, Median.median(list));
    }

    @Test
    void median_twoElementList_even() {
        List<Integer> list = Arrays.asList(6, 5);
        assertEquals(5.5, Median.median(list));
    }

    @Test
    void median_threeElementList_odd() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertEquals(2, Median.median(list));
    }

    @Test
    void median_fourElementList_even() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        assertEquals(2.5, Median.median(list));
    }

    @Test
    void median_fiveElementList_odd() {
        List<Integer> list = Arrays.asList(3, 1, 2, 4, 5);
        assertEquals(3, Median.median(list));
    }

    @Test
    void median_sixElementList_even() {
        List<Integer> list = Arrays.asList(-10, 4, 6, 10, 20, 30);
        assertEquals(8.0, Median.median(list));
    }

    @Test
    void median_sevenElementList_odd() {
        List<Integer> list = Arrays.asList(8, 1, 3, 9, 9, 2, 7);
        assertEquals(7, Median.median(list));
    }

    @Test
    void median_duplicateElements_odd() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3, 4);
        assertEquals(2, Median.median(list));
    }

    @Test
    void median_duplicateElements_even() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3);
        assertEquals(2.0, Median.median(list));
    }

    @Test
    void median_negativeNumbers_odd() {
        List<Integer> list = Arrays.asList(-1, -2, -3);
        assertEquals(-2, Median.median(list));
    }

    @Test
    void median_negativeNumbers_even() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4);
        assertEquals(-2.5, Median.median(list));
    }

    @Test
    void median_mixedNumbers_odd() {
        List<Integer> list = Arrays.asList(-1, 0, 1);
        assertEquals(0, Median.median(list));
    }

    @Test
    void median_mixedNumbers_even() {
        List<Integer> list = Arrays.asList(-1, 0, 1, 2);
        assertEquals(0.5, Median.median(list));
    }

    @Test
    void median_boundaryValues() {
        List<Integer> list = Arrays.asList(-100, 0, 100);
        assertEquals(0, Median.median(list));
    }

    @Test
    void median_largeNumbers_odd() {
        List<Integer> list = Arrays.asList(100, 200, 300);
        assertEquals(200, Median.median(list));
    }

    @Test
    void median_largeNumbers_even() {
        List<Integer> list = Arrays.asList(100, 200, 300, 400);
        assertEquals(250.0, Median.median(list));
    }

    @Test
    void median_alreadySorted_odd() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(3, Median.median(list));
    }

    @Test
    void median_alreadySorted_even() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        assertEquals(2.5, Median.median(list));
    }

    @Test
    void median_reverseSorted_odd() {
        List<Integer> list = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(3, Median.median(list));
    }

    @Test
    void median_reverseSorted_even() {
        List<Integer> list = Arrays.asList(4, 3, 2, 1);
        assertEquals(2.5, Median.median(list));
    }

    @Test
    void median_sameNumbers_odd() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(5, Median.median(list));
    }

    @Test
    void median_sameNumbers_even() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5);
        assertEquals(5.0, Median.median(list));
    }
}