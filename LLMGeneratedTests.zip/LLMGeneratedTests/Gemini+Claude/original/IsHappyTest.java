package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsHappyTest {

    @Test
    void isHappy_emptyString_returnsFalse() {
        assertFalse(IsHappy.isHappy(""));
    }

    @Test
    void isHappy_singleCharacter_returnsFalse() {
        assertFalse(IsHappy.isHappy("a"));
    }

    @Test
    void isHappy_twoCharacters_returnsFalse() {
        assertFalse(IsHappy.isHappy("aa"));
    }

    @Test
    void isHappy_threeDistinctCharacters_returnsTrue() {
        assertTrue(IsHappy.isHappy("abc"));
    }

    @Test
    void isHappy_threeSameCharacters_returnsFalse() {
        assertFalse(IsHappy.isHappy("aaa"));
    }

    @Test
    void isHappy_fourDistinctCharacters_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcd"));
    }

    @Test
    void isHappy_fourCharactersWithDuplicates_returnsFalse() {
        assertFalse(IsHappy.isHappy("aabb"));
    }

    @Test
    void isHappy_fiveCharactersWithDuplicates_returnsFalse() {
        assertFalse(IsHappy.isHappy("aabca"));
    }

    @Test
    void isHappy_fiveCharactersAllSame_returnsFalse() {
        assertFalse(IsHappy.isHappy("aaaaa"));
    }

    @Test
    void isHappy_longStringWithDuplicates_returnsFalse() {
        assertFalse(IsHappy.isHappy("abcdefghijkla"));
    }

    @Test
    void isHappy_longStringWithoutDuplicates_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcdefghijklm"));
    }

    @Test
    void isHappy_stringWithDuplicateAtBeginning_returnsFalse() {
        assertFalse(IsHappy.isHappy("aab"));
    }

    @Test
    void isHappy_stringWithDuplicateAtEnd_returnsFalse() {
        assertFalse(IsHappy.isHappy("aba"));
    }

    @Test
    void isHappy_stringWithDuplicateInMiddle_returnsFalse() {
        assertFalse(IsHappy.isHappy("abcabc"));
    }

    @Test
    void isHappy_stringWithOnlyTwoDistinctChars_returnsFalse() {
        assertFalse(IsHappy.isHappy("ababab"));
    }

    @Test
    void isHappy_stringWithTwoDistinctCharsAndLengthGreaterThan3_returnsFalse() {
        assertFalse(IsHappy.isHappy("abab"));
    }

    @Test
    void isHappy_stringWithThreeDistinctCharsAndLengthGreaterThan3_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcdef"));
    }

    @Test
    void isHappy_stringWithThreeDistinctCharsAndLengthGreaterThan3_returnsFalse_duplicate() {
        assertFalse(IsHappy.isHappy("abcade"));
    }

    @Test
    void isHappy_stringWithThreeDistinctCharsAndLengthGreaterThan3_returnsFalse_duplicate_end() {
        assertFalse(IsHappy.isHappy("abccde"));
    }

    @Test
    void isHappy_stringWithThreeDistinctCharsAndLengthGreaterThan3_returnsFalse_duplicate_middle() {
        assertFalse(IsHappy.isHappy("abcbde"));
    }

    @Test
    void isHappy_stringWithThreeDistinctCharsAndLengthGreaterThan3_returnsFalse_duplicate_start() {
        assertFalse(IsHappy.isHappy("aabcde"));
    }

    @Test
    void isHappy_stringWithThreeDistinctCharsAndLengthExactlyThree_returnsTrue() {
        assertTrue(IsHappy.isHappy("xyz"));
    }

    @Test
    void isHappy_stringWithThreeCharactersAllSame_returnsFalse() {
        assertFalse(IsHappy.isHappy("zzz"));
    }

    @Test
    void isHappy_stringWithThreeCharactersTwoSameOneDifferent_returnsFalse() {
        assertFalse(IsHappy.isHappy("zzy"));
    }

    @Test
    void isHappy_stringWithThreeCharactersOneSameTwoDifferent_returnsFalse() {
        assertFalse(IsHappy.isHappy("zyz"));
    }

    @Test
    void isHappy_stringWithThreeCharactersDifferent_returnsTrue() {
        assertTrue(IsHappy.isHappy("xyz"));
    }
}