package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AnyIntTest {

    @Test
    void anyInt_allIntegers_xIsSumOfOthers_returnsTrue() {
        assertTrue(AnyInt.anyInt(5, 2, 7));
    }

    @Test
    void anyInt_allIntegers_yIsSumOfOthers_returnsTrue() {
        assertTrue(AnyInt.anyInt(2, 5, 7));
    }

    @Test
    void anyInt_allIntegers_zIsSumOfOthers_returnsTrue() {
        assertTrue(AnyInt.anyInt(2, 7, 5));
    }

    @Test
    void anyInt_allIntegers_noSumMatches_returnsFalse() {
        assertFalse(AnyInt.anyInt(2, 3, 4));
    }

    @Test
    void anyInt_oneDouble_returnsFalse() {
        assertFalse(AnyInt.anyInt(2.5, 3, 5));
    }

    @Test
    void anyInt_twoDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(2.5, 3.5, 5));
    }

    @Test
    void anyInt_allDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(2.5, 3.5, 5.5));
    }

    @Test
    void anyInt_negativeNumbers_xIsSumOfOthers_returnsTrue() {
        assertTrue(AnyInt.anyInt(-1, -2, -3));
    }

    @Test
    void anyInt_negativeNumbers_yIsSumOfOthers_returnsTrue() {
        assertTrue(AnyInt.anyInt(-2, -1, -3));
    }

    @Test
    void anyInt_negativeNumbers_zIsSumOfOthers_returnsTrue() {
        assertTrue(AnyInt.anyInt(-3, -1, -2));
    }

    @Test
    void anyInt_zeroValues_returnsTrue() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_zeroAndPositive_returnsTrue() {
        assertTrue(AnyInt.anyInt(5, 5, 0));
    }

    @Test
    void anyInt_zeroAndNegative_returnsTrue() {
        assertTrue(AnyInt.anyInt(-5, -5, 0));
    }

    @Test
    void anyInt_boundaryValues_returnsTrue() {
        assertTrue(AnyInt.anyInt(100, 0, 100));
    }

    @Test
    void anyInt_boundaryValues_returnsFalse() {
        assertFalse(AnyInt.anyInt(100, 1, 98));
    }

    @Test
    void anyInt_oneIntegerOneDoubleOneInteger_returnsFalse() {
        assertFalse(AnyInt.anyInt(1, 2.5, 3));
    }

    @Test
    void anyInt_oneIntegerOneIntegerOneDouble_returnsFalse() {
        assertFalse(AnyInt.anyInt(1, 2, 3.5));
    }

    @Test
    void anyInt_negativeAndPositive_returnsTrue() {
        assertTrue(AnyInt.anyInt(1, -2, 3));
    }

    @Test
    void anyInt_minimumValidInputs_returnsTrue() {
        assertTrue(AnyInt.anyInt(-100, 0, 100));
    }

    @Test
    void anyInt_maximumValidInputs_returnsTrue() {
        assertTrue(AnyInt.anyInt(100, 100, 0));
    }

    @Test
    void anyInt_allNegative_noSumMatches_returnsFalse() {
        assertFalse(AnyInt.anyInt(-1, -2, -4));
    }
}