package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DerivativeTest {

    @Test
    void testDerivative_emptyList() {
        List<Integer> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_singleElementList() {
        List<Integer> input = Arrays.asList(1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_twoElementList() {
        List<Integer> input = Arrays.asList(3, 2);
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_threeElementList() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_example1() {
        List<Integer> input = Arrays.asList(3, 1, 2, 4, 5);
        List<Object> expected = Arrays.asList(1, 4, 12, 20);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_example2() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_example3() {
        List<Integer> input = Arrays.asList(3, 2, 1);
        List<Object> expected = Arrays.asList(2, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_example4() {
        List<Integer> input = Arrays.asList(3, 2, 1, 0, 4);
        List<Object> expected = Arrays.asList(2, 2, 0, 16);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_allZeros() {
        List<Integer> input = Arrays.asList(0, 0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_negativeCoefficients() {
        List<Integer> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(-2, -6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_mixedPositiveNegative() {
        List<Integer> input = Arrays.asList(1, -2, 3, -4);
        List<Object> expected = Arrays.asList(-2, 6, -12);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_zeroAndPositive() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3);
        List<Object> expected = Arrays.asList(1, 4, 9);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_zeroAndNegative() {
        List<Integer> input = Arrays.asList(0, -1, -2, -3);
        List<Object> expected = Arrays.asList(-1, -4, -9);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_alternatingSigns() {
        List<Integer> input = Arrays.asList(1, -1, 1, -1);
        List<Object> expected = Arrays.asList(-1, 2, -3);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_boundaryCase_smallValues() {
        List<Integer> input = Arrays.asList(1, 1, 1);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_withZeroCoefficient() {
        List<Integer> input = Arrays.asList(1, 0, 1);
        List<Object> expected = Arrays.asList(0, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_allSameValues() {
        List<Integer> input = Arrays.asList(5, 5, 5, 5);
        List<Object> expected = Arrays.asList(5, 10, 15);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testDerivative_longList() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        List<Object> expected = Arrays.asList(2, 6, 12, 20, 30, 42, 56, 72, 90);
        assertEquals(expected, Derivative.derivative(input));
    }
}