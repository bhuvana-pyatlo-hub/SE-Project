package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ParseNestedParensTest {

    @Test
    void testEmptyString() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens(""));
    }

    @Test
    void testSingleLevelParentheses() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("()"));
    }

    @Test
    void testMultipleSingleLevelParentheses() {
        List<Integer> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("() () ()"));
    }

    @Test
    void testDoubleNestedParentheses() {
        List<Integer> expected = Arrays.asList(2);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(())"));
    }

    @Test
    void testTripleNestedParentheses() {
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, ParseNestedParens.parseNestedParens("((()))"));
    }

    @Test
    void testMixedNestedParentheses() {
        List<Integer> expected = Arrays.asList(2, 3, 1, 3);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()()) ((())) () ((())()())"));
    }

    @Test
    void testIncreasingNestedParentheses() {
        List<Integer> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, ParseNestedParens.parseNestedParens("() (()) ((())) (((())))"));
    }

    @Test
    void testComplexNestedParentheses() {
        List<Integer> expected = Arrays.asList(4);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()(())((())))"));
    }

    @Test
    void testNoParentheses() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("abc"));
    }

    @Test
    void testOnlyOpenParentheses() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("((("));
    }

    @Test
    void testOnlyCloseParentheses() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens(")))"));
    }

    @Test
    void testUnbalancedParentheses() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()"));
    }

    @Test
    void testUnbalancedParentheses2() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("())"));
    }

    @Test
    void testParenthesesWithOtherCharacters() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(a)"));
    }

    @Test
    void testParenthesesWithOtherCharacters2() {
        List<Integer> expected = Arrays.asList(2);
        assertEquals(expected, ParseNestedParens.parseNestedParens("((b))"));
    }

    @Test
    void testParenthesesWithSpaceAndOtherCharacters() {
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(a) ((b))"));
    }

    @Test
    void testSingleGroupMultipleNestingLevels() {
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, ParseNestedParens.parseNestedParens("((())())"));
    }

    @Test
    void testSingleGroupMultipleNestingLevels2() {
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()(()))"));
    }

    @Test
    void testSingleGroupMultipleNestingLevels3() {
        List<Integer> expected = Arrays.asList(4);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(((())))"));
    }

    @Test
    void testSingleGroupMultipleNestingLevels4() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("()()"));
    }

    @Test
    void testSingleGroupMultipleNestingLevels5() {
        List<Integer> expected = Arrays.asList(2);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(())()"));
    }

    @Test
    void testSingleGroupWithInvalidCharacters() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("((a))b)"));
    }

    @Test
    void testNestedWithSpaces() {
        List<Integer> expected = Arrays.asList(2, 1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(() ) ()"));
    }
}