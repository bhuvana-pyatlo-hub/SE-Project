package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TriTest {

    @Test
    void tri_n0() {
        assertEquals(Arrays.asList(1), Tri.tri(0));
    }

    @Test
    void tri_n1() {
        assertEquals(Arrays.asList(1, 3), Tri.tri(1));
    }

    @Test
    void tri_n2() {
        assertEquals(Arrays.asList(1, 3, 2.0), Tri.tri(2));
    }

    @Test
    void tri_n3() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0), Tri.tri(3));
    }

    @Test
    void tri_n4() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0), Tri.tri(4));
    }

    @Test
    void tri_n5() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0), Tri.tri(5));
    }

    @Test
    void tri_n6() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0), Tri.tri(6));
    }

    @Test
    void tri_n7() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0), Tri.tri(7));
    }

    @Test
    void tri_n8() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0), Tri.tri(8));
    }

    @Test
    void tri_n9() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0), Tri.tri(9));
    }

    @Test
    void tri_n10() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0), Tri.tri(10));
    }

    @Test
    void tri_n11() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0), Tri.tri(11));
    }

    @Test
    void tri_n12() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0), Tri.tri(12));
    }

    @Test
    void tri_n13() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0), Tri.tri(13));
    }

    @Test
    void tri_n14() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0), Tri.tri(14));
    }

    @Test
    void tri_n15() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0), Tri.tri(15));
    }

    @Test
    void tri_n16() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0), Tri.tri(16));
    }

    @Test
    void tri_n17() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0), Tri.tri(17));
    }

    @Test
    void tri_n18() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0), Tri.tri(18));
    }

    @Test
    void tri_n19() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0), Tri.tri(19));
    }

    @Test
    void tri_n20() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0);
        assertEquals(expected, Tri.tri(20));
    }

    @Test
    void tri_n_negative() {
        assertEquals(Arrays.asList(1, 3), Tri.tri(-1)); // Testing for negative input
    }
}