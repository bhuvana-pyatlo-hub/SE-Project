package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LargestDivisorTest {

    @Test
    void largestDivisor_positiveNumber_returnsLargestDivisor() {
        assertEquals(5, LargestDivisor.largestDivisor(15));
    }

    @Test
    void largestDivisor_primeNumber_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(7));
    }

    @Test
    void largestDivisor_evenNumber_returnsHalf() {
        assertEquals(50, LargestDivisor.largestDivisor(100));
    }

    @Test
    void largestDivisor_numberWithMultipleDivisors_returnsLargest() {
        assertEquals(7, LargestDivisor.largestDivisor(49));
    }

    @Test
    void largestDivisor_smallNumber_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(3));
    }

    @Test
    void largestDivisor_anotherPositiveNumber_returnsLargestDivisor() {
        assertEquals(5, LargestDivisor.largestDivisor(10));
    }

    @Test
    void largestDivisor_divisibleByThree_returnsLargestDivisor() {
        assertEquals(9, LargestDivisor.largestDivisor(27));
    }

    @Test
    void largestDivisor_divisibleByFour_returnsLargestDivisor() {
        assertEquals(12, LargestDivisor.largestDivisor(48));
    }

    @Test
    void largestDivisor_divisibleByFive_returnsLargestDivisor() {
        assertEquals(20, LargestDivisor.largestDivisor(100));
    }

    @Test
    void largestDivisor_divisibleBySix_returnsLargestDivisor() {
        assertEquals(12, LargestDivisor.largestDivisor(36));
    }

    @Test
    void largestDivisor_divisibleBySeven_returnsLargestDivisor() {
        assertEquals(8, LargestDivisor.largestDivisor(64));
    }

    @Test
    void largestDivisor_divisibleByEight_returnsLargestDivisor() {
        assertEquals(10, LargestDivisor.largestDivisor(80));
    }

    @Test
    void largestDivisor_divisibleByNine_returnsLargestDivisor() {
        assertEquals(10, LargestDivisor.largestDivisor(90));
    }

    @Test
    void largestDivisor_edgeCase_zero_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(0));
    }

    @Test
    void largestDivisor_negativeNumber_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(-10));
    }

    @Test
    void largestDivisor_boundaryValue_one_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(1));
    }

    @Test
    void largestDivisor_boundaryValue_two_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(2));
    }
}