package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ReverseDeleteTest {

    @Test
    void reverseDelete_emptyC() {
        List<Object> result = ReverseDelete.reverseDelete("abcde", "");
        assertEquals("abcde", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_emptyS() {
        List<Object> result = ReverseDelete.reverseDelete("", "a");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_bothEmpty() {
        List<Object> result = ReverseDelete.reverseDelete("", "");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_singleCharMatch() {
        List<Object> result = ReverseDelete.reverseDelete("a", "a");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_singleCharNoMatch() {
        List<Object> result = ReverseDelete.reverseDelete("a", "b");
        assertEquals("a", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_palindromeAfterDeletion() {
        List<Object> result = ReverseDelete.reverseDelete("abcdedcba", "ab");
        assertEquals("cdedc", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_notPalindromeAfterDeletion() {
        List<Object> result = ReverseDelete.reverseDelete("abcde", "ae");
        assertEquals("bcd", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_noCharsToDelete() {
        List<Object> result = ReverseDelete.reverseDelete("abcde", "f");
        assertEquals("abcde", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_allCharsToDelete() {
        List<Object> result = ReverseDelete.reverseDelete("abc", "abc");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_someCharsToDelete() {
        List<Object> result = ReverseDelete.reverseDelete("abcdef", "b");
        assertEquals("acdef", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_multipleCharsInC() {
        List<Object> result = ReverseDelete.reverseDelete("hello", "elo");
        assertEquals("h", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_cLongerThanS() {
        List<Object> result = ReverseDelete.reverseDelete("a", "abcdefg");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_sWithRepeatedChars() {
        List<Object> result = ReverseDelete.reverseDelete("aabbcc", "a");
        assertEquals("bbcc", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_cWithRepeatedChars() {
        List<Object> result = ReverseDelete.reverseDelete("abc", "aabbcc");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_boundaryCase_singleCharPalindrome() {
        List<Object> result = ReverseDelete.reverseDelete("a", "");
        assertEquals("a", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_boundaryCase_twoCharPalindrome() {
        List<Object> result = ReverseDelete.reverseDelete("aa", "");
        assertEquals("aa", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_boundaryCase_twoCharNotPalindrome() {
        List<Object> result = ReverseDelete.reverseDelete("ab", "");
        assertEquals("ab", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_realisticCase1() {
        List<Object> result = ReverseDelete.reverseDelete("dwik", "w");
        assertEquals("dik", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_realisticCase2() {
        List<Object> result = ReverseDelete.reverseDelete("vabba", "v");
        assertEquals("abba", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_realisticCase3() {
        List<Object> result = ReverseDelete.reverseDelete("mamma", "mia");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_noDeletionNeeded_isPalindrome() {
        List<Object> result = ReverseDelete.reverseDelete("madam", "z");
        assertEquals("madam", result.get(0));
        assertEquals(true, result.get(1));
    }

    @Test
    void reverseDelete_noDeletionNeeded_notPalindrome() {
        List<Object> result = ReverseDelete.reverseDelete("levelk", "z");
        assertEquals("levelk", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_edgeCase_negativeInput() {
        List<Object> result = ReverseDelete.reverseDelete("abcde", "c");
        assertEquals("abde", result.get(0));
        assertEquals(false, result.get(1));
    }

    @Test
    void reverseDelete_edgeCase_zeroInput() {
        List<Object> result = ReverseDelete.reverseDelete("0", "0");
        assertEquals("", result.get(0));
        assertEquals(true, result.get(1));
    }
}