package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FizzBuzzTest {

    @Test
    void fizzBuzz_nIsZero_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(0));
    }

    @Test
    void fizzBuzz_nIsOne_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(1));
    }

    @Test
    void fizzBuzz_nIsEleven_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(11));
    }

    @Test
    void fizzBuzz_nIsTwelve_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(12));
    }

    @Test
    void fizzBuzz_nIsThirteen_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(13));
    }

    @Test
    void fizzBuzz_nIsFourteen_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(14));
    }

    @Test
    void fizzBuzz_nIsSeventySeven_returnsOne() {
        assertEquals(1, FizzBuzz.fizzBuzz(77));
    }

    @Test
    void fizzBuzz_nIsSeventyEight_returnsTwo() {
        assertEquals(2, FizzBuzz.fizzBuzz(78));
    }

    @Test
    void fizzBuzz_nIsSeventyNine_returnsThree() {
        assertEquals(3, FizzBuzz.fizzBuzz(79));
    }

    @Test
    void fizzBuzz_nIsEighty_returnsThree() {
        assertEquals(3, FizzBuzz.fizzBuzz(80));
    }

    @Test
    void fizzBuzz_nIsNinetyOne_returnsThree() {
        assertEquals(3, FizzBuzz.fizzBuzz(91));
    }

    @Test
    void fizzBuzz_nIsOneHundred_returnsThree() {
        assertEquals(3, FizzBuzz.fizzBuzz(100));
    }

    @Test
    void fizzBuzz_nIsOneHundredAndFortyThree_returnsFour() {
        assertEquals(4, FizzBuzz.fizzBuzz(143));
    }

    @Test
    void fizzBuzz_nIsOneHundredAndFiftyFour_returnsFive() {
        assertEquals(5, FizzBuzz.fizzBuzz(154));
    }

    @Test
    void fizzBuzz_nIsTwoHundred_returnsSix() {
        assertEquals(6, FizzBuzz.fizzBuzz(200));
    }

    @Test
    void fizzBuzz_nIsNegativeValue_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(-10));
    }

    @Test
    void fizzBuzz_nIsNegativeBoundaryValue_returnsZero() {
        assertEquals(0, FizzBuzz.fizzBuzz(-1));
    }
}