package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountDistinctCharactersTest {

    @Test
    void testEmptyString() {
        assertEquals(0, CountDistinctCharacters.countDistinctCharacters(""));
    }

    @Test
    void testSingleCharacter() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("a"));
    }

    @Test
    void testSingleCharacterUppercase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("A"));
    }

    @Test
    void testAllSameCharactersLowercase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aaaa"));
    }

    @Test
    void testAllSameCharactersUppercase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("AAAA"));
    }

    @Test
    void testAllSameCharactersMixedCase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aAaA"));
    }

    @Test
    void testDistinctCharactersLowercase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcde"));
    }

    @Test
    void testDistinctCharactersUppercase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("ABCDE"));
    }

    @Test
    void testDistinctCharactersMixedCase() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("aBcDe"));
    }

    @Test
    void testStringWithSpaces() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("a b c"));
    }

    @Test
    void testStringWithNumbers() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("a1b"));
    }

    @Test
    void testStringWithSpecialCharacters() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("a!b"));
    }

    @Test
    void testStringWithMixedCharacters() {
        assertEquals(7, CountDistinctCharacters.countDistinctCharacters("a1b!CdE"));
    }

    @Test
    void testStringWithRepeatedCharactersLowercase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("aabbcc"));
    }

    @Test
    void testStringWithRepeatedCharactersUppercase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("AABBCC"));
    }

    @Test
    void testStringWithRepeatedCharactersMixedCase() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("AaBbCc"));
    }

    @Test
    void testStringWithRepeatedCharactersAndSpaces() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("aa bb cc "));
    }

    @Test
    void testStringWithRepeatedCharactersAndNumbers() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("aa11bb22"));
    }

    @Test
    void testStringWithRepeatedCharactersAndSpecialCharacters() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("aa!!bb@@"));
    }

    @Test
    void testStringWithMixedRepeatedCharacters() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("aA1!bB2@"));
    }

    @Test
    void testExample1() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("xyzXYZ"));
    }

    @Test
    void testExample2() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("Jerry"));
    }

    @Test
    void testExample3() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcdecadeCADE"));
    }

    @Test
    void testExample4() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("Jerry jERRY JeRRRY"));
    }

    @Test
    void testStringWithOnlySpaces() {
        assertEquals(0, CountDistinctCharacters.countDistinctCharacters("   "));
    }

    @Test
    void testStringWithMixedSpacesAndCharacters() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters(" a b c d e "));
    }

    @Test
    void testStringWithAllCharacters() {
        assertEquals(26, CountDistinctCharacters.countDistinctCharacters("abcdefghijklmnopqrstuvwxyz"));
    }

    @Test
    void testStringWithAllUppercaseCharacters() {
        assertEquals(26, CountDistinctCharacters.countDistinctCharacters("ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
    }
}