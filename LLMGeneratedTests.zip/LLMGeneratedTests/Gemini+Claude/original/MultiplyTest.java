package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MultiplyTest {

    @Test
    void multiply_positiveNumbers_returnsCorrectProduct() {
        assertEquals(16, Multiply.multiply(148, 412));
    }

    @Test
    void multiply_positiveNumbersDifferentDigits_returnsCorrectProduct() {
        assertEquals(72, Multiply.multiply(19, 28));
    }

    @Test
    void multiply_oneNumberEndsInZero_returnsZero() {
        assertEquals(0, Multiply.multiply(2020, 1851));
    }

    @Test
    void multiply_oneNumberNegative_returnsCorrectProduct() {
        assertEquals(20, Multiply.multiply(14, -15));
    }

    @Test
    void multiply_bothNumbersNegative_returnsCorrectProduct() {
        assertEquals(20, Multiply.multiply(-14, -15));
    }

    @Test
    void multiply_bothNumbersPositive_returnsCorrectProduct2() {
        assertEquals(42, Multiply.multiply(76, 67));
    }

    @Test
    void multiply_bothNumbersPositive_returnsCorrectProduct3() {
        assertEquals(49, Multiply.multiply(17, 27));
    }

    @Test
    void multiply_oneNumberZero_returnsZero() {
        assertEquals(0, Multiply.multiply(0, 1));
    }

    @Test
    void multiply_bothNumbersZero_returnsZero() {
        assertEquals(0, Multiply.multiply(0, 0));
    }

    @Test
    void multiply_oneNumberNegativeZero_returnsZero() {
        assertEquals(0, Multiply.multiply(-0, 1));
    }

    @Test
    void multiply_bothNumbersNegativeZero_returnsZero() {
        assertEquals(0, Multiply.multiply(-0, -0));
    }

    @Test
    void multiply_oneNumberNegative_returnsCorrectProduct2() {
        assertEquals(0, Multiply.multiply(10, -10));
    }

    @Test
    void multiply_oneNumberNegative_returnsCorrectProduct3() {
        assertEquals(0, Multiply.multiply(-10, 10));
    }

    @Test
    void multiply_oneNumberNegative_returnsCorrectProduct4() {
        assertEquals(1, Multiply.multiply(-11, 11));
    }

    @Test
    void multiply_oneNumberNegative_returnsCorrectProduct5() {
        assertEquals(1, Multiply.multiply(11, -11));
    }

    @Test
    void multiply_smallPositiveNumbers_returnsCorrectProduct() {
        assertEquals(4, Multiply.multiply(2, 2));
    }

    @Test
    void multiply_smallNegativeNumbers_returnsCorrectProduct() {
        assertEquals(4, Multiply.multiply(-2, -2));
    }

    @Test
    void multiply_smallPositiveNegativeNumbers_returnsCorrectProduct() {
        assertEquals(4, Multiply.multiply(2, -2));
    }

    @Test
    void multiply_smallNegativePositiveNumbers_returnsCorrectProduct() {
        assertEquals(4, Multiply.multiply(-2, 2));
    }

    @Test
    void multiply_boundaryValues_returnsCorrectProduct() {
        assertEquals(0, Multiply.multiply(-100, 100));
        assertEquals(0, Multiply.multiply(100, -100));
        assertEquals(0, Multiply.multiply(0, -100));
        assertEquals(0, Multiply.multiply(0, 100));
    }

    @Test
    void multiply_largeNumbers_returnsCorrectProduct() {
        assertEquals(9, Multiply.multiply(109, 219));
    }
}