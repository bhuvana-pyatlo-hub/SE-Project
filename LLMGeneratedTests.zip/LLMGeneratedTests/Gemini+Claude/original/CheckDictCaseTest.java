package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CheckDictCaseTest {

    @Test
    void checkDictCase_emptyDict_returnsFalse() {
        Map<String, String> emptyDict = new HashMap<>();
        assertFalse(CheckDictCase.checkDictCase(emptyDict));
    }

    @Test
    void checkDictCase_allLowercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("b", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allUppercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("A", "apple");
        dict.put("B", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCase_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_nonStringKey_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put(8, "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_nullInput_returnsFalse() {
        assertFalse(CheckDictCase.checkDictCase(null));
    }

    @Test
    void checkDictCase_notAMap_returnsFalse() {
        assertFalse(CheckDictCase.checkDictCase("not a map"));
    }

    @Test
    void checkDictCase_singleLowercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a", "apple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_singleUppercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("A", "apple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCaseAndNonString_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("a", "apple");
        dict.put("A", "banana");
        dict.put(1, "orange");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allLowercaseWithNumbers_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a1", "apple");
        dict.put("b2", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_allUppercaseWithNumbers_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("A1", "apple");
        dict.put("B2", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedCaseWithNumbers_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("a1", "apple");
        dict.put("A2", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_emptyStringKey_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("", "apple");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_emptyStringKeyMixedCase_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("", "apple");
        dict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_specialCharactersLowercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "apple");
        dict.put("$%^", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_specialCharactersUppercase_returnsTrue() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "apple");
        dict.put("$%^", "banana");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_mixedSpecialCharacters_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put("!@#", "apple");
        dict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_oneKeyAllLowerRestNonString_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("abc", "value");
        dict.put(123, "value2");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_oneKeyAllUpperRestNonString_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("ABC", "value");
        dict.put(123, "value2");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_boundaryValues_returnsFalse() {
        Map<Object, String> dict = new HashMap<>();
        dict.put("", "apple");
        dict.put(" ", "banana");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void checkDictCase_singleSpaceKey_returnsFalse() {
        Map<String, String> dict = new HashMap<>();
        dict.put(" ", "apple");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }
}