package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class WillItFlyTest {

    @Test
    void willItFly_emptyList_returnsTrue() {
        assertTrue(WillItFly.willItFly(Collections.emptyList(), 0));
    }

    @Test
    void willItFly_singleElementList_weightSufficient_returnsTrue() {
        assertTrue(WillItFly.willItFly(Collections.singletonList(5), 5));
    }

    @Test
    void willItFly_singleElementList_weightInsufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Collections.singletonList(5), 4));
    }

    @Test
    void willItFly_balancedList_weightSufficient_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(3, 2, 3), 9));
    }

    @Test
    void willItFly_balancedList_weightInsufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(3, 2, 3), 1));
    }

    @Test
    void willItFly_unbalancedList_weightSufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2), 5));
    }

    @Test
    void willItFly_unbalancedList_weightInsufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3), 3));
    }

    @Test
    void willItFly_balancedList_zeroWeight_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 1), 0));
    }

    @Test
    void willItFly_balancedList_zeroSum_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(0, 0, 0), 1));
    }

    @Test
    void willItFly_unbalancedList_zeroSum_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(0, 1, 0), 1));
    }

    @Test
    void willItFly_balancedList_negativeWeight_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(0, 0, 0), -1));
    }

    @Test
    void willItFly_unbalancedList_negativeWeight_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3), -1));
    }

    @Test
    void willItFly_balancedList_largeWeight_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(1, 2, 1), 100));
    }

    @Test
    void willItFly_unbalancedList_largeWeight_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3), 100));
    }

    @Test
    void willItFly_balancedList_equalWeight_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(1, 2, 1), 4));
    }

    @Test
    void willItFly_unbalancedList_equalWeight_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3), 6));
    }

    @Test
    void willItFly_longBalancedList_weightSufficient_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(1, 2, 3, 4, 3, 2, 1), 20));
    }

    @Test
    void willItFly_longUnbalancedList_weightSufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3, 4, 5, 6, 7), 30));
    }

    @Test
    void willItFly_longBalancedList_weightInsufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(1, 2, 3, 4, 3, 2, 1), 10));
    }

    @Test
    void willItFly_listWithNegativeNumbers_balanced_weightSufficient_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(-1, 2, -1), 1));
    }

    @Test
    void willItFly_listWithNegativeNumbers_balanced_weightInsufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(-1, 2, -1), -1));
    }

    @Test
    void willItFly_listWithNegativeNumbers_unbalanced_weightSufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(-1, 2, 1), 2));
    }

    @Test
    void willItFly_balancedList_withNegativeAndZero_weightSufficient_returnsTrue() {
        assertTrue(WillItFly.willItFly(Arrays.asList(-1, 0, -1), 0));
    }

    @Test
    void willItFly_unbalancedList_withNegativeAndZero_weightInsufficient_returnsFalse() {
        assertFalse(WillItFly.willItFly(Arrays.asList(-1, 0, 1), 0));
    }
}