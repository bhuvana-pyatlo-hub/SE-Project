package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GetClosestVowelTest {

    @Test
    void getClosestVowel_emptyString() {
        assertEquals("", GetClosestVowel.getClosestVowel(""));
    }

    @Test
    void getClosestVowel_singleCharacterVowel() {
        assertEquals("", GetClosestVowel.getClosestVowel("a"));
    }

    @Test
    void getClosestVowel_singleCharacterConsonant() {
        assertEquals("", GetClosestVowel.getClosestVowel("b"));
    }

    @Test
    void getClosestVowel_twoCharacterVowelConsonant() {
        assertEquals("", GetClosestVowel.getClosestVowel("ae"));
    }

    @Test
    void getClosestVowel_twoCharacterConsonantVowel() {
        assertEquals("", GetClosestVowel.getClosestVowel("ba"));
    }

    @Test
    void getClosestVowel_yogurt() {
        assertEquals("u", GetClosestVowel.getClosestVowel("yogurt"));
    }

    @Test
    void getClosestVowel_FULL() {
        assertEquals("U", GetClosestVowel.getClosestVowel("FULL"));
    }

    @Test
    void getClosestVowel_quick() {
        assertEquals("", GetClosestVowel.getClosestVowel("quick"));
    }

    @Test
    void getClosestVowel_ab() {
        assertEquals("", GetClosestVowel.getClosestVowel("ab"));
    }

    @Test
    void getClosestVowel_bad() {
        assertEquals("a", GetClosestVowel.getClosestVowel("bad"));
    }

    @Test
    void getClosestVowel_most() {
        assertEquals("o", GetClosestVowel.getClosestVowel("most"));
    }

    @Test
    void getClosestVowel_anime() {
        assertEquals("i", GetClosestVowel.getClosestVowel("anime"));
    }

    @Test
    void getClosestVowel_Asia() {
        assertEquals("", GetClosestVowel.getClosestVowel("Asia"));
    }

    @Test
    void getClosestVowel_Above() {
        assertEquals("o", GetClosestVowel.getClosestVowel("Above"));
    }

    @Test
    void getClosestVowel_easy() {
        assertEquals("", GetClosestVowel.getClosestVowel("easy"));
    }

    @Test
    void getClosestVowel_eAsy() {
        assertEquals("", GetClosestVowel.getClosestVowel("eAsy"));
    }

    @Test
    void getClosestVowel_ali() {
        assertEquals("", GetClosestVowel.getClosestVowel("ali"));
    }

    @Test
    void getClosestVowel_consonantVowelConsonant() {
        assertEquals("a", GetClosestVowel.getClosestVowel("bab"));
    }

    @Test
    void getClosestVowel_multipleVowels() {
        assertEquals("i", GetClosestVowel.getClosestVowel("strinGi"));
    }

    @Test
    void getClosestVowel_noVowelsBetweenConsonants() {
        assertEquals("", GetClosestVowel.getClosestVowel("strength"));
    }

    @Test
    void getClosestVowel_vowelAtBeginningAndEnd() {
        assertEquals("", GetClosestVowel.getClosestVowel("apple"));
    }

    @Test
    void getClosestVowel_allConsonants() {
        assertEquals("", GetClosestVowel.getClosestVowel("bcdfgh"));
    }

    @Test
    void getClosestVowel_allVowels() {
        assertEquals("", GetClosestVowel.getClosestVowel("aeiouAEIOU"));
    }

    @Test
    void getClosestVowel_mixedCase() {
        assertEquals("e", GetClosestVowel.getClosestVowel("bEdb"));
    }

    @Test
    void getClosestVowel_longWord() {
        assertEquals("o", GetClosestVowel.getClosestVowel("longwordwithvowels"));
    }

    @Test
    void getClosestVowel_boundaryCase() {
        assertEquals("", GetClosestVowel.getClosestVowel("aA"));
    }

    @Test
    void getClosestVowel_negativeValues() {
        assertEquals("", GetClosestVowel.getClosestVowel("!@#"));
    }
}