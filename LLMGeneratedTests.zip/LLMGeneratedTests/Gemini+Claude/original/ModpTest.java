package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ModpTest {

    @Test
    void modp_n3_p5() {
        assertEquals(3, Modp.modp(3, 5));
    }

    @Test
    void modp_n1101_p101() {
        assertEquals(2, Modp.modp(1101, 101));
    }

    @Test
    void modp_n0_p101() {
        assertEquals(1, Modp.modp(0, 101));
    }

    @Test
    void modp_n3_p11() {
        assertEquals(8, Modp.modp(3, 11));
    }

    @Test
    void modp_n100_p101() {
        assertEquals(1, Modp.modp(100, 101));
    }

    @Test
    void modp_n30_p5() {
        assertEquals(4, Modp.modp(30, 5));
    }

    @Test
    void modp_n31_p5() {
        assertEquals(3, Modp.modp(31, 5));
    }

    @Test
    void modp_n1_p2() {
        assertEquals(0, Modp.modp(1, 2));
    }

    @Test
    void modp_n2_p3() {
        assertEquals(1, Modp.modp(2, 3));
    }

    @Test
    void modp_n5_p7() {
        assertEquals(4, Modp.modp(5, 7));
    }

    @Test
    void modp_n10_p13() {
        assertEquals(12, Modp.modp(10, 13));
    }

    @Test
    void modp_n15_p17() {
        assertEquals(16, Modp.modp(15, 17));
    }

    @Test
    void modp_n20_p23() {
        assertEquals(1, Modp.modp(20, 23));
    }

    @Test
    void modp_n25_p29() {
        assertEquals(4, Modp.modp(25, 29));
    }

    @Test
    void modp_n30_p31() {
        assertEquals(1, Modp.modp(30, 31));
    }

    @Test
    void modp_n100_p3() {
        assertEquals(1, Modp.modp(100, 3));
    }

    @Test
    void modp_n100_p5() {
        assertEquals(1, Modp.modp(100, 5));
    }

    @Test
    void modp_n100_p7() {
        assertEquals(2, Modp.modp(100, 7));
    }

    @Test
    void modp_n100_p11() {
        assertEquals(3, Modp.modp(100, 11));
    }

    @Test
    void modp_n100_p13() {
        assertEquals(9, Modp.modp(100, 13));
    }

    @Test
    void modp_n100_p17() {
        assertEquals(16, Modp.modp(100, 17));
    }

    @Test
    void modp_n99_p99() {
        assertEquals(0, Modp.modp(99, 99));
    }

    @Test
    void modp_n1_p5() {
        assertEquals(1, Modp.modp(-1, 5)); // Testing negative n
    }

    @Test
    void modp_n50_p1() {
        assertEquals(0, Modp.modp(50, 1)); // Testing p = 1
    }

    @Test
    void modp_n100_p0() {
        assertThrows(ArithmeticException.class, () -> Modp.modp(100, 0)); // Testing p = 0
    }
}