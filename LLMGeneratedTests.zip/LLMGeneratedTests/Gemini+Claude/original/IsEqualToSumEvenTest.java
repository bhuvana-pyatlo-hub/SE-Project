package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsEqualToSumEvenTest {

    @Test
    void isEqualToSumEven_lessThan8_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(4));
    }

    @Test
    void isEqualToSumEven_equalTo8_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(8));
    }

    @Test
    void isEqualToSumEven_equalTo10_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(10));
    }

    @Test
    void isEqualToSumEven_equalTo12_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(12));
    }

    @Test
    void isEqualToSumEven_equalTo16_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(16));
    }

    @Test
    void isEqualToSumEven_equalTo6_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(6));
    }

    @Test
    void isEqualToSumEven_equalTo11_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(11));
    }

    @Test
    void isEqualToSumEven_equalTo13_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(13));
    }

    @Test
    void isEqualToSumEven_equalTo7_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(7));
    }

    @Test
    void isEqualToSumEven_equalTo9_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(9));
    }

    @Test
    void isEqualToSumEven_equalTo14_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(14));
    }

    @Test
    void isEqualToSumEven_equalTo15_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(15));
    }

    @Test
    void isEqualToSumEven_equalTo17_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(17));
    }

    @Test
    void isEqualToSumEven_equalTo18_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(18));
    }

    @Test
    void isEqualToSumEven_equalTo19_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(19));
    }

    @Test
    void isEqualToSumEven_equalTo20_returnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(20));
    }

    @Test
    void isEqualToSumEven_equalTo0_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(0));
    }

    @Test
    void isEqualToSumEven_equalTo1_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(1));
    }

    @Test
    void isEqualToSumEven_equalTo2_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(2));
    }

    @Test
    void isEqualToSumEven_equalTo3_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(3));
    }

    @Test
    void isEqualToSumEven_equalTo5_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(5));
    }

    @Test
    void isEqualToSumEven_negativeValue_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-2));
    }

    @Test
    void isEqualToSumEven_negativeEvenValue_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-8));
    }

    @Test
    void isEqualToSumEven_negativeOddValue_returnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-7));
    }
}