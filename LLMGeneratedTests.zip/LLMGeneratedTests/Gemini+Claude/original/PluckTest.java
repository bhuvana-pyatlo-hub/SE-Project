package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PluckTest {

    @Test
    void pluck_emptyArray_returnsEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_noEvenNumbers_returnsEmptyList() {
        List<Object> input = Arrays.asList(1, 3, 5, 7);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_singleEvenNumber_returnsListWithValueAndIndex() {
        List<Object> input = Arrays.asList(1, 2, 3, 5);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_multipleEvenNumbers_returnsListWithSmallestValueAndIndex() {
        List<Object> input = Arrays.asList(4, 2, 3);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_multipleSameSmallestEvenNumbers_returnsListWithFirstIndex() {
        List<Object> input = Arrays.asList(5, 0, 3, 0, 4, 2);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_zeroAsSmallestEvenNumber_returnsListWithValueAndIndex() {
        List<Object> input = Arrays.asList(1, 0, 3, 5);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_onlyEvenNumbers_returnsListWithSmallestValueAndIndex() {
        List<Object> input = Arrays.asList(4, 2, 6, 8);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_mixedDataTypes_handlesIntegerValuesCorrectly() {
        List<Object> input = Arrays.asList(1, 2, "string", 4, 5.0);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_onlyOddNumbersAndStrings_returnsEmptyList() {
        List<Object> input = Arrays.asList(1, 3, "string", 5.0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithNegativeNumbers_ignoresNegativeNumbers() {
        List<Object> input = Arrays.asList(-2, 1, 4, 2);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithOnlyOneElement_returnsCorrectResult() {
        List<Object> input = Arrays.asList(2);
        List<Object> expected = Arrays.asList(2, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithOnlyOneOddElement_returnsEmptyList() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithMultipleOccurrencesOfZero_returnsFirstOccurrence() {
        List<Object> input = Arrays.asList(0, 1, 0, 3);
        List<Object> expected = Arrays.asList(0, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithZeroAndOtherEvenNumbers_returnsZero() {
        List<Object> input = Arrays.asList(2, 0, 4, 6);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithNullValues_ignoresNullValues() {
        List<Object> input = Arrays.asList(null, 2, 4);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithOnlyNullValues_returnsEmptyList() {
        List<Object> input = Arrays.asList(null, null, null);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithIntegerMaxValue_handlesCorrectly() {
        List<Object> input = Arrays.asList(Integer.MAX_VALUE, 2, 4);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithIntegerMinValue_ignoresIt() {
        List<Object> input = Arrays.asList(Integer.MIN_VALUE, 2, 4);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_largeArrayWithEvenNumbers_returnsCorrectResult() {
        List<Object> input = Arrays.asList(1, 3, 5, 2, 7, 9, 4, 6, 8, 0);
        List<Object> expected = Arrays.asList(0, 9);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_arrayWithLargeEvenNumbers_returnsSmallestEvenNumber() {
        List<Object> input = Arrays.asList(100, 200, 50, 300);
        List<Object> expected = Arrays.asList(50, 2);
        assertEquals(expected, Pluck.pluck(input));
    }
}