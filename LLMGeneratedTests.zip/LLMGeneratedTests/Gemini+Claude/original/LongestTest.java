package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LongestTest {

    @Test
    void longest_emptyList_returnsNull() {
        List<Object> strings = new ArrayList<>();
        assertNull(Longest.longest(strings));
    }

    @Test
    void longest_singleElementList_returnsElement() {
        List<Object> strings = Arrays.asList("a");
        assertEquals("a", Longest.longest(strings));
    }

    @Test
    void longest_multipleElements_returnsLongest() {
        List<Object> strings = Arrays.asList("a", "bb", "ccc");
        assertEquals("ccc", Longest.longest(strings));
    }

    @Test
    void longest_multipleElementsSameLength_returnsFirst() {
        List<Object> strings = Arrays.asList("x", "y", "z");
        assertEquals("x", Longest.longest(strings));
    }

    @Test
    void longest_mixedLengths_returnsLongest() {
        List<Object> strings = Arrays.asList("x", "yyy", "zzzz", "www", "kkkk", "abc");
        assertEquals("zzzz", Longest.longest(strings));
    }

    @Test
    void longest_numbersAsStrings_returnsLongest() {
        List<Object> strings = Arrays.asList("1", "12", "123");
        assertEquals("123", Longest.longest(strings));
    }

    @Test
    void longest_emptyStringInList_returnsLongestNonEmpty() {
        List<Object> strings = Arrays.asList("", "abc", "de");
        assertEquals("abc", Longest.longest(strings));
    }

    @Test
    void longest_allEmptyStrings_returnsFirstEmpty() {
        List<Object> strings = Arrays.asList("", "", "");
        assertEquals("", Longest.longest(strings));
    }

    @Test
    void longest_nullObjectInList_returnsLongest() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("abc");
        assertEquals("abc", Longest.longest(strings));
    }

    @Test
    void longest_listWithIntegers_returnsLongest() {
        List<Object> strings = Arrays.asList(1, 12, 123);
        assertEquals("123", Longest.longest(strings));
    }

    @Test
    void longest_listWithMixedTypes_returnsLongest() {
        List<Object> strings = Arrays.asList("a", 12, "cde");
        assertEquals("cde", Longest.longest(strings));
    }

    @Test
    void longest_listWithSpecialCharacters_returnsLongest() {
        List<Object> strings = Arrays.asList("!", "!!", "!!!", " ");
        assertEquals("!!!", Longest.longest(strings));
    }

    @Test
    void longest_listWithSameLengthStrings_returnsFirst() {
        List<Object> strings = Arrays.asList("aa", "bb", "cc");
        assertEquals("aa", Longest.longest(strings));
    }

    @Test
    void longest_listWithOneElementNull_returnsNullString() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        assertEquals("null", Longest.longest(strings));
    }

    @Test
    void longest_listWithNullAndEmptyString_returnsLongest() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("");
        assertEquals("null", Longest.longest(strings));
    }

    @Test
    void longest_listWithNullAndNonEmptyString_returnsLongest() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("abc");
        assertEquals("abc", Longest.longest(strings));
    }

    @Test
    void longest_listWithMultipleNulls_returnsFirstNullString() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add(null);
        assertEquals("null", Longest.longest(strings));
    }

    @Test
    void longest_listWithNullAndSameLengthString_returnsString() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("nu");
        assertEquals("null", Longest.longest(strings));
    }

    @Test
    void longest_listWithNullAndLongerString_returnsString() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("nulls");
        assertEquals("nulls", Longest.longest(strings));
    }

    @Test
    void longest_listWithOnlyNulls_returnsFirstNullString() {
        List<Object> strings = Arrays.asList(null, null, null);
        assertEquals("null", Longest.longest(strings));
    }

    @Test
    void longest_boundaryValues_returnsLongest() {
        List<Object> strings = Arrays.asList("a", "ab", "abc", "abcd", "abcde");
        assertEquals("abcde", Longest.longest(strings));
    }

    @Test
    void longest_negativeValues_returnsLongest() {
        List<Object> strings = Arrays.asList(-1, -12, -123);
        assertEquals("-123", Longest.longest(strings));
    }

    @Test
    void longest_zeroValue_returnsLongest() {
        List<Object> strings = Arrays.asList(0, 1, 2);
        assertEquals("2", Longest.longest(strings));
    }
}