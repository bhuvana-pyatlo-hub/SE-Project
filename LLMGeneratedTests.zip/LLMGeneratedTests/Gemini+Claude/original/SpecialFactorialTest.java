package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SpecialFactorialTest {

    @Test
    void specialFactorial_zero_returnsOne() {
        assertEquals(1, SpecialFactorial.specialFactorial(0));
    }

    @Test
    void specialFactorial_one_returnsOne() {
        assertEquals(1, SpecialFactorial.specialFactorial(1));
    }

    @Test
    void specialFactorial_two_returnsTwo() {
        assertEquals(2, SpecialFactorial.specialFactorial(2));
    }

    @Test
    void specialFactorial_three_returnsTwelve() {
        assertEquals(12, SpecialFactorial.specialFactorial(3));
    }

    @Test
    void specialFactorial_four_returnsCorrectResult() {
        assertEquals(288, SpecialFactorial.specialFactorial(4));
    }

    @Test
    void specialFactorial_five_returnsCorrectResult() {
        assertEquals(34560, SpecialFactorial.specialFactorial(5));
    }

    @Test
    void specialFactorial_six_returnsCorrectResult() {
        assertEquals(40320, SpecialFactorial.specialFactorial(6)); // 720 * 5040
    }

    @Test
    void specialFactorial_seven_returnsCorrectResult() {
        assertEquals(125411328000L, SpecialFactorial.specialFactorial(7));
    }

    @Test
    void specialFactorial_eight_returnsCorrectResult() {
        assertEquals(20922789888000L, SpecialFactorial.specialFactorial(8));
    }

    @Test
    void specialFactorial_nine_returnsCorrectResult() {
        assertEquals(752476579840000L, SpecialFactorial.specialFactorial(9));
    }

    @Test
    void specialFactorial_negativeInput_throwsIllegalArgumentException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SpecialFactorial.specialFactorial(-1);
        });
        assertEquals("Input must be non-negative", exception.getMessage());
    }

    @Test
    void specialFactorial_boundaryNegativeInput_throwsIllegalArgumentException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            SpecialFactorial.specialFactorial(-100);
        });
        assertEquals("Input must be non-negative", exception.getMessage());
    }
}