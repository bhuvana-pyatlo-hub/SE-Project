package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TriangleAreaTest {

    @Test
    void testTriangleArea_validInput_positiveValues() {
        assertEquals(7.5, TriangleArea.triangleArea(5, 3));
    }

    @Test
    void testTriangleArea_validInput_smallValues() {
        assertEquals(2.0, TriangleArea.triangleArea(2, 2));
    }

    @Test
    void testTriangleArea_validInput_largerValues() {
        assertEquals(40.0, TriangleArea.triangleArea(10, 8));
    }

    @Test
    void testTriangleArea_validInput_one() {
        assertEquals(0.5, TriangleArea.triangleArea(1, 1));
    }

    @Test
    void testTriangleArea_validInput_zeroHeight() {
        assertEquals(0.0, TriangleArea.triangleArea(5, 0));
    }

    @Test
    void testTriangleArea_validInput_zeroBase() {
        assertEquals(0.0, TriangleArea.triangleArea(0, 5));
    }

    @Test
    void testTriangleArea_validInput_zeroBoth() {
        assertEquals(0.0, TriangleArea.triangleArea(0, 0));
    }

    @Test
    void testTriangleArea_validInput_differentValues() {
        assertEquals(12.5, TriangleArea.triangleArea(5, 5));
    }

    @Test
    void testTriangleArea_validInput_baseGreaterThanHeight() {
        assertEquals(15.0, TriangleArea.triangleArea(6, 5));
    }

    @Test
    void testTriangleArea_validInput_heightGreaterThanBase() {
        assertEquals(15.0, TriangleArea.triangleArea(5, 6));
    }

    @Test
    void testTriangleArea_validInput_largeBaseSmallHeight() {
        assertEquals(5.0, TriangleArea.triangleArea(10, 1));
    }

    @Test
    void testTriangleArea_validInput_smallBaseLargeHeight() {
        assertEquals(5.0, TriangleArea.triangleArea(1, 10));
    }

    @Test
    void testTriangleArea_validInput_mediumValues() {
        assertEquals(100.0, TriangleArea.triangleArea(20, 10));
    }

    @Test
    void testTriangleArea_validInput_sameMediumValues() {
        assertEquals(200.0, TriangleArea.triangleArea(20, 20));
    }

    @Test
    void testTriangleArea_validInput_closeToZero() {
        assertEquals(0.5, TriangleArea.triangleArea(1, 1));
    }

    @Test
    void testTriangleArea_validInput_anotherSet() {
        assertEquals(17.5, TriangleArea.triangleArea(7, 5));
    }

    @Test
    void testTriangleArea_validInput_anotherSet2() {
        assertEquals(17.5, TriangleArea.triangleArea(5, 7));
    }

    @Test
    void testTriangleArea_validInput_evenNumbers() {
        assertEquals(18.0, TriangleArea.triangleArea(6, 6));
    }

    @Test
    void testTriangleArea_validInput_oddNumbers() {
        assertEquals(12.5, TriangleArea.triangleArea(5, 5));
    }

    @Test
    void testTriangleArea_validInput_negativeBase() {
        assertEquals(-25.0, TriangleArea.triangleArea(-10, 5));
    }

    @Test
    void testTriangleArea_validInput_negativeHeight() {
        assertEquals(-25.0, TriangleArea.triangleArea(10, -5));
    }

    @Test
    void testTriangleArea_validInput_negativeBoth() {
        assertEquals(25.0, TriangleArea.triangleArea(-10, -5));
    }

    @Test
    void testTriangleArea_validInput_largeValues() {
        assertEquals(499500.0, TriangleArea.triangleArea(100, 99));
    }
}