package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SumSquaresTest {

    @Test
    void testEmptyList() {
        List<Number> emptyList = new ArrayList<>();
        assertEquals(0, SumSquares.sumSquares(emptyList));
    }

    @Test
    void testPositiveIntegers() {
        List<Number> list = Arrays.asList(1, 2, 3);
        assertEquals(14, SumSquares.sumSquares(list));
    }

    @Test
    void testPositiveDoubles() {
        List<Number> list = Arrays.asList(1.4, 4.2, 0.0);
        assertEquals(29, SumSquares.sumSquares(list));
    }

    @Test
    void testNegativeAndPositiveNumbers() {
        List<Number> list = Arrays.asList(-2.4, 1, 1);
        assertEquals(6, SumSquares.sumSquares(list));
    }

    @Test
    void testSmallPositiveIntegers() {
        List<Number> list = Arrays.asList(2, 3, 4);
        assertEquals(29, SumSquares.sumSquares(list));
    }

    @Test
    void testNegativeDoubles() {
        List<Number> list = Arrays.asList(-1.4, 4.6, 6.3);
        assertEquals(75, SumSquares.sumSquares(list));
    }

    @Test
    void testMixedNegativeAndPositiveDoubles() {
        List<Number> list = Arrays.asList(-1.4, 17.9, 18.9, 19.9);
        assertEquals(1086, SumSquares.sumSquares(list));
    }

    @Test
    void testZero() {
        List<Number> list = Collections.singletonList(0);
        assertEquals(0, SumSquares.sumSquares(list));
    }

    @Test
    void testNegativeOne() {
        List<Number> list = Collections.singletonList(-1);
        assertEquals(1, SumSquares.sumSquares(list));
    }

    @Test
    void testNegativePositiveAndZero() {
        List<Number> list = Arrays.asList(-1, 1, 0);
        assertEquals(2, SumSquares.sumSquares(list));
    }

    @Test
    void testOnlyNegativeNumbers() {
        List<Number> list = Arrays.asList(-1.0, -2.0, -3.0);
        assertEquals(14, SumSquares.sumSquares(list));
    }

    @Test
    void testMixedIntegersAndDoubles() {
        List<Number> list = Arrays.asList(1, 2.5, 3);
        assertEquals(25, SumSquares.sumSquares(list));
    }

    @Test
    void testAllSameNumbers() {
        List<Number> list = Arrays.asList(5, 5, 5);
        assertEquals(75, SumSquares.sumSquares(list));
    }

    @Test
    void testSmallNegativeDoubles() {
        List<Number> list = Arrays.asList(-0.1, -0.2, -0.3);
        assertEquals(3, SumSquares.sumSquares(list));
    }

    @Test
    void testZeroPointFive() {
        List<Number> list = Collections.singletonList(0.5);
        assertEquals(1, SumSquares.sumSquares(list));
    }

    @Test
    void testNegativeZeroPointFive() {
        List<Number> list = Collections.singletonList(-0.5);
        assertEquals(1, SumSquares.sumSquares(list));
    }

    @Test
    void testBoundaryNegativeValues() {
        List<Number> list = Arrays.asList(-100, -99, -98);
        assertEquals(29900, SumSquares.sumSquares(list));
    }

    @Test
    void testBoundaryPositiveValues() {
        List<Number> list = Arrays.asList(100, 99, 98);
        assertEquals(29900, SumSquares.sumSquares(list));
    }
}