package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class EatTest {

    @Test
    void testEat_needLessThanRemaining() {
        List<Integer> expected = Arrays.asList(11, 4);
        assertEquals(expected, Eat.eat(5, 6, 10));
    }

    @Test
    void testEat_needGreaterThanRemaining() {
        List<Integer> expected = Arrays.asList(7, 0);
        assertEquals(expected, Eat.eat(2, 11, 5));
    }

    @Test
    void testEat_needEqualsRemaining() {
        List<Integer> expected = Arrays.asList(11, 0);
        assertEquals(expected, Eat.eat(1, 10, 10));
    }

    @Test
    void testEat_zeroNumber() {
        List<Integer> expected = Arrays.asList(6, 4);
        assertEquals(expected, Eat.eat(0, 6, 10));
    }

    @Test
    void testEat_zeroNeed() {
        List<Integer> expected = Arrays.asList(5, 10);
        assertEquals(expected, Eat.eat(5, 0, 10));
    }

    @Test
    void testEat_zeroRemaining() {
        List<Integer> expected = Arrays.asList(5, 0);
        assertEquals(expected, Eat.eat(5, 6, 0));
    }

    @Test
    void testEat_allZero() {
        List<Integer> expected = Arrays.asList(0, 0);
        assertEquals(expected, Eat.eat(0, 0, 0));
    }

    @Test
    void testEat_maxValues() {
        List<Integer> expected = Arrays.asList(1000, 0);
        assertEquals(expected, Eat.eat(0, 1000, 1000));
    }

    @Test
    void testEat_numberAtMax() {
        List<Integer> expected = Arrays.asList(1000, 5);
        assertEquals(expected, Eat.eat(1000, 0, 5));
    }

    @Test
    void testEat_needAtMax() {
        List<Integer> expected = Arrays.asList(1000, 0);
        assertEquals(expected, Eat.eat(0, 1000, 1000));
    }

    @Test
    void testEat_remainingAtMax() {
        List<Integer> expected = Arrays.asList(1000, 0);
        assertEquals(expected, Eat.eat(0, 1000, 1000));
    }

    @Test
    void testEat_numberPlusNeedExceedsRemaining() {
        List<Integer> expected = Arrays.asList(9, 0);
        assertEquals(expected, Eat.eat(4, 5, 5));
    }

    @Test
    void testEat_numberPlusNeedLessThanRemaining() {
        List<Integer> expected = Arrays.asList(9, 1);
        assertEquals(expected, Eat.eat(4, 5, 6));
    }

    @Test
    void testEat_smallValues1() {
        List<Integer> expected = Arrays.asList(5, 2);
        assertEquals(expected, Eat.eat(1, 4, 4));
    }

    @Test
    void testEat_smallValues2() {
        List<Integer> expected = Arrays.asList(5, 0);
        assertEquals(expected, Eat.eat(1, 4, 3));
    }

    @Test
    void testEat_edgeCase1() {
        List<Integer> expected = Arrays.asList(1000, 0);
        assertEquals(expected, Eat.eat(999, 1, 0));
    }

    @Test
    void testEat_edgeCase2() {
        List<Integer> expected = Arrays.asList(1000, 0);
        assertEquals(expected, Eat.eat(999, 2, 1));
    }

    @Test
    void testEat_edgeCase3() {
        List<Integer> expected = Arrays.asList(1000, 1);
        assertEquals(expected, Eat.eat(999, 0, 1));
    }

    @Test
    void testEat_sameValues() {
        List<Integer> expected = Arrays.asList(6, 0);
        assertEquals(expected, Eat.eat(2, 4, 4));
    }

    @Test
    void testEat_needIsOneRemainingIsZero() {
        List<Integer> expected = Arrays.asList(1, 0);
        assertEquals(expected, Eat.eat(0, 1, 0));
    }

    @Test
    void testEat_negativeValues() {
        List<Integer> expected = Arrays.asList(0, 0);
        assertEquals(expected, Eat.eat(-1, -1, -1));
    }
}