package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MaxFillTest {

    @Test
    void testEmptyGrid() {
        List<List<Integer>> grid = new ArrayList<>();
        int capacity = 1;
        assertEquals(0, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellNoWater() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 0));
        int capacity = 1;
        assertEquals(0, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellWithWaterCapacityOne() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1));
        int capacity = 1;
        assertEquals(3, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellWithWaterCapacityGreaterThanWater() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1));
        int capacity = 4;
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithVaryingWaterCapacityOne() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 0));
        grid.add(Arrays.asList(0, 1, 0, 0));
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 1;
        assertEquals(6, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithVaryingWaterCapacityTwo() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 1));
        grid.add(Arrays.asList(0, 0, 0, 0));
        grid.add(Arrays.asList(1, 1, 1, 1));
        grid.add(Arrays.asList(0, 1, 1, 1));
        int capacity = 2;
        assertEquals(5, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsNoWater() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 0));
        grid.add(Arrays.asList(0, 0, 0));
        int capacity = 5;
        assertEquals(0, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsFullWellsCapacityTwo() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 2;
        assertEquals(4, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsFullWellsCapacityNine() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 9;
        assertEquals(2, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellAllWater() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 1;
        assertEquals(4, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellAllWaterCapacityGreaterThanTotalWater() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 5;
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithZeroesAndOnesCapacityOne() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 1, 0, 1));
        grid.add(Arrays.asList(1, 0, 1, 0));
        int capacity = 1;
        assertEquals(4, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithZeroesAndOnesCapacityTwo() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 1, 0, 1));
        grid.add(Arrays.asList(1, 0, 1, 0));
        int capacity = 2;
        assertEquals(2, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithZeroesAndOnesCapacityThree() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 1, 0, 1));
        grid.add(Arrays.asList(1, 0, 1, 0));
        int capacity = 3;
        assertEquals(2, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithZeroesAndOnesCapacityFour() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 1, 0, 1));
        grid.add(Arrays.asList(1, 0, 1, 0));
        int capacity = 4;
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsWithZeroesAndOnesCapacityFive() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 1, 0, 1));
        grid.add(Arrays.asList(1, 0, 1, 0));
        int capacity = 5;
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellWithSingleOne() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 0));
        int capacity = 1;
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testSingleWellWithSingleOneLargeCapacity() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 0));
        int capacity = 10;
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMultipleWellsDifferentLengths() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1));
        grid.add(Arrays.asList(1, 1, 1));
        int capacity = 2;
        assertEquals(3, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testBoundaryCapacity() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 1; // Minimum capacity
        assertEquals(4, MaxFill.maxFill(grid, capacity));
    }

    @Test
    void testMaximumCapacity() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        int capacity = 10; // Maximum capacity
        assertEquals(1, MaxFill.maxFill(grid, capacity));
    }
}