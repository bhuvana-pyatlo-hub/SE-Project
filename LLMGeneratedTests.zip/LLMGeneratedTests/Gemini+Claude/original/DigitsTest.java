package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DigitsTest {

    @Test
    void testDigits_singleOddDigit() {
        assertEquals(1, Digits.digits(1));
    }

    @Test
    void testDigits_singleEvenDigit() {
        assertEquals(0, Digits.digits(4));
    }

    @Test
    void testDigits_mixedOddAndEvenDigits() {
        assertEquals(15, Digits.digits(235));
    }

    @Test
    void testDigits_singleDigitFive() {
        assertEquals(5, Digits.digits(5));
    }

    @Test
    void testDigits_evenFollowedByOdd() {
        assertEquals(5, Digits.digits(54));
    }

    @Test
    void testDigits_oddFollowedByEvenFollowedByEven() {
        assertEquals(1, Digits.digits(120));
    }

    @Test
    void testDigits_oddEvenOddEven() {
        assertEquals(5, Digits.digits(5014));
    }

    @Test
    void testDigits_multipleOddDigits() {
        assertEquals(315, Digits.digits(98765));
    }

    @Test
    void testDigits_multipleOddDigitsWithNegative() {
        assertEquals(0, Digits.digits(-5576543)); // Testing negative input
    }

    @Test
    void testDigits_allEvenDigits() {
        assertEquals(0, Digits.digits(2468));
    }

    @Test
    void testDigits_zero() {
        assertEquals(0, Digits.digits(0)); // Testing zero input
    }

    @Test
    void testDigits_one() {
        assertEquals(1, Digits.digits(1));
    }

    @Test
    void testDigits_ten() {
        assertEquals(0, Digits.digits(10));
    }

    @Test
    void testDigits_eleven() {
        assertEquals(1, Digits.digits(11));
    }

    @Test
    void testDigits_twelve() {
        assertEquals(1, Digits.digits(12));
    }

    @Test
    void testDigits_thirteen() {
        assertEquals(3, Digits.digits(13));
    }

    @Test
    void testDigits_twentyOne() {
        assertEquals(1, Digits.digits(21));
    }

    @Test
    void testDigits_thirtyFive() {
        assertEquals(15, Digits.digits(35));
    }

    @Test
    void testDigits_fiftySeven() {
        assertEquals(35, Digits.digits(57));
    }

    @Test
    void testDigits_seventyNine() {
        assertEquals(63, Digits.digits(79));
    }

    @Test
    void testDigits_ninetyOne() {
        assertEquals(1, Digits.digits(91));
    }

    @Test
    void testDigits_ninetyNine() {
        assertEquals(81, Digits.digits(99));
    }

    @Test
    void testDigits_boundaryValues() {
        assertEquals(0, Digits.digits(100)); // Testing boundary value with zero
        assertEquals(1, Digits.digits(101)); // Testing boundary value with odd digits
    }
}