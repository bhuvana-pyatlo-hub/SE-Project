package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FindClosestElementsTest {

    @Test
    void testFindClosestElements_basicCase() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2);
        List<Double> expected = Arrays.asList(3.9, 4.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_anotherBasicCase() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0);
        List<Double> expected = Arrays.asList(5.0, 5.9);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_duplicateValues() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.0);
        List<Double> expected = Arrays.asList(2.0, 2.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_closeValues() {
        List<Double> numbers = Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1);
        List<Double> expected = Arrays.asList(2.2, 3.1);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_negativeValues() {
        List<Double> numbers = Arrays.asList(-1.0, -2.0, -3.0, -4.0, -5.0);
        List<Double> expected = Arrays.asList(-2.0, -1.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_mixedPositiveNegative() {
        List<Double> numbers = Arrays.asList(-1.0, 2.0, -3.0, 4.0, -5.0);
        List<Double> expected = Arrays.asList(-1.0, 2.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_sameValueTwice() {
        List<Double> numbers = Arrays.asList(1.0, 1.0, 3.0, 4.0, 5.0);
        List<Double> expected = Arrays.asList(1.0, 1.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_smallDifference() {
        List<Double> numbers = Arrays.asList(1.0, 1.01, 3.0, 4.0, 5.0);
        List<Double> expected = Arrays.asList(1.0, 1.01);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_allSameValues() {
        List<Double> numbers = Arrays.asList(2.0, 2.0, 2.0, 2.0, 2.0);
        List<Double> expected = Arrays.asList(2.0, 2.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_sortedList() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        List<Double> expected = Arrays.asList(1.0, 2.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_reverseSortedList() {
        List<Double> numbers = Arrays.asList(5.0, 4.0, 3.0, 2.0, 1.0);
        List<Double> expected = Arrays.asList(1.0, 2.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_zeroValues() {
        List<Double> numbers = Arrays.asList(0.0, 0.0, 1.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(0.0, 0.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_oneNegativeOnePositiveClose() {
        List<Double> numbers = Arrays.asList(-0.5, 0.5, 1.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(-0.5, 0.5);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_decimalValues() {
        List<Double> numbers = Arrays.asList(1.5, 2.5, 3.5, 4.5, 5.5);
        List<Double> expected = Arrays.asList(1.5, 2.5);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }

    @Test
    void testFindClosestElements_twoElements() {
        List<Double> numbers = Arrays.asList(1.0, 2.0);
        List<Double> expected = Arrays.asList(1.0, 2.0);
        List<Double> actual = FindClosestElements.findClosestElements(numbers);
        assertEquals(expected, actual);
    }
}