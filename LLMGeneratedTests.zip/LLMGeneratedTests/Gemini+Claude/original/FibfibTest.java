package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FibfibTest {

    @Test
    void fibfib_zero() {
        assertEquals(0, Fibfib.fibfib(0));
    }

    @Test
    void fibfib_one() {
        assertEquals(0, Fibfib.fibfib(1));
    }

    @Test
    void fibfib_two() {
        assertEquals(1, Fibfib.fibfib(2));
    }

    @Test
    void fibfib_three() {
        assertEquals(1, Fibfib.fibfib(3));
    }

    @Test
    void fibfib_four() {
        assertEquals(2, Fibfib.fibfib(4));
    }

    @Test
    void fibfib_five() {
        assertEquals(4, Fibfib.fibfib(5));
    }

    @Test
    void fibfib_six() {
        assertEquals(7, Fibfib.fibfib(6));
    }

    @Test
    void fibfib_seven() {
        assertEquals(13, Fibfib.fibfib(7));
    }

    @Test
    void fibfib_eight() {
        assertEquals(24, Fibfib.fibfib(8));
    }

    @Test
    void fibfib_nine() {
        assertEquals(44, Fibfib.fibfib(9));
    }

    @Test
    void fibfib_ten() {
        assertEquals(81, Fibfib.fibfib(10));
    }

    @Test
    void fibfib_eleven() {
        assertEquals(149, Fibfib.fibfib(11));
    }

    @Test
    void fibfib_twelve() {
        assertEquals(274, Fibfib.fibfib(12));
    }

    @Test
    void fibfib_thirteen() {
        assertEquals(504, Fibfib.fibfib(13));
    }

    @Test
    void fibfib_fourteen() {
        assertEquals(927, Fibfib.fibfib(14));
    }

    @Test
    void fibfib_fifteen() {
        assertEquals(1705, Fibfib.fibfib(15));
    }

    @Test
    void fibfib_sixteen() {
        assertEquals(3136, Fibfib.fibfib(16));
    }

    @Test
    void fibfib_seventeen() {
        assertEquals(5768, Fibfib.fibfib(17));
    }

    @Test
    void fibfib_eighteen() {
        assertEquals(10609, Fibfib.fibfib(18));
    }

    @Test
    void fibfib_nineteen() {
        assertEquals(19483, Fibfib.fibfib(19));
    }

    @Test
    void fibfib_twenty() {
        assertEquals(35836, Fibfib.fibfib(20));
    }

    @Test
    void fibfib_boundary_negative() {
        assertThrows(IllegalArgumentException.class, () -> Fibfib.fibfib(-1));
    }

    @Test
    void fibfib_boundary_large() {
        assertThrows(IllegalArgumentException.class, () -> Fibfib.fibfib(101));
    }
}