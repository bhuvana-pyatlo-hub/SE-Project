package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TruncateNumberTest {

    @Test
    void truncateNumber_positiveNumberWithDecimal_returnsDecimalPart() {
        assertEquals(0.5, TruncateNumber.truncateNumber(3.5));
    }

    @Test
    void truncateNumber_positiveNumberWithMultipleDecimals_returnsDecimalPart() {
        assertEquals(0.33, TruncateNumber.truncateNumber(1.33));
    }

    @Test
    void truncateNumber_smallPositiveNumberWithDecimals_returnsDecimalPart() {
        assertEquals(0.456, TruncateNumber.truncateNumber(123.456));
    }

    @Test
    void truncateNumber_numberWithZeroDecimal_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(5.0));
    }

    @Test
    void truncateNumber_numberCloseToInteger_returnsCorrectDecimal() {
        assertEquals(0.999, TruncateNumber.truncateNumber(2.999));
    }

    @Test
    void truncateNumber_numberSlightlyAboveInteger_returnsCorrectDecimal() {
        assertEquals(0.001, TruncateNumber.truncateNumber(3.001));
    }

    @Test
    void truncateNumber_smallDecimalNumber_returnsCorrectDecimal() {
        assertEquals(0.123, TruncateNumber.truncateNumber(0.123));
    }

    @Test
    void truncateNumber_numberWithRepeatingDecimal_returnsCorrectDecimal() {
        assertEquals(0.333, TruncateNumber.truncateNumber(1.333333333));
    }

    @Test
    void truncateNumber_numberWithLongDecimal_returnsCorrectDecimal() {
        assertEquals(0.123, TruncateNumber.truncateNumber(1.123456789));
    }

    @Test
    void truncateNumber_zero_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(0.0));
    }

    @Test
    void truncateNumber_one_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(1.0));
    }

    @Test
    void truncateNumber_negativeNumberWithDecimal_returnsDecimalPart() {
        assertEquals(0.5, TruncateNumber.truncateNumber(-3.5));
    }

    @Test
    void truncateNumber_negativeNumberWithZeroDecimal_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(-5.0));
    }

    @Test
    void truncateNumber_largeInteger_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(1000.0));
    }

    @Test
    void truncateNumber_smallPositiveNumber_returnsCorrectDecimal() {
        assertEquals(0.01, TruncateNumber.truncateNumber(0.01));
    }

    @Test
    void truncateNumber_numberWithDecimalEndingInZero_returnsCorrectDecimal() {
        assertEquals(0.1, TruncateNumber.truncateNumber(1.10));
    }

    @Test
    void truncateNumber_numberWithDecimalEndingInMultipleZeros_returnsCorrectDecimal() {
        assertEquals(0.1, TruncateNumber.truncateNumber(1.100));
    }

    @Test
    void truncateNumber_numberWithDecimalStartingWithZero_returnsCorrectDecimal() {
        assertEquals(0.01, TruncateNumber.truncateNumber(1.01));
    }

    @Test
    void truncateNumber_numberWithDecimalStartingAndEndingWithZero_returnsCorrectDecimal() {
        assertEquals(0.01, TruncateNumber.truncateNumber(1.010));
    }

    @Test
    void truncateNumber_numberWithDecimalCloseToZero_returnsCorrectDecimal() {
        assertEquals(0.001, TruncateNumber.truncateNumber(1.001));
    }

    @Test
    void truncateNumber_numberWithDecimalCloseToOne_returnsCorrectDecimal() {
        assertEquals(0.999, TruncateNumber.truncateNumber(1.999));
    }
}