package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortArray1Test {

    @Test
    void sortArray_emptyArray() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_singleElementArray() {
        List<Object> input = new ArrayList<>(Arrays.asList(5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_evenSum_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 4, 3, 0, 1, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_oddSum_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 4, 3, 0, 1, 5, 6));
        List<Object> expected = new ArrayList<>(Arrays.asList(6, 5, 4, 3, 2, 1, 0));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_twoElements_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_sixElements_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(15, 42, 87, 32, 11, 0));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 11, 15, 32, 42, 87));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_fourElements_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(21, 14, 23, 11));
        List<Object> expected = new ArrayList<>(Arrays.asList(23, 21, 14, 11));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_allSameElements_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_alreadySorted_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_alreadySorted_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(5, 4, 3, 2, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_negativeNumbers_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(-2, -1, 0, 1, 2));
        List<Object> expected = new ArrayList<>(Arrays.asList(-2, -1, 0, 1, 2));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_negativeNumbers_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(-5, -4, -3, -2, -1));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -2, -3, -4, -5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_mixedPositiveNegative_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(-2, 4, -3, 0, 1, -5));
        List<Object> expected = new ArrayList<>(Arrays.asList(-5, -3, -2, 0, 1, 4));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_mixedPositiveNegative_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(-2, 4, -3, 0, 1, -5, 6));
        List<Object> expected = new ArrayList<>(Arrays.asList(6, 4, 1, 0, -2, -3, -5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_zeroAndPositive_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_zeroAndPositive_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6));
        List<Object> expected = new ArrayList<>(Arrays.asList(6, 5, 4, 3, 2, 1, 0));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_duplicateValues_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 1, 2, 3, 3, 4, 5, 5, 5, 6, 9));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_duplicateValues_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 7));
        List<Object> expected = new ArrayList<>(Arrays.asList(9, 7, 6, 5, 5, 5, 4, 3, 3, 2, 1, 1));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_zeroSum_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 0));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 0, 1, 2, 3, 4));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_largeArray_ascending() {
        List<Object> input = new ArrayList<>(Arrays.asList(10, 9, 8, 7, 6, 5, 4, 3, 2, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_largeArray_descending() {
        List<Object> input = new ArrayList<>(Arrays.asList(11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1));
        assertEquals(expected, SortArray1.sortArray(input));
    }
}