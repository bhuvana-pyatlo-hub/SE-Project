package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IncrListTest {

    @Test
    void incrList_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listOfIntegers() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 3, 4);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listOfIntegersWithDuplicates() {
        List<Object> input = Arrays.asList(5, 3, 5, 2, 3, 3, 9, 0, 123);
        List<Object> expected = Arrays.asList(6, 4, 6, 3, 4, 4, 10, 1, 124);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listOfIntegersDescending() {
        List<Object> input = Arrays.asList(3, 2, 1);
        List<Object> expected = Arrays.asList(4, 3, 2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listOfIntegersMixed() {
        List<Object> input = Arrays.asList(5, 2, 5, 2, 3, 3, 9, 0, 123);
        List<Object> expected = Arrays.asList(6, 3, 6, 3, 4, 4, 10, 1, 124);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_singleInteger() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_singleZero() {
        List<Object> input = Arrays.asList(0);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_singleNegativeInteger() {
        List<Object> input = Arrays.asList(-1);
        List<Object> expected = Arrays.asList(0);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_mixedTypes() {
        List<Object> input = Arrays.asList(1, "hello", 2, 3.14, 4);
        List<Object> expected = Arrays.asList(2, 3, 5);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_onlyStrings() {
        List<Object> input = Arrays.asList("hello", "world");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_onlyDoubles() {
        List<Object> input = Arrays.asList(1.1, 2.2, 3.3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_negativeAndPositiveIntegers() {
        List<Object> input = Arrays.asList(-1, 0, 1);
        List<Object> expected = Arrays.asList(0, 1, 2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_multipleNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(0, -1, -2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_zeroAndPositiveIntegers() {
        List<Object> input = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithNull() {
        List<Object> input = Arrays.asList(1, null, 2);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithOnlyNull() {
        List<Object> input = Arrays.asList(null, null);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithZeroAndString() {
        List<Object> input = Arrays.asList(0, "test");
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMaxIntValue() {
        List<Object> input = Arrays.asList(100);
        List<Object> expected = Arrays.asList(101);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMinIntValue() {
        List<Object> input = Arrays.asList(-100);
        List<Object> expected = Arrays.asList(-99);
        assertEquals(expected, IncrList.incrList(input));
    }
}