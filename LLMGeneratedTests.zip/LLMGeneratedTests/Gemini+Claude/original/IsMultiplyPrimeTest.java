package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsMultiplyPrimeTest {

    @Test
    void isMultiplyPrime_30_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(30));
    }

    @Test
    void isMultiplyPrime_5_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(5));
    }

    @Test
    void isMultiplyPrime_8_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(8));
    }

    @Test
    void isMultiplyPrime_10_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(10));
    }

    @Test
    void isMultiplyPrime_125_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(125));
    }

    @Test
    void isMultiplyPrime_105_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(105));
    }

    @Test
    void isMultiplyPrime_126_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(126));
    }

    @Test
    void isMultiplyPrime_729_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(729));
    }

    @Test
    void isMultiplyPrime_891_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(891));
    }

    @Test
    void isMultiplyPrime_1001_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(1001));
    }

    @Test
    void isMultiplyPrime_1_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(1));
    }

    @Test
    void isMultiplyPrime_2_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(2));
    }

    @Test
    void isMultiplyPrime_3_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(3));
    }

    @Test
    void isMultiplyPrime_6_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(6));
    }

    @Test
    void isMultiplyPrime_9_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(9));
    }

    @Test
    void isMultiplyPrime_15_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(15));
    }

    @Test
    void isMultiplyPrime_21_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(21));
    }

    @Test
    void isMultiplyPrime_42_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(42));
    }

    @Test
    void isMultiplyPrime_70_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(70));
    }

    @Test
    void isMultiplyPrime_77_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(77));
    }

    @Test
    void isMultiplyPrime_99_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(99));
    }

    @Test
    void isMultiplyPrime_0_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(0));
    }

    @Test
    void isMultiplyPrime_negativeValue_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(-10));
    }
}