package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Fib4Test {

    @Test
    void fib4_n0() {
        assertEquals(0, Fib4.fib4(0));
    }

    @Test
    void fib4_n1() {
        assertEquals(0, Fib4.fib4(1));
    }

    @Test
    void fib4_n2() {
        assertEquals(2, Fib4.fib4(2));
    }

    @Test
    void fib4_n3() {
        assertEquals(0, Fib4.fib4(3));
    }

    @Test
    void fib4_n4() {
        assertEquals(2, Fib4.fib4(4));
    }

    @Test
    void fib4_n5() {
        assertEquals(4, Fib4.fib4(5));
    }

    @Test
    void fib4_n6() {
        assertEquals(8, Fib4.fib4(6));
    }

    @Test
    void fib4_n7() {
        assertEquals(14, Fib4.fib4(7));
    }

    @Test
    void fib4_n8() {
        assertEquals(28, Fib4.fib4(8));
    }

    @Test
    void fib4_n9() {
        assertEquals(54, Fib4.fib4(9));
    }

    @Test
    void fib4_n10() {
        assertEquals(104, Fib4.fib4(10));
    }

    @Test
    void fib4_n11() {
        assertEquals(200, Fib4.fib4(11));
    }

    @Test
    void fib4_n12() {
        assertEquals(386, Fib4.fib4(12));
    }

    @Test
    void fib4_n13() {
        assertEquals(740, Fib4.fib4(13));
    }

    @Test
    void fib4_n14() {
        assertEquals(1430, Fib4.fib4(14));
    }

    @Test
    void fib4_n15() {
        assertEquals(2756, Fib4.fib4(15));
    }

    @Test
    void fib4_n16() {
        assertEquals(5356, Fib4.fib4(16));
    }

    @Test
    void fib4_n17() {
        assertEquals(10302, Fib4.fib4(17));
    }

    @Test
    void fib4_n18() {
        assertEquals(19844, Fib4.fib4(18));
    }

    @Test
    void fib4_n19() {
        assertEquals(38258, Fib4.fib4(19));
    }

    @Test
    void fib4_n20() {
        assertEquals(73760, Fib4.fib4(20));
    }

    @Test
    void fib4_boundary_negative() {
        assertThrows(IllegalArgumentException.class, () -> Fib4.fib4(-1));
    }

    @Test
    void fib4_boundary_large() {
        assertThrows(IllegalArgumentException.class, () -> Fib4.fib4(101));
    }
}