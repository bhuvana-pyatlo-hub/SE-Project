package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MaxElementTest {

    @Test
    void testMaxElement_emptyList() {
        List<Integer> emptyList = new ArrayList<>();
        assertEquals(Integer.MIN_VALUE, MaxElement.maxElement(emptyList));
    }

    @Test
    void testMaxElement_singleElementList() {
        List<Integer> singleElementList = Collections.singletonList(5);
        assertEquals(5, MaxElement.maxElement(singleElementList));
    }

    @Test
    void testMaxElement_positiveNumbers() {
        List<Integer> positiveNumbers = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(5, MaxElement.maxElement(positiveNumbers));
    }

    @Test
    void testMaxElement_negativeNumbers() {
        List<Integer> negativeNumbers = Arrays.asList(-5, -4, -3, -2, -1);
        assertEquals(-1, MaxElement.maxElement(negativeNumbers));
    }

    @Test
    void testMaxElement_mixedNumbers() {
        List<Integer> mixedNumbers = Arrays.asList(-5, 0, 5, -1, 1);
        assertEquals(5, MaxElement.maxElement(mixedNumbers));
    }

    @Test
    void testMaxElement_duplicateMax() {
        List<Integer> duplicateMax = Arrays.asList(1, 5, 2, 5, 3);
        assertEquals(5, MaxElement.maxElement(duplicateMax));
    }

    @Test
    void testMaxElement_allSameNumbers() {
        List<Integer> allSameNumbers = Arrays.asList(7, 7, 7, 7, 7);
        assertEquals(7, MaxElement.maxElement(allSameNumbers));
    }

    @Test
    void testMaxElement_zeroAndPositive() {
        List<Integer> zeroAndPositive = Arrays.asList(0, 1, 2, 3);
        assertEquals(3, MaxElement.maxElement(zeroAndPositive));
    }

    @Test
    void testMaxElement_zeroAndNegative() {
        List<Integer> zeroAndNegative = Arrays.asList(0, -1, -2, -3);
        assertEquals(0, MaxElement.maxElement(zeroAndNegative));
    }

    @Test
    void testMaxElement_zeroOnly() {
        List<Integer> zeroOnly = Arrays.asList(0, 0, 0);
        assertEquals(0, MaxElement.maxElement(zeroOnly));
    }

    @Test
    void testMaxElement_negativeAndZeroAndPositive() {
        List<Integer> mixedList = Arrays.asList(-10, 0, 10);
        assertEquals(10, MaxElement.maxElement(mixedList));
    }

    @Test
    void testMaxElement_multipleNegativeNumbers() {
        List<Integer> multipleNegative = Arrays.asList(-1, -5, -2, -8);
        assertEquals(-1, MaxElement.maxElement(multipleNegative));
    }

    @Test
    void testMaxElement_positiveAndNegativeMixed() {
        List<Integer> positiveAndNegative = Arrays.asList(1, -1, 2, -2);
        assertEquals(2, MaxElement.maxElement(positiveAndNegative));
    }

    @Test
    void testMaxElement_positiveAndZeroMixed() {
        List<Integer> positiveAndZero = Arrays.asList(1, 0, 2, 0);
        assertEquals(2, MaxElement.maxElement(positiveAndZero));
    }

    @Test
    void testMaxElement_negativeAndZeroMixed() {
        List<Integer> negativeAndZero = Arrays.asList(-1, 0, -2, 0);
        assertEquals(0, MaxElement.maxElement(negativeAndZero));
    }

    @Test
    void testMaxElement_allNegativeExceptOneZero() {
        List<Integer> allNegativeExceptOneZero = Arrays.asList(-1, -2, -3, 0);
        assertEquals(0, MaxElement.maxElement(allNegativeExceptOneZero));
    }

    @Test
    void testMaxElement_allPositiveExceptOneZero() {
        List<Integer> allPositiveExceptOneZero = Arrays.asList(1, 2, 3, 0);
        assertEquals(3, MaxElement.maxElement(allPositiveExceptOneZero));
    }

    @Test
    void testMaxElement_listWithMinIntValue() {
        List<Integer> listWithMinIntValue = Arrays.asList(Integer.MIN_VALUE, 1, 2);
        assertEquals(2, MaxElement.maxElement(listWithMinIntValue));
    }

    @Test
    void testMaxElement_listWithMaxIntValue() {
        List<Integer> listWithMaxIntValue = Arrays.asList(Integer.MAX_VALUE, -1, -2);
        assertEquals(Integer.MAX_VALUE, MaxElement.maxElement(listWithMaxIntValue));
    }
}