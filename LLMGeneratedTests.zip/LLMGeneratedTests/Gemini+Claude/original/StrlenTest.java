package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StrlenTest {

    @Test
    void strlen_emptyString() {
        assertEquals(0, Strlen.strlen(""), "Empty string should return 0");
    }

    @Test
    void strlen_singleCharacterString() {
        assertEquals(1, Strlen.strlen("a"), "Single character string should return 1");
    }

    @Test
    void strlen_shortString() {
        assertEquals(3, Strlen.strlen("abc"), "Short string should return correct length");
    }

    @Test
    void strlen_mediumString() {
        assertEquals(10, Strlen.strlen("0123456789"), "Medium string should return correct length");
    }

    @Test
    void strlen_longString() {
        assertEquals(20, Strlen.strlen("abcdefghij0123456789"), "Long string should return correct length");
    }

    @Test
    void strlen_stringWithSpaces() {
        assertEquals(5, Strlen.strlen("a b c"), "String with spaces should return correct length");
    }

    @Test
    void strlen_stringWithSpecialCharacters() {
        assertEquals(5, Strlen.strlen("!@#$%"), "String with special characters should return correct length");
    }

    @Test
    void strlen_stringWithMixedCharacters() {
        assertEquals(10, Strlen.strlen("a1b2c3d4e5"), "String with mixed characters should return correct length");
    }

    @Test
    void strlen_stringWithUnicodeCharacters() {
        assertEquals(3, Strlen.strlen("你好世"), "String with Unicode characters should return correct length");
    }

    @Test
    void strlen_stringWithNumbers() {
        assertEquals(5, Strlen.strlen("12345"), "String with numbers should return correct length");
    }

    @Test
    void strlen_stringWithLeadingAndTrailingSpaces() {
        assertEquals(7, Strlen.strlen("  abc  "), "String with leading and trailing spaces should return correct length");
    }

    @Test
    void strlen_stringWithInternalSpaces() {
        assertEquals(11, Strlen.strlen("abc def ghi "), "String with internal spaces should return correct length");
    }

    @Test
    void strlen_stringWithTabs() {
        assertEquals(3, Strlen.strlen("a\tb"), "String with tabs should return correct length");
    }

    @Test
    void strlen_stringWithNewlines() {
        assertEquals(3, Strlen.strlen("a\nb"), "String with newlines should return correct length");
    }

    @Test
    void strlen_stringWithCarriageReturns() {
        assertEquals(3, Strlen.strlen("a\rb"), "String with carriage returns should return correct length");
    }

    @Test
    void strlen_stringWithEscapedCharacters() {
        assertEquals(2, Strlen.strlen("\\\""), "String with escaped characters should return correct length");
    }

    @Test
    void strlen_stringWithNullCharacter() {
        assertEquals(1, Strlen.strlen("\0"), "String with null character should return correct length");
    }

    @Test
    void strlen_stringWithEmoji() {
        assertEquals(1, Strlen.strlen("😀"), "String with emoji should return correct length");
    }

    @Test
    void strlen_stringWithCombinedCharacters() {
        assertEquals(2, Strlen.strlen("á"), "String with combined characters should return correct length");
    }

    @Test
    void strlen_stringWithZeroLength() {
        assertEquals(0, Strlen.strlen(""), "String with zero length should return 0");
    }
}