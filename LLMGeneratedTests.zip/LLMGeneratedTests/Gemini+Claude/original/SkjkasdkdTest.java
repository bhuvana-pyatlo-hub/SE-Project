package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SkjkasdkdTest {

    @Test
    void skjkasdkd_emptyList_returnsZero() {
        List<Integer> lst = Collections.emptyList();
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_noPrimes_returnsZero() {
        List<Integer> lst = Arrays.asList(4, 6, 8, 9, 10);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_singlePrime_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_multiplePrimes_returnsSumOfDigitsOfLargest() {
        List<Integer> lst = Arrays.asList(2, 3, 5, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_mixedPrimesAndNonPrimes_returnsSumOfDigitsOfLargestPrime() {
        List<Integer> lst = Arrays.asList(4, 6, 7, 8, 11);
        assertEquals(2, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_zeroAndOne_returnsZero() {
        List<Integer> lst = Arrays.asList(0, 1);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_negativeNumbers_ignoresNegativeNumbers() {
        List<Integer> lst = Arrays.asList(-2, -3, 5, -7);
        assertEquals(5, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_largePrime_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(97);
        assertEquals(16, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithOne_returnsZero() {
        List<Integer> lst = Arrays.asList(1);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithZero_returnsZero() {
        List<Integer> lst = Arrays.asList(0);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithTwo_returnsTwo() {
        List<Integer> lst = Arrays.asList(2);
        assertEquals(2, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithThree_returnsThree() {
        List<Integer> lst = Arrays.asList(3);
        assertEquals(3, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithSmallPrimesAndNonPrimes() {
        List<Integer> lst = Arrays.asList(2, 4, 6, 3, 5);
        assertEquals(5, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithDuplicatePrimes() {
        List<Integer> lst = Arrays.asList(7, 7, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithMultiplePrimesAndZero() {
        List<Integer> lst = Arrays.asList(0, 2, 3, 5);
        assertEquals(5, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithPrimesAndLargeNonPrimes() {
        List<Integer> lst = Arrays.asList(2, 3, 100, 101);
        assertEquals(2, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithPrimeAndItsMultiple() {
        List<Integer> lst = Arrays.asList(3, 9);
        assertEquals(3, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithOnlyNonPrimeNumbers() {
        List<Integer> lst = Arrays.asList(4, 6, 8, 10);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithSingleDigitPrimes() {
        List<Integer> lst = Arrays.asList(2, 3, 5, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithTwoDigitPrimes() {
        List<Integer> lst = Arrays.asList(11, 13, 17, 19);
        assertEquals(1, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithPrimeAndComposite() {
        List<Integer> lst = Arrays.asList(17, 25);
        assertEquals(8, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithLargePrimeAndComposite() {
        List<Integer> lst = Arrays.asList(31, 25);
        assertEquals(4, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithMultipleLargePrimes() {
        List<Integer> lst = Arrays.asList(89, 97, 83);
        assertEquals(17, Skjkasdkd.skjkasdkd(lst));
    }
}