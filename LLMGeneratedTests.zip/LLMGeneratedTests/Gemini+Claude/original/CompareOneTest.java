package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CompareOneTest {

    @Test
    void compareOne_integerAndFloat_returnsFloat() {
        assertEquals(2.5f, CompareOne.compareOne(1, 2.5f));
    }

    @Test
    void compareOne_integerAndString_returnsString() {
        assertEquals("2,3", CompareOne.compareOne(1, "2,3"));
    }

    @Test
    void compareOne_stringAndString_returnsString() {
        assertEquals("6", CompareOne.compareOne("5,1", "6"));
    }

    @Test
    void compareOne_stringAndInteger_returnsNull() {
        assertNull(CompareOne.compareOne("1", 1));
    }

    @Test
    void compareOne_integers_returnsLargerInteger() {
        assertEquals(2, CompareOne.compareOne(1, 2));
    }

    @Test
    void compareOne_integers_returnsLargerInteger2() {
        assertEquals(3, CompareOne.compareOne(2, 3));
    }

    @Test
    void compareOne_integers_returnsLargerInteger3() {
        assertEquals(6, CompareOne.compareOne(5, 6));
    }

    @Test
    void compareOne_strings_returnsLargerString() {
        assertEquals("2", CompareOne.compareOne("1", "2"));
    }

    @Test
    void compareOne_equalIntegers_returnsNull() {
        assertNull(CompareOne.compareOne(1, 1));
    }

    @Test
    void compareOne_equalFloats_returnsNull() {
        assertNull(CompareOne.compareOne(1.5f, 1.5f));
    }

    @Test
    void compareOne_equalStrings_returnsNull() {
        assertNull(CompareOne.compareOne("1", "1"));
    }

    @Test
    void compareOne_floatAndInteger_returnsFloat() {
        assertEquals(2.5f, CompareOne.compareOne(2.5f, 1));
    }

    @Test
    void compareOne_stringAndFloat_returnsString() {
        assertEquals("2.5", CompareOne.compareOne("2.5", 1));
    }

    @Test
    void compareOne_floatAndString_returnsFloat() {
        assertEquals(2.5f, CompareOne.compareOne(1, "2.5"));
    }

    @Test
    void compareOne_stringWithCommaAndInteger_returnsString() {
        assertEquals("2,5", CompareOne.compareOne(1, "2,5"));
    }

    @Test
    void compareOne_integerAndStringWithComma_returnsString() {
        assertEquals("2,5", CompareOne.compareOne(1, "2,5"));
    }

    @Test
    void compareOne_stringWithCommaAndString_returnsString() {
        assertEquals("6", CompareOne.compareOne("5,1", "6"));
    }

    @Test
    void compareOne_stringWithCommaAndStringWithComma_returnsString() {
        assertEquals("2,0", CompareOne.compareOne("1,0", "2,0"));
    }

    @Test
    void compareOne_equalStringsWithComma_returnsNull() {
        assertNull(CompareOne.compareOne("1,0", "1,0"));
    }

    @Test
    void compareOne_negativeNumbers_returnsLarger() {
        assertEquals(-1, CompareOne.compareOne(-2, -1));
    }

    @Test
    void compareOne_negativeAndPositive_returnsPositive() {
        assertEquals(1, CompareOne.compareOne(-1, 1));
    }

    @Test
    void compareOne_zeroAndPositive_returnsPositive() {
        assertEquals(1, CompareOne.compareOne(0, 1));
    }

    @Test
    void compareOne_zeroAndNegative_returnsNegative() {
        assertEquals(-1, CompareOne.compareOne(0, -1));
    }

    @Test
    void compareOne_zeroAndZero_returnsNull() {
        assertNull(CompareOne.compareOne(0, 0));
    }

    @Test
    void compareOne_largeNegativeAndSmallNegative_returnsSmallNegative() {
        assertEquals(-1, CompareOne.compareOne(-100, -1));
    }

    @Test
    void compareOne_largePositiveAndSmallPositive_returnsLargePositive() {
        assertEquals(100, CompareOne.compareOne(100, 1));
    }
}