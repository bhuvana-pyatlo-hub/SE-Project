package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class IntersectionTest {

    @Test
    void intersection_intersectingIntervals_primeLength_returnsYES() {
        List<Integer> interval1 = Arrays.asList(-3, -1);
        List<Integer> interval2 = Arrays.asList(-5, 5);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_intersectingIntervals_nonPrimeLength_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(2, 3);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_nonIntersectingIntervals_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(3, 5);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_intersectingIntervals_lengthZero_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 1);
        List<Integer> interval2 = Arrays.asList(1, 1);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_intersectingIntervals_negativeValues_returnsYES() {
        List<Integer> interval1 = Arrays.asList(-2, 2);
        List<Integer> interval2 = Arrays.asList(-4, 0);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_intersectingIntervals_negativeValues_returnsNO() {
        List<Integer> interval1 = Arrays.asList(-11, 2);
        List<Integer> interval2 = Arrays.asList(-1, -1);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_sameIntervals_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(1, 2);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_adjacentIntervals_returnsNO() {
        List<Integer> interval1 = Arrays.asList(-2, -2);
        List<Integer> interval2 = Arrays.asList(-3, -2);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_interval1ContainsInterval2_returnsNO() {
        List<Integer> interval1 = Arrays.asList(-1, 1);
        List<Integer> interval2 = Arrays.asList(0, 0);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_interval2ContainsInterval1_returnsNO() {
        List<Integer> interval1 = Arrays.asList(0, 0);
        List<Integer> interval2 = Arrays.asList(-1, 1);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_interval1BeforeInterval2_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 3);
        List<Integer> interval2 = Arrays.asList(4, 6);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_interval2BeforeInterval1_returnsNO() {
        List<Integer> interval1 = Arrays.asList(4, 6);
        List<Integer> interval2 = Arrays.asList(1, 3);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_interval1StartEqualsInterval2End_returnsNO() {
        List<Integer> interval1 = Arrays.asList(3, 5);
        List<Integer> interval2 = Arrays.asList(1, 3);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_interval2StartEqualsInterval1End_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 3);
        List<Integer> interval2 = Arrays.asList(3, 5);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_negativeIntervals_primeLength_returnsYES() {
        List<Integer> interval1 = Arrays.asList(-5, -3);
        List<Integer> interval2 = Arrays.asList(-4, -2);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_negativeIntervals_nonPrimeLength_returnsNO() {
        List<Integer> interval1 = Arrays.asList(-5, -1);
        List<Integer> interval2 = Arrays.asList(-3, 0);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_singlePointIntersection_returnsNO() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(2, 4);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_zeroLengthIntersection_returnsNO() {
        List<Integer> interval1 = Arrays.asList(5, 5);
        List<Integer> interval2 = Arrays.asList(5, 5);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_largeNegativeIntervals_returnsYES() {
        List<Integer> interval1 = Arrays.asList(-3, -1);
        List<Integer> interval2 = Arrays.asList(-2, 0);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_largeNegativeIntervals_returnsNO() {
        List<Integer> interval1 = Arrays.asList(-4, -2);
        List<Integer> interval2 = Arrays.asList(-1, 1);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }
}