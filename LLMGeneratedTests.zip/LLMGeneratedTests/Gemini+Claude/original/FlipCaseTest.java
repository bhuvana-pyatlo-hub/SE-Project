package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FlipCaseTest {

    @Test
    void testFlipCase_emptyString() {
        assertEquals("", FlipCase.flipCase(""));
    }

    @Test
    void testFlipCase_singleLowercase() {
        assertEquals("A", FlipCase.flipCase("a"));
    }

    @Test
    void testFlipCase_singleUppercase() {
        assertEquals("a", FlipCase.flipCase("A"));
    }

    @Test
    void testFlipCase_mixedCase() {
        assertEquals("hELLO", FlipCase.flipCase("Hello"));
    }

    @Test
    void testFlipCase_withSpecialCharacters() {
        assertEquals("hELLO!", FlipCase.flipCase("Hello!"));
    }

    @Test
    void testFlipCase_longString() {
        assertEquals("tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS", FlipCase.flipCase("These violent delights have violent ends"));
    }

    @Test
    void testFlipCase_numbersAndLetters() {
        assertEquals("123aBC", FlipCase.flipCase("123Abc"));
    }

    @Test
    void testFlipCase_allUppercase() {
        assertEquals("hello", FlipCase.flipCase("HELLO"));
    }

    @Test
    void testFlipCase_allLowercase() {
        assertEquals("HELLO", FlipCase.flipCase("hello"));
    }

    @Test
    void testFlipCase_stringWithSpaces() {
        assertEquals("hELLO wORLD", FlipCase.flipCase("Hello World"));
    }

    @Test
    void testFlipCase_stringWithLeadingAndTrailingSpaces() {
        assertEquals(" hELLO ", FlipCase.flipCase(" Hello "));
    }

    @Test
    void testFlipCase_stringWithMultipleSpaces() {
        assertEquals("hELLO  wORLD", FlipCase.flipCase("Hello  World"));
    }

    @Test
    void testFlipCase_stringWithTabs() {
        assertEquals("hELLO\tWORLD", FlipCase.flipCase("Hello\tworld"));
    }

    @Test
    void testFlipCase_stringWithNewline() {
        assertEquals("hELLO\nWOrLd", FlipCase.flipCase("Hello\nwORlD"));
    }

    @Test
    void testFlipCase_stringWithUnicodeCharacters() {
        assertEquals("ß", FlipCase.flipCase("ß"));
    }

    @Test
    void testFlipCase_stringWithMixedUnicodeAndAscii() {
        assertEquals("hELLO ßORLD", FlipCase.flipCase("Hello ßorld"));
    }

    @Test
    void testFlipCase_stringWithSymbols() {
        assertEquals("!@#$%^", FlipCase.flipCase("!@#$%^"));
    }

    @Test
    void testFlipCase_stringWithMixedCaseAndSymbols() {
        assertEquals("hELLO! wORLD?", FlipCase.flipCase("Hello! World?"));
    }

    @Test
    void testFlipCase_stringWithOnlyNumbers() {
        assertEquals("12345", FlipCase.flipCase("12345"));
    }

    @Test
    void testFlipCase_stringWithSpecialCharsAndNumbers() {
        assertEquals("123!@#aBC", FlipCase.flipCase("123!@#Abc"));
    }

    @Test
    void testFlipCase_boundaryValues() {
        assertEquals("A", FlipCase.flipCase("a")); // Lower boundary
        assertEquals("a", FlipCase.flipCase("A")); // Upper boundary
    }

    @Test
    void testFlipCase_negativeAndZeroValues() {
        assertEquals("0", FlipCase.flipCase("0")); // Zero value
        assertEquals("1", FlipCase.flipCase("1")); // Negative value (not applicable but included for completeness)
    }
}