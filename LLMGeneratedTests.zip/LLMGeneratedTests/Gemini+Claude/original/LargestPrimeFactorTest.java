package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LargestPrimeFactorTest {

    @Test
    void largestPrimeFactor_smallPrime() {
        assertEquals(2, LargestPrimeFactor.largestPrimeFactor(2));
    }

    @Test
    void largestPrimeFactor_smallComposite() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(15));
    }

    @Test
    void largestPrimeFactor_powerOfTwo() {
        assertEquals(2, LargestPrimeFactor.largestPrimeFactor(2048));
    }

    @Test
    void largestPrimeFactor_powerOfThree() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(27));
    }

    @Test
    void largestPrimeFactor_sixtyThree() {
        assertEquals(7, LargestPrimeFactor.largestPrimeFactor(63));
    }

    @Test
    void largestPrimeFactor_threeHundredThirty() {
        assertEquals(11, LargestPrimeFactor.largestPrimeFactor(330));
    }

    @Test
    void largestPrimeFactor_thirteenThousandOneHundredNinetyFive() {
        assertEquals(29, LargestPrimeFactor.largestPrimeFactor(13195));
    }

    @Test
    void largestPrimeFactor_smallNumber() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(9));
    }

    @Test
    void largestPrimeFactor_anotherSmallNumber() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(25));
    }

    @Test
    void largestPrimeFactor_numberWithMultipleFactors() {
        assertEquals(7, LargestPrimeFactor.largestPrimeFactor(49));
    }

    @Test
    void largestPrimeFactor_numberWithPrimeFactorAtEnd() {
        assertEquals(17, LargestPrimeFactor.largestPrimeFactor(17));
    }

    @Test
    void largestPrimeFactor_numberWithPrimeFactorAtBeginning() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(10));
    }

    @Test
    void largestPrimeFactor_numberWithPrimeFactorInMiddle() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(50));
    }

    @Test
    void largestPrimeFactor_numberWithRepeatedPrimeFactors() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(81));
    }

    @Test
    void largestPrimeFactor_numberWithDistinctPrimeFactors() {
        assertEquals(7, LargestPrimeFactor.largestPrimeFactor(21));
    }

    @Test
    void largestPrimeFactor_numberWithSmallPrimeFactor() {
        assertEquals(2, LargestPrimeFactor.largestPrimeFactor(4));
    }

    @Test
    void largestPrimeFactor_numberWithMediumPrimeFactor() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(125));
    }

    @Test
    void largestPrimeFactor_numberWithLargePrimeFactor() {
        assertEquals(13, LargestPrimeFactor.largestPrimeFactor(169));
    }

    @Test
    void largestPrimeFactor_numberWithPrimeFactorCloseToN() {
        assertEquals(19, LargestPrimeFactor.largestPrimeFactor(19));
    }

    @Test
    void largestPrimeFactor_numberWithTwoPrimeFactors() {
        assertEquals(3, LargestPrimeFactor.largestPrimeFactor(6));
    }

    @Test
    void largestPrimeFactor_numberWithThreePrimeFactors() {
        assertEquals(5, LargestPrimeFactor.largestPrimeFactor(30));
    }

    @Test
    void largestPrimeFactor_boundaryValue() {
        assertEquals(97, LargestPrimeFactor.largestPrimeFactor(97)); // Testing a prime number
    }

    @Test
    void largestPrimeFactor_negativeInput() {
        assertThrows(IllegalArgumentException.class, () -> LargestPrimeFactor.largestPrimeFactor(-10));
    }

    @Test
    void largestPrimeFactor_zeroInput() {
        assertThrows(IllegalArgumentException.class, () -> LargestPrimeFactor.largestPrimeFactor(0));
    }

    @Test
    void largestPrimeFactor_oneInput() {
        assertThrows(IllegalArgumentException.class, () -> LargestPrimeFactor.largestPrimeFactor(1));
    }
}