package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SumSquares1Test {

    @Test
    void sumSquares_emptyList_returnsZero() {
        List<Object> lst = new ArrayList<>();
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_singleElementList_indexMultipleOf3_returnsSquare() {
        List<Object> lst = Arrays.asList(3);
        assertEquals(9, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_singleElementList_indexMultipleOf4_returnsCube() {
        List<Object> lst = Arrays.asList(4);
        assertEquals(64, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_singleElementList_indexNotMultipleOf3Or4_returnsOriginal() {
        List<Object> lst = Arrays.asList(5);
        assertEquals(5, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example1() {
        List<Object> lst = Arrays.asList(1, 2, 3);
        assertEquals(6, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example2() {
        List<Object> lst = Arrays.asList(1, 4, 9);
        assertEquals(14, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example3() {
        List<Object> lst = new ArrayList<>();
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example4() {
        List<Object> lst = Arrays.asList(1, 1, 1, 1, 1, 1, 1, 1, 1);
        assertEquals(9, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example5() {
        List<Object> lst = Arrays.asList(-1, -1, -1, -1, -1, -1, -1, -1, -1);
        assertEquals(-3, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example6() {
        List<Object> lst = Arrays.asList(0);
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example7() {
        List<Object> lst = Arrays.asList(-1, -5, 2, -1, -5);
        assertEquals(-126, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example8() {
        List<Object> lst = Arrays.asList(-56, -99, 1, 0, -2);
        assertEquals(3030, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example9() {
        List<Object> lst = Arrays.asList(-1, 0, 0, 0, 0, 0, 0, 0, -1);
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example10() {
        List<Object> lst = Arrays.asList(-16, -9, -2, 36, 36, 26, -20, 25, -40, 20, -4, 12, -26, 35, 37);
        assertEquals(-14196, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example11() {
        List<Object> lst = Arrays.asList(-1, -3, 17, -1, -15, 13, -1, 14, -14, -12, -5, 14, -14, 6, 13, 11, 16, 16, 4, 10);
        assertEquals(-1448, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_mixedMultiplesOf3And4() {
        List<Object> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        assertEquals(1 + 2 + 9 + 64 + 5 + 36 + 7 + 512 + 81 + 10 + 11 + 144, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_allMultiplesOf3() {
        List<Object> lst = Arrays.asList(3, 6, 9, 12, 15);
        assertEquals(9 + 36 + 81 + 144 + 225, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_allMultiplesOf4() {
        List<Object> lst = Arrays.asList(4, 8, 12, 16);
        assertEquals(64 + 512 + 1728 + 4096, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_negativeNumbersAndZero() {
        List<Object> lst = Arrays.asList(-1, 0, 1, -2, 2, -3, 3, -4, 4);
        assertEquals(1 + 0 + 1 + -8 + 2 + 9 + 3 + -64 + 4, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_listWithOnlyZeroes() {
        List<Object> lst = Arrays.asList(0, 0, 0, 0, 0);
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_listWithOnlyNegativeMultiplesOf3() {
        List<Object> lst = Arrays.asList(-3, -6, -9);
        assertEquals(9 + 36 + 81, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_listWithOnlyNegativeMultiplesOf4() {
        List<Object> lst = Arrays.asList(-4, -8, -12);
        assertEquals(-64 + -512 + -1728, SumSquares1.sumSquares(lst));
    }
}