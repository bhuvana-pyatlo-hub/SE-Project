package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class SeparateParenGroupsTest {

    @Test
    void separateParenGroups_emptyString() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups(""));
    }

    @Test
    void separateParenGroups_singleGroup() {
        List<String> expected = new ArrayList<>();
        expected.add("(()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()())"));
    }

    @Test
    void separateParenGroups_multipleGroups() {
        List<String> expected = new ArrayList<>();
        expected.add("(()())");
        expected.add("((()))");
        expected.add("()");
        expected.add("((())()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()()) ((())) () ((())()())"));
    }

    @Test
    void separateParenGroups_multipleGroupsWithExtraSpaces() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("(())");
        expected.add("((()))");
        expected.add("(((())))");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() (()) ((())) (((())))"));
    }

    @Test
    void separateParenGroups_nestedGroups() {
        List<String> expected = new ArrayList<>();
        expected.add("(()(())((())))");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()(())((())))"));
    }

    @Test
    void separateParenGroups_groupsWithSpacesInside() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("(())");
        expected.add("(()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("( ) (( )) (( )( ))"));
    }

    @Test
    void separateParenGroups_unbalancedParentheses() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("("));
    }

    @Test
    void separateParenGroups_unbalancedParentheses2() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups(")"));
    }

    @Test
    void separateParenGroups_unbalancedParentheses3() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()"));
    }

    @Test
    void separateParenGroups_unbalancedParentheses4() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("())"));
    }

    @Test
    void separateParenGroups_onlySpaces() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("   "));
    }

    @Test
    void separateParenGroups_mixedCharacters() {
        List<String> expected = new ArrayList<>();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("a(b)c"));
    }

    @Test
    void separateParenGroups_singleParen() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("()"));
    }

    @Test
    void separateParenGroups_multipleSingleParens() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("()");
        expected.add("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() () ()"));
    }

    @Test
    void separateParenGroups_nestedAndSeparate() {
        List<String> expected = new ArrayList<>();
        expected.add("(())");
        expected.add("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()) ()"));
    }

    @Test
    void separateParenGroups_complexNesting() {
        List<String> expected = new ArrayList<>();
        expected.add("(((())))");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(((())))"));
    }

    @Test
    void separateParenGroups_leadingAndTrailingSpaces() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups(" () "));
    }

    @Test
    void separateParenGroups_multipleGroupsWithInternalSpaces() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("(())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("( ) (())"));
    }

    @Test
    void separateParenGroups_adjacentGroups() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("()()"));
    }

    @Test
    void separateParenGroups_complexMixed() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("((()))");
        expected.add("(()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() ((()))(()())"));
    }

    @Test
    void separateParenGroups_boundaryValues() {
        List<String> expected = new ArrayList<>();
        expected.add("()");
        expected.add("(())");
        expected.add("((()))");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() (()) ((()))"));
    }
}