package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class UniqueTest {

    @Test
    void unique_emptyList() {
        List<Integer> input = Collections.emptyList();
        List<Integer> expected = Collections.emptyList();
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_singleElementList() {
        List<Integer> input = Collections.singletonList(5);
        List<Integer> expected = Collections.singletonList(5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_duplicateElements() {
        List<Integer> input = Arrays.asList(5, 3, 5, 2, 3, 3, 9, 0, 123);
        List<Integer> expected = Arrays.asList(0, 2, 3, 5, 9, 123);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_alreadySortedUniqueElements() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_reverseSortedUniqueElements() {
        List<Integer> input = Arrays.asList(5, 4, 3, 2, 1);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_allSameElements() {
        List<Integer> input = Arrays.asList(7, 7, 7, 7, 7);
        List<Integer> expected = Collections.singletonList(7);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_negativeAndPositiveNumbers() {
        List<Integer> input = Arrays.asList(-5, 3, -5, 2, 3, -3, 9, 0, 123);
        List<Integer> expected = Arrays.asList(-5, -3, 0, 2, 3, 9, 123);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_zeroAndPositiveNumbers() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3, 0, 1, 2, 3);
        List<Integer> expected = Arrays.asList(0, 1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_smallNumbers() {
        List<Integer> input = Arrays.asList(1, 0, 1, 0, 1, 0);
        List<Integer> expected = Arrays.asList(0, 1);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_mixedPositiveNegativeZero() {
        List<Integer> input = Arrays.asList(-1, 0, 1, -1, 0, 1);
        List<Integer> expected = Arrays.asList(-1, 0, 1);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithNull() {
        List<Integer> input = Arrays.asList(1, 2, null, 3, null);
        List<Integer> expected = Arrays.asList(null, 1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithMultipleNulls() {
        List<Integer> input = Arrays.asList(null, null, null);
        List<Integer> expected = Collections.singletonList(null);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithOnlyNull() {
        List<Integer> input = Collections.singletonList(null);
        List<Integer> expected = Collections.singletonList(null);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithNullAndOtherValues() {
        List<Integer> input = Arrays.asList(1, null, 2, 3);
        List<Integer> expected = Arrays.asList(null, 1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithDuplicatesAndNull() {
        List<Integer> input = Arrays.asList(1, 1, null, 2, 2, 3, null);
        List<Integer> expected = Arrays.asList(null, 1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithNegativeAndNull() {
        List<Integer> input = Arrays.asList(-1, null, -2, -3);
        List<Integer> expected = Arrays.asList(null, -3, -2, -1);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithZeroAndNull() {
        List<Integer> input = Arrays.asList(0, null, 0, 0);
        List<Integer> expected = Arrays.asList(null, 0);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void unique_listWithMinMaxValues() {
        List<Integer> input = Arrays.asList(-100, 0, 100, -100, 100);
        List<Integer> expected = Arrays.asList(-100, 0, 100);
        assertEquals(expected, Unique.unique(input));
    }
}