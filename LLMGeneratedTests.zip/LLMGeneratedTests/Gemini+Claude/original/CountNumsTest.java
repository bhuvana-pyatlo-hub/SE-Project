package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CountNumsTest {

    @Test
    void countNums_emptyList_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.emptyList()));
    }

    @Test
    void countNums_singlePositiveNumber_returnsOne() {
        assertEquals(1, CountNums.countNums(Collections.singletonList(1)));
    }

    @Test
    void countNums_singleZero_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.singletonList(0)));
    }

    @Test
    void countNums_singleNegativeNumber_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.singletonList(-1)));
    }

    @Test
    void countNums_positiveAndNegativeNumbers_correctCount() {
        List<Object> list = Arrays.asList(1, -1, 11, -11);
        assertEquals(1, CountNums.countNums(list));
    }

    @Test
    void countNums_allPositiveNumbers_correctCount() {
        List<Object> list = Arrays.asList(1, 1, 2);
        assertEquals(3, CountNums.countNums(list));
    }

    @Test
    void countNums_mixedPositiveNegativeAndZero_correctCount() {
        List<Object> list = Arrays.asList(1, -2, 0);
        assertEquals(1, CountNums.countNums(list));
    }

    @Test
    void countNums_largerList_correctCount() {
        List<Object> list = Arrays.asList(1, 1, 2, -2, 3, 4, 5);
        assertEquals(6, CountNums.countNums(list));
    }

    @Test
    void countNums_anotherLargerList_correctCount() {
        List<Object> list = Arrays.asList(1, 6, 9, -6, 0, 1, 5);
        assertEquals(5, CountNums.countNums(list));
    }

    @Test
    void countNums_listWithTwoDigitNumbers_correctCount() {
        List<Object> list = Arrays.asList(12, 23, 34, -45, -56, 0);
        assertEquals(5, CountNums.countNums(list));
    }

    @Test
    void countNums_zeroAndOne_correctCount() {
        List<Object> list = Arrays.asList(0, 1);
        assertEquals(1, CountNums.countNums(list));
    }

    @Test
    void countNums_negativeTwoDigitNumber_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.singletonList(-10)));
    }

    @Test
    void countNums_positiveTwoDigitNumber_returnsOne() {
        assertEquals(1, CountNums.countNums(Collections.singletonList(10)));
    }

    @Test
    void countNums_negativeNumberWithPositiveDigitSum_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.singletonList(-123)));
    }

    @Test
    void countNums_positiveNumberWithPositiveDigitSum_returnsOne() {
        assertEquals(1, CountNums.countNums(Collections.singletonList(123)));
    }

    @Test
    void countNums_listWithOnlyNegativeNumbers_returnsZero() {
        List<Object> list = Arrays.asList(-1, -2, -3);
        assertEquals(0, CountNums.countNums(list));
    }

    @Test
    void countNums_listWithMultipleZeros_returnsZero() {
        List<Object> list = Arrays.asList(0, 0, 0);
        assertEquals(0, CountNums.countNums(list));
    }

    @Test
    void countNums_singleDigitNegativeNumber_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.singletonList(-5)));
    }

    @Test
    void countNums_singleDigitPositiveNumber_returnsOne() {
        assertEquals(1, CountNums.countNums(Collections.singletonList(5)));
    }

    @Test
    void countNums_negativeSingleDigitNumber_returnsZero() {
        assertEquals(0, CountNums.countNums(Collections.singletonList(-9)));
    }

    @Test
    void countNums_positiveSingleDigitNumber_returnsOne() {
        assertEquals(1, CountNums.countNums(Collections.singletonList(9)));
    }
}