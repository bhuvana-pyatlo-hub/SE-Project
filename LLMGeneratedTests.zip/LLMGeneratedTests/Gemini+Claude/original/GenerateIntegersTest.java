package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;

class GenerateIntegersTest {

    @Test
    void generateIntegers_aLessThanB_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(2, 8));
    }

    @Test
    void generateIntegers_aGreaterThanB_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(8, 2));
    }

    @Test
    void generateIntegers_noEvenNumbersInRange_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(10, 14));
    }

    @Test
    void generateIntegers_aIs2_bIs10_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(2, 10));
    }

    @Test
    void generateIntegers_aIs10_bIs2_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(10, 2));
    }

    @Test
    void generateIntegers_aIs132_bIs2_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(132, 2));
    }

    @Test
    void generateIntegers_aIs17_bIs89_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(17, 89));
    }

    @Test
    void generateIntegers_aEqualsB_andIsEven_returnsListWithSingleElement() {
        List<Object> expected = List.of(2);
        assertEquals(expected, GenerateIntegers.generateIntegers(2, 2));
    }

    @Test
    void generateIntegers_aEqualsB_andIsOdd_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(3, 3));
    }

    @Test
    void generateIntegers_aIsNegative_bIsPositive_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(-2, 10));
    }

    @Test
    void generateIntegers_aIsPositive_bIsNegative_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(10, -2));
    }

    @Test
    void generateIntegers_aAndB_areNegative_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(-5, -1));
    }

    @Test
    void generateIntegers_aIsZero_bIsTen_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(0, 10));
    }

    @Test
    void generateIntegers_aIsTen_bIsZero_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(10, 0));
    }

    @Test
    void generateIntegers_aIsOne_bIsNine_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(1, 9));
    }

    @Test
    void generateIntegers_aIsNine_bIsOne_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(9, 1));
    }

    @Test
    void generateIntegers_aIs3_bIs7_returnsEvenNumbers() {
        List<Object> expected = List.of(4, 6);
        assertEquals(expected, GenerateIntegers.generateIntegers(3, 7));
    }

    @Test
    void generateIntegers_aIs7_bIs3_returnsEvenNumbers() {
        List<Object> expected = List.of(4, 6);
        assertEquals(expected, GenerateIntegers.generateIntegers(7, 3));
    }

    @Test
    void generateIntegers_aIs6_bIs6_returnsListWithSingleElement6() {
        List<Object> expected = List.of(6);
        assertEquals(expected, GenerateIntegers.generateIntegers(6, 6));
    }

    @Test
    void generateIntegers_aIs4_bIs5_returnsListWithSingleElement4() {
        List<Object> expected = List.of(4);
        assertEquals(expected, GenerateIntegers.generateIntegers(4, 5));
    }

    @Test
    void generateIntegers_aIs5_bIs4_returnsListWithSingleElement4() {
        List<Object> expected = List.of(4);
        assertEquals(expected, GenerateIntegers.generateIntegers(5, 4));
    }

    @Test
    void generateIntegers_aIsNegative_bIsNegative_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(-100, -50));
    }

    @Test
    void generateIntegers_aIsNegative_bIsZero_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(-5, 0));
    }

    @Test
    void generateIntegers_aIsZero_bIsNegative_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(0, -5));
    }
}