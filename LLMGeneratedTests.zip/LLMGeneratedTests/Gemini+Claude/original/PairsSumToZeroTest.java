package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PairsSumToZeroTest {

    @Test
    void pairsSumToZero_emptyList_returnsFalse() {
        List<Integer> list = Collections.emptyList();
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_singleElementList_returnsFalse() {
        List<Integer> list = Collections.singletonList(5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_noPairSummingToZero_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_positiveAndNegativePair_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, -2, 4, 5);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_multiplePairsSummingToZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, -1, 2, -2, 3, -3);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_zeroAndZeroPair_returnsTrue() {
        List<Integer> list = Arrays.asList(0, 0, 1, 2, 3);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_negativeNumbersOnly_returnsFalse() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeListNoZeroSum_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeListWithZeroSum_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, -1);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_sameNumberTwice_returnsFalse() {
        List<Integer> list = Arrays.asList(5, 5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_negativeAndPositiveSameIndex_returnsFalse() {
        List<Integer> list = Arrays.asList(5, -5);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_zeroInList_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 0);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_negativeZeroInList_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, -0);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_mixedPositiveNegativeAndZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, -1, 0, 2, -2);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_onlyZero_returnsTrue() {
        List<Integer> list = Arrays.asList(0, 0);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_negativeNumbers_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, -2, 2);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeNegativeAndPositive_returnsTrue() {
        List<Integer> list = Arrays.asList(-100, 100);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_multipleSameValues_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 1, -1);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_nearZeroValues_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_listWithZeroAtEnd_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 0);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_listWithZeroAtBeginning_returnsFalse() {
        List<Integer> list = Arrays.asList(0, 1, 2, 3);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_boundaryValues_returnsTrue() {
        List<Integer> list = Arrays.asList(-100, 100);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_boundaryValuesNoPair_returnsFalse() {
        List<Integer> list = Arrays.asList(-99, 99);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }
}