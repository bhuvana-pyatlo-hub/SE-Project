package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GreatestCommonDivisorTest {

    @Test
    void testGreatestCommonDivisor_aIsZero() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(0, 5));
    }

    @Test
    void testGreatestCommonDivisor_bIsZero() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(5, 0));
    }

    @Test
    void testGreatestCommonDivisor_bothAreZero() {
        assertEquals(0, GreatestCommonDivisor.greatestCommonDivisor(0, 0));
    }

    @Test
    void testGreatestCommonDivisor_positiveNumbers_gcdExists() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(25, 15));
    }

    @Test
    void testGreatestCommonDivisor_positiveNumbers_gcdIsOne() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(3, 5));
    }

    @Test
    void testGreatestCommonDivisor_positiveNumbers_aIsMultipleOfB() {
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(49, 14));
    }

    @Test
    void testGreatestCommonDivisor_positiveNumbers_bIsMultipleOfA() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(10, 15));
    }

    @Test
    void testGreatestCommonDivisor_positiveNumbers_largerNumbers() {
        assertEquals(12, GreatestCommonDivisor.greatestCommonDivisor(144, 60));
    }

    @Test
    void testGreatestCommonDivisor_samePositiveNumbers() {
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(7, 7));
    }

    @Test
    void testGreatestCommonDivisor_oneAndPositiveNumber() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(1, 10));
    }

    @Test
    void testGreatestCommonDivisor_positiveNumberAndOne() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(10, 1));
    }

    @Test
    void testGreatestCommonDivisor_smallPositiveNumbers() {
        assertEquals(2, GreatestCommonDivisor.greatestCommonDivisor(2, 4));
    }

    @Test
    void testGreatestCommonDivisor_relativelyPrimeNumbers() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(8, 9));
    }

    @Test
    void testGreatestCommonDivisor_aIsOne() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(1, 5));
    }

    @Test
    void testGreatestCommonDivisor_bIsOne() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(5, 1));
    }

    @Test
    void testGreatestCommonDivisor_aEqualsB() {
        assertEquals(10, GreatestCommonDivisor.greatestCommonDivisor(10, 10));
    }

    @Test
    void testGreatestCommonDivisor_aIsLargerThanB() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(20, 5));
    }

    @Test
    void testGreatestCommonDivisor_bIsLargerThanA() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(5, 20));
    }

    @Test
    void testGreatestCommonDivisor_aIsPrime() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(7, 10));
    }

    @Test
    void testGreatestCommonDivisor_bIsPrime() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(10, 7));
    }

    @Test
    void testGreatestCommonDivisor_negativeNumbers() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(-25, 15));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(25, -15));
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(-25, -15));
    }

    @Test
    void testGreatestCommonDivisor_boundaryValues() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(1, 0));
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(0, 1));
    }
}