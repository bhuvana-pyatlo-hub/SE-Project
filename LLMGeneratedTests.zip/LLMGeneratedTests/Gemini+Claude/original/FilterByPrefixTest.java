package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FilterByPrefixTest {

    @Test
    void testFilterByPrefix_emptyList_emptyPrefix() {
        List<Object> input = new ArrayList<>();
        String prefix = "";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_emptyList_nonEmptyPrefix() {
        List<Object> input = new ArrayList<>();
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_emptyPrefix() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("bcd");
        String prefix = "";
        List<Object> expected = new ArrayList<>();
        expected.add("abc");
        expected.add("bcd");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixExists() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("bcd");
        input.add("cde");
        input.add("array");
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        expected.add("abc");
        expected.add("array");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixDoesNotExist() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("bcd");
        input.add("cde");
        input.add("array");
        String prefix = "z";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixIsSubstring() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("abcd");
        String prefix = "abc";
        List<Object> expected = new ArrayList<>();
        expected.add("abc");
        expected.add("abcd");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixMatchesEntireString() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("bcd");
        String prefix = "abc";
        List<Object> expected = new ArrayList<>();
        expected.add("abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_multipleMatches() {
        List<Object> input = new ArrayList<>();
        input.add("xxx");
        input.add("asd");
        input.add("xxy");
        input.add("john doe");
        input.add("xxxAAA");
        input.add("xxx");
        String prefix = "xxx";
        List<Object> expected = new ArrayList<>();
        expected.add("xxx");
        expected.add("xxxAAA");
        expected.add("xxx");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixIsLongerThanStrings() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("bcd");
        String prefix = "abcdefg";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixIsCaseSensitive() {
        List<Object> input = new ArrayList<>();
        input.add("Abc");
        input.add("abc");
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        expected.add("abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_prefixIsCaseSensitive2() {
        List<Object> input = new ArrayList<>();
        input.add("Abc");
        input.add("abc");
        String prefix = "A";
        List<Object> expected = new ArrayList<>();
        expected.add("Abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_nullPrefix() {
        List<Object> input = new ArrayList<>();
        input.add("abc");
        input.add("bcd");
        String prefix = null;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_nullString() {
        List<Object> input = new ArrayList<>();
        input.add(null);
        input.add("bcd");
        String prefix = "b";
        List<Object> expected = new ArrayList<>();
        expected.add("bcd");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_nullStringAndPrefix() {
        List<Object> input = new ArrayList<>();
        input.add(null);
        input.add("bcd");
        String prefix = null;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_emptyString() {
        List<Object> input = new ArrayList<>();
        input.add("");
        input.add("bcd");
        String prefix = "b";
        List<Object> expected = new ArrayList<>();
        expected.add("bcd");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_emptyStringAndPrefix() {
        List<Object> input = new ArrayList<>();
        input.add("");
        input.add("bcd");
        String prefix = "";
        List<Object> expected = new ArrayList<>();
        expected.add("");
        expected.add("bcd");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_numbersAsStrings() {
        List<Object> input = new ArrayList<>();
        input.add("123");
        input.add("456");
        String prefix = "1";
        List<Object> expected = new ArrayList<>();
        expected.add("123");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_specialCharacters() {
        List<Object> input = new ArrayList<>();
        input.add("!@#");
        input.add("$%^");
        String prefix = "!";
        List<Object> expected = new ArrayList<>();
        expected.add("!@#");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_mixedCaseAndSpecialChars() {
        List<Object> input = new ArrayList<>();
        input.add("aBc!@#");
        input.add("bcd");
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        expected.add("aBc!@#");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }

    @Test
    void testFilterByPrefix_nonEmptyList_unicodeCharacters() {
        List<Object> input = new ArrayList<>();
        input.add("你好世界");
        input.add("bcd");
        String prefix = "你";
        List<Object> expected = new ArrayList<>();
        expected.add("你好世界");
        assertEquals(expected, FilterByPrefix.filterByPrefix(input, prefix));
    }
}