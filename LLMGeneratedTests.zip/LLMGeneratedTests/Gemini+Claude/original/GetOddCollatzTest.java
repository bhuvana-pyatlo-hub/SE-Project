package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetOddCollatzTest {

    @Test
    void getOddCollatz_nIs1() {
        assertEquals(Collections.singletonList(1), GetOddCollatz.getOddCollatz(1));
    }

    @Test
    void getOddCollatz_nIs2() {
        assertEquals(Collections.singletonList(1), GetOddCollatz.getOddCollatz(2));
    }

    @Test
    void getOddCollatz_nIs3() {
        assertEquals(Arrays.asList(1, 3, 5), GetOddCollatz.getOddCollatz(3));
    }

    @Test
    void getOddCollatz_nIs4() {
        assertEquals(Arrays.asList(1, 5), GetOddCollatz.getOddCollatz(4));
    }

    @Test
    void getOddCollatz_nIs5() {
        assertEquals(Arrays.asList(1, 5), GetOddCollatz.getOddCollatz(5));
    }

    @Test
    void getOddCollatz_nIs6() {
        assertEquals(Arrays.asList(1, 3, 5), GetOddCollatz.getOddCollatz(6));
    }

    @Test
    void getOddCollatz_nIs7() {
        assertEquals(Arrays.asList(1, 7, 11, 13, 17), GetOddCollatz.getOddCollatz(7));
    }

    @Test
    void getOddCollatz_nIs8() {
        assertEquals(Arrays.asList(1, 5), GetOddCollatz.getOddCollatz(8));
    }

    @Test
    void getOddCollatz_nIs9() {
        assertEquals(Arrays.asList(1, 5, 7, 11, 13, 17, 19), GetOddCollatz.getOddCollatz(9));
    }

    @Test
    void getOddCollatz_nIs10() {
        assertEquals(Arrays.asList(1, 5), GetOddCollatz.getOddCollatz(10));
    }

    @Test
    void getOddCollatz_nIs11() {
        assertEquals(Arrays.asList(1, 11, 17), GetOddCollatz.getOddCollatz(11));
    }

    @Test
    void getOddCollatz_nIs12() {
        assertEquals(Arrays.asList(1, 3, 5), GetOddCollatz.getOddCollatz(12));
    }

    @Test
    void getOddCollatz_nIs13() {
        assertEquals(Arrays.asList(1, 13, 5, 17), GetOddCollatz.getOddCollatz(13));
    }

    @Test
    void getOddCollatz_nIs14() {
        assertEquals(Arrays.asList(1, 5, 7, 11, 13, 17), GetOddCollatz.getOddCollatz(14));
    }

    @Test
    void getOddCollatz_nIs15() {
        assertEquals(Arrays.asList(1, 5, 7, 11, 13, 15, 17, 19, 23), GetOddCollatz.getOddCollatz(15));
    }

    @Test
    void getOddCollatz_nIs16() {
        assertEquals(Arrays.asList(1, 5), GetOddCollatz.getOddCollatz(16));
    }

    @Test
    void getOddCollatz_nIs17() {
        assertEquals(Arrays.asList(1, 13, 17, 19, 23, 29, 31, 35, 41, 5, 53), GetOddCollatz.getOddCollatz(17));
    }

    @Test
    void getOddCollatz_nIs18() {
        assertEquals(Arrays.asList(1, 3, 5), GetOddCollatz.getOddCollatz(18));
    }

    @Test
    void getOddCollatz_nIs19() {
        assertEquals(Arrays.asList(1, 17, 19, 23, 29, 31, 35, 5, 53), GetOddCollatz.getOddCollatz(19));
    }

    @Test
    void getOddCollatz_nIs20() {
        assertEquals(Arrays.asList(1, 5), GetOddCollatz.getOddCollatz(20));
    }

}