package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FixSpacesTest {

    @Test
    void testNoSpaces() {
        assertEquals("Example", FixSpaces.fixSpaces("Example"));
    }

    @Test
    void testSingleSpace() {
        assertEquals("Example_1", FixSpaces.fixSpaces("Example 1"));
    }

    @Test
    void testLeadingSpace() {
        assertEquals("_Example_2", FixSpaces.fixSpaces(" Example 2"));
    }

    @Test
    void testMultipleConsecutiveSpaces() {
        assertEquals("_Example-3", FixSpaces.fixSpaces(" Example   3"));
    }

    @Test
    void testTrailingSpace() {
        assertEquals("Mudasir_Hanif_", FixSpaces.fixSpaces("Mudasir Hanif "));
    }

    @Test
    void testMultipleSpacesBetweenWords() {
        assertEquals("Yellow_Yellow__Dirty__Fellow", FixSpaces.fixSpaces("Yellow Yellow  Dirty  Fellow"));
    }

    @Test
    void testThreeConsecutiveSpaces() {
        assertEquals("Exa-mple", FixSpaces.fixSpaces("Exa   mple"));
    }

    @Test
    void testLeadingAndMultipleSpaces() {
        assertEquals("-Exa_1_2_2_mple", FixSpaces.fixSpaces("   Exa 1 2 2 mple"));
    }

    @Test
    void testEmptyString() {
        assertEquals("", FixSpaces.fixSpaces(""));
    }

    @Test
    void testOnlySpaces() {
        assertEquals("-", FixSpaces.fixSpaces("   "));
    }

    @Test
    void testTwoSpaces() {
        assertEquals("a__b", FixSpaces.fixSpaces("a  b"));
    }

    @Test
    void testFourSpaces() {
        assertEquals("a-b", FixSpaces.fixSpaces("a    b"));
    }

    @Test
    void testFiveSpaces() {
        assertEquals("a-b", FixSpaces.fixSpaces("a     b"));
    }

    @Test
    void testSpaceAtBeginningAndEnd() {
        assertEquals("_test_", FixSpaces.fixSpaces(" test "));
    }

    @Test
    void testMultipleSpacesAtBeginningAndEnd() {
        assertEquals("-test-", FixSpaces.fixSpaces("   test   "));
    }

    @Test
    void testMixedSpaces() {
        assertEquals("a_b-c_d", FixSpaces.fixSpaces("a b   c d"));
    }

    @Test
    void testLongStringWithSpaces() {
        String longString = "This is a very long string with many spaces in it.   Some are single, some are double, and some are triple.     Let's see how it handles it.";
        String expected = "This_is_a_very_long_string_with_many_spaces_in_it.__Some_are_single,_some_are_double,_and_some_are_triple.-Let's_see_how_it_handles_it.";
        assertEquals(expected, FixSpaces.fixSpaces(longString));
    }

    @Test
    void testStringWithOnlyOneSpace() {
        assertEquals("a_b", FixSpaces.fixSpaces("a b"));
    }

    @Test
    void testStringWithTwoSpacesAtEnd() {
        assertEquals("test__", FixSpaces.fixSpaces("test  "));
    }

    @Test
    void testStringWithThreeSpacesAtEnd() {
        assertEquals("test-", FixSpaces.fixSpaces("test   "));
    }

    @Test
    void testStringWithLeadingAndTrailingSpaces() {
        assertEquals("_test_", FixSpaces.fixSpaces("   test   "));
    }

    @Test
    void testStringWithMultipleLeadingSpaces() {
        assertEquals("-test", FixSpaces.fixSpaces("      test"));
    }

    @Test
    void testStringWithMultipleTrailingSpaces() {
        assertEquals("test-", FixSpaces.fixSpaces("test      "));
    }

    @Test
    void testStringWithOnlySpacesBetweenWords() {
        assertEquals("a-b-c", FixSpaces.fixSpaces("a     b     c"));
    }
}