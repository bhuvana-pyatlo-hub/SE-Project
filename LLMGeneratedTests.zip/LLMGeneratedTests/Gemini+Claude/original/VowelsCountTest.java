package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class VowelsCountTest {

    @Test
    void testEmptyString() {
        assertEquals(0, VowelsCount.vowelsCount(""));
    }

    @Test
    void testNoVowels() {
        assertEquals(0, VowelsCount.vowelsCount("bcdfgh"));
    }

    @Test
    void testOnlyVowelsLowercase() {
        assertEquals(5, VowelsCount.vowelsCount("aeiou"));
    }

    @Test
    void testOnlyVowelsUppercase() {
        assertEquals(5, VowelsCount.vowelsCount("AEIOU"));
    }

    @Test
    void testMixedCaseVowels() {
        assertEquals(5, VowelsCount.vowelsCount("aEiOu"));
    }

    @Test
    void testVowelsAndConsonantsLowercase() {
        assertEquals(2, VowelsCount.vowelsCount("abcde"));
    }

    @Test
    void testVowelsAndConsonantsUppercase() {
        assertEquals(2, VowelsCount.vowelsCount("AbCdE"));
    }

    @Test
    void testVowelsAndConsonantsMixedCase() {
        assertEquals(3, VowelsCount.vowelsCount("aBCdEf"));
    }

    @Test
    void testYAtEndLowercase() {
        assertEquals(2, VowelsCount.vowelsCount("key"));
    }

    @Test
    void testYAtEndUppercase() {
        assertEquals(2, VowelsCount.vowelsCount("keY"));
    }

    @Test
    void testYAtEndMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("bYe"));
    }

    @Test
    void testYNotAtEnd() {
        assertEquals(0, VowelsCount.vowelsCount("yellow"));
    }

    @Test
    void testYNotAtEndUppercase() {
        assertEquals(0, VowelsCount.vowelsCount("YELLOw"));
    }

    @Test
    void testYNotAtEndMixedCase() {
        assertEquals(0, VowelsCount.vowelsCount("YeLLOw"));
    }

    @Test
    void testOnlyYLowercase() {
        assertEquals(1, VowelsCount.vowelsCount("y"));
    }

    @Test
    void testOnlyYUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("Y"));
    }

    @Test
    void testWordWithYAndOtherVowelsLowercase() {
        assertEquals(3, VowelsCount.vowelsCount("bayou"));
    }

    @Test
    void testWordWithYAndOtherVowelsUppercase() {
        assertEquals(3, VowelsCount.vowelsCount("BAyoU"));
    }

    @Test
    void testWordWithYAndOtherVowelsMixedCase() {
        assertEquals(3, VowelsCount.vowelsCount("bAYoU"));
    }

    @Test
    void testWordWithYAndNoOtherVowels() {
        assertEquals(1, VowelsCount.vowelsCount("fly"));
    }

    @Test
    void testWordWithYAndNoOtherVowelsUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("FLy"));
    }

    @Test
    void testWordWithYAndNoOtherVowelsMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("fLY"));
    }

    @Test
    void testWordWithMultipleYAtEnd() {
        assertEquals(1, VowelsCount.vowelsCount("byy"));
    }

    @Test
    void testWordWithMultipleYAtEndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("bYY"));
    }

    @Test
    void testWordWithMultipleYAtEndMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("bYy"));
    }

    @Test
    void testLongStringWithVowelsAndY() {
        assertEquals(5, VowelsCount.vowelsCount("abracadabray"));
    }

    @Test
    void testStringWithNumbersAndSpecialCharacters() {
        assertEquals(2, VowelsCount.vowelsCount("h@ll0 w0rld!"));
    }

    @Test
    void testStringWithOnlySpecialCharacters() {
        assertEquals(0, VowelsCount.vowelsCount("!@#$%^&*()"));
    }

    @Test
    void testStringWithOnlyNumbers() {
        assertEquals(0, VowelsCount.vowelsCount("1234567890"));
    }

    @Test
    void testBoundaryValueYAtEnd() {
        assertEquals(1, VowelsCount.vowelsCount("day"));
    }

    @Test
    void testBoundaryValueYAtEndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("DAY"));
    }

    @Test
    void testBoundaryValueYNotAtEnd() {
        assertEquals(0, VowelsCount.vowelsCount("daisy"));
    }
}