package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RoundedAvgTest {

    @Test
    void roundedAvg_nGreaterThanM_returnsNegativeOne() {
        assertEquals(-1, RoundedAvg.roundedAvg(7, 5));
    }

    @Test
    void roundedAvg_nEqualsM_returnsBinaryRepresentation() {
        assertEquals("0b101", RoundedAvg.roundedAvg(5, 5));
    }

    @Test
    void roundedAvg_smallRange_returnsCorrectBinary() {
        assertEquals("0b11", RoundedAvg.roundedAvg(1, 5));
    }

    @Test
    void roundedAvg_mediumRange_returnsCorrectBinary() {
        assertEquals("0b1010", RoundedAvg.roundedAvg(7, 13));
    }

    @Test
    void roundedAvg_boundaryValues_returnsCorrectBinary() {
        assertEquals("0b10", RoundedAvg.roundedAvg(2, 3));
        assertEquals("0b10000000", RoundedAvg.roundedAvg(127, 129));
    }

    @Test
    void roundedAvg_nEqualsM_singleDigit() {
        assertEquals("0b1", RoundedAvg.roundedAvg(1, 1));
    }

    @Test
    void roundedAvg_nEqualsM_doubleDigit() {
        assertEquals("0b1100100", RoundedAvg.roundedAvg(100, 100));
    }

    @Test
    void roundedAvg_nAndMAreZero() {
        assertEquals("0b0", RoundedAvg.roundedAvg(0, 0));
    }

    @Test
    void roundedAvg_nIsZero() {
        assertEquals("0b1", RoundedAvg.roundedAvg(0, 2));
    }

    @Test
    void roundedAvg_mIsZero_nGreaterThanM() {
        assertEquals(-1, RoundedAvg.roundedAvg(1, 0));
    }

    @Test
    void roundedAvg_nIsNegative_mIsPositive() {
        assertEquals("0b0", RoundedAvg.roundedAvg(-1, 1));
    }

    @Test
    void roundedAvg_nIsNegative_mIsNegative() {
        assertEquals("0b-10", RoundedAvg.roundedAvg(-3, -1));
    }

    @Test
    void roundedAvg_smallRange_avgIsDecimal() {
        assertEquals("0b10", RoundedAvg.roundedAvg(2, 3));
    }

    @Test
    void roundedAvg_closeValues_returnsCorrectBinary() {
        assertEquals("0b1111100100", RoundedAvg.roundedAvg(996, 997));
    }

    @Test
    void roundedAvg_anotherMediumRange_returnsCorrectBinary() {
        assertEquals("0b110101101", RoundedAvg.roundedAvg(362, 496));
    }

    @Test
    void roundedAvg_smallerRange_returnsCorrectBinary() {
        assertEquals("0b11010111", RoundedAvg.roundedAvg(197, 233));
    }

    @Test
    void roundedAvg_nGreaterThanM_returnsNegativeOne_2() {
        assertEquals(-1, RoundedAvg.roundedAvg(5, 1));
    }
}