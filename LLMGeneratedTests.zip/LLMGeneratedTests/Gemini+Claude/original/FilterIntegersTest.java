package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FilterIntegersTest {

    @Test
    void testFilterIntegers_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_onlyIntegers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_onlyStrings() {
        List<Object> input = Arrays.asList("a", "b", "c", "d", "e");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_mixedTypes() {
        List<Object> input = Arrays.asList("a", 1, "b", 2, "c", 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_mixedTypes_withDoubles() {
        List<Object> input = Arrays.asList("a", 1, "b", 2.5, "c", 3);
        List<Object> expected = Arrays.asList(1, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_mixedTypes_withNull() {
        List<Object> input = Arrays.asList("a", 1, "b", null, "c", 3);
        List<Object> expected = Arrays.asList(1, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_mixedTypes_withZero() {
        List<Object> input = Arrays.asList("a", 0, "b", 2.5, "c", 3);
        List<Object> expected = Arrays.asList(0, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_mixedTypes_withNegativeIntegers() {
        List<Object> input = Arrays.asList("a", -1, "b", 2.5, "c", 3);
        List<Object> expected = Arrays.asList(-1, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_duplicateIntegers() {
        List<Object> input = Arrays.asList(1, 2, 1, 2, 1);
        List<Object> expected = Arrays.asList(1, 2, 1, 2, 1);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_onlyOneInteger() {
        List<Object> input = Arrays.asList("a", "b", 1, "c");
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_noIntegers() {
        List<Object> input = Arrays.asList("a", "b", "c");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_multipleTypes() {
        List<Object> input = Arrays.asList(1, "a", 2.5, 3, 'b', 4L);
        List<Object> expected = Arrays.asList(1, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_listWithNullElements() {
        List<Object> input = Arrays.asList(1, null, 2, null, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_listWithEmptyString() {
        List<Object> input = Arrays.asList(1, "", 2, "", 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_listWithSpecialCharacters() {
        List<Object> input = Arrays.asList(1, "@", 2, "#", 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_listWithBooleanValues() {
        List<Object> input = Arrays.asList(1, true, 2, false, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_listWithLongValues() {
        List<Object> input = Arrays.asList(1L, 2L, 3L);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_listWithCharacterValues() {
        List<Object> input = Arrays.asList('a', 'b', 'c');
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testFilterIntegers_nullList() {
        List<Object> input = null;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }
}