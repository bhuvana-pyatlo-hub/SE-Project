package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HowManyTimesTest {

    @Test
    void howManyTimes_emptyString_returnsZero() {
        assertEquals(0, HowManyTimes.howManyTimes("", "a"));
    }

    @Test
    void howManyTimes_emptySubstring_returnsZero() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", ""));
    }

    @Test
    void howManyTimes_emptyStringAndSubstring_returnsZero() {
        assertEquals(0, HowManyTimes.howManyTimes("", ""));
    }

    @Test
    void howManyTimes_substringNotFound_returnsZero() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", "d"));
    }

    @Test
    void howManyTimes_substringFoundOnce_returnsOne() {
        assertEquals(1, HowManyTimes.howManyTimes("abc", "ab"));
    }

    @Test
    void howManyTimes_substringFoundMultipleTimes_returnsCorrectCount() {
        assertEquals(3, HowManyTimes.howManyTimes("aaa", "a"));
    }

    @Test
    void howManyTimes_overlappingSubstrings_returnsCorrectCount() {
        assertEquals(3, HowManyTimes.howManyTimes("aaaa", "aa"));
    }

    @Test
    void howManyTimes_substringAtBeginning_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("john doe", "john"));
    }

    @Test
    void howManyTimes_substringAtEnd_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("doe john", "john"));
    }

    @Test
    void howManyTimes_substringInMiddle_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("doe john doe", "john"));
    }

    @Test
    void howManyTimes_substringEqualsString_returnsOne() {
        assertEquals(1, HowManyTimes.howManyTimes("abc", "abc"));
    }

    @Test
    void howManyTimes_substringLongerThanString_returnsZero() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", "abcd"));
    }

    @Test
    void howManyTimes_multipleOverlappingSubstrings_returnsCorrectCount() {
        assertEquals(4, HowManyTimes.howManyTimes("xyxyxyx", "x"));
    }

    @Test
    void howManyTimes_complexOverlappingSubstrings_returnsCorrectCount() {
        assertEquals(4, HowManyTimes.howManyTimes("cacacacac", "cac"));
    }

    @Test
    void howManyTimes_substringWithSpecialCharacters_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("abc$def", "$"));
    }

    @Test
    void howManyTimes_stringWithSpecialCharacters_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("$abc", "$"));
    }

    @Test
    void howManyTimes_substringWithSpaces_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("abc def", "abc def"));
    }

    @Test
    void howManyTimes_stringWithSpaces_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes(" abc def ", "abc def"));
    }

    @Test
    void howManyTimes_substringMultipleOccurrences_returnsCorrectCount() {
        assertEquals(2, HowManyTimes.howManyTimes("abababa", "ba"));
    }

    @Test
    void howManyTimes_stringWithRepeatedCharacters_returnsCorrectCount() {
        assertEquals(5, HowManyTimes.howManyTimes("bbbbb", "b"));
    }

    @Test
    void howManyTimes_substringAtStartAndEnd_returnsCorrectCount() {
        assertEquals(2, HowManyTimes.howManyTimes("aba", "a"));
    }

    @Test
    void howManyTimes_substringWithLeadingAndTrailingSpaces_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("  a b c  ", " "));
    }

    @Test
    void howManyTimes_substringWithNoOverlap_returnsZero() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", "xyz"));
    }

    @Test
    void howManyTimes_substringWithSingleCharacter_returnsCorrectCount() {
        assertEquals(1, HowManyTimes.howManyTimes("a", "a"));
    }

    @Test
    void howManyTimes_substringAtStartAndEndWithSpaces_returnsCorrectCount() {
        assertEquals(2, HowManyTimes.howManyTimes(" a a ", "a"));
    }
}