package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class IsSortedTest {

    @Test
    void isSorted_emptyList_returnsTrue() {
        List<Object> list = new ArrayList<>();
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_singleElementList_returnsTrue() {
        List<Object> list = Arrays.asList(5);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_ascendingList_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_notSortedList_returnsFalse() {
        List<Object> list = Arrays.asList(1, 3, 2, 4, 5);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_ascendingListLong_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_notSortedListLong_returnsFalse() {
        List<Object> list = Arrays.asList(1, 3, 2, 4, 5, 6, 7);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_duplicateElementsSorted_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 2, 3, 3, 4);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_multipleDuplicates_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 2, 2, 3, 4);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_descendingList_returnsFalse() {
        List<Object> list = Arrays.asList(3, 2, 1);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_multipleDuplicatesMiddle_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 3, 3, 3, 4);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_sameNumberList_returnsTrue() {
        List<Object> list = Arrays.asList(5, 5);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_sameNumberListMultiple_returnsFalse() {
        List<Object> list = Arrays.asList(5, 5, 5);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_almostSorted_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 0, 4, 5);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_sortedWithGaps_returnsTrue() {
        List<Object> list = Arrays.asList(1, 5, 7, 9, 10);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_unsortedWithGaps_returnsFalse() {
        List<Object> list = Arrays.asList(1, 5, 3, 9, 10);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_twoElementsSorted_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_twoElementsUnsorted_returnsFalse() {
        List<Object> list = Arrays.asList(2, 1);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithDuplicatesAtEnd_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 4);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithTooManyDuplicatesAtEnd_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 4, 4);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithDuplicatesAtBeginning_returnsTrue() {
        List<Object> list = Arrays.asList(1, 1, 2, 3, 4);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithTooManyDuplicatesAtBeginning_returnsFalse() {
        List<Object> list = Arrays.asList(1, 1, 1, 2, 3, 4);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_boundaryValues_returnsTrue() {
        List<Object> list = Arrays.asList(0, 0, 1);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_boundaryValuesTooManyDuplicates_returnsFalse() {
        List<Object> list = Arrays.asList(0, 0, 0, 1);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_negativeValues_returnsFalse() {
        List<Object> list = Arrays.asList(-1, -2, -3);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_negativeAndPositiveValues_returnsFalse() {
        List<Object> list = Arrays.asList(-1, 0, 1);
        assertTrue(IsSorted.isSorted(list));
    }
}