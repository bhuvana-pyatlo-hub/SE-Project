package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TriplesSumToZeroTest {

    @Test
    void triplesSumToZero_emptyList_returnsFalse() {
        List<Integer> list = new ArrayList<>();
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_oneElementList_returnsFalse() {
        List<Integer> list = Arrays.asList(1);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_twoElementList_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_threeElementList_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, -3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_threeElementList_sumIsNotZero_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_fourElementList_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, -6);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_fourElementList_noSumIsZero_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_multipleElements_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, -1, -2, 0);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_multipleElements_noSumIsZero_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_negativeNumbers_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, -2, 3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_negativeNumbers_noSumIsZero_returnsFalse() {
        List<Integer> list = Arrays.asList(-1, -2, -3);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_zeroes_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(0, 0, 0);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_zeroesAndNonZeroes_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(0, 1, -1);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_duplicateNumbers_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 1, -2);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_largeList_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, -1, -2, -3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_largeList_noSumIsZero_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_boundaryValues_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(100, -50, -50);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_allSameNumbers_noSumIsZero_returnsFalse() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_mixedPositiveNegativeZero_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(10, -5, 0, -5);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_negativeBoundaryValues_sumIsZero_returnsTrue() {
        List<Integer> list = Arrays.asList(-100, 50, 50);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void triplesSumToZero_negativeBoundaryValues_noSumIsZero_returnsFalse() {
        List<Integer> list = Arrays.asList(-100, -50, -50);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }
}