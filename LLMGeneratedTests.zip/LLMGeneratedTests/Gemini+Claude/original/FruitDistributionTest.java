package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FruitDistributionTest {

    @Test
    void fruitDistribution_validInput_returnsCorrectMangoes() {
        assertEquals(8, FruitDistribution.fruitDistribution("5 apples and 6 oranges", 19));
    }

    @Test
    void fruitDistribution_zeroApplesAndOranges_returnsCorrectMangoes() {
        assertEquals(3, FruitDistribution.fruitDistribution("0 apples and 0 oranges", 3));
    }

    @Test
    void fruitDistribution_zeroApples_returnsCorrectMangoes() {
        assertEquals(2, FruitDistribution.fruitDistribution("0 apples and 1 oranges", 3));
    }

    @Test
    void fruitDistribution_zeroOranges_returnsCorrectMangoes() {
        assertEquals(2, FruitDistribution.fruitDistribution("1 apples and 0 oranges", 3));
    }

    @Test
    void fruitDistribution_largeTotalFruits_returnsCorrectMangoes() {
        assertEquals(95, FruitDistribution.fruitDistribution("2 apples and 3 oranges", 100));
    }

    @Test
    void fruitDistribution_smallTotalFruits_returnsCorrectMangoes() {
        assertEquals(0, FruitDistribution.fruitDistribution("2 apples and 3 oranges", 5));
    }

    @Test
    void fruitDistribution_largeApples_returnsCorrectMangoes() {
        assertEquals(19, FruitDistribution.fruitDistribution("100 apples and 1 oranges", 120));
    }

    @Test
    void fruitDistribution_largeOranges_returnsCorrectMangoes() {
        assertEquals(19, FruitDistribution.fruitDistribution("1 apples and 100 oranges", 120));
    }

    @Test
    void fruitDistribution_noApplesOrOranges_returnsTotalFruits() {
        assertEquals(10, FruitDistribution.fruitDistribution("0 apples and 0 oranges", 10));
    }

    @Test
    void fruitDistribution_onlyApples_returnsCorrectMangoes() {
        assertEquals(5, FruitDistribution.fruitDistribution("5 apples and 0 oranges", 10));
    }

    @Test
    void fruitDistribution_onlyOranges_returnsCorrectMangoes() {
        assertEquals(5, FruitDistribution.fruitDistribution("0 apples and 5 oranges", 10));
    }

    @Test
    void fruitDistribution_applesAndOrangesAtStart_returnsCorrectMangoes() {
        assertEquals(4, FruitDistribution.fruitDistribution("2 apples and 4 oranges", 10));
    }

    @Test
    void fruitDistribution_applesAndOrangesAtEnd_returnsCorrectMangoes() {
        assertEquals(4, FruitDistribution.fruitDistribution("4 apples and 2 oranges", 10));
    }

    @Test
    void fruitDistribution_sameNumberOfApplesAndOranges_returnsCorrectMangoes() {
        assertEquals(6, FruitDistribution.fruitDistribution("2 apples and 2 oranges", 10));
    }

    @Test
    void fruitDistribution_negativeMangoes_returnsCorrectMangoes() {
        assertEquals(-1, FruitDistribution.fruitDistribution("10 apples and 1 oranges", 10));
    }

    @Test
    void fruitDistribution_applesAndOrangesMixedUp_returnsCorrectMangoes() {
        assertEquals(5, FruitDistribution.fruitDistribution("5 apples and 0 oranges", 5));
    }

    @Test
    void fruitDistribution_largeApplesAndOranges_returnsCorrectMangoes() {
        assertEquals(0, FruitDistribution.fruitDistribution("50 apples and 50 oranges", 100));
    }

    @Test
    void fruitDistribution_totalFruitsZero_returnsNegativeApplesAndOrangesSum() {
        assertEquals(-11, FruitDistribution.fruitDistribution("5 apples and 6 oranges", 0));
    }

    @Test
    void fruitDistribution_totalFruitsEqualToApplesAndOranges_returnsZero() {
        assertEquals(0, FruitDistribution.fruitDistribution("5 apples and 5 oranges", 10));
    }

    @Test
    void fruitDistribution_differentOrderOfApplesAndOranges_returnsCorrectMangoes() {
        assertEquals(4, FruitDistribution.fruitDistribution("4 apples and 2 oranges", 10));
    }
}