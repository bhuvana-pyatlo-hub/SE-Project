package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EncodeTest {

    @Test
    void encode_emptyString_returnsEmptyString() {
        assertEquals("", Encode.encode(""));
    }

    @Test
    void encode_lowercaseString_returnsUppercaseString() {
        assertEquals("TGST", Encode.encode("test"));
    }

    @Test
    void encode_uppercaseString_returnsLowercaseString() {
        assertEquals("tgst", Encode.encode("TEST"));
    }

    @Test
    void encode_mixedCaseString_returnsSwappedCaseString() {
        assertEquals("mWDCSKR", Encode.encode("Mudasir"));
    }

    @Test
    void encode_stringWithVowels_returnsEncodedVowels() {
        assertEquals("ygs", Encode.encode("YES"));
    }

    @Test
    void encode_stringWithSpaces_returnsEncodedStringWithSpaces() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message"));
    }

    @Test
    void encode_stringWithMixedCaseAndVowels_returnsEncodedString() {
        assertEquals("k dQnT kNqW wHcT Tq wRkTg", Encode.encode("I DoNt KnOw WhAt tO WrItE"));
    }

    @Test
    void encode_stringWithNonAlphaChars_returnsStringWithNonAlphaCharsUnchanged() {
        assertEquals("123", Encode.encode("123"));
    }

    @Test
    void encode_stringWithSpecialChars_returnsStringWithSpecialCharsUnchanged() {
        assertEquals("!@#", Encode.encode("!@#"));
    }

    @Test
    void encode_stringWithNumbersAndLetters_returnsEncodedString() {
        assertEquals("1tG2S3T", Encode.encode("1Te2s3t"));
    }

    @Test
    void encode_singleLowercaseVowel_returnsEncodedVowel() {
        assertEquals("c", Encode.encode("a"));
    }

    @Test
    void encode_singleUppercaseVowel_returnsEncodedVowel() {
        assertEquals("c", Encode.encode("A"));
    }

    @Test
    void encode_singleLowercaseConsonant_returnsUppercaseConsonant() {
        assertEquals("B", Encode.encode("b"));
    }

    @Test
    void encode_singleUppercaseConsonant_returnsLowercaseConsonant() {
        assertEquals("b", Encode.encode("B"));
    }

    @Test
    void encode_stringWithMultipleVowels_returnsEncodedString() {
        assertEquals("ckk", Encode.encode("aia"));
    }

    @Test
    void encode_stringWithMultipleConsonants_returnsEncodedString() {
        assertEquals("QRS", Encode.encode("qrs"));
    }

    @Test
    void encode_stringWithMixedVowelsAndConsonants_returnsEncodedString() {
        assertEquals("tHKS", Encode.encode("This"));
    }

    @Test
    void encode_stringWithLeadingAndTrailingSpaces_returnsEncodedStringWithSpaces() {
        assertEquals(" tGst ", Encode.encode(" test "));
    }

    @Test
    void encode_stringWithInternalMultipleSpaces_returnsEncodedStringWithSpaces() {
        assertEquals("tHKS  KS  C", Encode.encode("This  is  a"));
    }

    @Test
    void encode_stringWithOnlySpaces_returnsStringWithOnlySpaces() {
        assertEquals("   ", Encode.encode("   "));
    }

    @Test
    void encode_boundaryLowercaseVowel_returnsEncodedVowel() {
        assertEquals("c", Encode.encode("a")); // Testing boundary case for 'a'
    }

    @Test
    void encode_boundaryUppercaseVowel_returnsEncodedVowel() {
        assertEquals("c", Encode.encode("A")); // Testing boundary case for 'A'
    }

    @Test
    void encode_boundaryLowercaseConsonant_returnsUppercaseConsonant() {
        assertEquals("B", Encode.encode("b")); // Testing boundary case for 'b'
    }

    @Test
    void encode_boundaryUppercaseConsonant_returnsLowercaseConsonant() {
        assertEquals("b", Encode.encode("B")); // Testing boundary case for 'B'
    }

    @Test
    void encode_negativeAndZeroValues_returnsUnchanged() {
        assertEquals("0-1-2", Encode.encode("0-1-2")); // Testing with negative and zero values
    }
}