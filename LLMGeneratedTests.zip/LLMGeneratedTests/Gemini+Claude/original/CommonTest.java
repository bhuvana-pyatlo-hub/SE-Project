package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CommonTest {

    @Test
    void common_emptyLists_returnsEmptyList() {
        List<Integer> l1 = Collections.emptyList();
        List<Object> l2 = Collections.emptyList();
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }

    @Test
    void common_l1Empty_returnsEmptyList() {
        List<Integer> l1 = Collections.emptyList();
        List<Object> l2 = Arrays.asList(1, 2, 3);
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }

    @Test
    void common_l2Empty_returnsEmptyList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Collections.emptyList();
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }

    @Test
    void common_noCommonElements_returnsEmptyList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(4, 5, 6);
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }

    @Test
    void common_someCommonElements_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(1, 4, 3, 34, 653, 2, 5);
        List<Object> l2 = Arrays.asList(5, 7, 1, 5, 9, 653, 121);
        List<Object> expected = Arrays.asList(1, 5, 653);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_duplicateElementsInL1_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(1, 2, 2, 3);
        List<Object> l2 = Arrays.asList(2, 3, 4);
        List<Object> expected = Arrays.asList(2, 3);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_duplicateElementsInL2_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(2, 2, 3, 4);
        List<Object> expected = Arrays.asList(2, 3);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_allElementsCommon_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(3, 2, 1);
        List<Object> expected = Arrays.asList(1, 2, 3);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l2ContainsNonInteger_ignoresNonInteger() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(2, "hello", 3, 4);
        List<Object> expected = Arrays.asList(2, 3);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l2ContainsOnlyNonInteger_returnsEmptyList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList("hello", "world");
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }

    @Test
    void common_negativeNumbers_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(-1, -2, -3);
        List<Object> l2 = Arrays.asList(-3, -2, -4);
        List<Object> expected = Arrays.asList(-3, -2);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_mixedPositiveNegativeNumbers_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(-1, 2, -3);
        List<Object> l2 = Arrays.asList(-3, 2, 4);
        List<Object> expected = Arrays.asList(-3, 2);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_zeroInLists_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(0, 1, 2);
        List<Object> l2 = Arrays.asList(0, 2, 3);
        List<Object> expected = Arrays.asList(0, 2);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l1HasDuplicatesAndL2HasNonIntegersAndDuplicates() {
        List<Integer> l1 = Arrays.asList(1, 2, 2, 3, 4, 4, 5);
        List<Object> l2 = Arrays.asList(2, "string", 3, 3, 4, 6, 7, 2);
        List<Object> expected = Arrays.asList(2, 3, 4);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l1AndL2SameValuesDifferentOrder() {
        List<Integer> l1 = Arrays.asList(5, 2, 1, 4, 3);
        List<Object> l2 = Arrays.asList(3, 4, 1, 2, 5);
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l1ContainsZeroL2ContainsNull() {
        List<Integer> l1 = Arrays.asList(0, 1, 2);
        List<Object> l2 = Arrays.asList(null, 0, 2);
        List<Object> expected = Arrays.asList(0, 2);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l1ContainsNullL2ContainsZero() {
        List<Integer> l1 = new ArrayList<>();
        l1.add(null);
        l1.add(1);
        l1.add(2);
        List<Object> l2 = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(1, 2);
        List<Object> result = Common.common(l1, l2);
        assertEquals(expected, result);
    }

    @Test
    void common_l1ContainsOnlyNullL2ContainsOnlyZero() {
        List<Integer> l1 = new ArrayList<>();
        l1.add(null);
        List<Object> l2 = Arrays.asList(0);
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }

    @Test
    void common_l1ContainsOnlyNullL2ContainsOnlyNull() {
        List<Integer> l1 = new ArrayList<>();
        l1.add(null);
        List<Object> l2 = new ArrayList<>();
        l2.add(null);
        List<Object> result = Common.common(l1, l2);
        assertTrue(result.isEmpty());
    }
}