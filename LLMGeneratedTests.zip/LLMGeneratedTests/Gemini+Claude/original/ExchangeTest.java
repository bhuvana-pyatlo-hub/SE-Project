package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExchangeTest {

    @Test
    void exchange_allEvenLst1_returnsYes() {
        List<Integer> lst1 = Arrays.asList(2, 4, 6);
        List<Integer> lst2 = Arrays.asList(1, 3, 5);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_allOddLst1_sufficientEvenLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5);
        List<Integer> lst2 = Arrays.asList(2, 4, 6);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_mixedLst1_sufficientEvenLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4);
        List<Integer> lst2 = Arrays.asList(2, 4, 6);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_mixedLst1_insufficientEvenLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4);
        List<Integer> lst2 = Arrays.asList(1, 3, 5);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_noEvenLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5);
        List<Integer> lst2 = Arrays.asList(1, 3, 5);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_emptyLst2_returnsNoIfLst1HasOdd() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3);
        List<Integer> lst2 = Collections.emptyList();
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_emptyLst2_returnsYesIfLst1HasOnlyEven() {
        List<Integer> lst1 = Arrays.asList(2, 4, 6);
        List<Integer> lst2 = Collections.emptyList();
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_emptyLst1_returnsYes() {
        List<Integer> lst1 = Collections.emptyList();
        List<Integer> lst2 = Arrays.asList(2, 4, 6);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_bothEmptyLists_returnsYes() {
        List<Integer> lst1 = Collections.emptyList();
        List<Integer> lst2 = Collections.emptyList();
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleElementOddLst1_singleElementEvenLst2_returnsYes() {
        List<Integer> lst1 = Collections.singletonList(1);
        List<Integer> lst2 = Collections.singletonList(2);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleElementEvenLst1_singleElementOddLst2_returnsYes() {
        List<Integer> lst1 = Collections.singletonList(2);
        List<Integer> lst2 = Collections.singletonList(1);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleElementOddLst1_singleElementOddLst2_returnsNo() {
        List<Integer> lst1 = Collections.singletonList(1);
        List<Integer> lst2 = Collections.singletonList(1);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleElementEvenLst1_singleElementEvenLst2_returnsYes() {
        List<Integer> lst1 = Collections.singletonList(2);
        List<Integer> lst2 = Collections.singletonList(2);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_equalNumberOfOddAndEvenInLst1_sufficientEvenInLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4, 5, 6);
        List<Integer> lst2 = Arrays.asList(2, 4, 6, 8, 10);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_equalNumberOfOddAndEvenInLst1_insufficientEvenInLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4, 5, 6);
        List<Integer> lst2 = Arrays.asList(2, 4, 1, 3, 5);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_moreOddThanEvenInLst1_sufficientEvenInLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5, 2, 4);
        List<Integer> lst2 = Arrays.asList(2, 4, 6, 8, 10);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_moreOddThanEvenInLst1_insufficientEvenInLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5, 2, 4);
        List<Integer> lst2 = Arrays.asList(2, 4, 1, 3);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_lst1HasZero_lst2HasEven_returnsYes() {
        List<Integer> lst1 = Arrays.asList(0, 1, 3);
        List<Integer> lst2 = Arrays.asList(2, 4, 6);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_lst1HasZero_lst2HasNoEven_returnsNo() {
        List<Integer> lst1 = Arrays.asList(0, 1, 3);
        List<Integer> lst2 = Arrays.asList(1, 3, 5);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_lst1HasAllOdd_lst2HasOneEven_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5);
        List<Integer> lst2 = Arrays.asList(2, 1, 3);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_lst1HasNegativeOdd_lst2HasEven_returnsYes() {
        List<Integer> lst1 = Arrays.asList(-1, -3, -5);
        List<Integer> lst2 = Arrays.asList(2, 4, 6);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_lst1HasNegativeOdd_lst2HasNoEven_returnsNo() {
        List<Integer> lst1 = Arrays.asList(-1, -3, -5);
        List<Integer> lst2 = Arrays.asList(-1, -3, -5);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }
}