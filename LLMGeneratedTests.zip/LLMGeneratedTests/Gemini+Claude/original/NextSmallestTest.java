package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class NextSmallestTest {

    @Test
    void nextSmallest_emptyList_returnsNull() {
        List<Object> list = new ArrayList<>();
        assertNull(NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_singleElementList_returnsNull() {
        List<Object> list = Arrays.asList(1);
        assertNull(NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_example1() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_example2() {
        List<Object> list = Arrays.asList(5, 1, 4, 3, 2);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_example3() {
        List<Object> list = Arrays.asList(1, 1);
        assertNull(NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_example4() {
        List<Object> list = Arrays.asList(1, 1, 1, 1, 0);
        assertEquals(1, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_example5() {
        List<Object> list = Arrays.asList(-35, 34, 12, -45);
        assertEquals(-35, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_allSameElements_returnsNull() {
        List<Object> list = Arrays.asList(5, 5, 5, 5, 5);
        assertNull(NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_twoElements_different() {
        List<Object> list = Arrays.asList(5, 1);
        assertEquals(5, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_twoElements_same() {
        List<Object> list = Arrays.asList(1, 1);
        assertNull(NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_negativeNumbers() {
        List<Object> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(-4, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_mixedPositiveNegative() {
        List<Object> list = Arrays.asList(-1, 2, -3, 4, -5);
        assertEquals(-3, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_duplicateSmallest() {
        List<Object> list = Arrays.asList(1, 2, 1, 3, 4);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_smallestAtEnd() {
        List<Object> list = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_smallestInMiddle() {
        List<Object> list = Arrays.asList(5, 4, 1, 3, 2);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_zeroIncluded() {
        List<Object> list = Arrays.asList(5, 0, 2, 8, 1);
        assertEquals(1, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_onlyTwoUniqueElements() {
        List<Object> list = Arrays.asList(1, 2, 2, 2, 2);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_twoIdenticalElements() {
        List<Object> list = Arrays.asList(2, 2);
        assertNull(NextSmallest.nextSmallest(list));
    }

    @Test
    void nextSmallest_twoDifferentIdenticalElements() {
        List<Object> list = Arrays.asList(2, 1);
        assertEquals(2, NextSmallest.nextSmallest(list));
    }
}