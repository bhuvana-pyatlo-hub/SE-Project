package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CompareTest {

    @Test
    void compare_emptyLists_returnsEmptyList() {
        List<Integer> game = new ArrayList<>();
        List<Integer> guess = new ArrayList<>();
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_equalLists_returnsListWithZeros() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_differentLists_returnsListWithDifferences() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(4, 5, 6);
        List<Integer> expected = Arrays.asList(3, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_mixedLists_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> guess = Arrays.asList(1, 3, 5, 2, 4);
        List<Integer> expected = Arrays.asList(0, 1, 2, 2, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_negativeNumbers_returnsAbsoluteDifferences() {
        List<Integer> game = Arrays.asList(-1, -2, -3);
        List<Integer> guess = Arrays.asList(-4, -5, -6);
        List<Integer> expected = Arrays.asList(3, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_mixedPositiveNegative_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(1, -2, 3);
        List<Integer> guess = Arrays.asList(-1, 2, -3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_zeroValues_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(0, 0, 0);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_sameSizeLists_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(1, 5, 2, 8);
        List<Integer> guess = Arrays.asList(3, 2, 7, 1);
        List<Integer> expected = Arrays.asList(2, 3, 5, 7);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_oneElementLists_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(5);
        List<Integer> guess = Arrays.asList(10);
        List<Integer> expected = Arrays.asList(5);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allNegativeNumbers_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(-10, -5, -2);
        List<Integer> guess = Arrays.asList(-2, -8, -1);
        List<Integer> expected = Arrays.asList(8, 3, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allZeroGuesses_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(0, 0, 0);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allZeroGames_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(0, 0, 0);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_sameValuesDifferentSigns_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(5, -5);
        List<Integer> guess = Arrays.asList(-5, 5);
        List<Integer> expected = Arrays.asList(10, 10);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithDuplicates_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(1, 2, 1, 2);
        List<Integer> guess = Arrays.asList(2, 1, 2, 1);
        List<Integer> expected = Arrays.asList(1, 1, 1, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_largeAndSmallNumbers_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(100, 1);
        List<Integer> guess = Arrays.asList(1, 100);
        List<Integer> expected = Arrays.asList(99, 99);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allSameNumbers_returnsCorrectResult() {
        List<Integer> game = Arrays.asList(5, 5, 5);
        List<Integer> guess = Arrays.asList(1, 1, 1);
        List<Integer> expected = Arrays.asList(4, 4, 4);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_nullLists_returnsNonNullList() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> result = Compare.compare(game, guess);
        assertNotNull(result);
    }

    @Test
    void compare_validInput_returnsCorrectList() {
        List<Integer> game = Arrays.asList(10, 20, 30);
        List<Integer> guess = Arrays.asList(5, 15, 35);
        List<Integer> expected = Arrays.asList(5, 5, 5);
        assertEquals(expected, Compare.compare(game, guess));
    }
}