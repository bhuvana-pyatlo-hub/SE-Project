package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RescaleToUnitTest {

    @Test
    void rescaleToUnit_validInput_returnsRescaledList() {
        List<Double> input = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 0.25, 0.5, 0.75, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_twoElements_returnsRescaledList() {
        List<Double> input = Arrays.asList(2.0, 49.9);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_twoElementsReversed_returnsRescaledList() {
        List<Double> input = Arrays.asList(100.0, 49.9);
        List<Double> expected = Arrays.asList(1.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_unsortedInput_returnsRescaledList() {
        List<Double> input = Arrays.asList(2.0, 1.0, 5.0, 3.0, 4.0);
        List<Double> expected = Arrays.asList(0.25, 0.0, 1.0, 0.5, 0.75);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_anotherUnsortedInput_returnsRescaledList() {
        List<Double> input = Arrays.asList(12.0, 11.0, 15.0, 13.0, 14.0);
        List<Double> expected = Arrays.asList(0.25, 0.0, 1.0, 0.5, 0.75);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_allSameValues_returnsListWithZeros() {
        List<Double> input = Arrays.asList(5.0, 5.0, 5.0, 5.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_negativeValues_returnsRescaledList() {
        List<Double> input = Arrays.asList(-1.0, -2.0, -3.0, -4.0, -5.0);
        List<Double> expected = Arrays.asList(1.0, 0.75, 0.5, 0.25, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_mixedPositiveNegative_returnsRescaledList() {
        List<Double> input = Arrays.asList(-1.0, 0.0, 1.0, 2.0);
        List<Double> expected = Arrays.asList(0.0, 0.3333333333333333, 0.6666666666666666, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_smallValues_returnsRescaledList() {
        List<Double> input = Arrays.asList(0.1, 0.2, 0.3);
        List<Double> expected = Arrays.asList(0.0, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_duplicateValues_returnsRescaledList() {
        List<Double> input = Arrays.asList(1.0, 2.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(0.0, 0.5, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_minIsZero_returnsRescaledList() {
        List<Double> input = Arrays.asList(0.0, 1.0, 2.0);
        List<Double> expected = Arrays.asList(0.0, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_maxIsZero_returnsRescaledList() {
        List<Double> input = Arrays.asList(-2.0, -1.0, 0.0);
        List<Double> expected = Arrays.asList(0.0, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_minAndMaxAreZero_returnsListWithZeros() {
        List<Double> input = Arrays.asList(0.0, 0.0, 0.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_onePositiveOneNegative_returnsRescaledList() {
        List<Double> input = Arrays.asList(-1.0, 1.0);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_oneNegativeMultiplePositive_returnsRescaledList() {
        List<Double> input = Arrays.asList(-1.0, 1.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(0.0, 0.6666666666666666, 0.8333333333333334, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_multipleNegativeOnePositive_returnsRescaledList() {
        List<Double> input = Arrays.asList(-3.0, -2.0, -1.0, 1.0);
        List<Double> expected = Arrays.asList(0.0, 0.25, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_decimalValues_returnsRescaledList() {
        List<Double> input = Arrays.asList(1.1, 2.2, 3.3);
        List<Double> expected = Arrays.asList(0.0, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_sameMinAndMax_returnsListWithZeros() {
        List<Double> input = Arrays.asList(7.0, 7.0);
        List<Double> expected = Arrays.asList(0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void rescaleToUnit_minIsMax_returnsListWithZeros() {
        List<Double> input = Arrays.asList(8.0, 8.0, 8.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }
}