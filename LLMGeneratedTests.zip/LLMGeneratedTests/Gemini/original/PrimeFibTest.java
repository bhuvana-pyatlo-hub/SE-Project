package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PrimeFibTest {

    @Test
    void primeFib_firstPrimeFibonacciNumber() {
        assertEquals(2, PrimeFib.primeFib(1));
    }

    @Test
    void primeFib_secondPrimeFibonacciNumber() {
        assertEquals(3, PrimeFib.primeFib(2));
    }

    @Test
    void primeFib_thirdPrimeFibonacciNumber() {
        assertEquals(5, PrimeFib.primeFib(3));
    }

    @Test
    void primeFib_fourthPrimeFibonacciNumber() {
        assertEquals(13, PrimeFib.primeFib(4));
    }

    @Test
    void primeFib_fifthPrimeFibonacciNumber() {
        assertEquals(89, PrimeFib.primeFib(5));
    }

    @Test
    void primeFib_sixthPrimeFibonacciNumber() {
        assertEquals(233, PrimeFib.primeFib(6));
    }

    @Test
    void primeFib_seventhPrimeFibonacciNumber() {
        assertEquals(1597, PrimeFib.primeFib(7));
    }

    @Test
    void primeFib_eighthPrimeFibonacciNumber() {
        assertEquals(28657, PrimeFib.primeFib(8));
    }

    @Test
    void primeFib_ninthPrimeFibonacciNumber() {
        assertEquals(514229, PrimeFib.primeFib(9));
    }

    @Test
    void primeFib_tenthPrimeFibonacciNumber() {
        assertEquals(433494437, PrimeFib.primeFib(10));
    }

    @Test
    void primeFib_smallNumber() {
        assertEquals(9227465, PrimeFib.primeFib(15));
    }
}