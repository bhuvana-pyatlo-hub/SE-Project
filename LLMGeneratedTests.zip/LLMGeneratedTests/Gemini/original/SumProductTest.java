package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SumProductTest {

    @Test
    void sumProduct_emptyList() {
        List<Object> numbers = new ArrayList<>();
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(0, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void sumProduct_singleElementList() {
        List<Object> numbers = Arrays.asList(10);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(10, result.get(0));
        assertEquals(10, result.get(1));
    }

    @Test
    void sumProduct_multipleElementsList() {
        List<Object> numbers = Arrays.asList(1, 2, 3, 4);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(10, result.get(0));
        assertEquals(24, result.get(1));
    }

    @Test
    void sumProduct_allOnesList() {
        List<Object> numbers = Arrays.asList(1, 1, 1);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(3, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void sumProduct_withZero() {
        List<Object> numbers = Arrays.asList(100, 0);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(100, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_positiveNumbers() {
        List<Object> numbers = Arrays.asList(3, 5, 7);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(15, result.get(0));
        assertEquals(105, result.get(1));
    }

    @Test
    void sumProduct_negativeNumbers() {
        List<Object> numbers = Arrays.asList(-1, -2, -3);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(-6, result.get(0));
        assertEquals(-6, result.get(1));
    }

    @Test
    void sumProduct_mixedPositiveNegative() {
        List<Object> numbers = Arrays.asList(-1, 2, -3);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(-2, result.get(0));
        assertEquals(6, result.get(1));
    }

    @Test
    void sumProduct_largeNumbers() {
        List<Object> numbers = Arrays.asList(100, 200, 300);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(600, result.get(0));
        assertEquals(6000000, result.get(1));
    }

    @Test
    void sumProduct_oneNegativeNumber() {
        List<Object> numbers = Arrays.asList(1, 2, -3);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(0, result.get(0));
        assertEquals(-6, result.get(1));
    }

    @Test
    void sumProduct_onlyNegativeNumbers() {
        List<Object> numbers = Arrays.asList(-1, -2, -3, -4);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(-10, result.get(0));
        assertEquals(24, result.get(1));
    }

    @Test
    void sumProduct_zeroInMiddle() {
        List<Object> numbers = Arrays.asList(1, 0, 3);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(4, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_allZeros() {
        List<Object> numbers = Arrays.asList(0, 0, 0);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(0, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_mixedPositiveNegativeZero() {
        List<Object> numbers = Arrays.asList(-1, 0, 1);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(0, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void sumProduct_duplicateNumbers() {
        List<Object> numbers = Arrays.asList(2, 2, 2);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(6, result.get(0));
        assertEquals(8, result.get(1));
    }

    @Test
    void sumProduct_boundaryValues() {
        List<Object> numbers = Arrays.asList(Integer.MAX_VALUE, 1);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(Integer.MAX_VALUE, result.get(0));
        assertEquals(Integer.MAX_VALUE, result.get(1));
    }

    @Test
    void sumProduct_boundaryValuesNegative() {
        List<Object> numbers = Arrays.asList(Integer.MIN_VALUE, 1);
        List<Integer> result = SumProduct.sumProduct(numbers);
        assertEquals(Integer.MIN_VALUE, result.get(0));
        assertEquals(Integer.MIN_VALUE, result.get(1));
    }

    @Test
    void sumProduct_invalidInputType() {
        List<Object> numbers = Arrays.asList(1, "a", 2);
        assertThrows(IllegalArgumentException.class, () -> SumProduct.sumProduct(numbers));
    }

    @Test
    void sumProduct_mixedValidInvalidInput() {
        List<Object> numbers = Arrays.asList(1, 2, "a", 3);
        assertThrows(IllegalArgumentException.class, () -> SumProduct.sumProduct(numbers));
    }

    @Test
    void sumProduct_onlyInvalidInput() {
        List<Object> numbers = Arrays.asList("a", "b", "c");
        assertThrows(IllegalArgumentException.class, () -> SumProduct.sumProduct(numbers));
    }
}