package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FibTest {

    @Test
    void fib_of_1_returns_1() {
        assertEquals(1, Fib.fib(1));
    }

    @Test
    void fib_of_2_returns_1() {
        assertEquals(1, Fib.fib(2));
    }

    @Test
    void fib_of_3_returns_2() {
        assertEquals(2, Fib.fib(3));
    }

    @Test
    void fib_of_4_returns_3() {
        assertEquals(3, Fib.fib(4));
    }

    @Test
    void fib_of_5_returns_5() {
        assertEquals(5, Fib.fib(5));
    }

    @Test
    void fib_of_6_returns_8() {
        assertEquals(8, Fib.fib(6));
    }

    @Test
    void fib_of_7_returns_13() {
        assertEquals(13, Fib.fib(7));
    }

    @Test
    void fib_of_8_returns_21() {
        assertEquals(21, Fib.fib(8));
    }

    @Test
    void fib_of_9_returns_34() {
        assertEquals(34, Fib.fib(9));
    }

    @Test
    void fib_of_10_returns_55() {
        assertEquals(55, Fib.fib(10));
    }

    @Test
    void fib_of_11_returns_89() {
        assertEquals(89, Fib.fib(11));
    }

    @Test
    void fib_of_12_returns_144() {
        assertEquals(144, Fib.fib(12));
    }

    @Test
    void fib_of_0_returns_1() {
        assertEquals(1, Fib.fib(0));
    }

    @Test
    void fib_of_13_returns_233() {
        assertEquals(233, Fib.fib(13));
    }

    @Test
    void fib_of_14_returns_377() {
        assertEquals(377, Fib.fib(14));
    }

    @Test
    void fib_of_15_returns_610() {
        assertEquals(610, Fib.fib(15));
    }

    @Test
    void fib_of_16_returns_987() {
        assertEquals(987, Fib.fib(16));
    }

    @Test
    void fib_of_17_returns_1597() {
        assertEquals(1597, Fib.fib(17));
    }

    @Test
    void fib_of_18_returns_2584() {
        assertEquals(2584, Fib.fib(18));
    }

    @Test
    void fib_of_19_returns_4181() {
        assertEquals(4181, Fib.fib(19));
    }
}