package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Maximum1Test {

    @Test
    void maximum_emptyArray_returnsEmptyList() {
        List<Integer> arr = new ArrayList<>();
        int k = 3;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_kIsZero_returnsEmptyList() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        int k = 0;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_nEqualsK_returnsSortedList() {
        List<Integer> arr = Arrays.asList(3, 1, 2);
        int k = 3;
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_nLessThanK_returnsSortedList() {
        List<Integer> arr = Arrays.asList(3, 1, 2);
        int k = 4;
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_kIsOne_returnsSingleMaxElement() {
        List<Integer> arr = Arrays.asList(-3, 2, 1, 2, -1, -2, 1);
        int k = 1;
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example1() {
        List<Integer> arr = Arrays.asList(-3, -4, 5);
        int k = 3;
        List<Object> expected = Arrays.asList(-4, -3, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example2() {
        List<Integer> arr = Arrays.asList(4, -4, 4);
        int k = 2;
        List<Object> expected = Arrays.asList(4, 4);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example3() {
        List<Integer> arr = Arrays.asList(-3, 2, 1, 2, -1, -2, 1);
        int k = 1;
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example4() {
        List<Integer> arr = Arrays.asList(123, -123, 20, 0, 1, 2, -3);
        int k = 3;
        List<Object> expected = Arrays.asList(2, 20, 123);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example5() {
        List<Integer> arr = Arrays.asList(-123, 20, 0, 1, 2, -3);
        int k = 4;
        List<Object> expected = Arrays.asList(0, 1, 2, 20);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example6() {
        List<Integer> arr = Arrays.asList(5, 15, 0, 3, -13, -8, 0);
        int k = 7;
        List<Object> expected = Arrays.asList(-13, -8, 0, 0, 3, 5, 15);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example7() {
        List<Integer> arr = Arrays.asList(-1, 0, 2, 5, 3, -10);
        int k = 2;
        List<Object> expected = Arrays.asList(3, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example8() {
        List<Integer> arr = Arrays.asList(1, 0, 5, -7);
        int k = 1;
        List<Object> expected = Arrays.asList(5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example9() {
        List<Integer> arr = Arrays.asList(4, -4);
        int k = 2;
        List<Object> expected = Arrays.asList(-4, 4);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example10() {
        List<Integer> arr = Arrays.asList(-10, 10);
        int k = 2;
        List<Object> expected = Arrays.asList(-10, 10);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_example11() {
        List<Integer> arr = Arrays.asList(1, 2, 3, -23, 243, -400, 0);
        int k = 0;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_allNegativeNumbers() {
        List<Integer> arr = Arrays.asList(-1, -2, -3, -4, -5);
        int k = 3;
        List<Object> expected = Arrays.asList(-3, -2, -1);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_allSameNumbers() {
        List<Integer> arr = Arrays.asList(5, 5, 5, 5, 5);
        int k = 3;
        List<Object> expected = Arrays.asList(5, 5, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_mixedPositiveNegativeZero() {
        List<Integer> arr = Arrays.asList(-5, 0, 5, -10, 10, 15, -15);
        int k = 4;
        List<Object> expected = Arrays.asList(0, 10, 15, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_largeKValue() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5);
        int k = 10;
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }

    @Test
    void maximum_duplicateValues() {
        List<Integer> arr = Arrays.asList(1, 2, 2, 3, 3, 3);
        int k = 4;
        List<Object> expected = Arrays.asList(2, 2, 3, 3);
        assertEquals(expected, Maximum1.maximum(arr, k));
    }
}