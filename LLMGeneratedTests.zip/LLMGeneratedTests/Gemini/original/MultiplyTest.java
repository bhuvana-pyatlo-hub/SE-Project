package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MultiplyTest {

    @Test
    void multiply_positiveNumbers_returnsCorrectProduct() {
        assertEquals(16, Multiply.multiply(148, 412));
    }

    @Test
    void multiply_positiveNumbersDifferent_returnsCorrectProduct() {
        assertEquals(72, Multiply.multiply(19, 28));
    }

    @Test
    void multiply_oneNumberEndsInZero_returnsZero() {
        assertEquals(0, Multiply.multiply(2020, 1851));
    }

    @Test
    void multiply_bothNumbersEndInZero_returnsZero() {
        assertEquals(0, Multiply.multiply(2020, 1850));
    }

    @Test
    void multiply_oneNumberNegative_returnsCorrectProduct() {
        assertEquals(20, Multiply.multiply(14, -15));
    }

    @Test
    void multiply_bothNumbersNegative_returnsCorrectProduct() {
        assertEquals(20, Multiply.multiply(-14, -15));
    }

    @Test
    void multiply_bothNumbersPositive_returnsCorrectProduct2() {
        assertEquals(42, Multiply.multiply(76, 67));
    }

    @Test
    void multiply_bothNumbersPositive_returnsCorrectProduct3() {
        assertEquals(49, Multiply.multiply(17, 27));
    }

    @Test
    void multiply_oneNumberIsZero_returnsZero() {
        assertEquals(0, Multiply.multiply(0, 1));
    }

    @Test
    void multiply_bothNumbersAreZero_returnsZero() {
        assertEquals(0, Multiply.multiply(0, 0));
    }

    @Test
    void multiply_smallPositiveNumbers_returnsCorrectProduct() {
        assertEquals(6, Multiply.multiply(2, 3));
    }

    @Test
    void multiply_smallNegativeNumbers_returnsCorrectProduct() {
        assertEquals(6, Multiply.multiply(-2, -3));
    }

    @Test
    void multiply_oneSmallPositiveOneSmallNegative_returnsCorrectProduct() {
        assertEquals(6, Multiply.multiply(2, -3));
    }

    @Test
    void multiply_oneSmallNegativeOneSmallPositive_returnsCorrectProduct() {
        assertEquals(6, Multiply.multiply(-2, 3));
    }

    @Test
    void multiply_oneNumberIsSingleDigit_returnsCorrectProduct() {
        assertEquals(8, Multiply.multiply(123, 8));
    }

    @Test
    void multiply_oneNumberIsSingleDigitNegative_returnsCorrectProduct() {
        assertEquals(8, Multiply.multiply(123, -8));
    }

    @Test
    void multiply_bothNumbersAreSingleDigit_returnsCorrectProduct() {
        assertEquals(12, Multiply.multiply(3, 4));
    }

    @Test
    void multiply_bothNumbersAreSingleDigitNegative_returnsCorrectProduct() {
        assertEquals(12, Multiply.multiply(-3, -4));
    }

    @Test
    void multiply_oneNumberIsSingleDigitZero_returnsZero() {
        assertEquals(0, Multiply.multiply(123, 0));
    }

    @Test
    void multiply_largePositiveNumbers_returnsCorrectProduct() {
        assertEquals(9, Multiply.multiply(999, 999));
    }
}