package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RoundedAvgTest {

    @Test
    void roundedAvg_nGreaterThanM_returnsNegativeOne() {
        assertEquals(-1, RoundedAvg.roundedAvg(5, 1));
    }

    @Test
    void roundedAvg_nEqualsM_returnsBinaryRepresentation() {
        assertEquals("0b101", RoundedAvg.roundedAvg(5, 5));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation1() {
        assertEquals("0b11", RoundedAvg.roundedAvg(1, 5));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation2() {
        assertEquals("0b1010", RoundedAvg.roundedAvg(7, 13));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation3() {
        assertEquals("0b1111001010", RoundedAvg.roundedAvg(964, 977));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation4() {
        assertEquals("0b1111100100", RoundedAvg.roundedAvg(996, 997));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation5() {
        assertEquals("0b1011000010", RoundedAvg.roundedAvg(560, 851));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation6() {
        assertEquals("0b101101110", RoundedAvg.roundedAvg(185, 546));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation7() {
        assertEquals("0b110101101", RoundedAvg.roundedAvg(362, 496));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation8() {
        assertEquals("0b1001110010", RoundedAvg.roundedAvg(350, 902));
    }

    @Test
    void roundedAvg_validInput_returnsCorrectBinaryRepresentation9() {
        assertEquals("0b11010111", RoundedAvg.roundedAvg(197, 233));
    }

    @Test
    void roundedAvg_nEqualsM_returnsCorrectBinary() {
        assertEquals("0b1111010000", RoundedAvg.roundedAvg(976, 976));
    }

    @Test
    void roundedAvg_smallRange_returnsCorrectBinary() {
        assertEquals("0b11", RoundedAvg.roundedAvg(2, 3));
    }

    @Test
    void roundedAvg_largerRange_returnsCorrectBinary() {
        assertEquals("0b1100100", RoundedAvg.roundedAvg(90, 100));
    }

    @Test
    void roundedAvg_nIsZero_returnsCorrectBinary() {
        assertEquals("0b1111010", RoundedAvg.roundedAvg(0, 122));
    }

    @Test
    void roundedAvg_mIsZero_returnsNegativeOne() {
        assertEquals(-1, RoundedAvg.roundedAvg(1, 0));
    }

    @Test
    void roundedAvg_nAndMAreZero_returnsBinary() {
        assertEquals("0b0", RoundedAvg.roundedAvg(0, 0));
    }

    @Test
    void roundedAvg_nIsNegative_returnsCorrectBinary() {
        assertEquals("0b1111101000", RoundedAvg.roundedAvg(-10, 100));
    }

    @Test
    void roundedAvg_mIsNegative_returnsNegativeOne() {
        assertEquals(-1, RoundedAvg.roundedAvg(10, -10));
    }

    @Test
    void roundedAvg_bothNegative_returnsCorrectBinary() {
        assertEquals("0b-11", RoundedAvg.roundedAvg(-5, -1));
    }

    @Test
    void roundedAvg_largeNegativeRange_returnsCorrectBinary() {
        assertEquals("0b-1000000000000000000000000000000", RoundedAvg.roundedAvg(-100, -1));
    }

    @Test
    void roundedAvg_nIsNegativeAndMIsPositive_returnsCorrectBinary() {
        assertEquals("0b1111101000", RoundedAvg.roundedAvg(-10, 100));
    }
}