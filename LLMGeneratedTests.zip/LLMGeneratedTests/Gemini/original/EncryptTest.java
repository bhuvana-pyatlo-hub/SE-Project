package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EncryptTest {

    @Test
    void encrypt_emptyString() {
        assertEquals("", Encrypt.encrypt(""));
    }

    @Test
    void encrypt_singleChar_a() {
        assertEquals("e", Encrypt.encrypt("a"));
    }

    @Test
    void encrypt_singleChar_z() {
        assertEquals("d", Encrypt.encrypt("z"));
    }

    @Test
    void encrypt_singleChar_m() {
        assertEquals("q", Encrypt.encrypt("m"));
    }

    @Test
    void encrypt_twoChars_hi() {
        assertEquals("lm", Encrypt.encrypt("hi"));
    }

    @Test
    void encrypt_multipleChars_asdfghjkl() {
        assertEquals("ewhjklnop", Encrypt.encrypt("asdfghjkl"));
    }

    @Test
    void encrypt_multipleChars_gf() {
        assertEquals("kj", Encrypt.encrypt("gf"));
    }

    @Test
    void encrypt_multipleChars_et() {
        assertEquals("ix", Encrypt.encrypt("et"));
    }

    @Test
    void encrypt_multipleChars_faewfawefaewg() {
        assertEquals("jeiajeaijeiak", Encrypt.encrypt("faewfawefaewg"));
    }

    @Test
    void encrypt_multipleChars_hellomyfriend() {
        assertEquals("lippsqcjvmirh", Encrypt.encrypt("hellomyfriend"));
    }

    @Test
    void encrypt_multipleChars_longString() {
        assertEquals("hbdhpqrmpjylqmpyjlpmlyjrqpmqryjlpmqryjljygyjl", Encrypt.encrypt("dxzdlmnilfuhmilufhlihufnmlimnufhlimnufhfucufh"));
    }

    @Test
    void encrypt_stringWithNonAlphaChars() {
        assertEquals("1234", Encrypt.encrypt("1234"));
    }

    @Test
    void encrypt_stringWithMixedCase() {
        assertEquals("Test", Encrypt.encrypt("Test"));
    }

    @Test
    void encrypt_stringWithSpecialChars() {
        assertEquals("!@#$", Encrypt.encrypt("!@#$"));
    }

    @Test
    void encrypt_stringWithSpaces() {
        assertEquals("    ", Encrypt.encrypt("    "));
    }

    @Test
    void encrypt_stringWithAlphaAndNonAlpha() {
        assertEquals("e123", Encrypt.encrypt("a123"));
    }

    @Test
    void encrypt_stringWithAlphaAndSpecialChars() {
        assertEquals("e!@#", Encrypt.encrypt("a!@#"));
    }

    @Test
    void encrypt_stringWithAlphaAndSpaces() {
        assertEquals("e   ", Encrypt.encrypt("a   "));
    }

    @Test
    void encrypt_stringNearZ_x() {
        assertEquals("b", Encrypt.encrypt("x"));
    }

    @Test
    void encrypt_stringNearZ_y() {
        assertEquals("c", Encrypt.encrypt("y"));
    }
}