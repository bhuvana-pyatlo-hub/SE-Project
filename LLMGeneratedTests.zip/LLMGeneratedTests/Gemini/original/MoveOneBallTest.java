package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MoveOneBallTest {

    @Test
    void moveOneBall_emptyList_returnsTrue() {
        List<Object> arr = new ArrayList<>();
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_sortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_rotatedSortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(3, 4, 5, 1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_unsortedList_returnsFalse() {
        List<Object> arr = Arrays.asList(3, 5, 4, 1, 2);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_singleElementList_returnsTrue() {
        List<Object> arr = Arrays.asList(5);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementSortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_twoElementUnsortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(2, 1);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_almostSortedList_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 4, 3, 5);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_largeValuesRotated_returnsTrue() {
        List<Object> arr = Arrays.asList(998, 999, 1000, 1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_largeValuesUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(998, 1000, 999, 1, 2);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_negativeValuesRotated_returnsTrue() {
        List<Object> arr = Arrays.asList(-3, -2, -1, 1, 2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_negativeValuesUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(-3, -1, -2, 1, 2);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_mixedValuesRotated_returnsTrue() {
        List<Object> arr = Arrays.asList(3, 4, 5, -1, -2);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_mixedValuesUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(3, 5, 4, -1, -2);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_duplicateValuesSorted_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 2, 3, 4);
        assertThrows(ClassCastException.class, () -> MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_duplicateValuesUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(3, 5, 4, 1, 1);
        assertThrows(ClassCastException.class, () -> MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_allSameValues_returnsTrue() {
        List<Object> arr = Arrays.asList(5, 5, 5, 5, 5);
        assertThrows(ClassCastException.class, () -> MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_almostSortedNegative_returnsTrue() {
        List<Object> arr = Arrays.asList(-5, -4, -2, -3, -1);
        assertThrows(ClassCastException.class, () -> MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_longListSorted_returnsTrue() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_longListRotated_returnsTrue() {
        List<Object> arr = Arrays.asList(8, 9, 10, 1, 2, 3, 4, 5, 6, 7);
        assertTrue(MoveOneBall.moveOneBall(arr));
    }

    @Test
    void moveOneBall_longListUnsorted_returnsFalse() {
        List<Object> arr = Arrays.asList(1, 2, 3, 10, 5, 6, 7, 8, 9, 4);
        assertFalse(MoveOneBall.moveOneBall(arr));
    }
}