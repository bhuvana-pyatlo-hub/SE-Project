package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MedianTest {

    @Test
    void median_emptyList() {
        List<Integer> list = new ArrayList<>();
        try {
            Median.median(list);
        } catch (IndexOutOfBoundsException e) {
            // Expected behavior
        }
    }

    @Test
    void median_singleElementList() {
        List<Integer> list = new ArrayList<>(Arrays.asList(5));
        assertEquals(5, Median.median(list));
    }

    @Test
    void median_twoElementList_even() {
        List<Integer> list = new ArrayList<>(Arrays.asList(6, 5));
        assertEquals(5.5, Median.median(list));
    }

    @Test
    void median_twoElementList_odd() {
        List<Integer> list = new ArrayList<>(Arrays.asList(5, 6));
        assertEquals(5.5, Median.median(list));
    }

    @Test
    void median_fiveElementList() {
        List<Integer> list = new ArrayList<>(Arrays.asList(3, 1, 2, 4, 5));
        assertEquals(3, Median.median(list));
    }

    @Test
    void median_sixElementList() {
        List<Integer> list = new ArrayList<>(Arrays.asList(-10, 4, 6, 1000, 10, 20));
        assertEquals(8.0, Median.median(list));
    }

    @Test
    void median_sevenElementList() {
        List<Integer> list = new ArrayList<>(Arrays.asList(8, 1, 3, 9, 9, 2, 7));
        assertEquals(7, Median.median(list));
    }

    @Test
    void median_duplicateElements() {
        List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 2, 3, 3, 3));
        assertEquals(2.5, Median.median(list));
    }

    @Test
    void median_allSameElements() {
        List<Integer> list = new ArrayList<>(Arrays.asList(5, 5, 5, 5, 5));
        assertEquals(5, Median.median(list));
    }

    @Test
    void median_negativeNumbers() {
        List<Integer> list = new ArrayList<>(Arrays.asList(-1, -2, -3, -4, -5));
        assertEquals(-3, Median.median(list));
    }

    @Test
    void median_mixedPositiveNegative() {
        List<Integer> list = new ArrayList<>(Arrays.asList(-1, 2, -3, 4, -5));
        assertEquals(-1, Median.median(list));
    }

    @Test
    void median_largeNumbers() {
        List<Integer> list = new ArrayList<>(Arrays.asList(100, 200, 300, 400, 500));
        assertEquals(300, Median.median(list));
    }

    @Test
    void median_smallNumbers() {
        List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        assertEquals(3, Median.median(list));
    }

    @Test
    void median_boundaryValues_positive() {
        List<Integer> list = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4));
        assertEquals(2, Median.median(list));
    }

    @Test
    void median_boundaryValues_negative() {
        List<Integer> list = new ArrayList<>(Arrays.asList(-4, -3, -2, -1, 0));
        assertEquals(-2, Median.median(list));
    }

    @Test
    void median_evenSizeList_negativeNumbers() {
        List<Integer> list = new ArrayList<>(Arrays.asList(-4, -2, -1, -3));
        assertEquals(-2.5, Median.median(list));
    }

    @Test
    void median_evenSizeList_positiveNumbers() {
        List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
        assertEquals(2.5, Median.median(list));
    }

    @Test
    void median_evenSizeList_mixedNumbers() {
        List<Integer> list = new ArrayList<>(Arrays.asList(-1, 2, -3, 4));
        assertEquals(0.5, Median.median(list));
    }

    @Test
    void median_largeList_oddSize() {
        List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
        assertEquals(5, Median.median(list));
    }

    @Test
    void median_largeList_evenSize() {
        List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
        assertEquals(5.5, Median.median(list));
    }
}