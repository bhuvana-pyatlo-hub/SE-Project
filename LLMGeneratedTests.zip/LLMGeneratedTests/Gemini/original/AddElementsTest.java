package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AddElementsTest {

    @Test
    void testAddElements_basicCase() {
        List<Integer> arr = Arrays.asList(11, 21, 3, 90, 5, 6, 7, 8, 9);
        int k = 4;
        assertEquals(125, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_exampleCase() {
        List<Integer> arr = Arrays.asList(111, 21, 3, 4000, 5, 6, 7, 8, 9);
        int k = 4;
        assertEquals(24, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_negativeNumbers() {
        List<Integer> arr = Arrays.asList(1, -2, -3, 41, 57, 76, 87, 88, 99);
        int k = 3;
        assertEquals(-4, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_noValidElements() {
        List<Integer> arr = Arrays.asList(111, 121, 3, 4000, 5, 6);
        int k = 2;
        assertEquals(0, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_singleElement() {
        List<Integer> arr = Arrays.asList(1);
        int k = 1;
        assertEquals(1, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_allElementsValid() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        int k = 9;
        assertEquals(45, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kEqualsArrayLength() {
        List<Integer> arr = Arrays.asList(10, 20, 100, 40, 50);
        int k = 5;
        assertEquals(120, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_kIsOne() {
        List<Integer> arr = Arrays.asList(55, 101, 200);
        int k = 1;
        assertEquals(55, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_largeNumbers() {
        List<Integer> arr = Arrays.asList(99, 100, 101);
        int k = 3;
        assertEquals(99, AddElements.addElements(arr, k));
    }

    @Test
    void testAddElements_emptyList() {
        List<Integer> arr = Arrays.asList(101, 102, 103);
        int k = 3;
        assertEquals(0, AddElements.addElements(arr, k));
    }
}