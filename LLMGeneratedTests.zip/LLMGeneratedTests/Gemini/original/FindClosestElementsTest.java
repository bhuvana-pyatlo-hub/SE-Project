package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class FindClosestElementsTest {

    @Test
    void testFindClosestElements_example1() {
        List<Double> input = Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2);
        List<Double> expected = Arrays.asList(3.9, 4.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_example2() {
        List<Double> input = Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0);
        List<Double> expected = Arrays.asList(5.0, 5.9);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_example3() {
        List<Double> input = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.2);
        List<Double> expected = Arrays.asList(2.0, 2.2);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_example4() {
        List<Double> input = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.0);
        List<Double> expected = Arrays.asList(2.0, 2.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_example5() {
        List<Double> input = Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1);
        List<Double> expected = Arrays.asList(2.2, 3.1);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_sameElements() {
        List<Double> input = Arrays.asList(2.0, 2.0, 2.0, 2.0);
        List<Double> expected = Arrays.asList(2.0, 2.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_negativeNumbers() {
        List<Double> input = Arrays.asList(-1.0, -2.0, -3.0, -4.0);
        List<Double> expected = Arrays.asList(-4.0, -3.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_mixedPositiveNegative() {
        List<Double> input = Arrays.asList(-1.0, 1.0, 2.0, -2.0);
        List<Double> expected = Arrays.asList(-1.0, 1.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_largeDifference() {
        List<Double> input = Arrays.asList(1.0, 100.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(2.0, 3.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_smallDifference() {
        List<Double> input = Arrays.asList(1.0, 1.01, 2.0, 3.0);
        List<Double> expected = Arrays.asList(1.0, 1.01);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_duplicateClosest() {
        List<Double> input = Arrays.asList(1.0, 2.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(2.0, 2.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_decimalNumbers() {
        List<Double> input = Arrays.asList(1.5, 2.5, 3.5, 4.5);
        List<Double> expected = Arrays.asList(1.5, 2.5);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_zeroAndPositive() {
        List<Double> input = Arrays.asList(0.0, 1.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_zeroAndNegative() {
        List<Double> input = Arrays.asList(0.0, -1.0, -2.0, -3.0);
        List<Double> expected = Arrays.asList(-1.0, 0.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_allSameNegative() {
        List<Double> input = Arrays.asList(-5.0, -5.0, -5.0, -5.0);
        List<Double> expected = Arrays.asList(-5.0, -5.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_edgeCaseSmallValues() {
        List<Double> input = Arrays.asList(0.1, 0.2, 0.3, 0.4);
        List<Double> expected = Arrays.asList(0.1, 0.2);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_edgeCaseNegativeSmallValues() {
        List<Double> input = Arrays.asList(-0.1, -0.2, -0.3, -0.4);
        List<Double> expected = Arrays.asList(-0.4, -0.3);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_mixedSmallValues() {
        List<Double> input = Arrays.asList(-0.1, 0.1, 0.2, -0.2);
        List<Double> expected = Arrays.asList(-0.1, 0.1);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_identicalValuesAtDifferentIndices() {
        List<Double> input = Arrays.asList(1.0, 2.0, 1.0, 3.0);
        List<Double> expected = Arrays.asList(1.0, 1.0);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }

    @Test
    void testFindClosestElements_largeAndSmallNumbers() {
        List<Double> input = Arrays.asList(1.0, 100.0, 1.1, 2.0);
        List<Double> expected = Arrays.asList(1.0, 1.1);
        assertEquals(expected, FindClosestElements.findClosestElements(input));
    }
}