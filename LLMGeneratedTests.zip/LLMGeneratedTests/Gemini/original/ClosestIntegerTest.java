package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClosestIntegerTest {

    @Test
    void closestInteger_positiveInteger() {
        assertEquals(10, ClosestInteger.closestInteger("10"));
    }

    @Test
    void closestInteger_positiveDecimalRoundUp() {
        assertEquals(15, ClosestInteger.closestInteger("14.5"));
    }

    @Test
    void closestInteger_negativeDecimalRoundDown() {
        assertEquals(-16, ClosestInteger.closestInteger("-15.5"));
    }

    @Test
    void closestInteger_positiveDecimalRoundDown() {
        assertEquals(15, ClosestInteger.closestInteger("15.3"));
    }

    @Test
    void closestInteger_zero() {
        assertEquals(0, ClosestInteger.closestInteger("0"));
    }

    @Test
    void closestInteger_positiveDecimalNearInteger() {
        assertEquals(11, ClosestInteger.closestInteger("10.9"));
    }

    @Test
    void closestInteger_negativeDecimalNearInteger() {
        assertEquals(-11, ClosestInteger.closestInteger("-10.9"));
    }

    @Test
    void closestInteger_positiveDecimalSlightlyAbove() {
        assertEquals(10, ClosestInteger.closestInteger("9.6"));
    }

    @Test
    void closestInteger_negativeDecimalSlightlyBelow() {
        assertEquals(-10, ClosestInteger.closestInteger("-9.6"));
    }

    @Test
    void closestInteger_positiveOne() {
        assertEquals(1, ClosestInteger.closestInteger("1"));
    }

    @Test
    void closestInteger_negativeOne() {
        assertEquals(-1, ClosestInteger.closestInteger("-1"));
    }

    @Test
    void closestInteger_positiveSmallDecimal() {
        assertEquals(1, ClosestInteger.closestInteger("0.6"));
    }

    @Test
    void closestInteger_negativeSmallDecimal() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.6"));
    }

    @Test
    void closestInteger_positiveDecimalExactlyHalf() {
        assertEquals(5, ClosestInteger.closestInteger("4.5"));
    }

    @Test
    void closestInteger_negativeDecimalExactlyHalf() {
        assertEquals(-5, ClosestInteger.closestInteger("-4.5"));
    }

    @Test
    void closestInteger_positiveLargeInteger() {
        assertEquals(100, ClosestInteger.closestInteger("100"));
    }

    @Test
    void closestInteger_negativeLargeInteger() {
        assertEquals(-100, ClosestInteger.closestInteger("-100"));
    }

    @Test
    void closestInteger_positiveLargeDecimal() {
        assertEquals(99, ClosestInteger.closestInteger("98.5"));
    }

    @Test
    void closestInteger_negativeLargeDecimal() {
        assertEquals(-99, ClosestInteger.closestInteger("-98.5"));
    }

    @Test
    void closestInteger_positiveDecimalJustBelowHalf() {
        assertEquals(0, ClosestInteger.closestInteger("0.4"));
    }

    @Test
    void closestInteger_negativeDecimalJustAboveHalf() {
        assertEquals(0, ClosestInteger.closestInteger("-0.4"));
    }

    @Test
    void closestInteger_positiveDecimalEqualToPointFive() {
        assertEquals(1, ClosestInteger.closestInteger("0.5"));
    }

    @Test
    void closestInteger_negativeDecimalEqualToPointFive() {
        assertEquals(-1, ClosestInteger.closestInteger("-0.5"));
    }
}