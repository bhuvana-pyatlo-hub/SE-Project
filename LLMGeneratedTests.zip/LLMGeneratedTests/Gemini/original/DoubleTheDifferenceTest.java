package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DoubleTheDifferenceTest {

    @Test
    void testEmptyList() {
        List<Object> emptyList = Collections.emptyList();
        assertEquals(0, DoubleTheDifference.doubleTheDifference(emptyList));
    }

    @Test
    void testListWithPositiveOddNumbers() {
        List<Object> list = Arrays.asList(1, 3, 5);
        assertEquals(35, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithPositiveEvenNumbers() {
        List<Object> list = Arrays.asList(2, 4, 6);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithNegativeNumbers() {
        List<Object> list = Arrays.asList(-1, -3, -5);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithMixedNumbers() {
        List<Object> list = Arrays.asList(1, -2, 3, -4, 5);
        assertEquals(35, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithZero() {
        List<Object> list = Collections.singletonList(0);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithIntegersAndNonIntegers() {
        List<Object> list = Arrays.asList(1, "hello", 3, 5.0, 5);
        assertEquals(26, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithOnlyNonIntegers() {
        List<Object> list = Arrays.asList("hello", 5.0, true);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithLargeOddNumbers() {
        List<Object> list = Arrays.asList(99, 101);
        assertEquals(99*99 + 101*101, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithLargeEvenNumbers() {
        List<Object> list = Arrays.asList(100, 102);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithMixedLargeAndSmallNumbers() {
        List<Object> list = Arrays.asList(1, 101, 2, 102);
        assertEquals(1 + 101*101, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithOnlyOneOddNumber() {
        List<Object> list = Collections.singletonList(7);
        assertEquals(49, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithOnlyOneEvenNumber() {
        List<Object> list = Collections.singletonList(8);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithOnlyOneNegativeNumber() {
        List<Object> list = Collections.singletonList(-9);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithMultipleOccurrencesOfSameOddNumber() {
        List<Object> list = Arrays.asList(3, 3, 3);
        assertEquals(27, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithMultipleOccurrencesOfSameEvenNumber() {
        List<Object> list = Arrays.asList(4, 4, 4);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithZeroAndPositiveOdd() {
        List<Object> list = Arrays.asList(0, 5);
        assertEquals(25, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithZeroAndNegative() {
        List<Object> list = Arrays.asList(0, -5);
        assertEquals(0, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithPositiveOddAndNegative() {
        List<Object> list = Arrays.asList(5, -5);
        assertEquals(25, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithPositiveOddAndZeroAndNegative() {
        List<Object> list = Arrays.asList(5, 0, -5);
        assertEquals(25, DoubleTheDifference.doubleTheDifference(list));
    }

    @Test
    void testListWithMultipleTypes() {
        List<Object> list = new ArrayList<>();
        list.add(1);
        list.add(2.0);
        list.add("test");
        list.add(3);
        list.add(-4);
        assertEquals(10, DoubleTheDifference.doubleTheDifference(list));
    }
}