package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SumSquares1Test {

    @Test
    void sumSquares_emptyList() {
        List<Object> lst = new ArrayList<>();
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_singleElement_multipleOf3() {
        List<Object> lst = Arrays.asList(1);
        assertEquals(1, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_singleElement_multipleOf4() {
        List<Object> lst = Arrays.asList(1);
        assertEquals(1, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_singleElement_notMultipleOf3Or4() {
        List<Object> lst = Arrays.asList(1);
        assertEquals(1, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example1() {
        List<Object> lst = Arrays.asList(1, 2, 3);
        assertEquals(6, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example2() {
        List<Object> lst = Arrays.asList(1, 4, 9);
        assertEquals(14, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example3() {
        List<Object> lst = new ArrayList<>();
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example4() {
        List<Object> lst = Arrays.asList(1, 1, 1, 1, 1, 1, 1, 1, 1);
        assertEquals(9, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example5() {
        List<Object> lst = Arrays.asList(-1, -1, -1, -1, -1, -1, -1, -1, -1);
        assertEquals(-3, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example6() {
        List<Object> lst = Arrays.asList(0);
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example7() {
        List<Object> lst = Arrays.asList(-1, -5, 2, -1, -5);
        assertEquals(-126, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example8() {
        List<Object> lst = Arrays.asList(-56, -99, 1, 0, -2);
        assertEquals(3030, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example9() {
        List<Object> lst = Arrays.asList(-1, 0, 0, 0, 0, 0, 0, 0, -1);
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example10() {
        List<Object> lst = Arrays.asList(-16, -9, -2, 36, 36, 26, -20, 25, -40, 20, -4, 12, -26, 35, 37);
        assertEquals(-14196, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_example11() {
        List<Object> lst = Arrays.asList(-1, -3, 17, -1, -15, 13, -1, 14, -14, -12, -5, 14, -14, 6, 13, 11, 16, 16, 4, 10);
        assertEquals(-1448, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_allMultiplesOf3() {
        List<Object> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> lst2 = new ArrayList<>();
        for(int i = 0; i < 9; i++){
            lst2.add(i, i+1);
        }
        assertEquals(1 + 4 + 25 + 49 + 81, SumSquares1.sumSquares(lst2));
    }

    @Test
    void sumSquares_allMultiplesOf4() {
        List<Object> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> lst2 = new ArrayList<>();
        for(int i = 0; i < 9; i++){
            lst2.add(i, i+1);
        }
        assertEquals(1 + 2 + 3 + 64 + 5 + 6 + 7 + 512 + 9, SumSquares1.sumSquares(lst2));
    }

    @Test
    void sumSquares_mixedMultiples() {
        List<Object> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        assertEquals(1 + 2 + 9 + 64 + 5 + 36 + 7 + 8 + 81 + 10 + 11 + 144, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_negativeNumbers() {
        List<Object> lst = Arrays.asList(-1, -2, -3, -4, -5, -6);
        assertEquals(1 - 2 + 9 - 64 - 5 + 36, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_zeroValues() {
        List<Object> lst = Arrays.asList(0, 0, 0, 0, 0, 0);
        assertEquals(0, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_largeList() {
        List<Object> lst = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            lst.add(i);
        }
        int expectedSum = 0;
        for (int i = 0; i < 100; i++) {
            if (i % 3 == 0) {
                expectedSum += i * i;
            } else if (i % 4 == 0) {
                expectedSum += i * i * i;
            } else {
                expectedSum += i;
            }
        }
        assertEquals(expectedSum, SumSquares1.sumSquares(lst));
    }

    @Test
    void sumSquares_listWithNulls() {
        List<Object> lst = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        assertEquals(1 + 2 + 9 + 64 + 5 + 36 + 7 + 8 + 81 + 10 + 11 + 144, SumSquares1.sumSquares(lst));
    }
}