package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OddCountTest {

    @Test
    void oddCount_singleString_oddDigits() {
        List<String> input = Collections.singletonList("1234567");
        List<String> expected = Collections.singletonList("the number of odd elements 4n the str4ng 4 of the 4nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_varyingOddDigits() {
        List<String> input = Arrays.asList("3", "11111111");
        List<String> expected = Arrays.asList("the number of odd elements 1n the str1ng 1 of the 1nput.", "the number of odd elements 8n the str8ng 8 of the 8nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_mixedOddEvenDigits() {
        List<String> input = Arrays.asList("271", "137", "314");
        List<String> expected = Arrays.asList("the number of odd elements 2n the str2ng 2 of the 2nput.", "the number of odd elements 3n the str3ng 3 of the 3nput.", "the number of odd elements 2n the str2ng 2 of the 2nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_emptyStringList() {
        List<String> input = new ArrayList<>();
        List<String> expected = new ArrayList<>();
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithNoOddDigits() {
        List<String> input = Collections.singletonList("2468");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithAllOddDigits() {
        List<String> input = Collections.singletonList("13579");
        List<String> expected = Collections.singletonList("the number of odd elements 5n the str5ng 5 of the 5nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithSingleOddDigit() {
        List<String> input = Collections.singletonList("2221222");
        List<String> expected = Collections.singletonList("the number of odd elements 1n the str1ng 1 of the 1nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithSingleEvenDigit() {
        List<String> input = Collections.singletonList("1112111");
        List<String> expected = Collections.singletonList("the number of odd elements 6n the str6ng 6 of the 6nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_emptyStrings() {
        List<String> input = Arrays.asList("", "");
        List<String> expected = Arrays.asList("the number of odd elements 0n the str0ng 0 of the 0nput.", "the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithZero() {
        List<String> input = Collections.singletonList("0");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithMultipleZeros() {
        List<String> input = Collections.singletonList("000");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithLeadingZero() {
        List<String> input = Collections.singletonList("0123");
        List<String> expected = Collections.singletonList("the number of odd elements 2n the str2ng 2 of the 2nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithTrailingZero() {
        List<String> input = Collections.singletonList("1230");
        List<String> expected = Collections.singletonList("the number of odd elements 2n the str2ng 2 of the 2nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithOnlyZero() {
        List<String> input = Collections.singletonList("0");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_oneEmpty() {
        List<String> input = Arrays.asList("123", "");
        List<String> expected = Arrays.asList("the number of odd elements 2n the str2ng 2 of the 2nput.", "the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_longString_manyOdd() {
        List<String> input = Collections.singletonList("135791357913579");
        List<String> expected = Collections.singletonList("the number of odd elements 15n the str15ng 15 of the 15nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_longString_manyEven() {
        List<String> input = Collections.singletonList("246802468024680");
        List<String> expected = Collections.singletonList("the number of odd elements 0n the str0ng 0 of the 0nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_multipleStrings_sameOddCount() {
        List<String> input = Arrays.asList("13", "31");
        List<String> expected = Arrays.asList("the number of odd elements 2n the str2ng 2 of the 2nput.", "the number of odd elements 2n the str2ng 2 of the 2nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithLargeNumberOfDigits() {
        List<String> input = Collections.singletonList("12345678901234567890");
        List<String> expected = Collections.singletonList("the number of odd elements 10n the str10ng 10 of the 10nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }

    @Test
    void oddCount_stringWithOnlyOneDigit() {
        List<String> input = Collections.singletonList("5");
        List<String> expected = Collections.singletonList("the number of odd elements 1n the str1ng 1 of the 1nput.");
        assertEquals(expected, OddCount.oddCount(input));
    }
}