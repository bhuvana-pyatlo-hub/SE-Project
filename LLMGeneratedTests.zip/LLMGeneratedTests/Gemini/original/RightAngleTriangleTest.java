package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RightAngleTriangleTest {

    @Test
    void testRightAngleTriangle_validRightTriangle() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(3, 4, 5));
        assertTrue(RightAngleTriangle.rightAngleTriangle(5, 12, 13));
        assertTrue(RightAngleTriangle.rightAngleTriangle(8, 15, 17));
    }

    @Test
    void testRightAngleTriangle_notRightTriangle() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 2, 3));
        assertFalse(RightAngleTriangle.rightAngleTriangle(2, 2, 2));
        assertFalse(RightAngleTriangle.rightAngleTriangle(10, 5, 7));
    }

    @Test
    void testRightAngleTriangle_edgeCases() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(1, 1, 1));
        assertFalse(RightAngleTriangle.rightAngleTriangle(2, 2, 10));
    }

    @Test
    void testRightAngleTriangle_aIsLargest() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(5, 4, 3));
        assertFalse(RightAngleTriangle.rightAngleTriangle(6, 4, 3));
    }

    @Test
    void testRightAngleTriangle_bIsLargest() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(4, 5, 3));
        assertFalse(RightAngleTriangle.rightAngleTriangle(4, 6, 3));
    }

    @Test
    void testRightAngleTriangle_cIsLargest() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(3, 4, 5));
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 4, 6));
    }

    @Test
    void testRightAngleTriangle_equalSides() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(5, 5, 6));
        assertFalse(RightAngleTriangle.rightAngleTriangle(6, 5, 5));
        assertFalse(RightAngleTriangle.rightAngleTriangle(5, 6, 5));
    }

    @Test
    void testRightAngleTriangle_negativeValues() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(-3, 4, 5));
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, -4, 5));
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 4, -5));
    }

    @Test
    void testRightAngleTriangle_zeroValues() {
        assertFalse(RightAngleTriangle.rightAngleTriangle(0, 4, 5));
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 0, 5));
        assertFalse(RightAngleTriangle.rightAngleTriangle(3, 4, 0));
    }

    @Test
    void testRightAngleTriangle_largeValues() {
        assertTrue(RightAngleTriangle.rightAngleTriangle(65, 72, 97));
    }
}