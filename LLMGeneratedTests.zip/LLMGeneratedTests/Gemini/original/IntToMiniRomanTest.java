package original;
import org.junit.jupiter.api.Test;
//import original.IntToMiniRoman;

import static org.junit.jupiter.api.Assertions.*;

class IntToMiniRomanTest {

    @Test
    void testIntToMiniRoman_basicCases() {
        assertEquals("i", IntToMiniRoman.intToMiniRoman(1));
        assertEquals("v", IntToMiniRoman.intToMiniRoman(5));
        assertEquals("x", IntToMiniRoman.intToMiniRoman(10));
        assertEquals("l", IntToMiniRoman.intToMiniRoman(50));
        assertEquals("c", IntToMiniRoman.intToMiniRoman(100));
        assertEquals("d", IntToMiniRoman.intToMiniRoman(500));
        assertEquals("m", IntToMiniRoman.intToMiniRoman(1000));
    }

    @Test
    void testIntToMiniRoman_edgeCases() {
        assertEquals("iv", IntToMiniRoman.intToMiniRoman(4));
        assertEquals("ix", IntToMiniRoman.intToMiniRoman(9));
        assertEquals("xl", IntToMiniRoman.intToMiniRoman(40));
        assertEquals("xc", IntToMiniRoman.intToMiniRoman(90));
        assertEquals("cd", IntToMiniRoman.intToMiniRoman(400));
        assertEquals("cm", IntToMiniRoman.intToMiniRoman(900));
    }

    @Test
    void testIntToMiniRoman_complexCases() {
        assertEquals("xix", IntToMiniRoman.intToMiniRoman(19));
        assertEquals("clii", IntToMiniRoman.intToMiniRoman(152));
        assertEquals("cdxxvi", IntToMiniRoman.intToMiniRoman(426));
        assertEquals("xliii", IntToMiniRoman.intToMiniRoman(43));
        assertEquals("xciv", IntToMiniRoman.intToMiniRoman(94));
        assertEquals("dxxxii", IntToMiniRoman.intToMiniRoman(532));
        assertEquals("cmxciv", IntToMiniRoman.intToMiniRoman(994));
        assertEquals("ccli", IntToMiniRoman.intToMiniRoman(251));
    }

    @Test
    void testIntToMiniRoman_smallNumbers() {
        assertEquals("ii", IntToMiniRoman.intToMiniRoman(2));
        assertEquals("iii", IntToMiniRoman.intToMiniRoman(3));
        assertEquals("vi", IntToMiniRoman.intToMiniRoman(6));
        assertEquals("vii", IntToMiniRoman.intToMiniRoman(7));
        assertEquals("viii", IntToMiniRoman.intToMiniRoman(8));
    }

    @Test
    void testIntToMiniRoman_mediumNumbers() {
        assertEquals("xi", IntToMiniRoman.intToMiniRoman(11));
        assertEquals("xx", IntToMiniRoman.intToMiniRoman(20));
        assertEquals("xxx", IntToMiniRoman.intToMiniRoman(30));
        assertEquals("lxi", IntToMiniRoman.intToMiniRoman(61));
        assertEquals("lxx", IntToMiniRoman.intToMiniRoman(70));
        assertEquals("lxxx", IntToMiniRoman.intToMiniRoman(80));
    }

    @Test
    void testIntToMiniRoman_largeNumbers() {
        assertEquals("cxi", IntToMiniRoman.intToMiniRoman(111));
        assertEquals("cc", IntToMiniRoman.intToMiniRoman(200));
        assertEquals("ccc", IntToMiniRoman.intToMiniRoman(300));
        assertEquals("dxi", IntToMiniRoman.intToMiniRoman(511));
        assertEquals("dc", IntToMiniRoman.intToMiniRoman(600));
        assertEquals("dcc", IntToMiniRoman.intToMiniRoman(700));
        assertEquals("dccc", IntToMiniRoman.intToMiniRoman(800));
    }
}