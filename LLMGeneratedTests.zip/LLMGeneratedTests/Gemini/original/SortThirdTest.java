package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortThirdTest {

    @Test
    void sortThird_emptyList() {
        List<Integer> input = new ArrayList<>();
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_singleElementNotDivisibleByThree() {
        List<Integer> input = Arrays.asList(1);
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_singleElementDivisibleByThree() {
        List<Integer> input = Arrays.asList(3);
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_twoElements() {
        List<Integer> input = Arrays.asList(1, 2);
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_threeElementsNoChange() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_threeElementsWithChange() {
        List<Integer> input = Arrays.asList(3, 2, 1);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4, 8, 9, 2);
        List<Integer> expected = Arrays.asList(2, 6, 3, 4, 8, 9, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements2() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10);
        List<Integer> expected = Arrays.asList(1, 3, -5, 2, -3, 3, 5, 0, 123, 9, -10);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements3() {
        List<Integer> input = Arrays.asList(5, 8, -12, 4, 23, 2, 3, 11, 12, -10);
        List<Integer> expected = Arrays.asList(-10, 8, -12, 3, 23, 2, 4, 11, 12, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements4() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4, 8, 9, 2);
        List<Integer> expected = Arrays.asList(2, 6, 3, 4, 8, 9, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements5() {
        List<Integer> input = Arrays.asList(5, 8, 3, 4, 6, 9, 2);
        List<Integer> expected = Arrays.asList(2, 8, 3, 4, 6, 9, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements6() {
        List<Integer> input = Arrays.asList(5, 6, 9, 4, 8, 3, 2);
        List<Integer> expected = Arrays.asList(2, 6, 9, 4, 8, 3, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_multipleElements7() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4, 8, 9, 2, 1);
        List<Integer> expected = Arrays.asList(2, 6, 3, 4, 8, 9, 5, 1);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_allDivisibleByThree() {
        List<Integer> input = Arrays.asList(9, 6, 3, 0);
        List<Integer> expected = Arrays.asList(0, 6, 3, 9);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_allNotDivisibleByThree() {
        List<Integer> input = Arrays.asList(1, 2, 4, 5);
        List<Integer> expected = Arrays.asList(1, 2, 4, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_negativeAndPositiveNumbers() {
        List<Integer> input = Arrays.asList(-3, 1, 0, 2, 3, 4, -6);
        List<Integer> expected = Arrays.asList(-6, 1, 0, 2, -3, 4, 3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_duplicateValues() {
        List<Integer> input = Arrays.asList(3, 1, 3, 2, 3, 4, 3);
        List<Integer> expected = Arrays.asList(1, 1, 3, 2, 3, 4, 3);
    }

    @Test
    void sortThird_largeListWithMixedValues() {
        List<Integer> input = Arrays.asList(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110);
        List<Integer> expected = Arrays.asList(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_listWithZeros() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3, 4, 5, 6);
        List<Integer> expected = Arrays.asList(0, 1, 2, 0, 4, 5, 3);
        assertEquals(expected, SortThird.sortThird(input));
    }

    @Test
    void sortThird_listWithSameValuesAtDivisibleIndices() {
        List<Integer> input = Arrays.asList(5, 1, 5, 2, 5, 3, 5);
        List<Integer> expected = Arrays.asList(5, 1, 5, 2, 5, 3, 5);
        assertEquals(expected, SortThird.sortThird(input));
    }
}