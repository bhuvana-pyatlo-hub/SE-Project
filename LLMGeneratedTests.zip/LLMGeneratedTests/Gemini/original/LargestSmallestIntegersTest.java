package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LargestSmallestIntegersTest {

    @Test
    void largestSmallestIntegers_emptyList_returnsNullNull() {
        List<Object> input = new ArrayList<>();
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_onlyZero_returnsNullNull() {
        List<Object> input = Arrays.asList(0);
        List<Integer> expected = Arrays.asList(null, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_onlyPositive_returnsNullSmallest() {
        List<Object> input = Arrays.asList(2, 4, 1, 3, 5, 7);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_onlyNegative_returnsLargestNull() {
        List<Object> input = Arrays.asList(-1, -3, -5, -6);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_mixedPositiveNegative_returnsLargestSmallest() {
        List<Object> input = Arrays.asList(1, 3, 2, 4, 5, 6, -2);
        List<Integer> expected = Arrays.asList(-2, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_mixedPositiveNegativeLargeNegative_returnsLargestSmallest() {
        List<Object> input = Arrays.asList(4, 5, 3, 6, 2, 7, -7);
        List<Integer> expected = Arrays.asList(-7, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_mixedPositiveNegativeSmallNegative_returnsLargestSmallest() {
        List<Object> input = Arrays.asList(7, 3, 8, 4, 9, 2, 5, -9);
        List<Integer> expected = Arrays.asList(-9, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_mixedPositiveNegativeZero_returnsLargestSmallest() {
        List<Object> input = Arrays.asList(-6, -4, -4, -3, 1, 0);
        List<Integer> expected = Arrays.asList(-3, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_mixedPositiveNegativeLargeNegativeAndPositive_returnsLargestSmallest() {
        List<Object> input = Arrays.asList(-6, -4, -4, -3, -100, 1);
        List<Integer> expected = Arrays.asList(-3, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_onlyPositiveWithZero_returnsNullSmallest() {
        List<Object> input = Arrays.asList(2, 4, 1, 3, 5, 7, 0);
        List<Integer> expected = Arrays.asList(null, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_onlyNegativeWithZero_returnsLargestNull() {
        List<Object> input = Arrays.asList(-1, -3, -5, -6, 0);
        List<Integer> expected = Arrays.asList(-1, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_positiveAndNegativeSameValue_returnsCorrectResult() {
        List<Object> input = Arrays.asList(-5, 5);
        List<Integer> expected = Arrays.asList(-5, 5);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_multipleSameNegativeValues_returnsLargest() {
        List<Object> input = Arrays.asList(-2, -2, -2, -5);
        List<Integer> expected = Arrays.asList(-2, null);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_multipleSamePositiveValues_returnsSmallest() {
        List<Object> input = Arrays.asList(2, 2, 2, 5);
        List<Integer> expected = Arrays.asList(null, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_negativeOneAndOne_returnsCorrectResult() {
        List<Object> input = Arrays.asList(-1, 1);
        List<Integer> expected = Arrays.asList(-1, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_largeListMixedValues_returnsCorrectResult() {
        List<Object> input = Arrays.asList(-10, 5, -3, 8, 2, -1, 0, 15, -7, 1);
        List<Integer> expected = Arrays.asList(-1, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_allNegativeExceptOnePositive_returnsCorrectResult() {
        List<Object> input = Arrays.asList(-10, -5, -3, -8, -2, -1, 1);
        List<Integer> expected = Arrays.asList(-1, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_allPositiveExceptOneNegative_returnsCorrectResult() {
        List<Object> input = Arrays.asList(10, 5, 3, 8, 2, 1, -1);
        List<Integer> expected = Arrays.asList(-1, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_onlyOneNegativeAndOnePositive_returnsCorrectResult() {
        List<Object> input = Arrays.asList(-5, 2);
        List<Integer> expected = Arrays.asList(-5, 2);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }

    @Test
    void largestSmallestIntegers_duplicateValuesMixed_returnsCorrectResult() {
        List<Object> input = Arrays.asList(-2, 1, -2, 1, -3, 2, 2);
        List<Integer> expected = Arrays.asList(-2, 1);
        assertEquals(expected, LargestSmallestIntegers.largestSmallestIntegers(input));
    }
}