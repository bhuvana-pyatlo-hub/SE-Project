package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DigitsumTest {

    @Test
    void digitSum_emptyString() {
        assertEquals(0, Digitsum.digitSum(""));
    }

    @Test
    void digitSum_noUpperCase() {
        assertEquals(0, Digitsum.digitSum("abcdefg"));
    }

    @Test
    void digitSum_singleUpperCase() {
        assertEquals(65, Digitsum.digitSum("A"));
    }

    @Test
    void digitSum_multipleUpperCase() {
        assertEquals(131, Digitsum.digitSum("AB"));
    }

    @Test
    void digitSum_mixedCase() {
        assertEquals(65, Digitsum.digitSum("aA"));
    }

    @Test
    void digitSum_mixedCaseMultiple() {
        assertEquals(131, Digitsum.digitSum("abAB"));
    }

    @Test
    void digitSum_mixedCaseWithNumbers() {
        assertEquals(67, Digitsum.digitSum("abcCd123"));
    }

    @Test
    void digitSum_mixedCaseWithSpecialChars() {
        assertEquals(69, Digitsum.digitSum("helloE!"));
    }

    @Test
    void digitSum_stringWithSpaces() {
        assertEquals(131, Digitsum.digitSum("woArBld"));
    }

    @Test
    void digitSum_stringWithLeadingAndTrailingSpaces() {
        assertEquals(153, Digitsum.digitSum("aAaaaXa"));
    }

    @Test
    void digitSum_stringWithOnlySpaces() {
        assertEquals(0, Digitsum.digitSum("   "));
    }

    @Test
    void digitSum_stringWithUpperCaseAndSpaces() {
        assertEquals(151, Digitsum.digitSum(" How are yOu?"));
    }

    @Test
    void digitSum_stringWithUpperCaseAndLowerCaseAndSpaces() {
        assertEquals(327, Digitsum.digitSum("You arE Very Smart"));
    }

    @Test
    void digitSum_singleCharLowerCase() {
        assertEquals(0, Digitsum.digitSum("a"));
    }

    @Test
    void digitSum_singleCharUpperCase() {
        assertEquals(65, Digitsum.digitSum("A"));
    }

    @Test
    void digitSum_stringWithUpperCaseAtEnd() {
        assertEquals(69, Digitsum.digitSum("helloE"));
    }

    @Test
    void digitSum_stringWithUpperCaseAtBeginning() {
        assertEquals(67, Digitsum.digitSum("Chello"));
    }

    @Test
    void digitSum_stringWithUpperCaseInMiddle() {
        assertEquals(67, Digitsum.digitSum("helClo"));
    }

    @Test
    void digitSum_stringWithMultipleUpperCaseConsecutive() {
        assertEquals(198, Digitsum.digitSum("ABCdef"));
    }

    @Test
    void digitSum_stringWithMultipleUpperCaseScattered() {
        assertEquals(198, Digitsum.digitSum("aBcDeF"));
    }

    @Test
    void digitSum_stringWithAllUpperCase() {
        assertEquals(2015, Digitsum.digitSum("ABCDEFGHIJKLMNOPQRSTUVWXYZ"));
    }
}