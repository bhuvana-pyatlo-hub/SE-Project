package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AntiShuffleTest {

    @Test
    void antiShuffle_emptyString() {
        assertEquals("", AntiShuffle.antiShuffle(""));
    }

    @Test
    void antiShuffle_singleWord_alreadySorted() {
        assertEquals("abcd", AntiShuffle.antiShuffle("abcd"));
    }

    @Test
    void antiShuffle_singleWord_unsorted() {
        assertEquals("ehllo", AntiShuffle.antiShuffle("hello"));
    }

    @Test
    void antiShuffle_singleWord_mixedCase() {
        assertEquals("Hello", AntiShuffle.antiShuffle("Hello"));
    }

    @Test
    void antiShuffle_singleWord_withSymbols() {
        assertEquals("!!!", AntiShuffle.antiShuffle("!!!"));
    }

    @Test
    void antiShuffle_multipleWords() {
        assertEquals("Hello !!!Wdlor", AntiShuffle.antiShuffle("Hello World!!!"));
    }

    @Test
    void antiShuffle_multipleWords_withPunctuation() {
        assertEquals(".Hi My aemn is Meirst .Rboot How aer ?ouy", AntiShuffle.antiShuffle("Hi. My name is Mister Robot. How are you?"));
    }

    @Test
    void antiShuffle_multipleWords_withNumbers() {
        assertEquals("123 abc", AntiShuffle.antiShuffle("123 abc"));
    }

    @Test
    void antiShuffle_singleCharacter() {
        assertEquals("a", AntiShuffle.antiShuffle("a"));
    }

    @Test
    void antiShuffle_singleCharacter_uppercase() {
        assertEquals("A", AntiShuffle.antiShuffle("A"));
    }

    @Test
    void antiShuffle_stringWithLeadingAndTrailingSpaces() {
        assertEquals("   abc   ", AntiShuffle.antiShuffle("   abc   "));
    }

    @Test
    void antiShuffle_stringWithMultipleSpacesBetweenWords() {
        assertEquals("abc   def", AntiShuffle.antiShuffle("abc   def"));
    }

    @Test
    void antiShuffle_stringWithOnlySpaces() {
        assertEquals("   ", AntiShuffle.antiShuffle("   "));
    }

    @Test
    void antiShuffle_stringWithSpecialCharacters() {
        assertEquals("!@#", AntiShuffle.antiShuffle("!@#"));
    }

    @Test
    void antiShuffle_stringWithMixedCaseAndSpecialCharacters() {
        assertEquals("!Helol Wrdlo", AntiShuffle.antiShuffle("Hello World!"));
    }

    @Test
    void antiShuffle_stringWithNumbersAndLetters() {
        assertEquals("1abe2", AntiShuffle.antiShuffle("abe12"));
    }

    @Test
    void antiShuffle_stringWithRepeatingCharacters() {
        assertEquals("aaabbb", AntiShuffle.antiShuffle("baaabb"));
    }

    @Test
    void antiShuffle_stringWithUnicodeCharacters() {
        assertEquals("你好", AntiShuffle.antiShuffle("你好"));
    }

    @Test
    void antiShuffle_stringWithMixedUnicodeAndAscii() {
        assertEquals("a你好", AntiShuffle.antiShuffle("你好a"));
    }

    @Test
    void antiShuffle_stringWithEmptyWords() {
        assertEquals("  abc", AntiShuffle.antiShuffle("  abc"));
    }

    @Test
    void antiShuffle_stringWithTabs() {
        assertEquals("abc\tdef", AntiShuffle.antiShuffle("abc\tdef"));
    }
}