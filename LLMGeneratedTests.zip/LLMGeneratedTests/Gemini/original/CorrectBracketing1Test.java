package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketing1Test {

    @Test
    void testEmptyString() {
        assertTrue(CorrectBracketing1.correctBracketing(""));
    }

    @Test
    void testSingleOpenBracket() {
        assertFalse(CorrectBracketing1.correctBracketing("("));
    }

    @Test
    void testSingleCloseBracket() {
        assertFalse(CorrectBracketing1.correctBracketing(")"));
    }

    @Test
    void testSimpleCorrectBrackets() {
        assertTrue(CorrectBracketing1.correctBracketing("()"));
    }

    @Test
    void testSimpleIncorrectBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing(")("));
    }

    @Test
    void testNestedCorrectBrackets() {
        assertTrue(CorrectBracketing1.correctBracketing("(())"));
    }

    @Test
    void testNestedIncorrectBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("(()"));
    }

    @Test
    void testMultipleCorrectBrackets() {
        assertTrue(CorrectBracketing1.correctBracketing("()()"));
    }

    @Test
    void testMultipleIncorrectBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("())("));
    }

    @Test
    void testComplexCorrectBrackets() {
        assertTrue(CorrectBracketing1.correctBracketing("(()(()))"));
    }

    @Test
    void testComplexIncorrectBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("(()(()))("));
    }

    @Test
    void testStartingWithCloseBracket() {
        assertFalse(CorrectBracketing1.correctBracketing(")()"));
    }

    @Test
    void testEndingWithOpenBracket() {
        assertFalse(CorrectBracketing1.correctBracketing("()("));
    }

    @Test
    void testOnlyOpenBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("((("));
    }

    @Test
    void testOnlyCloseBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing(")))"));
    }

    @Test
    void testAlternatingBracketsIncorrect() {
        assertFalse(CorrectBracketing1.correctBracketing(")(()("));
    }

    @Test
    void testCorrectBracketsWithExtraOpen() {
        assertFalse(CorrectBracketing1.correctBracketing("(()))("));
    }

    @Test
    void testCorrectBracketsWithExtraClose() {
        assertFalse(CorrectBracketing1.correctBracketing("((()))))"));
    }

    @Test
    void testLongCorrectBrackets() {
        assertTrue(CorrectBracketing1.correctBracketing("(((())))"));
    }

    @Test
    void testLongIncorrectBrackets() {
        assertFalse(CorrectBracketing1.correctBracketing("(((()))))("));
    }

    @Test
    void testCorrectBracketingExample1() {
        assertTrue(CorrectBracketing1.correctBracketing("()()(()())()"));
    }

    @Test
    void testCorrectBracketingExample2() {
        assertTrue(CorrectBracketing1.correctBracketing("()()((()()())())(()()(()))"));
    }

    @Test
    void testIncorrectBracketingExample1() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())())(()"));
    }

    @Test
    void testIncorrectBracketingExample2() {
        assertFalse(CorrectBracketing1.correctBracketing("()()(()())()))()"));
    }
}