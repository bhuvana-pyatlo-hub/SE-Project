package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SumSquaresTest {

    @Test
    void testEmptyList() {
        List<Number> lst = Collections.emptyList();
        assertEquals(0, SumSquares.sumSquares(lst));
    }

    @Test
    void testPositiveIntegers() {
        List<Number> lst = Arrays.asList(1, 2, 3);
        assertEquals(14, SumSquares.sumSquares(lst));
    }

    @Test
    void testPositiveDoubles() {
        List<Number> lst = Arrays.asList(1.4, 4.2, 0.0);
        assertEquals(29, SumSquares.sumSquares(lst));
    }

    @Test
    void testNegativeAndPositiveNumbers() {
        List<Number> lst = Arrays.asList(-2.4, 1, 1);
        assertEquals(6, SumSquares.sumSquares(lst));
    }

    @Test
    void testLargePositiveIntegers() {
        List<Number> lst = Arrays.asList(100, 1, 15, 2);
        assertEquals(10230, SumSquares.sumSquares(lst));
    }

    @Test
    void testVeryLargePositiveIntegers() {
        List<Number> lst = Arrays.asList(10000, 10000);
        assertEquals(200000000, SumSquares.sumSquares(lst));
    }

    @Test
    void testNegativeDoubles() {
        List<Number> lst = Arrays.asList(-1.4, 4.6, 6.3);
        assertEquals(75, SumSquares.sumSquares(lst));
    }

    @Test
    void testNegativeAndLargePositiveDoubles() {
        List<Number> lst = Arrays.asList(-1.4, 17.9, 18.9, 19.9);
        assertEquals(1086, SumSquares.sumSquares(lst));
    }

    @Test
    void testZero() {
        List<Number> lst = Collections.singletonList(0);
        assertEquals(0, SumSquares.sumSquares(lst));
    }

    @Test
    void testNegativeOne() {
        List<Number> lst = Collections.singletonList(-1);
        assertEquals(1, SumSquares.sumSquares(lst));
    }

    @Test
    void testNegativePositiveAndZero() {
        List<Number> lst = Arrays.asList(-1, 1, 0);
        assertEquals(2, SumSquares.sumSquares(lst));
    }

    @Test
    void testMixedIntegerAndDouble() {
        List<Number> lst = Arrays.asList(1.0, 2, 3);
        assertEquals(14, SumSquares.sumSquares(lst));
    }

    @Test
    void testOnlyNegativeNumbers() {
        List<Number> lst = Arrays.asList(-1.0, -2.0, -3.0);
        assertEquals(14, SumSquares.sumSquares(lst));
    }

    @Test
    void testLargeNegativeNumbers() {
        List<Number> lst = Arrays.asList(-100.0, -200.0, -300.0);
        assertEquals(140000, SumSquares.sumSquares(lst));
    }

    @Test
    void testSmallPositiveNumbers() {
        List<Number> lst = Arrays.asList(0.1, 0.2, 0.3);
        assertEquals(3, SumSquares.sumSquares(lst));
    }

    @Test
    void testSmallNegativeNumbers() {
        List<Number> lst = Arrays.asList(-0.1, -0.2, -0.3);
        assertEquals(0, SumSquares.sumSquares(lst));
    }

    @Test
    void testListWithNull() {
        List<Number> lst = new ArrayList<>();
        lst.add(1);
        lst.add(null);
        lst.add(2);
        lst.add(3);
        lst.remove(1);
        assertEquals(14, SumSquares.sumSquares(lst));
    }

    @Test
    void testListWithOnlyNull() {
        List<Number> lst = new ArrayList<>();
        lst.add(null);
        lst.remove(0);
        assertEquals(0, SumSquares.sumSquares(lst));
    }

    @Test
    void testSingleElementList() {
        List<Number> lst = Collections.singletonList(5);
        assertEquals(25, SumSquares.sumSquares(lst));
    }

    @Test
    void testSingleNegativeDouble() {
        List<Number> lst = Collections.singletonList(-5.5);
        assertEquals(36, SumSquares.sumSquares(lst));
    }
}