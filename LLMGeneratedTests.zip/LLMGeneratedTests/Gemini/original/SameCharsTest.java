package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SameCharsTest {

    @Test
    void testSameChars_basicSame() {
        assertTrue(SameChars.sameChars("abc", "cba"));
    }

    @Test
    void testSameChars_basicDifferent() {
        assertFalse(SameChars.sameChars("abc", "abd"));
    }

    @Test
    void testSameChars_s0LongerSameChars() {
        assertTrue(SameChars.sameChars("abcd", "dddddddabc"));
    }

    @Test
    void testSameChars_s1LongerSameChars() {
        assertTrue(SameChars.sameChars("dddddddabc", "abcd"));
    }

    @Test
    void testSameChars_s0LongerDifferentChars() {
        assertFalse(SameChars.sameChars("eabcd", "dddddddabc"));
    }

    @Test
    void testSameChars_s1LongerDifferentChars() {
        assertFalse(SameChars.sameChars("abcd", "dddddddabcf"));
    }

    @Test
    void testSameChars_complexSame() {
        assertTrue(SameChars.sameChars("eabcdzzzz", "dddzzzzzzzddeddabc"));
    }

    @Test
    void testSameChars_complexDifferent() {
        assertFalse(SameChars.sameChars("eabcdzzzz", "dddzzzzzzzddddabc"));
    }

    @Test
    void testSameChars_s0Empty() {
        assertTrue(SameChars.sameChars("", ""));
    }

    @Test
    void testSameChars_s1Empty() {
        assertTrue(SameChars.sameChars("abc", "abc"));
    }

    @Test
    void testSameChars_s0EmptyS1NotEmpty() {
        assertFalse(SameChars.sameChars("", "a"));
    }

    @Test
    void testSameChars_s0NotEmptyS1Empty() {
        assertFalse(SameChars.sameChars("a", ""));
    }

    @Test
    void testSameChars_sameCharsRepeated() {
        assertFalse(SameChars.sameChars("aabb", "aaccc"));
    }

    @Test
    void testSameChars_singleCharSame() {
        assertTrue(SameChars.sameChars("a", "a"));
    }

    @Test
    void testSameChars_singleCharDifferent() {
        assertFalse(SameChars.sameChars("a", "b"));
    }

    @Test
    void testSameChars_allSameChars() {
        assertTrue(SameChars.sameChars("aaaa", "aaaa"));
    }

    @Test
    void testSameChars_differentLengthsSameChars() {
        assertFalse(SameChars.sameChars("abcd", "dddddddabce"));
    }

    @Test
    void testSameChars_edgeCase1() {
        assertTrue(SameChars.sameChars("abcdefghijklmnopqrstuvwxyz", "zyxwvutsrqponmlkjihgfedcba"));
    }

    @Test
    void testSameChars_edgeCase2() {
        assertFalse(SameChars.sameChars("abcdefghijklmnopqrstwxyz", "zyxwvutsrqponmlkjihgfedcba"));
    }
}