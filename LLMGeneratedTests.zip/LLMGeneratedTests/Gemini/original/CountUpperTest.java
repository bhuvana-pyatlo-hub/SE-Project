package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountUpperTest {

    @Test
    void countUpper_emptyString_returnsZero() {
        assertEquals(0, CountUpper.countUpper(""));
    }

    @Test
    void countUpper_noUppercaseVowels_returnsZero() {
        assertEquals(0, CountUpper.countUpper("abcdefg"));
    }

    @Test
    void countUpper_uppercaseVowelAtOddIndex_returnsZero() {
        assertEquals(0, CountUpper.countUpper("aBcDeFg"));
    }

    @Test
    void countUpper_uppercaseVowelAtEvenIndex_returnsOne() {
        assertEquals(1, CountUpper.countUpper("ABCdefg"));
    }

    @Test
    void countUpper_multipleUppercaseVowelsAtEvenIndices_returnsCorrectCount() {
        assertEquals(2, CountUpper.countUpper("AEIOUaeiou"));
    }

    @Test
    void countUpper_onlyUppercaseVowelsAtEvenIndices_returnsCorrectCount() {
        assertEquals(2, CountUpper.countUpper("EEEE"));
    }

    @Test
    void countUpper_uppercaseConsonantAtEvenIndex_returnsZero() {
        assertEquals(0, CountUpper.countUpper("BCDE"));
    }

    @Test
    void countUpper_mixedCaseVowels_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("AeIoU"));
    }

    @Test
    void countUpper_stringWithSpaces_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A BC"));
    }

    @Test
    void countUpper_stringWithNumbers_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A123"));
    }

    @Test
    void countUpper_stringWithSpecialCharacters_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A!@#"));
    }

    @Test
    void countUpper_singleUppercaseVowelAtEvenIndex_returnsOne() {
        assertEquals(1, CountUpper.countUpper("A"));
    }

    @Test
    void countUpper_singleLowercaseVowel_returnsZero() {
        assertEquals(0, CountUpper.countUpper("a"));
    }

    @Test
    void countUpper_singleUppercaseConsonant_returnsZero() {
        assertEquals(0, CountUpper.countUpper("B"));
    }

    @Test
    void countUpper_singleLowercaseConsonant_returnsZero() {
        assertEquals(0, CountUpper.countUpper("b"));
    }

    @Test
    void countUpper_longStringWithManyCharacters_returnsCorrectCount() {
        assertEquals(3, CountUpper.countUpper("AEIOUabcdefAEIOUghijkAEIOU"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelsOnlyAtOddIndices_returnsZero() {
        assertEquals(0, CountUpper.countUpper("aEaIaOaU"));
    }

    @Test
    void countUpper_stringWithUppercaseVowelsAndConsonants_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("ABcDe"));
    }

    @Test
    void countUpper_stringWithOnlyConsonants_returnsZero() {
        assertEquals(0, CountUpper.countUpper("BCDFGHJKLMNPQRSTVWXYZ"));
    }

    @Test
    void countUpper_stringWithMixedCaseAndNumbers_returnsCorrectCount() {
        assertEquals(1, CountUpper.countUpper("A1b2C3d4E"));
    }
}