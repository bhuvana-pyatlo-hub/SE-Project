package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsNestedTest {

    @Test
    void isNested_emptyString_returnsFalse() {
        assertFalse(IsNested.isNested(""));
    }

    @Test
    void isNested_singleOpeningBracket_returnsFalse() {
        assertFalse(IsNested.isNested("["));
    }

    @Test
    void isNested_singleClosingBracket_returnsFalse() {
        assertFalse(IsNested.isNested("]"));
    }

    @Test
    void isNested_simpleValidBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[]"));
    }

    @Test
    void isNested_nestedValidBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[]]"));
    }

    @Test
    void isNested_multipleValidBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[][]"));
    }

    @Test
    void isNested_nestedAndMultipleValidBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[][]]"));
    }

    @Test
    void isNested_unbalancedBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[[]][["));
    }

    @Test
    void isNested_onlyOpeningBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[[[[[[[["));
    }

    @Test
    void isNested_onlyClosingBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("]]]]]]]]"));
    }

    @Test
    void isNested_unbalancedBracketsWithExtraClosing_returnsFalse() {
        assertFalse(IsNested.isNested("[]]]]]]]]]]"));
    }

    @Test
    void isNested_unbalancedBracketsWithExtraOpening_returnsFalse() {
        assertFalse(IsNested.isNested("[[]"));
    }

    @Test
    void isNested_unbalancedBracketsWithClosingAtEnd_returnsFalse() {
        assertFalse(IsNested.isNested("[]]"));
    }

    @Test
    void isNested_complexUnbalancedBrackets_returnsFalse() {
        assertFalse(IsNested.isNested("[]]]]]]][[[[[]"));
    }

    @Test
    void isNested_complexNestedBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[[[]]]]"));
    }

    @Test
    void isNested_multipleNestedBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[][][[]]"));
    }

    @Test
    void isNested_nestedBracketsWithUnbalancedOpening_returnsTrue() {
        assertTrue(IsNested.isNested("[[]][["));
    }

    @Test
    void isNested_nestedBracketsWithMultipleOuterBrackets_returnsTrue() {
        assertTrue(IsNested.isNested("[[[][][[]]]]"));
    }

    @Test
    void isNested_nestedBracketsWithSingleOuterBracket_returnsTrue() {
        assertTrue(IsNested.isNested("[[][]]"));
    }

    @Test
    void isNested_nestedBracketsWithClosingBracketsAtEnd_returnsFalse() {
        assertFalse(IsNested.isNested("[[]]]]]"));
    }
}