package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StartsOneEndsTest {

    @Test
    void startsOneEnds_n1_returns1() {
        assertEquals(1, StartsOneEnds.startsOneEnds(1));
    }

    @Test
    void startsOneEnds_n2_returns18() {
        assertEquals(18, StartsOneEnds.startsOneEnds(2));
    }

    @Test
    void startsOneEnds_n3_returns180() {
        assertEquals(180, StartsOneEnds.startsOneEnds(3));
    }

    @Test
    void startsOneEnds_n4_returns1800() {
        assertEquals(1800, StartsOneEnds.startsOneEnds(4));
    }

    @Test
    void startsOneEnds_n5_returns18000() {
        assertEquals(18000, StartsOneEnds.startsOneEnds(5));
    }

    @Test
    void startsOneEnds_n6_returns180000() {
        assertEquals(180000, StartsOneEnds.startsOneEnds(6));
    }

    @Test
    void startsOneEnds_n7_returns1800000() {
        assertEquals(1800000, StartsOneEnds.startsOneEnds(7));
    }

    @Test
    void startsOneEnds_n8_returns18000000() {
        assertEquals(18000000, StartsOneEnds.startsOneEnds(8));
    }

    @Test
    void startsOneEnds_n9_returns180000000() {
        assertEquals(180000000, StartsOneEnds.startsOneEnds(9));
    }

    @Test
    void startsOneEnds_n10_returns1800000000() {
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n11_returnsExpectedValue() {
        // Test case for n = 11.  The expected value is calculated as 1.8 * 10^10.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n12_returnsExpectedValue() {
        // Test case for n = 12.  The expected value is calculated as 1.8 * 10^11.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n13_returnsExpectedValue() {
        // Test case for n = 13.  The expected value is calculated as 1.8 * 10^12.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n14_returnsExpectedValue() {
        // Test case for n = 14.  The expected value is calculated as 1.8 * 10^13.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n15_returnsExpectedValue() {
        // Test case for n = 15.  The expected value is calculated as 1.8 * 10^14.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n16_returnsExpectedValue() {
        // Test case for n = 16.  The expected value is calculated as 1.8 * 10^15.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n17_returnsExpectedValue() {
        // Test case for n = 17.  The expected value is calculated as 1.8 * 10^16.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n18_returnsExpectedValue() {
        // Test case for n = 18.  The expected value is calculated as 1.8 * 10^17.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n19_returnsExpectedValue() {
        // Test case for n = 19.  The expected value is calculated as 1.8 * 10^18.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }

    @Test
    void startsOneEnds_n20_returnsExpectedValue() {
        // Test case for n = 20.  The expected value is calculated as 1.8 * 10^19.
        assertEquals(1800000000, StartsOneEnds.startsOneEnds(10));
    }
}