package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class RescaleToUnitTest {

    @Test
    void testRescaleToUnit_validInput_ascending() {
        List<Double> input = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 0.25, 0.5, 0.75, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_twoElements() {
        List<Double> input = Arrays.asList(2.0, 49.9);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_descending() {
        List<Double> input = Arrays.asList(100.0, 49.9);
        List<Double> expected = Arrays.asList(1.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_mixedOrder() {
        List<Double> input = Arrays.asList(2.0, 1.0, 5.0, 3.0, 4.0);
        List<Double> expected = Arrays.asList(0.25, 0.0, 1.0, 0.5, 0.75);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_anotherMixedOrder() {
        List<Double> input = Arrays.asList(12.0, 11.0, 15.0, 13.0, 14.0);
        List<Double> expected = Arrays.asList(0.25, 0.0, 1.0, 0.5, 0.75);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_sameValues() {
        List<Double> input = Arrays.asList(5.0, 5.0, 5.0, 5.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_negativeValues() {
        List<Double> input = Arrays.asList(-1.0, -2.0, -3.0, -4.0, -5.0);
        List<Double> expected = Arrays.asList(1.0, 0.75, 0.5, 0.25, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_mixedPositiveNegative() {
        List<Double> input = Arrays.asList(-1.0, 0.0, 1.0, 2.0, 3.0);
        List<Double> expected = Arrays.asList(0.0, 0.25, 0.5, 0.75, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_decimalValues() {
        List<Double> input = Arrays.asList(1.1, 2.2, 3.3, 4.4, 5.5);
        List<Double> expected = Arrays.asList(0.0, 0.25, 0.5, 0.75, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_smallValues() {
        List<Double> input = Arrays.asList(0.1, 0.2, 0.3, 0.4, 0.5);
        List<Double> expected = Arrays.asList(0.0, 0.25, 0.5, 0.75, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_largeRange() {
        List<Double> input = Arrays.asList(1.0, 100.0);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_sameMinMax() {
        List<Double> input = Arrays.asList(10.0, 10.0);
        List<Double> expected = Arrays.asList(0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_minIsMax() {
        List<Double> input = Arrays.asList(5.0, 5.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_oneNegativeOnePositive() {
        List<Double> input = Arrays.asList(-1.0, 1.0);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_zeroAndPositive() {
        List<Double> input = Arrays.asList(0.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_zeroAndNegative() {
        List<Double> input = Arrays.asList(0.0, -5.0);
        List<Double> expected = Arrays.asList(1.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_allZeros() {
        List<Double> input = Arrays.asList(0.0, 0.0, 0.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_minMaxSameValueMultipleElements() {
        List<Double> input = Arrays.asList(7.0, 7.0, 7.0, 7.0);
        List<Double> expected = Arrays.asList(0.0, 0.0, 0.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_negativeAndZeroAndPositive() {
        List<Double> input = Arrays.asList(-5.0, 0.0, 5.0);
        List<Double> expected = Arrays.asList(0.0, 0.5, 1.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }

    @Test
    void testRescaleToUnit_validInput_twoElementsReverseOrder() {
        List<Double> input = Arrays.asList(5.0, 1.0);
        List<Double> expected = Arrays.asList(1.0, 0.0);
        List<Double> actual = RescaleToUnit.rescaleToUnit(input);
        assertEquals(expected, actual);
    }
}