package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class Add1Test {

    @Test
    void testAdd_emptyList() {
        List<Integer> lst = Collections.emptyList();
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_singleElementList_oddIndex() {
        List<Integer> lst = Collections.singletonList(4);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_singleElementList_evenIndex() {
        List<Integer> lst = Collections.singletonList(5);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_twoElements_evenAtOddIndex() {
        List<Integer> lst = Arrays.asList(4, 2);
        int result = Add1.add(lst);
        assertEquals(2, result);
    }

    @Test
    void testAdd_twoElements_oddAtOddIndex() {
        List<Integer> lst = Arrays.asList(4, 3);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_mixedEvenOdd() {
        List<Integer> lst = Arrays.asList(4, 2, 6, 7);
        int result = Add1.add(lst);
        assertEquals(2, result);
    }

    @Test
    void testAdd_multipleElements_allEvenAtOddIndices() {
        List<Integer> lst = Arrays.asList(4, 2, 6, 8, 10, 12);
        int result = Add1.add(lst);
        assertEquals(22, result);
    }

    @Test
    void testAdd_multipleElements_allOddAtOddIndices() {
        List<Integer> lst = Arrays.asList(4, 1, 6, 3, 10, 5);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_noEvenAtOddIndices() {
        List<Integer> lst = Arrays.asList(1, 3, 5, 7, 9);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_zeroAtOddIndex() {
        List<Integer> lst = Arrays.asList(4, 0, 6, 7);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_largeEvenNumber() {
        List<Integer> lst = Arrays.asList(1, 100);
        int result = Add1.add(lst);
        assertEquals(100, result);
    }

    @Test
    void testAdd_multipleElements_largeOddNumber() {
        List<Integer> lst = Arrays.asList(1, 99);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_negativeEvenNumber() {
        List<Integer> lst = Arrays.asList(1, -2);
        int result = Add1.add(lst);
        assertEquals(-2, result);
    }

    @Test
    void testAdd_multipleElements_negativeOddNumber() {
        List<Integer> lst = Arrays.asList(1, -1);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_multipleElements_mixedNegativePositive() {
        List<Integer> lst = Arrays.asList(-4, 2, -6, 7);
        int result = Add1.add(lst);
        assertEquals(2, result);
    }

    @Test
    void testAdd_multipleElements_allNegativeEvenAtOddIndices() {
        List<Integer> lst = Arrays.asList(-4, -2, -6, -8, -10, -12);
        int result = Add1.add(lst);
        assertEquals(-22, result);
    }

    @Test
    void testAdd_multipleElements_alternatingEvenOdd() {
        List<Integer> lst = Arrays.asList(2, 1, 4, 3, 6, 5);
        int result = Add1.add(lst);
        assertEquals(1, result);
    }

    @Test
    void testAdd_multipleElements_sameEvenNumberAtOddIndices() {
        List<Integer> lst = Arrays.asList(1, 2, 3, 2, 5, 2);
        int result = Add1.add(lst);
        assertEquals(6, result);
    }

    @Test
    void testAdd_listWithZeroes() {
        List<Integer> lst = Arrays.asList(0, 0, 0, 0);
        int result = Add1.add(lst);
        assertEquals(0, result);
    }

    @Test
    void testAdd_listWithLargeNumbers() {
        List<Integer> lst = Arrays.asList(100, 200, 300, 400);
        int result = Add1.add(lst);
        assertEquals(600, result);
    }
}