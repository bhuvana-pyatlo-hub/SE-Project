package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MatchParensTest {

    @Test
    void matchParens_s1s2Good_returnsYes() {
        List<String> lst = Arrays.asList("()(", ")");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad_s2s1Bad_returnsNo() {
        List<String> lst = Arrays.asList(")", ")");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_longStrings_s1s2Bad_s2s1Bad_returnsNo() {
        List<String> lst = Arrays.asList("(()(())", "())())");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_longStrings_s1s2Bad_s2s1Good_returnsYes() {
        List<String> lst = Arrays.asList(")())", "(()(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_longStrings_s1s2Bad_s2s1Good2_returnsYes() {
        List<String> lst = Arrays.asList("(())))", "(()())((");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad_s2s1Bad2_returnsNo() {
        List<String> lst = Arrays.asList("()", "())");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad_s2s1Good3_returnsYes() {
        List<String> lst = Arrays.asList("(()(", "()))()");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad_s2s1Bad3_returnsNo() {
        List<String> lst = Arrays.asList("((((", "((())");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad_s2s1Bad4_returnsNo() {
        List<String> lst = Arrays.asList(")()(", "(()(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Bad_s2s1Bad5_returnsNo() {
        List<String> lst = Arrays.asList(")(", ")(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Good2_returnsYes() {
        List<String> lst = Arrays.asList("(", ")");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2Good3_returnsYes() {
        List<String> lst = Arrays.asList(")", "(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_emptyStrings_returnsYes() {
        List<String> lst = Arrays.asList("", "");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_emptyString_with_balanced_returnsYes() {
        List<String> lst = Arrays.asList("", "()");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_emptyString_with_unbalanced_returnsNo() {
        List<String> lst = Arrays.asList("", "(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_singleOpen_singleClose_returnsYes() {
        List<String> lst = Arrays.asList("(", ")");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_singleClose_singleOpen_returnsYes() {
        List<String> lst = Arrays.asList(")", "(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_balanced_with_unbalanced_returnsNo() {
        List<String> lst = Arrays.asList("()", "(");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_unbalanced_with_balanced_returnsNo() {
        List<String> lst = Arrays.asList("(", "()");
        assertEquals("No", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s1s2_count_less_than_zero_returns_no() {
        List<String> lst = Arrays.asList(")", "(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }

    @Test
    void matchParens_s2s1_count_less_than_zero_returns_no() {
        List<String> lst = Arrays.asList(")", "(");
        assertEquals("Yes", MatchParens.matchParens(lst));
    }
}