package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsMultiplyPrimeTest {

    @Test
    void isMultiplyPrime_30_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(30));
    }

    @Test
    void isMultiplyPrime_5_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(5));
    }

    @Test
    void isMultiplyPrime_8_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(8));
    }

    @Test
    void isMultiplyPrime_10_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(10));
    }

    @Test
    void isMultiplyPrime_125_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(125));
    }

    @Test
    void isMultiplyPrime_105_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(105));
    }

    @Test
    void isMultiplyPrime_126_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(126));
    }

    @Test
    void isMultiplyPrime_729_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(729));
    }

    @Test
    void isMultiplyPrime_891_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(891));
    }

    @Test
    void isMultiplyPrime_1001_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(1001));
    }

    @Test
    void isMultiplyPrime_2_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(2));
    }

    @Test
    void isMultiplyPrime_6_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(6));
    }

    @Test
    void isMultiplyPrime_14_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(14));
    }

    @Test
    void isMultiplyPrime_21_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(21));
    }

    @Test
    void isMultiplyPrime_22_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(22));
    }

    @Test
    void isMultiplyPrime_26_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(26));
    }

    @Test
    void isMultiplyPrime_33_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(33));
    }

    @Test
    void isMultiplyPrime_34_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(34));
    }

    @Test
    void isMultiplyPrime_35_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(35));
    }

    @Test
    void isMultiplyPrime_42_returnsTrue() {
        assertTrue(IsMultiplyPrime.isMultiplyPrime(42));
    }

    @Test
    void isMultiplyPrime_1_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(1));
    }

    @Test
    void isMultiplyPrime_0_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(0));
    }

    @Test
    void isMultiplyPrime_neg1_returnsFalse() {
        assertFalse(IsMultiplyPrime.isMultiplyPrime(-1));
    }
}