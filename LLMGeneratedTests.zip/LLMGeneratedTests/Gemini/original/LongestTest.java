package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LongestTest {

    @Test
    void longest_emptyList_returnsNull() {
        List<Object> strings = new ArrayList<>();
        assertNull(Longest.longest(strings));
    }

    @Test
    void longest_singleElementList_returnsElement() {
        List<Object> strings = Collections.singletonList("a");
        assertEquals("a", Longest.longest(strings));
    }

    @Test
    void longest_multipleElementsDifferentLengths_returnsLongest() {
        List<Object> strings = Arrays.asList("a", "bb", "ccc");
        assertEquals("ccc", Longest.longest(strings));
    }

    @Test
    void longest_multipleElementsSameLengths_returnsFirst() {
        List<Object> strings = Arrays.asList("x", "y", "z");
        assertEquals("x", Longest.longest(strings));
    }

    @Test
    void longest_mixedLengths_returnsLongest() {
        List<Object> strings = Arrays.asList("x", "yyy", "zzzz", "www", "kkkk", "abc");
        assertEquals("zzzz", Longest.longest(strings));
    }

    @Test
    void longest_numbersAsStrings_returnsLongest() {
        List<Object> strings = Arrays.asList("1", "12", "123");
        assertEquals("123", Longest.longest(strings));
    }

    @Test
    void longest_emptyStringInList_returnsLongestNonEmpty() {
        List<Object> strings = Arrays.asList("", "a", "bb");
        assertEquals("bb", Longest.longest(strings));
    }

    @Test
    void longest_allEmptyStrings_returnsFirstEmpty() {
        List<Object> strings = Arrays.asList("", "", "");
        assertEquals("", Longest.longest(strings));
    }

    @Test
    void longest_nullObjectInList_returnsLongest() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("abc");
        assertEquals("abc", Longest.longest(strings));
    }

    @Test
    void longest_nullObjectFirst_returnsLongest() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("a");
        assertEquals("a", Longest.longest(strings));
    }

    @Test
    void longest_nullObjectOnly_returnsNullPointerException() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        assertThrows(NullPointerException.class, () -> Longest.longest(strings));
    }

    @Test
    void longest_listWithIntegers_returnsLongest() {
        List<Object> strings = Arrays.asList(1, 12, 123);
        assertEquals("123", Longest.longest(strings));
    }

    @Test
    void longest_listWithMixedTypes_returnsLongest() {
        List<Object> strings = Arrays.asList("a", 12, "ccc");
        assertEquals("ccc", Longest.longest(strings));
    }

    @Test
    void longest_listWithSpecialCharacters_returnsLongest() {
        List<Object> strings = Arrays.asList("!", "!!", "!!!");
        assertEquals("!!!", Longest.longest(strings));
    }

    @Test
    void longest_listWithUnicodeCharacters_returnsLongest() {
        List<Object> strings = Arrays.asList("你好", "世界", "你好世界");
        assertEquals("你好世界", Longest.longest(strings));
    }

    @Test
    void longest_listWithSameLengthStrings_returnsFirstString() {
        List<Object> strings = Arrays.asList("abc", "def", "ghi");
        assertEquals("abc", Longest.longest(strings));
    }

    @Test
    void longest_listWithLeadingAndTrailingSpaces_returnsLongest() {
        List<Object> strings = Arrays.asList(" a ", "  bb  ", "   ccc   ");
        assertEquals("   ccc   ", Longest.longest(strings));
    }

    @Test
    void longest_listWithNumbersAndStrings_returnsLongest() {
        List<Object> strings = Arrays.asList(1, "abc", 1234, "defgh");
        assertEquals("defgh", Longest.longest(strings));
    }

    @Test
    void longest_listWithEmptyAndNonEmptyStrings_returnsLongestNonEmpty() {
        List<Object> strings = Arrays.asList("", "a", "bb", "ccc", "");
        assertEquals("ccc", Longest.longest(strings));
    }

    @Test
    void longest_listWithOnlyOneElement_returnsThatElement() {
        List<Object> strings = Collections.singletonList("test");
        assertEquals("test", Longest.longest(strings));
    }
}