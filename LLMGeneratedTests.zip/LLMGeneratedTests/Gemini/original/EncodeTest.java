package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EncodeTest {

    @Test
    void encode_emptyString_returnsEmptyString() {
        assertEquals("", Encode.encode(""));
    }

    @Test
    void encode_lowercaseLetter_returnsUppercase() {
        assertEquals("A", Encode.encode("a"));
    }

    @Test
    void encode_uppercaseLetter_returnsLowercase() {
        assertEquals("a", Encode.encode("A"));
    }

    @Test
    void encode_mixedCaseString_returnsSwappedCase() {
        assertEquals("tEsT", Encode.encode("TeSt"));
    }

    @Test
    void encode_vowelA_returnsC() {
        assertEquals("c", Encode.encode("a"));
    }

    @Test
    void encode_vowelE_returnsG() {
        assertEquals("g", Encode.encode("e"));
    }

    @Test
    void encode_vowelI_returnsK() {
        assertEquals("k", Encode.encode("i"));
    }

    @Test
    void encode_vowelO_returnsQ() {
        assertEquals("q", Encode.encode("o"));
    }

    @Test
    void encode_vowelU_returnsW() {
        assertEquals("w", Encode.encode("u"));
    }

    @Test
    void encode_vowelCapitalA_returnsCapitalC() {
        assertEquals("C", Encode.encode("A"));
    }

    @Test
    void encode_vowelCapitalE_returnsCapitalG() {
        assertEquals("G", Encode.encode("E"));
    }

    @Test
    void encode_vowelCapitalI_returnsCapitalK() {
        assertEquals("K", Encode.encode("I"));
    }

    @Test
    void encode_vowelCapitalO_returnsCapitalQ() {
        assertEquals("Q", Encode.encode("O"));
    }

    @Test
    void encode_vowelCapitalU_returnsCapitalW() {
        assertEquals("W", Encode.encode("U"));
    }

    @Test
    void encode_stringWithSpace_returnsEncodedStringWithSpace() {
        assertEquals(" ", Encode.encode(" "));
    }

    @Test
    void encode_stringWithNumber_returnsSameNumber() {
        assertEquals("1", Encode.encode("1"));
    }

    @Test
    void encode_stringWithSpecialCharacter_returnsSameSpecialCharacter() {
        assertEquals("!", Encode.encode("!"));
    }

    @Test
    void encode_complexString_returnsEncodedString() {
        assertEquals("tHKS KS C MGSSCGG", Encode.encode("This is a message"));
    }

    @Test
    void encode_stringWithMultipleVowels_returnsEncodedString() {
        assertEquals("gck", Encode.encode("eae"));
    }

    @Test
    void encode_stringWithMixedCaseVowels_returnsEncodedString() {
        assertEquals("CgK", Encode.encode("AeI"));
    }

    @Test
    void encode_stringWithVowelsAndConsonants_returnsEncodedString() {
        assertEquals("bCdGf", Encode.encode("BacEf"));
    }

    @Test
    void encode_stringWithAllTypesOfCharacters_returnsEncodedString() {
        assertEquals("1!a A", Encode.encode("1!A a"));
    }

    @Test
    void encode_stringWithOnlyConsonants_returnsEncodedString() {
        assertEquals("BCDF", Encode.encode("bcdf"));
    }
}