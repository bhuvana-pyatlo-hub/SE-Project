package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FruitDistributionTest {

    @Test
    void fruitDistribution_validInput_positiveMangoes() {
        assertEquals(8, FruitDistribution.fruitDistribution("5 apples and 6 oranges", 19));
    }

    @Test
    void fruitDistribution_validInput_zeroApples() {
        assertEquals(2, FruitDistribution.fruitDistribution("0 apples and 1 oranges", 3));
    }

    @Test
    void fruitDistribution_validInput_zeroOranges() {
        assertEquals(2, FruitDistribution.fruitDistribution("1 apples and 0 oranges", 3));
    }

    @Test
    void fruitDistribution_validInput_largeTotalFruits() {
        assertEquals(95, FruitDistribution.fruitDistribution("2 apples and 3 oranges", 100));
    }

    @Test
    void fruitDistribution_validInput_largeApples() {
        assertEquals(19, FruitDistribution.fruitDistribution("100 apples and 1 oranges", 120));
    }

    @Test
    void fruitDistribution_validInput_largeOranges() {
        assertEquals(19, FruitDistribution.fruitDistribution("1 apples and 100 oranges", 120));
    }

    @Test
    void fruitDistribution_validInput_zeroMangoes() {
        assertEquals(0, FruitDistribution.fruitDistribution("2 apples and 3 oranges", 5));
    }

    @Test
    void fruitDistribution_validInput_negativeMangoes() {
        assertEquals(-1, FruitDistribution.fruitDistribution("10 apples and 10 oranges", 9));
    }

    @Test
    void fruitDistribution_validInput_equalApplesOrangesTotal() {
        assertEquals(0, FruitDistribution.fruitDistribution("5 apples and 5 oranges", 10));
    }

    @Test
    void fruitDistribution_validInput_onlyApples() {
        assertEquals(5, FruitDistribution.fruitDistribution("5 apples and 0 oranges", 10));
    }

    @Test
    void fruitDistribution_validInput_onlyOranges() {
        assertEquals(5, FruitDistribution.fruitDistribution("0 apples and 5 oranges", 10));
    }

    @Test
    void fruitDistribution_validInput_noApplesOranges() {
        assertEquals(10, FruitDistribution.fruitDistribution("0 apples and 0 oranges", 10));
    }

    @Test
    void fruitDistribution_validInput_singleDigitApplesOranges() {
        assertEquals(1, FruitDistribution.fruitDistribution("1 apples and 2 oranges", 4));
    }

    @Test
    void fruitDistribution_validInput_doubleDigitApplesOranges() {
        assertEquals(10, FruitDistribution.fruitDistribution("10 apples and 20 oranges", 40));
    }

    @Test
    void fruitDistribution_validInput_applesAndOrangesSameValue() {
        assertEquals(5, FruitDistribution.fruitDistribution("5 apples and 5 oranges", 15));
    }

    @Test
    void fruitDistribution_validInput_applesGreaterThanOranges() {
        assertEquals(5, FruitDistribution.fruitDistribution("10 apples and 5 oranges", 20));
    }

    @Test
    void fruitDistribution_validInput_orangesGreaterThanApples() {
        assertEquals(5, FruitDistribution.fruitDistribution("5 apples and 10 oranges", 20));
    }

    @Test
    void fruitDistribution_validInput_applesAndOrangesZeroTotal() {
        assertEquals(0, FruitDistribution.fruitDistribution("0 apples and 0 oranges", 0));
    }

    @Test
    void fruitDistribution_validInput_applesAndOrangesEqualToTotal() {
        assertEquals(0, FruitDistribution.fruitDistribution("5 apples and 5 oranges", 10));
    }

    @Test
    void fruitDistribution_validInput_largeNumbers() {
        assertEquals(100, FruitDistribution.fruitDistribution("100 apples and 100 oranges", 300));
    }
}