package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SumToNTest {

    @Test
    void sumToN_positiveSmallValue() {
        assertEquals(15, SumToN.sumToN(5));
    }

    @Test
    void sumToN_positiveMediumValue() {
        assertEquals(55, SumToN.sumToN(10));
    }

    @Test
    void sumToN_positiveSingleValue() {
        assertEquals(1, SumToN.sumToN(1));
    }

    @Test
    void sumToN_positiveAnotherSmallValue() {
        assertEquals(21, SumToN.sumToN(6));
    }

    @Test
    void sumToN_positiveAnotherMediumValue() {
        assertEquals(66, SumToN.sumToN(11));
    }

    @Test
    void sumToN_positiveValue30() {
        assertEquals(465, SumToN.sumToN(30));
    }

    @Test
    void sumToN_positiveValue100() {
        assertEquals(5050, SumToN.sumToN(100));
    }

    @Test
    void sumToN_zeroValue() {
        assertEquals(0, SumToN.sumToN(0));
    }

    @Test
    void sumToN_largePositiveValue() {
        assertEquals(4950, SumToN.sumToN(99));
    }

    @Test
    void sumToN_value2() {
        assertEquals(3, SumToN.sumToN(2));
    }

    @Test
    void sumToN_value3() {
        assertEquals(6, SumToN.sumToN(3));
    }

    @Test
    void sumToN_value4() {
        assertEquals(10, SumToN.sumToN(4));
    }

    @Test
    void sumToN_value7() {
        assertEquals(28, SumToN.sumToN(7));
    }

    @Test
    void sumToN_value8() {
        assertEquals(36, SumToN.sumToN(8));
    }

    @Test
    void sumToN_value9() {
        assertEquals(45, SumToN.sumToN(9));
    }

    @Test
    void sumToN_value12() {
        assertEquals(78, SumToN.sumToN(12));
    }

    @Test
    void sumToN_value13() {
        assertEquals(91, SumToN.sumToN(13));
    }

    @Test
    void sumToN_value14() {
        assertEquals(105, SumToN.sumToN(14));
    }

    @Test
    void sumToN_value15() {
        assertEquals(120, SumToN.sumToN(15));
    }

    @Test
    void sumToN_value16() {
        assertEquals(136, SumToN.sumToN(16));
    }
}