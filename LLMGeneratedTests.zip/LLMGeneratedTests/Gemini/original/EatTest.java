package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EatTest {

    @Test
    void testEat_needLessThanRemaining() {
        List<Integer> result = Eat.eat(5, 6, 10);
        assertEquals(11, result.get(0));
        assertEquals(4, result.get(1));
    }

    @Test
    void testEat_needGreaterThanRemaining() {
        List<Integer> result = Eat.eat(2, 11, 5);
        assertEquals(7, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testEat_needEqualsRemaining() {
        List<Integer> result = Eat.eat(1, 10, 10);
        assertEquals(11, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testEat_zeroNumber() {
        List<Integer> result = Eat.eat(0, 5, 7);
        assertEquals(5, result.get(0));
        assertEquals(2, result.get(1));
    }

    @Test
    void testEat_zeroNeed() {
        List<Integer> result = Eat.eat(4, 0, 7);
        assertEquals(4, result.get(0));
        assertEquals(7, result.get(1));
    }

    @Test
    void testEat_zeroRemaining() {
        List<Integer> result = Eat.eat(4, 5, 0);
        assertEquals(4, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testEat_largeValues() {
        List<Integer> result = Eat.eat(100, 50, 75);
        assertEquals(150, result.get(0));
        assertEquals(25, result.get(1));
    }

    @Test
    void testEat_largeValuesRemainingLessThanNeed() {
        List<Integer> result = Eat.eat(100, 75, 50);
        assertEquals(150, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testEat_negativeNumber() {
        List<Integer> result = Eat.eat(-5, 6, 10);
        assertEquals(1, result.get(0));
        assertEquals(4, result.get(1));
    }

    @Test
    void testEat_negativeNeed() {
        List<Integer> result = Eat.eat(5, -6, 10);
        assertEquals(-1, result.get(0));
        assertEquals(16, result.get(1));
    }

    @Test
    void testEat_negativeRemaining() {
        List<Integer> result = Eat.eat(5, 6, -10);
        assertEquals(-5, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testEat_allNegative() {
        List<Integer> result = Eat.eat(-5, -6, -10);
        assertEquals(-15, result.get(0));
        assertEquals(0, result.get(1));
    }
}