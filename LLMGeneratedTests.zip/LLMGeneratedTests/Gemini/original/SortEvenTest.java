package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class SortEvenTest {

    @Test
    void testEmptyList() {
        List<Integer> input = Arrays.asList();
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testSingleElementList() {
        List<Integer> input = Arrays.asList(1);
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testTwoElementList() {
        List<Integer> input = Arrays.asList(1, 2);
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testThreeElementList() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testFourElementList() {
        List<Integer> input = Arrays.asList(5, 6, 3, 4);
        List<Integer> expected = Arrays.asList(3, 6, 5, 4);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testFiveElementList() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testSixElementList() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3);
        List<Integer> expected = Arrays.asList(-5, 3, -3, 2, 5, 3);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testSevenElementList() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9);
        List<Integer> expected = Arrays.asList(-5, 3, -3, 2, 5, 3, 9);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testEightElementList() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0);
        List<Integer> expected = Arrays.asList(-5, 3, -3, 2, 5, 3, 9, 0);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testNineElementList() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123);
        List<Integer> expected = Arrays.asList(-5, 3, -3, 2, 5, 3, 9, 0, 123);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testTenElementList() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1);
        List<Integer> expected = Arrays.asList(-5, 3, -3, 2, 5, 3, 9, 0, 123, 1);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testElevenElementList() {
        List<Integer> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10);
        List<Integer> expected = Arrays.asList(-10, 3, -5, 2, -3, 3, 5, 0, 9, 1, 123);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testTwelveElementList() {
        List<Integer> input = Arrays.asList(5, 8, -12, 4, 23, 2, 3, 11, 12, -10, 1, 7);
        List<Integer> expected = Arrays.asList(-12, 8, 1, 4, 3, 2, 5, 11, 12, -10, 23, 7);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testAllEvenIndicesSameValue() {
        List<Integer> input = Arrays.asList(2, 1, 2, 3, 2, 5);
        List<Integer> expected = Arrays.asList(2, 1, 2, 3, 2, 5);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testAllOddIndicesSameValue() {
        List<Integer> input = Arrays.asList(1, 2, 3, 2, 5, 2);
        List<Integer> expected = Arrays.asList(1, 2, 3, 2, 5, 2);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testNegativeAndPositiveNumbers() {
        List<Integer> input = Arrays.asList(-1, 2, 1, 4, -3, 6);
        List<Integer> expected = Arrays.asList(-3, 2, -1, 4, 1, 6);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testZeroInEvenIndices() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3, 4, 5);
        List<Integer> expected = Arrays.asList(0, 1, 2, 3, 4, 5);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testZeroInOddIndices() {
        List<Integer> input = Arrays.asList(1, 0, 3, 0, 5, 0);
        List<Integer> expected = Arrays.asList(1, 0, 3, 0, 5, 0);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testLargeList() {
        List<Integer> input = Arrays.asList(10, 1, 9, 2, 8, 3, 7, 4, 6, 5);
        List<Integer> expected = Arrays.asList(6, 1, 7, 2, 8, 3, 9, 4, 10, 5);
        assertEquals(expected, SortEven.sortEven(input));
    }

    @Test
    void testDuplicateEvenNumbers() {
        List<Integer> input = Arrays.asList(4, 1, 2, 2, 4, 3);
        List<Integer> expected = Arrays.asList(2, 1, 2, 2, 4, 3);
        assertEquals(expected, SortEven.sortEven(input));
    }
}