package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortArray1Test {

    @Test
    void sortArray_emptyArray() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_singleElementArray() {
        List<Object> input = new ArrayList<>(Arrays.asList(5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_evenSumAscending() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 4, 3, 0, 1, 5, 6));
        List<Object> expected = new ArrayList<>(Arrays.asList(6, 5, 4, 3, 2, 1, 0));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_oddSumAscending() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 4, 3, 0, 1, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_twoElementsOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_twoElementsEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(4, 2));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_multipleElementsOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(15, 42, 87, 32, 11, 0));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 11, 15, 32, 42, 87));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_multipleElementsEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(21, 14, 23, 11));
        List<Object> expected = new ArrayList<>(Arrays.asList(23, 21, 14, 11));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_allSameElementsOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5, 5, 5, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_allSameElementsEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(4, 4, 4, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(4, 4, 4, 4));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_negativeAndPositiveOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 2, 3, 4));
    }

    @Test
    void sortArray_negativeAndPositiveEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(-2, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(4, 3, 2, -2));
        assertEquals(new ArrayList<>(expected), SortArray1.sortArray(new ArrayList<>(input)));
    }

    @Test
    void sortArray_zeroAndPositiveOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 2, 3, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 2, 3, 5));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_zeroAndPositiveEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(4, 3, 2, 0));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_largeValuesOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(100, 200, 300, 500));
        List<Object> expected = new ArrayList<>(Arrays.asList(100, 200, 300, 500));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_largeValuesEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(100, 200, 300, 400));
        List<Object> expected = new ArrayList<>(Arrays.asList(400, 300, 200, 100));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_mixedValuesOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 50, 2, 100));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 50, 100));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_mixedValuesEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 50, 2, 99));
        List<Object> expected = new ArrayList<>(Arrays.asList(99, 50, 2, 1));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_negativeValuesOddSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, -50, -2, -100));
        List<Object> expected = new ArrayList<>(Arrays.asList(-100, -50, -2, -1));
        assertEquals(expected, SortArray1.sortArray(input));
    }

    @Test
    void sortArray_negativeValuesEvenSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, -50, -2, -99));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -2, -50, -99));
        assertEquals(new ArrayList<>(expected), SortArray1.sortArray(new ArrayList<>(input)));
    }
}