package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RollingMaxTest {

    @Test
    void rollingMax_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_singleElement() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_increasingSequence() {
        List<Object> input = Arrays.asList(1, 2, 3, 4);
        List<Object> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_decreasingSequence() {
        List<Object> input = Arrays.asList(4, 3, 2, 1);
        List<Object> expected = Arrays.asList(4, 4, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_mixedSequence() {
        List<Object> input = Arrays.asList(3, 2, 3, 100, 3);
        List<Object> expected = Arrays.asList(3, 3, 3, 100, 100);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_example1() {
        List<Object> input = Arrays.asList(1, 2, 3, 2, 3, 4, 2);
        List<Object> expected = Arrays.asList(1, 2, 3, 3, 3, 4, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_allSameElements() {
        List<Object> input = Arrays.asList(5, 5, 5, 5, 5);
        List<Object> expected = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_negativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3, -4);
        List<Object> expected = Arrays.asList(-1, -1, -1, -1);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_mixedPositiveNegative() {
        List<Object> input = Arrays.asList(-1, 2, -3, 4);
        List<Object> expected = Arrays.asList(-1, 2, 2, 4);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_zeroes() {
        List<Object> input = Arrays.asList(0, 0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0, 0);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_largeNumbers() {
        List<Object> input = Arrays.asList(100, 200, 50, 300);
        List<Object> expected = Arrays.asList(100, 200, 200, 300);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_alternatingHighLow() {
        List<Object> input = Arrays.asList(10, 1, 20, 2, 30, 3);
        List<Object> expected = Arrays.asList(10, 10, 20, 20, 30, 30);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_boundaryValues() {
        List<Object> input = Arrays.asList(Integer.MAX_VALUE, Integer.MIN_VALUE, 0);
        List<Object> expected = Arrays.asList(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_duplicateMaxValues() {
        List<Object> input = Arrays.asList(5, 2, 5, 1, 5);
        List<Object> expected = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_initialMaxIsSmall() {
        List<Object> input = Arrays.asList(1, 5, 2, 8, 3);
        List<Object> expected = Arrays.asList(1, 5, 5, 8, 8);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_allNegativeExceptOnePositive() {
        List<Object> input = Arrays.asList(-5, -2, 1, -8, -3);
        List<Object> expected = Arrays.asList(-5, -2, 1, 1, 1);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_firstElementIsMax() {
        List<Object> input = Arrays.asList(10, 1, 2, 3);
        List<Object> expected = Arrays.asList(10, 10, 10, 10);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_lastElementIsMax() {
        List<Object> input = Arrays.asList(1, 2, 3, 10);
        List<Object> expected = Arrays.asList(1, 2, 3, 10);
        assertEquals(expected, RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_invalidInputType() {
        List<Object> input = Arrays.asList(1, 2, "a", 4);
        assertThrows(IllegalArgumentException.class, () -> RollingMax.rollingMax(input));
    }

    @Test
    void rollingMax_onlyInvalidInputType() {
        List<Object> input = Arrays.asList("a", "b", "c");
        assertThrows(IllegalArgumentException.class, () -> RollingMax.rollingMax(input));
    }
}