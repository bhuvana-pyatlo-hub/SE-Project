package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StrlenTest {

    @Test
    void testStrlen_emptyString() {
        assertEquals(0, Strlen.strlen(""), "Should return 0 for an empty string");
    }

    @Test
    void testStrlen_singleCharacter() {
        assertEquals(1, Strlen.strlen("a"), "Should return 1 for a single character string");
    }

    @Test
    void testStrlen_shortString() {
        assertEquals(3, Strlen.strlen("abc"), "Should return 3 for 'abc'");
    }

    @Test
    void testStrlen_mediumString() {
        assertEquals(10, Strlen.strlen("0123456789"), "Should return 10 for '0123456789'");
    }

    @Test
    void testStrlen_stringWithSpaces() {
        assertEquals(5, Strlen.strlen("a b c"), "Should return 5 for 'a b c'");
    }

    @Test
    void testStrlen_stringWithSpecialCharacters() {
        assertEquals(5, Strlen.strlen("!@#$%"), "Should return 5 for '!@#$%'");
    }

    @Test
    void testStrlen_stringWithNumbersAndLetters() {
        assertEquals(7, Strlen.strlen("a1b2c3d"), "Should return 7 for 'a1b2c3d'");
    }

    @Test
    void testStrlen_stringWithMixedCase() {
        assertEquals(5, Strlen.strlen("AbCdE"), "Should return 5 for 'AbCdE'");
    }

    @Test
    void testStrlen_stringWithLeadingAndTrailingSpaces() {
        assertEquals(7, Strlen.strlen("  abc  "), "Should return 7 for '  abc  '");
    }

    @Test
    void testStrlen_stringWithOnlySpaces() {
        assertEquals(5, Strlen.strlen("     "), "Should return 5 for '     '");
    }

    @Test
    void testStrlen_stringWithUnicodeCharacters() {
        assertEquals(3, Strlen.strlen("你好世"), "Should return 3 for '你好世'");
    }

    @Test
    void testStrlen_stringWithEmoji() {
        assertEquals(1, Strlen.strlen("😀"), "Should return 1 for '😀'");
    }

    @Test
    void testStrlen_stringWithNewline() {
        assertEquals(1, Strlen.strlen("\n"), "Should return 1 for '\\n'");
    }

    @Test
    void testStrlen_stringWithTab() {
        assertEquals(1, Strlen.strlen("\t"), "Should return 1 for '\\t'");
    }

    @Test
    void testStrlen_stringWithNullCharacter() {
        assertEquals(1, Strlen.strlen("\0"), "Should return 1 for '\\0'");
    }

    @Test
    void testStrlen_longString() {
        String longString = "abcdefghijklmnopqrstuvwxyz";
        assertEquals(26, Strlen.strlen(longString), "Should return 26 for a long string");
    }

    @Test
    void testStrlen_stringWithRepeatingCharacters() {
        assertEquals(5, Strlen.strlen("aaaaa"), "Should return 5 for 'aaaaa'");
    }

    @Test
    void testStrlen_stringWithDifferentRepeatingCharacters() {
        assertEquals(6, Strlen.strlen("ababab"), "Should return 6 for 'ababab'");
    }

    @Test
    void testStrlen_stringWithEmptyStringInside() {
        assertEquals(5, Strlen.strlen("a  b "), "Should return 5 for 'a  b '");
    }

    @Test
    void testStrlen_stringWithMixedSpecialAndNormalChars() {
        assertEquals(5, Strlen.strlen("a!b@c"), "Should return 5 for 'a!b@c'");
    }
}