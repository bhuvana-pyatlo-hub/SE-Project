package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GetMaxTriplesTest {

    @Test
    void getMaxTriples_nEquals1() {
        assertEquals(0, GetMaxTriples.getMaxTriples(1));
    }

    @Test
    void getMaxTriples_nEquals2() {
        assertEquals(0, GetMaxTriples.getMaxTriples(2));
    }

    @Test
    void getMaxTriples_nEquals3() {
        assertEquals(0, GetMaxTriples.getMaxTriples(3));
    }

    @Test
    void getMaxTriples_nEquals4() {
        assertEquals(0, GetMaxTriples.getMaxTriples(4));
    }

    @Test
    void getMaxTriples_nEquals5() {
        assertEquals(1, GetMaxTriples.getMaxTriples(5));
    }

    @Test
    void getMaxTriples_nEquals6() {
        assertEquals(4, GetMaxTriples.getMaxTriples(6));
    }

    @Test
    void getMaxTriples_nEquals7() {
        assertEquals(10, GetMaxTriples.getMaxTriples(7));
    }

    @Test
    void getMaxTriples_nEquals8() {
        assertEquals(20, GetMaxTriples.getMaxTriples(8));
    }

    @Test
    void getMaxTriples_nEquals9() {
        assertEquals(35, GetMaxTriples.getMaxTriples(9));
    }

    @Test
    void getMaxTriples_nEquals10() {
        assertEquals(56, GetMaxTriples.getMaxTriples(10));
    }

    @Test
    void getMaxTriples_nEquals11() {
        assertEquals(83, GetMaxTriples.getMaxTriples(11));
    }

    @Test
    void getMaxTriples_nEquals12() {
        assertEquals(116, GetMaxTriples.getMaxTriples(12));
    }

    @Test
    void getMaxTriples_nEquals15() {
        assertEquals(276, GetMaxTriples.getMaxTriples(15));
    }

    @Test
    void getMaxTriples_nEquals20() {
        assertEquals(969, GetMaxTriples.getMaxTriples(20));
    }

    @Test
    void getMaxTriples_nEquals25() {
        assertEquals(2530, GetMaxTriples.getMaxTriples(25));
    }

    @Test
    void getMaxTriples_nEquals30() {
        assertEquals(5330, GetMaxTriples.getMaxTriples(30));
    }

    @Test
    void getMaxTriples_nEquals50() {
        assertEquals(27725, GetMaxTriples.getMaxTriples(50));
    }

    @Test
    void getMaxTriples_nEquals100() {
        assertEquals(53361, GetMaxTriples.getMaxTriples(100));
    }

    @Test
    void getMaxTriples_nEquals101() {
        assertEquals(54926, GetMaxTriples.getMaxTriples(101));
    }
}