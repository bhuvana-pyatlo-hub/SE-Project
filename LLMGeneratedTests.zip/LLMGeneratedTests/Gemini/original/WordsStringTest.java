package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WordsStringTest {

    @Test
    void testEmptyString() {
        assertEquals(Collections.emptyList(), WordsString.wordsString(""));
    }

    @Test
    void testSingleWord() {
        assertEquals(Arrays.asList("Hello"), WordsString.wordsString("Hello"));
    }

    @Test
    void testCommaSeparatedWords() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString("One,two,three"));
    }

    @Test
    void testSpaceSeparatedWords() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString("One two three"));
    }

    @Test
    void testCommaAndSpaceSeparatedWords() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString("One, two, three"));
    }

    @Test
    void testMultipleCommas() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString("One,,two,three"));
    }

    @Test
    void testMultipleSpaces() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString("One   two three"));
    }

    @Test
    void testLeadingAndTrailingCommas() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString(",One,two,three,"));
    }

    @Test
    void testLeadingAndTrailingSpaces() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString(" One two three "));
    }

    @Test
    void testLeadingAndTrailingCommasAndSpaces() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString(" , One, two, three, "));
    }

    @Test
    void testMixedSeparators() {
        assertEquals(Arrays.asList("One", "two", "three"), WordsString.wordsString("One, two,three"));
    }

    @Test
    void testEmptyWords() {
        assertEquals(Arrays.asList(""), WordsString.wordsString(" "));
    }

    @Test
    void testOnlyCommas() {
        assertEquals(Arrays.asList(""), WordsString.wordsString(","));
    }

    @Test
    void testOnlySpaces() {
        assertEquals(Arrays.asList(""), WordsString.wordsString("   "));
    }

    @Test
    void testCommaAndSpaceOnly() {
        assertEquals(Arrays.asList(""), WordsString.wordsString(",   "));
    }

    @Test
    void testWordsWithNumbers() {
        assertEquals(Arrays.asList("Word1", "Word2"), WordsString.wordsString("Word1, Word2"));
    }

    @Test
    void testWordsWithSpecialCharacters() {
        assertEquals(Arrays.asList("Word!", "Word@"), WordsString.wordsString("Word!, Word@"));
    }

    @Test
    void testWordsWithMixedCase() {
        assertEquals(Arrays.asList("Word", "word"), WordsString.wordsString("Word, word"));
    }

    @Test
    void testLongString() {
        assertEquals(Arrays.asList("This", "is", "a", "long", "string"), WordsString.wordsString("This, is, a, long, string"));
    }

    @Test
    void testStringWithTabs() {
        assertEquals(Arrays.asList("One", "two"), WordsString.wordsString("One\t two"));
    }

    @Test
    void testStringWithNewline() {
        assertEquals(Arrays.asList("One", "two"), WordsString.wordsString("One\n two"));
    }
}