package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CheckIfLastCharIsALetterTest {

    @Test
    void testEmptyString() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(""));
    }

    @Test
    void testLastCharIsLetterAndSingleChar() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("A"));
    }

    @Test
    void testLastCharIsLetterAndNotPartOfWord() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e"));
    }

    @Test
    void testLastCharIsLetterAndPartOfWord() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple"));
    }

    @Test
    void testLastCharIsNotLetter() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pie"));
    }

    @Test
    void testLastCharIsLetterButTrailingSpace() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("apple pi e "));
    }

    @Test
    void testLastCharIsNumber() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie 1"));
    }

    @Test
    void testLastCharIsLetterAndPartOfWordWithTrailingSpace() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee e "));
    }

    @Test
    void testLastCharIsLetterAndPartOfWord2() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("eeeee"));
    }

    @Test
    void testLastCharIsLetterAndTrailingSpace() {
        assertFalse(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("Pumpkin pie "));
    }

    @Test
    void testLastCharIsLetterAndSecondLastIsNumber() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter("1a"));
    }

    @Test
    void testLastCharIsLetterAndSecondLastIsSpace() {
        assertTrue(CheckIfLastCharIsALetter.checkIfLastCharIsALetter(" a"));
    }
}