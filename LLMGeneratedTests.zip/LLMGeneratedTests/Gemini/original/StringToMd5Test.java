package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringToMd5Test {

    @Test
    void stringToMd5_emptyString_returnsNull() {
        assertNull(StringToMd5.stringToMd5(""));
    }

    @Test
    void stringToMd5_helloWorld_returnsCorrectMd5() {
        assertEquals("3e25960a79dbc69b674cd4ec67a72c62", StringToMd5.stringToMd5("Hello world"));
    }

    @Test
    void stringToMd5_abc_returnsCorrectMd5() {
        assertEquals("900150983cd24fb0d6963f7d28e17f72", StringToMd5.stringToMd5("abc"));
    }

    @Test
    void stringToMd5_aBc_returnsCorrectMd5() {
        assertEquals("4e07408562bedb8b60ce05c1ca0dae2f", StringToMd5.stringToMd5("aBc"));
    }

    @Test
    void stringToMd5_oneTwoThree_returnsCorrectMd5() {
        assertEquals("202cb962ac59075b964b07152d234b70", StringToMd5.stringToMd5("123"));
    }

    @Test
    void stringToMd5_password_returnsCorrectMd5() {
        assertEquals("5f4dcc3b5aa765d61d8327deb882cf99", StringToMd5.stringToMd5("password"));
    }

    @Test
    void stringToMd5_shortString_returnsCorrectMd5() {
        assertEquals("ac59075b964b0715", StringToMd5.stringToMd5("12"));
    }

    @Test
    void stringToMd5_longString_returnsCorrectMd5() {
        assertEquals("a61a04a4f5f74198404924b45f677373", StringToMd5.stringToMd5("This is a very long string to test the md5 function."));
    }

    @Test
    void stringToMd5_stringWithSpaces_returnsCorrectMd5() {
        assertEquals("0ef78513b0cb8cef12743f5aeb35f888", StringToMd5.stringToMd5("A B C"));
    }

    @Test
    void stringToMd5_stringWithSpecialCharacters_returnsCorrectMd5() {
        assertEquals("b10a8db164e0754105b7a99be72e3fe5", StringToMd5.stringToMd5("!@#$%^"));
    }

    @Test
    void stringToMd5_stringWithNumbersAndLetters_returnsCorrectMd5() {
        assertEquals("b393e102663473780752a4a7073202a1", StringToMd5.stringToMd5("a1b2c3d4"));
    }

    @Test
    void stringToMd5_stringWithUnicodeCharacters_returnsCorrectMd5() {
        assertEquals("9f6e677895941141960195610f747065", StringToMd5.stringToMd5("你好世界"));
    }

    @Test
    void stringToMd5_stringWithMixedCase_returnsCorrectMd5() {
        assertEquals("b10a8db164e0754105b7a99be72e3fe5", StringToMd5.stringToMd5("!@#$%^"));
    }

    @Test
    void stringToMd5_stringWithLeadingAndTrailingSpaces_returnsCorrectMd5() {
        assertEquals("228f022090361166977157137a99780c", StringToMd5.stringToMd5("  test  "));
    }

    @Test
    void stringToMd5_stringWithOnlySpaces_returnsCorrectMd5() {
        assertEquals("7215ee9c7d9dc229d2921a40e899ec5f", StringToMd5.stringToMd5("   "));
    }

    @Test
    void stringToMd5_stringWithTabs_returnsCorrectMd5() {
        assertEquals("43f64a897753317267a815a656346878", StringToMd5.stringToMd5("\ttest\t"));
    }

    @Test
    void stringToMd5_stringWithNewlines_returnsCorrectMd5() {
        assertEquals("43f64a897753317267a815a656346878", StringToMd5.stringToMd5("\ttest\t"));
    }

    @Test
    void stringToMd5_stringWithControlCharacters_returnsCorrectMd5() {
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", StringToMd5.stringToMd5("\0"));
    }

    @Test
    void stringToMd5_stringWithNumbers_returnsCorrectMd5() {
        assertEquals("c4ca4238a0b923820dcc509a6f75849b", StringToMd5.stringToMd5("1"));
    }

    @Test
    void stringToMd5_stringWithSpecialCharactersOnly_returnsCorrectMd5() {
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", StringToMd5.stringToMd5(""));
    }
}