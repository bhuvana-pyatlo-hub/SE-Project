package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PrimeLengthTest {

    @Test
    void primeLength_emptyString_returnsFalse() {
        assertFalse(PrimeLength.primeLength(""));
    }

    @Test
    void primeLength_singleCharacterString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("M"));
    }

    @Test
    void primeLength_lengthTwoString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("HI"));
    }

    @Test
    void primeLength_lengthThreeString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("Wow"));
    }

    @Test
    void primeLength_lengthFiveString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("Hello"));
    }

    @Test
    void primeLength_lengthSevenString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdcba"));
    }

    @Test
    void primeLength_lengthSixString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("orange"));
    }

    @Test
    void primeLength_lengthFourString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("gogo"));
    }

    @Test
    void primeLength_lengthEightString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefgh"));
    }

    @Test
    void primeLength_lengthNineString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghi"));
    }

    @Test
    void primeLength_lengthTenString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghij"));
    }

    @Test
    void primeLength_lengthElevenString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijk"));
    }

    @Test
    void primeLength_lengthTwelveString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijkl"));
    }

    @Test
    void primeLength_lengthThirteenString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklm"));
    }

    @Test
    void primeLength_lengthFourteenString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmn"));
    }

    @Test
    void primeLength_lengthFifteenString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmno"));
    }

    @Test
    void primeLength_lengthSixteenString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnop"));
    }

    @Test
    void primeLength_lengthSeventeenString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopq"));
    }

    @Test
    void primeLength_lengthEighteenString_returnsFalse() {
        assertFalse(PrimeLength.primeLength("abcdefghijklmnopqr"));
    }

    @Test
    void primeLength_lengthNineteenString_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrs"));
    }

    @Test
    void primeLength_length23String_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrstuvw"));
    }

    @Test
    void primeLength_length29String_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrstuvwxyzabc"));
    }

    @Test
    void primeLength_length31String_returnsTrue() {
        assertTrue(PrimeLength.primeLength("abcdefghijklmnopqrstuvwxyzabcd "));
    }
}