package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SeparateParenGroupsTest {

    @Test
    void separateParenGroups_emptyString() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups(""));
    }

    @Test
    void separateParenGroups_singleGroup() {
        List<String> expected = Collections.singletonList("(()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()())"));
    }

    @Test
    void separateParenGroups_multipleGroups() {
        List<String> expected = Arrays.asList("(()())", "((()))", "()", "((())()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()()) ((())) () ((())()())"));
    }

    @Test
    void separateParenGroups_multipleGroupsWithSpaces() {
        List<String> expected = Arrays.asList("()", "(())", "((()))", "(((())))");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() (()) ((())) (((())))"));
    }

    @Test
    void separateParenGroups_singleLargeGroup() {
        List<String> expected = Collections.singletonList("(()(())((())))");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()(())((())))"));
    }

    @Test
    void separateParenGroups_groupsWithInternalSpaces() {
        List<String> expected = Arrays.asList("()", "(())", "(()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("( ) (( )) (( )( ))"));
    }

    @Test
    void separateParenGroups_unbalancedString() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("("));
    }

    @Test
    void separateParenGroups_unbalancedString2() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups(")"));
    }

    @Test
    void separateParenGroups_unbalancedString3() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()"));
    }

    @Test
    void separateParenGroups_unbalancedString4() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("())"));
    }

    @Test
    void separateParenGroups_onlySpaces() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("   "));
    }

    @Test
    void separateParenGroups_spacesAndUnbalanced() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups(" ( "));
    }

    @Test
    void separateParenGroups_nestedAndSeparate() {
        List<String> expected = Arrays.asList("()", "(())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() (())"));
    }

    @Test
    void separateParenGroups_complexMix() {
        List<String> expected = Arrays.asList("(()())", "((()))", "()", "((())()())");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("(()()) ((())) () ((())()())"));
    }

    @Test
    void separateParenGroups_adjacentGroups() {
        List<String> expected = Arrays.asList("()", "()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("()()"));
    }

    @Test
    void separateParenGroups_adjacentGroupsWithSpace() {
        List<String> expected = Arrays.asList("()", "()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("() ()"));
    }

    @Test
    void separateParenGroups_singleParen() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("("));
    }

    @Test
    void separateParenGroups_singleCloseParen() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups(")"));
    }

    @Test
    void separateParenGroups_multipleUnbalanced() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("((((((((((((((("));
    }

    @Test
    void separateParenGroups_multipleUnbalancedClose() {
        List<String> expected = Collections.emptyList();
        assertEquals(expected, SeparateParenGroups.separateParenGroups("))))))))))))))))))"));
    }

    @Test
    void separateParenGroups_mixedBalancedAndUnbalanced() {
        List<String> expected = Collections.singletonList("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups("()("));
    }

    @Test
    void separateParenGroups_mixedBalancedAndUnbalanced2() {
        List<String> expected = Collections.singletonList("()");
        assertEquals(expected, SeparateParenGroups.separateParenGroups(")()"));
    }
}