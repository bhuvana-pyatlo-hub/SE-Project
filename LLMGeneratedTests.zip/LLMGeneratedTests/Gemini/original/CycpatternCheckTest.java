package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CycpatternCheckTest {

    @Test
    void cycpatternCheck_emptyA_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("", "abc"));
    }

    @Test
    void cycpatternCheck_emptyB_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abc", ""));
    }

    @Test
    void cycpatternCheck_bothEmpty_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("", ""));
    }

    @Test
    void cycpatternCheck_bLongerThanA_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("ab", "abcd"));
    }

    @Test
    void cycpatternCheck_exactMatch_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abc", "abc"));
    }

    @Test
    void cycpatternCheck_substringMatch_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abcdef", "bcd"));
    }

    @Test
    void cycpatternCheck_noMatch_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abcdef", "xyz"));
    }

    @Test
    void cycpatternCheck_cyclicMatch_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abcd", "bcd"));
    }

    @Test
    void cycpatternCheck_cyclicMatchAtEnd_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abcd", "dab"));
    }

    @Test
    void cycpatternCheck_cyclicMatchMultipleRotations_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("abab", "baa"));
    }

    @Test
    void cycpatternCheck_noCyclicMatch_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abcd", "abd"));
    }

    @Test
    void cycpatternCheck_helloEll_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("hello", "ell"));
    }

    @Test
    void cycpatternCheck_whassupPsus_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("whassup", "psus"));
    }

    @Test
    void cycpatternCheck_efefEeff_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("efef", "eeff"));
    }

    @Test
    void cycpatternCheck_himenssSimen_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("himenss", "simen"));
    }

    @Test
    void cycpatternCheck_xyzwXyw_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("xyzw", "xyw"));
    }

    @Test
    void cycpatternCheck_yelloEll_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("yello", "ell"));
    }

    @Test
    void cycpatternCheck_whattupPtut_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("whattup", "ptut"));
    }

    @Test
    void cycpatternCheck_efefFee_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("efef", "fee"));
    }

    @Test
    void cycpatternCheck_ababAabb_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("abab", "aabb"));
    }

    @Test
    void cycpatternCheck_winemttTinem_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("winemtt", "tinem"));
    }

    @Test
    void cycpatternCheck_aEqualsB_returnsTrue() {
        assertTrue(CycpatternCheck.cycpatternCheck("a", "a"));
    }

    @Test
    void cycpatternCheck_singleCharNoMatch_returnsFalse() {
        assertFalse(CycpatternCheck.cycpatternCheck("a", "b"));
    }
}