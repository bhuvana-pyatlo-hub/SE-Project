package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DigitsTest {

    @Test
    void testPositiveSingleDigitOdd() {
        assertEquals(1, Digits.digits(1));
    }

    @Test
    void testPositiveSingleDigitEven() {
        assertEquals(0, Digits.digits(4));
    }

    @Test
    void testPositiveMultipleDigitsMixed() {
        assertEquals(15, Digits.digits(235));
    }

    @Test
    void testPositiveMultipleDigitsAllEven() {
        assertEquals(0, Digits.digits(2468));
    }

    @Test
    void testPositiveMultipleDigitsWithZero() {
        assertEquals(5, Digits.digits(5014));
    }

    @Test
    void testPositiveMultipleDigitsLargeNumber() {
        assertEquals(2625, Digits.digits(5576543));
    }

    @Test
    void testPositiveMultipleDigitsLargeNumber2() {
        assertEquals(315, Digits.digits(98765));
    }

    @Test
    void testPositiveMultipleDigitsWithLeadingZerosIgnored() {
        assertEquals(1, Digits.digits(120));
    }

    @Test
    void testPositiveMultipleDigitsWithOnlyOneOddDigit() {
        assertEquals(5, Digits.digits(54));
    }

    @Test
    void testPositiveMultipleDigitsWithOnlyOneOddDigitAtEnd() {
        assertEquals(5, Digits.digits(5));
    }

    @Test
    void testPositiveNumberWithMultipleOddDigits() {
        assertEquals(9, Digits.digits(9090));
    }
}