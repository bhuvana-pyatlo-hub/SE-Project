package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MeanAbsoluteDeviationTest {

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMAD2() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0);
        double expected = 1.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_validInput_returnsCorrectMAD3() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0);
        double expected = 1.2;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_emptyList_returnsCorrectMAD() {
        List<Double> numbers = new ArrayList<>();
        assertThrows(ArithmeticException.class, () -> MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers));
    }

    @Test
    void meanAbsoluteDeviation_singleElementList_returnsZero() {
        List<Double> numbers = Collections.singletonList(5.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithNegativeNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(-1.0, -2.0, -3.0);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithMixedPositiveAndNegativeNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(-1.0, 1.0, 2.0);
        double expected = 1.1111111111111112;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithZero_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(0.0, 1.0, 2.0);
        double expected = 0.8888888888888889;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithDuplicateNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(1.0, 1.0, 1.0);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithLargeNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(100.0, 200.0, 300.0);
        double expected = 66.66666666666667;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithSmallNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(0.1, 0.2, 0.3);
        double expected = 0.06666666666666667;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(1.5, 2.5, 3.5);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithNegativeDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(-1.5, -2.5, -3.5);
        double expected = 0.6666666666666666;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithMixedDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(-1.5, 2.5, 3.5);
        double expected = 1.9444444444444444;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithZeroAndDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(0.0, 1.5, 2.5);
        double expected = 1.1111111111111112;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithDuplicateDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(1.5, 1.5, 1.5);
        double expected = 0.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithLargeDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(100.5, 200.5, 300.5);
        double expected = 66.66666666666667;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithSmallDecimalNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(0.15, 0.25, 0.35);
        double expected = 0.06666666666666667;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }

    @Test
    void meanAbsoluteDeviation_listWithSameNegativeAndPositiveNumbers_returnsCorrectMAD() {
        List<Double> numbers = Arrays.asList(-1.0, 1.0);
        double expected = 1.0;
        double actual = MeanAbsoluteDeviation.meanAbsoluteDeviation(numbers);
        assertEquals(expected, actual, 0.000001);
    }
}