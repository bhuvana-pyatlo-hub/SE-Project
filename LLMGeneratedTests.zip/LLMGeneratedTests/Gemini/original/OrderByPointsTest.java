package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OrderByPointsTest {

    @Test
    void orderByPoints_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_singleElement() {
        List<Object> input = new ArrayList<>(Arrays.asList(5));
        List<Object> expected = new ArrayList<>(Arrays.asList(5));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_positiveNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 11, 2, 22));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 11, 22));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_negativeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, -11, -2, -22));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -2, -11, -22));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_mixedNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 11, -1, -11));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 1, -11, 11));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_sameDigitSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(12, 21, 30));
        List<Object> expected = new ArrayList<>(Arrays.asList(12, 21, 30));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_zero() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1, -1));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 0, 1));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_largeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(123, 45, 6));
        List<Object> expected = new ArrayList<>(Arrays.asList(6, 45, 123));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_negativeLargeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(-123, -45, -6));
        List<Object> expected = new ArrayList<>(Arrays.asList(-6, -45, -123));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_mixedLargeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(123, -45, 6, -1));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, 6, -45, 123));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_duplicateNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 1, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 1, 1));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_duplicateNumbersWithDifferentSigns() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, -1, 1, -1));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -1, 1, 1));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 11, -1, -11, -12));
        List<Object> expected = new ArrayList<>(Arrays.asList(-1, -11, 1, -12, 11));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList2() {
        List<Object> input = new ArrayList<>(Arrays.asList(1234, 423, 463, 145, 2, 423, 423, 53, 6, 37, 3457, 3, 56, 0, 46));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 2, 3, 6, 53, 423, 423, 423, 1234, 145, 37, 46, 56, 463, 3457));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList3() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, -11, -32, 43, 54, -98, 2, -3));
        List<Object> expected = new ArrayList<>(Arrays.asList(-3, -32, -98, -11, 1, 2, 43, 54));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList4() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 10, 2, 11, 3, 4, 5, 6, 7, 8, 9));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_complexList5() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 6, 6, -76, -21, 23, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(-76, -21, 0, 4, 23, 6, 6));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_allSameDigitSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(11, 20, 2, 101));
        List<Object> expected = new ArrayList<>(Arrays.asList(2, 11, 20, 101));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_negativeAndPositiveSameDigitSum() {
        List<Object> input = new ArrayList<>(Arrays.asList(11, -2, 2, -11));
        List<Object> expected = new ArrayList<>(Arrays.asList(-2, -11, 2, 11));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }

    @Test
    void orderByPoints_zeroAndOtherNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 12, -3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(-3, 0, 4, 12));
        assertEquals(expected, OrderByPoints.orderByPoints(input));
    }
}