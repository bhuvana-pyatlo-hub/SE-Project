package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ByLengthTest {

    @Test
    void byLength_emptyArray() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_validInput() {
        List<Object> input = Arrays.asList(2, 1, 1, 4, 5, 8, 2, 3);
        List<Object> expected = Arrays.asList("Eight", "Five", "Four", "Three", "Two", "Two", "One", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_strangeNumbers() {
        List<Object> input = Arrays.asList(1, -1, 55);
        List<Object> expected = Arrays.asList("One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_mixedInput() {
        List<Object> input = Arrays.asList(1, -1, 3, 2);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allValidNumbers() {
        List<Object> input = Arrays.asList(9, 4, 8);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Four");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyOneValidNumber() {
        List<Object> input = Arrays.asList(10, 11, 1);
        List<Object> expected = Arrays.asList("One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyInvalidNumbers() {
        List<Object> input = Arrays.asList(10, 11, 12);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allSameValidNumber() {
        List<Object> input = Arrays.asList(5, 5, 5, 5);
        List<Object> expected = Arrays.asList("Five", "Five", "Five", "Five");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_boundaryValuesOneAndNine() {
        List<Object> input = Arrays.asList(1, 9);
        List<Object> expected = Arrays.asList("Nine", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_zeroInput() {
        List<Object> input = Arrays.asList(0);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_negativeInput() {
        List<Object> input = Arrays.asList(-1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_duplicateValidNumbers() {
        List<Object> input = Arrays.asList(2, 2, 2);
        List<Object> expected = Arrays.asList("Two", "Two", "Two");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_largeInputList() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        List<Object> expected = Arrays.asList("Nine", "Eight", "Seven", "Six", "Five", "Four", "Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyIntegerObjects() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2, 3));
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_mixedObjectTypes() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, "hello", 2, 3.0, 4));
        List<Object> expected = Arrays.asList("Four", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_onlyStringObjects() {
        List<Object> input = new ArrayList<>(Arrays.asList("one", "two", "three"));
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_singleValidNumber() {
        List<Object> input = Arrays.asList(7);
        List<Object> expected = Arrays.asList("Seven");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_multipleValidAndInvalidNumbers() {
        List<Object> input = Arrays.asList(1, 10, 2, -5, 3, 15);
        List<Object> expected = Arrays.asList("Three", "Two", "One");
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allNumbersGreaterThanNine() {
        List<Object> input = Arrays.asList(10, 11, 12, 13);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }

    @Test
    void byLength_allNumbersLessThanOne() {
        List<Object> input = Arrays.asList(0, -1, -2, -3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, ByLength.byLength(input));
    }
}