package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ParseNestedParensTest {

    @Test
    void testEmptyString() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens(""));
    }

    @Test
    void testSingleGroupNoNesting() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("()"));
    }

    @Test
    void testSingleGroupSimpleNesting() {
        List<Integer> expected = Arrays.asList(2);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(())"));
    }

    @Test
    void testSingleGroupMultipleNesting() {
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, ParseNestedParens.parseNestedParens("((()))"));
    }

    @Test
    void testMultipleGroupsNoNesting() {
        List<Integer> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("() () ()"));
    }

    @Test
    void testMultipleGroupsMixedNesting() {
        List<Integer> expected = Arrays.asList(2, 3, 1);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()()) ((())) ()"));
    }

    @Test
    void testComplexNesting() {
        List<Integer> expected = Arrays.asList(4);
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()(())((())))"));
    }

    @Test
    void testOnlyOpenParens() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("((("));
    }

    @Test
    void testOnlyCloseParens() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens(")))"));
    }

    @Test
    void testUnbalancedParens() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("(()"));
    }

    @Test
    void testUnbalancedParens2() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("())"));
    }

    @Test
    void testLeadingAndTrailingSpaces() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, ParseNestedParens.parseNestedParens(" () "));
    }

    @Test
    void testMultipleSpacesBetweenGroups() {
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, ParseNestedParens.parseNestedParens("()  (())"));
    }

    @Test
    void testSingleGroupWithInternalSpaces() {
        List<Integer> expected = Arrays.asList();
        assertEquals(Arrays.asList(), ParseNestedParens.parseNestedParens("( )"));
    }

    @Test
    void testSingleGroupWithInternalSpacesAndNesting() {
        List<Integer> expected = Arrays.asList();
        assertEquals(Arrays.asList(), ParseNestedParens.parseNestedParens("(( ))"));
    }

    @Test
    void testMixedCharacters() {
        List<Integer> expected = Arrays.asList();
        assertEquals(Arrays.asList(), ParseNestedParens.parseNestedParens("(a)"));
    }

    @Test
    void testMixedCharactersAndNesting() {
        List<Integer> expected = Arrays.asList();
        assertEquals(Arrays.asList(), ParseNestedParens.parseNestedParens("((a))"));
    }

    @Test
    void testLargeNesting() {
        List<Integer> expected = Arrays.asList(5);
        assertEquals(Arrays.asList(5), ParseNestedParens.parseNestedParens("((((())))"));
    }

    @Test
    void testNoParens() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("abc"));
    }

    @Test
    void testOnlySpaces() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, ParseNestedParens.parseNestedParens("   "));
    }

    @Test
    void testSingleGroupWithAdjacentParens() {
        List<Integer> expected = Arrays.asList(2);
        assertEquals(Arrays.asList(2), ParseNestedParens.parseNestedParens("(()"));
    }

    @Test
    void testSingleGroupWithAdjacentParens2() {
        List<Integer> expected = Arrays.asList();
        assertEquals(Arrays.asList(), ParseNestedParens.parseNestedParens("())"));
    }
}