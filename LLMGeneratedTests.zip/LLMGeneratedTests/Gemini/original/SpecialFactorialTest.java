package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SpecialFactorialTest {

    @Test
    void testSpecialFactorial_positiveSmallValue() {
        assertEquals(288, SpecialFactorial.specialFactorial(4));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue2() {
        assertEquals(34560, SpecialFactorial.specialFactorial(5));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue3() {
        assertEquals(1, SpecialFactorial.specialFactorial(1));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue4() {
        assertEquals(2, SpecialFactorial.specialFactorial(2));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue5() {
        assertEquals(12, SpecialFactorial.specialFactorial(3));
    }

    @Test
    void testSpecialFactorial_positiveBoundaryValue() {
        assertEquals(125411328000L, SpecialFactorial.specialFactorial(7));
    }

    @Test
    void testSpecialFactorial_positiveEdgeCase() {
        assertEquals(1, SpecialFactorial.specialFactorial(1));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue6() {
        assertEquals(6227020800L, SpecialFactorial.specialFactorial(6));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue7() {
        assertEquals(87178291200L * 125411328000L, SpecialFactorial.specialFactorial(8));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue8() {
        long expected = 1;
        for (int i = 1; i <= 9; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(9));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue9() {
        long expected = 1;
        for (int i = 1; i <= 10; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(10));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue10() {
        long expected = 1;
        for (int i = 1; i <= 11; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(11));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue12() {
        long expected = 1;
        for (int i = 1; i <= 12; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(12));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue13() {
        long expected = 1;
        for (int i = 1; i <= 13; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(13));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue14() {
        long expected = 1;
        for (int i = 1; i <= 14; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(14));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue15() {
        long expected = 1;
        for (int i = 1; i <= 15; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(15));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue16() {
        long expected = 1;
        for (int i = 1; i <= 16; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(16));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue17() {
        long expected = 1;
        for (int i = 1; i <= 17; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(17));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue18() {
        long expected = 1;
        for (int i = 1; i <= 18; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(18));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue19() {
        long expected = 1;
        for (int i = 1; i <= 19; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(19));
    }

    @Test
    void testSpecialFactorial_positiveSmallValue20() {
        long expected = 1;
        for (int i = 1; i <= 20; i++) {
            long factorial = 1;
            for (int j = 1; j <= i; j++) {
                factorial *= j;
            }
            expected *= factorial;
        }
        assertEquals(expected, SpecialFactorial.specialFactorial(20));
    }
}