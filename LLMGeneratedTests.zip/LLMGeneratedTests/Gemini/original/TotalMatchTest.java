package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TotalMatchTest {

    @Test
    void totalMatch_emptyLists_returnsFirstList() {
        List<Object> list1 = new ArrayList<>();
        List<Object> list2 = new ArrayList<>();
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1Shorter_returnsList1() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hi", "hi", "admin", "project");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2Shorter_returnsList2() {
        List<Object> list1 = Arrays.asList("hi", "hi", "admin", "project");
        List<Object> list2 = Arrays.asList("hi", "admin");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1Shorter_returnsList1_caseInsensitive() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hI", "hi", "hii");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2Shorter_returnsList2_caseInsensitive() {
        List<Object> list1 = Arrays.asList("hI", "hi", "hii");
        List<Object> list2 = Arrays.asList("hi", "admin");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1Shorter_returnsList1_numbers() {
        List<Object> list1 = Collections.singletonList("4");
        List<Object> list2 = Arrays.asList("1", "2", "3", "4", "5");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2Shorter_returnsList2_numbers() {
        List<Object> list1 = Arrays.asList("1", "2", "3", "4", "5");
        List<Object> list2 = Collections.singletonList("4");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1Empty_returnsList1() {
        List<Object> list1 = new ArrayList<>();
        List<Object> list2 = Collections.singletonList("this");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2Empty_returnsList1() {
        List<Object> list1 = Collections.singletonList("this");
        List<Object> list2 = new ArrayList<>();
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_equalLength_returnsList1() {
        List<Object> list1 = Arrays.asList("hi", "admin");
        List<Object> list2 = Arrays.asList("hI", "Hi");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1NullElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", null, "admin");
        List<Object> list2 = Arrays.asList("hI", "Hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2NullElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hI", "Hi");
        List<Object> list2 = Arrays.asList("hi", null, "admin");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1And2NullElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hi", null, "admin");
        List<Object> list2 = Arrays.asList("hi", null, "admin");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1EmptyString_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("", "admin");
        List<Object> list2 = Arrays.asList("hI", "Hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2EmptyString_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hI", "Hi");
        List<Object> list2 = Arrays.asList("", "admin");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1And2EmptyString_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("", "admin");
        List<Object> list2 = Arrays.asList("", "admin");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1IntegerElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(1, "admin");
        List<Object> list2 = Arrays.asList("hI", "Hi");
        assertEquals(list2, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list2IntegerElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList("hI", "Hi");
        List<Object> list2 = Arrays.asList(1, "admin");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1And2IntegerElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(1, "admin");
        List<Object> list2 = Arrays.asList(1, "admin");
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }

    @Test
    void totalMatch_list1And2MixElement_returnsCorrectList() {
        List<Object> list1 = Arrays.asList(1, "admin", null);
        List<Object> list2 = Arrays.asList(1, "admin", null);
        assertEquals(list1, TotalMatch.totalMatch(list1, list2));
    }
}