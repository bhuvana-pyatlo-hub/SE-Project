package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CommonTest {

    @Test
    void common_emptyLists_returnsEmptyList() {
        List<Integer> l1 = new ArrayList<>();
        List<Object> l2 = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1Empty_returnsEmptyList() {
        List<Integer> l1 = new ArrayList<>();
        List<Object> l2 = Arrays.asList(1, 2, 3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l2Empty_returnsEmptyList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_noCommonElements_returnsEmptyList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(4, 5, 6);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_oneCommonElement_returnsListWithOneElement() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(3, 4, 5);
        List<Object> expected = Arrays.asList(3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_multipleCommonElements_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> l2 = Arrays.asList(3, 5, 1, 6, 2);
        List<Object> expected = Arrays.asList(1, 2, 3, 5);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_duplicateElementsInL1_returnsUniqueCommonElements() {
        List<Integer> l1 = Arrays.asList(1, 2, 2, 3, 4, 4, 5);
        List<Object> l2 = Arrays.asList(2, 4, 5, 6);
        List<Object> expected = Arrays.asList(2, 4, 5);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_duplicateElementsInL2_returnsUniqueCommonElements() {
        List<Integer> l1 = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> l2 = Arrays.asList(2, 2, 4, 4, 5, 5);
        List<Object> expected = Arrays.asList(2, 4, 5);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l2ContainsNonInteger_ignoresNonInteger() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(2, "hello", 3.14, 3);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1AndL2SameElementsDifferentOrder_returnsSortedList() {
        List<Integer> l1 = Arrays.asList(5, 2, 1, 4, 3);
        List<Object> l2 = Arrays.asList(3, 4, 1, 2, 5);
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1ContainsNegativeNumbers_returnsCorrectList() {
        List<Integer> l1 = Arrays.asList(-1, -2, 0, 1, 2);
        List<Object> l2 = Arrays.asList(-2, 0, 2, 3);
        List<Object> expected = Arrays.asList(-2, 0, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l2ContainsNegativeNumbers_returnsCorrectList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(-1, -2, 1, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1ContainsZero_returnsCorrectList() {
        List<Integer> l1 = Arrays.asList(0, 1, 2);
        List<Object> l2 = Arrays.asList(0, 2, 3);
        List<Object> expected = Arrays.asList(0, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l2ContainsZero_returnsCorrectList() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(0, 1, 2);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_largeListsWithCommonElements_returnsCorrectList() {
        List<Integer> l1 = new ArrayList<>();
        List<Object> l2 = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            l1.add(i);
            l2.add(i);
        }
        List<Object> expected = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            expected.add(i);
        }
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l2ContainsNull_ignoresNull() {
        List<Integer> l1 = Arrays.asList(1, 2, 3);
        List<Object> l2 = Arrays.asList(1, null, 2);
        List<Object> expected = Arrays.asList(1, 2);
    }

    @Test
    void common_l1AndL2ContainSameElementMultipleTimes_returnsElementOnce() {
        List<Integer> l1 = Arrays.asList(1, 1, 2, 2, 3, 3);
        List<Object> l2 = Arrays.asList(1, 1, 2, 2, 3, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1AndL2ContainSameElementMultipleTimesDifferentOrder_returnsElementOnce() {
        List<Integer> l1 = Arrays.asList(3, 2, 1, 3, 2, 1);
        List<Object> l2 = Arrays.asList(1, 2, 3, 1, 2, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1AndL2ContainSameElementMultipleTimesWithOtherElements_returnsCorrectList() {
        List<Integer> l1 = Arrays.asList(1, 1, 2, 2, 3, 3, 4, 5);
        List<Object> l2 = Arrays.asList(1, 1, 2, 2, 3, 3, 6, 7);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }

    @Test
    void common_l1AndL2ContainSameElementMultipleTimesWithOtherElementsDifferentOrder_returnsCorrectList() {
        List<Integer> l1 = Arrays.asList(5, 4, 3, 3, 2, 2, 1, 1);
        List<Object> l2 = Arrays.asList(7, 6, 3, 3, 2, 2, 1, 1);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Common.common(l1, l2));
    }
}