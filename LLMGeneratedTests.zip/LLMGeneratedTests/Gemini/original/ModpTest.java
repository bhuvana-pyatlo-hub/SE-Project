package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ModpTest {

    @Test
    void modp_n3_p5() {
        assertEquals(3, Modp.modp(3, 5));
    }

    @Test
    void modp_n1101_p101() {
        assertEquals(2, Modp.modp(1101, 101));
    }

    @Test
    void modp_n0_p101() {
        assertEquals(1, Modp.modp(0, 101));
    }

    @Test
    void modp_n3_p11() {
        assertEquals(8, Modp.modp(3, 11));
    }

    @Test
    void modp_n100_p101() {
        assertEquals(1, Modp.modp(100, 101));
    }

    @Test
    void modp_n30_p5() {
        assertEquals(4, Modp.modp(30, 5));
    }

    @Test
    void modp_n31_p5() {
        assertEquals(3, Modp.modp(31, 5));
    }

    @Test
    void modp_n1_p2() {
        assertEquals(0, Modp.modp(1, 2));
    }

    @Test
    void modp_n2_p3() {
        assertEquals(1, Modp.modp(2, 3));
    }

    @Test
    void modp_n5_p7() {
        assertEquals(4, Modp.modp(5, 7));
    }

    @Test
    void modp_n10_p13() {
        assertEquals(12, Modp.modp(10, 13));
    }

    @Test
    void modp_n15_p17() {
        assertEquals(16, Modp.modp(15, 17));
    }

    @Test
    void modp_n20_p23() {
        assertEquals(1, Modp.modp(20, 23));
    }

    @Test
    void modp_n25_p29() {
        assertEquals(4, Modp.modp(25, 29));
    }

    @Test
    void modp_n30_p31() {
        assertEquals(1, Modp.modp(30, 31));
    }

    @Test
    void modp_n100_p103() {
        assertEquals(1, Modp.modp(100, 103));
    }

    @Test
    void modp_n10_p11() {
        assertEquals(1024 % 11, Modp.modp(10, 11));
    }

    @Test
    void modp_n50_p53() {
        assertEquals(1048576 % 53, Modp.modp(20, 53));
    }

    @Test
    void modp_n100_p97() {
        assertEquals(1, Modp.modp(100, 97));
    }

    @Test
    void modp_n1_p100() {
        assertEquals(2, Modp.modp(1, 100));
    }

    @Test
    void modp_n2_p100() {
        assertEquals(4, Modp.modp(2, 100));
    }
}