package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AnyIntTest {

    @Test
    void anyInt_validIntegers_xEqualsYPlusZ() {
        assertTrue(AnyInt.anyInt(5, 2, 3));
    }

    @Test
    void anyInt_validIntegers_yEqualsXPlusZ() {
        assertTrue(AnyInt.anyInt(2, 5, 3));
    }

    @Test
    void anyInt_validIntegers_zEqualsXPlusY() {
        assertTrue(AnyInt.anyInt(2, 3, 5));
    }

    @Test
    void anyInt_validIntegers_noSumEqualsOther() {
        assertFalse(AnyInt.anyInt(2, 3, 4));
    }

    @Test
    void anyInt_oneDouble_returnsFalse() {
        assertFalse(AnyInt.anyInt(2.5, 3, 5));
    }

    @Test
    void anyInt_twoDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(2.5, 3.5, 5));
    }

    @Test
    void anyInt_allDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(2.5, 3.5, 5.5));
    }

    @Test
    void anyInt_negativeNumbers_xEqualsYPlusZ() {
        assertTrue(AnyInt.anyInt(-1, 2, -3));
    }

    @Test
    void anyInt_negativeNumbers_yEqualsXPlusZ() {
        assertTrue(AnyInt.anyInt(2, -1, -3));
    }

    @Test
    void anyInt_negativeNumbers_zEqualsXPlusY() {
        assertTrue(AnyInt.anyInt(2, -3, -1));
    }

    @Test
    void anyInt_zeroValues_xEqualsYPlusZ() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_zeroValues_yEqualsXPlusZ() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_zeroValues_zEqualsXPlusY() {
        assertTrue(AnyInt.anyInt(0, 0, 0));
    }

    @Test
    void anyInt_xIsZero_yPlusZEqualsZero() {
        assertTrue(AnyInt.anyInt(0, 2, -2));
    }

    @Test
    void anyInt_yIsZero_xPlusZEqualsZero() {
        assertTrue(AnyInt.anyInt(2, 0, -2));
    }

    @Test
    void anyInt_zIsZero_xPlusYEqualsZero() {
        assertTrue(AnyInt.anyInt(2, -2, 0));
    }

    @Test
    void anyInt_largeIntegers_returnsFalse() {
        assertFalse(AnyInt.anyInt(1001, 2, 3));
    }

    @Test
    void anyInt_boundaryIntegers_returnsTrue() {
        assertTrue(AnyInt.anyInt(10, 5, 5));
    }

    @Test
    void anyInt_sameIntegers_returnsFalse() {
        assertFalse(AnyInt.anyInt(2, 2, 2));
    }

    @Test
    void anyInt_oneIntegerAndTwoDoubles_returnsFalse() {
        assertFalse(AnyInt.anyInt(5, 2.5, 2.5));
    }
}