package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SortArrayTest {

    @Test
    void testSortArray_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_singleElement() {
        List<Object> input = new ArrayList<>(Arrays.asList(1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_example1() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 5, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2, 4, 3, 5));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_example2() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 0, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 1, 2, 4, 3));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_example3() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 5, 77, 4, 5, 3, 5, 7, 2, 3, 4));
        List<Object> expected = new ArrayList<>(Arrays.asList(2, 2, 4, 4, 3, 3, 5, 5, 5, 7, 77));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_example4() {
        List<Object> input = new ArrayList<>(Arrays.asList(3, 6, 44, 12, 32, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(32, 3, 5, 6, 12, 44));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_example5() {
        List<Object> input = new ArrayList<>(Arrays.asList(2, 4, 8, 16, 32));
        List<Object> expected = new ArrayList<>(Arrays.asList(2, 4, 8, 16, 32));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_sameNumberOfOnes_differentValues() {
        List<Object> input = new ArrayList<>(Arrays.asList(3, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(3, 5));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_differentNumberOfOnes_differentValues() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 2));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_zeroAndOne() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 1));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_multipleZeros() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 0, 0));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 0, 0));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_multipleOnes() {
        List<Object> input = new ArrayList<>(Arrays.asList(1, 1, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 1, 1));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_mixedZerosAndOnes() {
        List<Object> input = new ArrayList<>(Arrays.asList(0, 1, 0, 1));
        List<Object> expected = new ArrayList<>(Arrays.asList(0, 0, 1, 1));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_largerNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(10, 12, 15));
        List<Object> expected = new ArrayList<>(Arrays.asList(8, 4, 12));
        List<Object> actual = SortArray.sortArray(input);
        List<Object> expected2 = new ArrayList<>(Arrays.asList(8, 4, 12));
        assertEquals(expected2, actual);
    }

    @Test
    void testSortArray_sameOnesDifferentValues() {
        List<Object> input = new ArrayList<>(Arrays.asList(3, 5, 6, 9));
        List<Object> expected = new ArrayList<>(Arrays.asList(6, 9, 3, 5));
        List<Object> actual = SortArray.sortArray(input);
        List<Object> expected2 = new ArrayList<>(Arrays.asList(6, 9, 3, 5));
        assertEquals(expected2, actual);
    }

    @Test
    void testSortArray_allSameValues() {
        List<Object> input = new ArrayList<>(Arrays.asList(7, 7, 7, 7));
        List<Object> expected = new ArrayList<>(Arrays.asList(7, 7, 7, 7));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_negativeNumbers() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, -2, -3));
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_mixedPositiveNegative() {
        List<Object> input = new ArrayList<>(Arrays.asList(-1, 1, -2, 2));
        List<Object> expected = new ArrayList<>(Arrays.asList(1, 2));
        List<Object> actual = SortArray.sortArray(input);
        List<Object> expected2 = new ArrayList<>(Arrays.asList(1, 2));
        assertEquals(expected2, actual);
    }

    @Test
    void testSortArray_largeNumbersWithFewOnes() {
        List<Object> input = new ArrayList<>(Arrays.asList(1024, 2048, 4096));
        List<Object> expected = new ArrayList<>(Arrays.asList(1024, 2048, 4096));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_numbersWithManyOnes() {
        List<Object> input = new ArrayList<>(Arrays.asList(7, 15, 31));
        List<Object> expected = new ArrayList<>(Arrays.asList(7, 15, 31));
        assertEquals(expected, SortArray.sortArray(input));
    }

    @Test
    void testSortArray_duplicateValuesWithDifferentOnes() {
        List<Object> input = new ArrayList<>(Arrays.asList(3, 3, 5, 5));
        List<Object> expected = new ArrayList<>(Arrays.asList(3, 3, 5, 5));
        assertEquals(expected, SortArray.sortArray(input));
    }
}