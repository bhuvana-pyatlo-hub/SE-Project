package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FilterByPrefixTest {

    @Test
    void testFilterByPrefix_emptyList() {
        List<Object> strings = new ArrayList<>();
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithMatchingAndNonMatchingStrings() {
        List<Object> strings = Arrays.asList("abc", "bcd", "cde", "array");
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc", "array");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_emptyListWithLongPrefix() {
        List<Object> strings = new ArrayList<>();
        String prefix = "john";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithPrefixMultipleMatches() {
        List<Object> strings = Arrays.asList("xxx", "asd", "xxy", "john doe", "xxxAAA", "xxx");
        String prefix = "xxx";
        List<Object> expected = Arrays.asList("xxx", "xxxAAA", "xxx");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixMatchesAll() {
        List<Object> strings = Arrays.asList("aa", "ab", "ac");
        String prefix = "a";
        List<Object> expected = Arrays.asList("aa", "ab", "ac");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixMatchesNone() {
        List<Object> strings = Arrays.asList("bb", "bc", "bd");
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_emptyPrefix() {
        List<Object> strings = Arrays.asList("aa", "bb", "cc");
        String prefix = "";
        List<Object> expected = Arrays.asList("aa", "bb", "cc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixLongerThanString() {
        List<Object> strings = Arrays.asList("a", "b", "c");
        String prefix = "abc";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixEqualsString() {
        List<Object> strings = Arrays.asList("abc", "def", "ghi");
        String prefix = "abc";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixIsSubstring() {
        List<Object> strings = Arrays.asList("abcdef", "defghi", "ghijkl");
        String prefix = "abc";
        List<Object> expected = Arrays.asList("abcdef");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixIsCaseSensitive() {
        List<Object> strings = Arrays.asList("Abc", "abc", "aBC");
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc", "aBC");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithNullString() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithNullAndMatchingString() {
        List<Object> strings = new ArrayList<>();
        strings.add(null);
        strings.add("abc");
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithIntegerObjects() {
        List<Object> strings = Arrays.asList(123, 456, 789, 12);
        String prefix = "1";
        List<Object> expected = Arrays.asList(123, 12);
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithMixedObjects() {
        List<Object> strings = Arrays.asList("abc", 123, "array", 45);
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc", "array");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithEmptyString() {
        List<Object> strings = Arrays.asList("", "abc", "def");
        String prefix = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithEmptyStringAndEmptyPrefix() {
        List<Object> strings = Arrays.asList("", "abc", "def");
        String prefix = "";
        List<Object> expected = Arrays.asList("", "abc", "def");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithOnlyEmptyStringAndEmptyPrefix() {
        List<Object> strings = Arrays.asList("");
        String prefix = "";
        List<Object> expected = Arrays.asList("");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_listWithOnlyEmptyStringAndPrefix() {
        List<Object> strings = Arrays.asList("");
        String prefix = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }

    @Test
    void testFilterByPrefix_prefixWithSpecialCharacters() {
        List<Object> strings = Arrays.asList("a!bc", "a@bc", "a#bc");
        String prefix = "a!";
        List<Object> expected = Arrays.asList("a!bc");
        assertEquals(expected, FilterByPrefix.filterByPrefix(strings, prefix));
    }
}