package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsPalindromeTest {

    @Test
    void testEmptyString() {
        assertTrue(IsPalindrome.isPalindrome(""));
    }

    @Test
    void testSingleCharacterString() {
        assertTrue(IsPalindrome.isPalindrome("a"));
    }

    @Test
    void testSimplePalindrome() {
        assertTrue(IsPalindrome.isPalindrome("aba"));
    }

    @Test
    void testLongerPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("level"));
    }

    @Test
    void testAnotherLongerPalindrome() {
        assertTrue(IsPalindrome.isPalindrome("rotor"));
    }

    @Test
    void testNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("abc"));
    }

    @Test
    void testAlmostPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("abda"));
    }

    @Test
    void testPalindromeWithEvenLength() {
        assertTrue(IsPalindrome.isPalindrome("abba"));
    }

    @Test
    void testNonPalindromeWithEvenLength() {
        assertFalse(IsPalindrome.isPalindrome("abcd"));
    }

    @Test
    void testPalindromeWithMixedCharacters() {
        assertTrue(IsPalindrome.isPalindrome("madam"));
    }

    @Test
    void testNonPalindromeWithSimilarCharacters() {
        assertFalse(IsPalindrome.isPalindrome("abbc"));
    }

    @Test
    void testPalindromeWithRepeatingCharacters() {
        assertTrue(IsPalindrome.isPalindrome("aaaaa"));
    }

    @Test
    void testNonPalindromeWithRepeatingCharacters() {
        assertFalse(IsPalindrome.isPalindrome("aaab"));
    }

    @Test
    void testPalindromeWithDifferentCase() {
        assertFalse(IsPalindrome.isPalindrome("Aba"));
    }

    @Test
    void testPalindromeWithSpaces() {
        assertFalse(IsPalindrome.isPalindrome("race car"));
    }

    @Test
    void testNonPalindromeNearBoundary() {
        assertFalse(IsPalindrome.isPalindrome("xywyz"));
    }

    @Test
    void testPalindromeNearBoundary() {
        assertTrue(IsPalindrome.isPalindrome("xywyx"));
    }

    @Test
    void testPalindromeLengthTwo() {
        assertTrue(IsPalindrome.isPalindrome("aa"));
    }

    @Test
    void testNonPalindromeLengthTwo() {
        assertFalse(IsPalindrome.isPalindrome("ab"));
    }

    @Test
    void testLongNonPalindrome() {
        assertFalse(IsPalindrome.isPalindrome("abcdefgh"));
    }
}