package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SortNumbersTest {

    @Test
    void sortNumbers_emptyString() {
        assertEquals("", SortNumbers.sortNumbers(""));
    }

    @Test
    void sortNumbers_singleNumber() {
        assertEquals("three", SortNumbers.sortNumbers("three"));
    }

    @Test
    void sortNumbers_alreadySorted() {
        assertEquals("three five nine", SortNumbers.sortNumbers("three five nine"));
    }

    @Test
    void sortNumbers_unsorted() {
        assertEquals("zero four five seven eight nine", SortNumbers.sortNumbers("five zero four seven nine eight"));
    }

    @Test
    void sortNumbers_reverseSorted() {
        assertEquals("zero one two three four five six", SortNumbers.sortNumbers("six five four three two one zero"));
    }

    @Test
    void sortNumbers_duplicateNumbers() {
        assertEquals("one one three three", SortNumbers.sortNumbers("three one three one"));
    }

    @Test
    void sortNumbers_allSameNumber() {
        assertEquals("five five five", SortNumbers.sortNumbers("five five five"));
    }

    @Test
    void sortNumbers_zeroToNine() {
        assertEquals("zero one two three four five six seven eight nine", SortNumbers.sortNumbers("nine eight seven six five four three two one zero"));
    }

    @Test
    void sortNumbers_one() {
        assertEquals("one", SortNumbers.sortNumbers("one"));
    }

    @Test
    void sortNumbers_two() {
        assertEquals("two", SortNumbers.sortNumbers("two"));
    }

    @Test
    void sortNumbers_three() {
        assertEquals("three", SortNumbers.sortNumbers("three"));
    }

    @Test
    void sortNumbers_four() {
        assertEquals("four", SortNumbers.sortNumbers("four"));
    }

    @Test
    void sortNumbers_five() {
        assertEquals("five", SortNumbers.sortNumbers("five"));
    }

    @Test
    void sortNumbers_six() {
        assertEquals("six", SortNumbers.sortNumbers("six"));
    }

    @Test
    void sortNumbers_seven() {
        assertEquals("seven", SortNumbers.sortNumbers("seven"));
    }

    @Test
    void sortNumbers_eight() {
        assertEquals("eight", SortNumbers.sortNumbers("eight"));
    }

    @Test
    void sortNumbers_nine() {
        assertEquals("nine", SortNumbers.sortNumbers("nine"));
    }

    @Test
    void sortNumbers_zero() {
        assertEquals("zero", SortNumbers.sortNumbers("zero"));
    }

    @Test
    void sortNumbers_invalidInput() {
        assertEquals("", SortNumbers.sortNumbers("invalid"));
    }

    @Test
    void sortNumbers_mixedValidAndInvalid() {
        assertEquals("five", SortNumbers.sortNumbers("five invalid"));
    }

    @Test
    void sortNumbers_multipleInvalid() {
        assertEquals("", SortNumbers.sortNumbers("invalid1 invalid2"));
    }

    @Test
    void sortNumbers_leadingAndTrailingSpaces() {
        assertEquals("one two", SortNumbers.sortNumbers(" one two "));
    }

    @Test
    void sortNumbers_multipleSpacesBetweenNumbers() {
        assertEquals("one two", SortNumbers.sortNumbers("one   two"));
    }
}