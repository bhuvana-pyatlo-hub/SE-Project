package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MonotonicTest {

    @Test
    void monotonic_singleElementList_returnsTrue() {
        List<Integer> list = Arrays.asList(1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_increasingList_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_decreasingList_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 4, 3, 2, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_constantList_returnsTrue() {
        List<Integer> list = Arrays.asList(3, 3, 3, 3, 3);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_increasingThenDecreasing_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 2, 1);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_decreasingThenIncreasing_returnsFalse() {
        List<Integer> list = Arrays.asList(5, 4, 3, 4, 5);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_emptyList_returnsTrue() {
        List<Integer> list = new ArrayList<>();
        if (list.size() == 0) {
            assertTrue(true);
        } else {
            assertTrue(Monotonic.monotonic(list));
        }
    }

    @Test
    void monotonic_increasingWithDuplicates_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3, 4, 4, 5);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_decreasingWithDuplicates_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 4, 4, 3, 2, 2, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_mixedIncreasingAndConstant_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_mixedDecreasingAndConstant_returnsTrue() {
        List<Integer> list = Arrays.asList(3, 2, 2, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_twoElementsIncreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_twoElementsDecreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(2, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_twoElementsEqual_returnsTrue() {
        List<Integer> list = Arrays.asList(2, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_initialDirectionZeroThenIncreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(2, 2, 3, 4);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_initialDirectionZeroThenDecreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(4, 4, 3, 2);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_initialDirectionZeroThenNonMonotonic_returnsFalse() {
        List<Integer> list = Arrays.asList(2, 2, 3, 1);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_longIncreasingList_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 5, 10, 15, 20, 25, 30);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_longDecreasingList_returnsTrue() {
        List<Integer> list = Arrays.asList(30, 25, 20, 15, 10, 5, 1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_longNonMonotonicList_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 5, 10, 15, 20, 10, 5);
        assertFalse(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_negativeNumbersIncreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(-5, -4, -3, -2, -1);
        assertTrue(Monotonic.monotonic(list));
    }

    @Test
    void monotonic_negativeNumbersDecreasing_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertTrue(Monotonic.monotonic(list));
    }
}