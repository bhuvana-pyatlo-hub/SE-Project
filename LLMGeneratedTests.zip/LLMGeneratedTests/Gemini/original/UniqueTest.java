package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class UniqueTest {

    @Test
    void testUnique_emptyList() {
        List<Integer> input = Collections.emptyList();
        List<Integer> expected = Collections.emptyList();
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_singleElementList() {
        List<Integer> input = Collections.singletonList(5);
        List<Integer> expected = Collections.singletonList(5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_multipleUniqueElements() {
        List<Integer> input = Arrays.asList(5, 3, 2, 9, 0, 123);
        List<Integer> expected = Arrays.asList(0, 2, 3, 5, 9, 123);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_duplicateElements() {
        List<Integer> input = Arrays.asList(5, 3, 5, 2, 3, 3, 9, 0, 123);
        List<Integer> expected = Arrays.asList(0, 2, 3, 5, 9, 123);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_allSameElements() {
        List<Integer> input = Arrays.asList(5, 5, 5, 5, 5);
        List<Integer> expected = Collections.singletonList(5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_negativeNumbers() {
        List<Integer> input = Arrays.asList(-5, -3, -2, -9, 0, 123);
        List<Integer> expected = Arrays.asList(-9, -5, -3, -2, 0, 123);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_mixedPositiveNegativeZero() {
        List<Integer> input = Arrays.asList(-5, 3, 0, -2, 5, 0);
        List<Integer> expected = Arrays.asList(-5, -2, 0, 3, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_alreadySortedList() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_reverseSortedList() {
        List<Integer> input = Arrays.asList(5, 4, 3, 2, 1);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithZero() {
        List<Integer> input = Arrays.asList(5, 0, 3, 0, 2);
        List<Integer> expected = Arrays.asList(0, 2, 3, 5);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_largeListWithDuplicates() {
        List<Integer> input = Arrays.asList(1, 2, 3, 1, 2, 3, 4, 5, 6, 4, 5, 6, 7, 8, 9, 7, 8, 9);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithLargeNumbers() {
        List<Integer> input = Arrays.asList(100, 200, 300, 100, 200, 300);
        List<Integer> expected = Arrays.asList(100, 200, 300);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithSmallNumbers() {
        List<Integer> input = Arrays.asList(1, 2, 3, 1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithMixedSmallAndLargeNumbers() {
        List<Integer> input = Arrays.asList(1, 100, 2, 200, 3, 300);
        List<Integer> expected = Arrays.asList(1, 2, 3, 100, 200, 300);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithZeroAndOne() {
        List<Integer> input = Arrays.asList(0, 1, 0, 1, 0, 1);
        List<Integer> expected = Arrays.asList(0, 1);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithConsecutiveDuplicates() {
        List<Integer> input = Arrays.asList(1, 1, 2, 2, 3, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithScatteredDuplicates() {
        List<Integer> input = Arrays.asList(1, 2, 1, 3, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithManyDuplicates() {
        List<Integer> input = Arrays.asList(1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithAllZeros() {
        List<Integer> input = Arrays.asList(0, 0, 0, 0, 0);
        List<Integer> expected = Collections.singletonList(0);
        assertEquals(expected, Unique.unique(input));
    }

    @Test
    void testUnique_listWithOneNegativeNumber() {
        List<Integer> input = Arrays.asList(1, 2, -3, 4, 5);
        List<Integer> expected = Arrays.asList(-3, 1, 2, 4, 5);
        assertEquals(expected, Unique.unique(input));
    }
}