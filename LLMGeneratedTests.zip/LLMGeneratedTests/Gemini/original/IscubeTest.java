package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IscubeTest {

    @Test
    void testIsCube_positiveCube() {
        assertTrue(Iscube.iscube(8));
    }

    @Test
    void testIsCube_negativeCube() {
        assertTrue(Iscube.iscube(-8));
    }

    @Test
    void testIsCube_zero() {
        assertTrue(Iscube.iscube(0));
    }

    @Test
    void testIsCube_one() {
        assertTrue(Iscube.iscube(1));
    }

    @Test
    void testIsCube_negativeOne() {
        assertTrue(Iscube.iscube(-1));
    }

    @Test
    void testIsCube_positiveNonCube() {
        assertFalse(Iscube.iscube(7));
    }

    @Test
    void testIsCube_negativeNonCube() {
        assertFalse(Iscube.iscube(-7));
    }

    @Test
    void testIsCube_largePositiveCube() {
        assertTrue(Iscube.iscube(1000));
    }

    @Test
    void testIsCube_largeNegativeCube() {
        assertTrue(Iscube.iscube(-1000));
    }

    @Test
    void testIsCube_largePositiveNonCube() {
        assertFalse(Iscube.iscube(999));
    }

    @Test
    void testIsCube_largeNegativeNonCube() {
        assertFalse(Iscube.iscube(-999));
    }

    @Test
    void testIsCube_smallPositiveCube() {
        assertTrue(Iscube.iscube(27));
    }

    @Test
    void testIsCube_smallNegativeCube() {
        assertTrue(Iscube.iscube(-27));
    }

    @Test
    void testIsCube_smallPositiveNonCube() {
        assertFalse(Iscube.iscube(26));
    }

    @Test
    void testIsCube_smallNegativeNonCube() {
        assertFalse(Iscube.iscube(-26));
    }

    @Test
    void testIsCube_boundaryPositiveCube() {
        assertTrue(Iscube.iscube(64));
    }

    @Test
    void testIsCube_boundaryNegativeCube() {
        assertTrue(Iscube.iscube(-64));
    }

    @Test
    void testIsCube_boundaryPositiveNonCube() {
        assertFalse(Iscube.iscube(63));
    }

    @Test
    void testIsCube_boundaryNegativeNonCube() {
        assertFalse(Iscube.iscube(-63));
    }

    @Test
    void testIsCube_nonCubeValue() {
        assertFalse(Iscube.iscube(180));
    }

    @Test
    void testIsCube_anotherNonCubeValue() {
        assertFalse(Iscube.iscube(1729));
    }
}