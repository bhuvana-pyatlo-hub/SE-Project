package original;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CompareOneTest {

    @Test
    void compareOne_integerAndFloat_returnsFloat() {
        assertEquals(2.5f, CompareOne.compareOne(1, 2.5f));
    }

    @Test
    void compareOne_integerAndString_returnsString() {
        assertEquals("2,3", CompareOne.compareOne(1, "2,3"));
    }

    @Test
    void compareOne_stringAndString_returnsString() {
        assertEquals("6", CompareOne.compareOne("5,1", "6"));
    }

    @Test
    void compareOne_stringAndInteger_returnsNull() {
        assertNull(CompareOne.compareOne("1", 1));
    }

    @Test
    void compareOne_integers_returnsLargerInteger() {
        assertEquals(2, CompareOne.compareOne(1, 2));
    }

    @Test
    void compareOne_integers_returnsLargerInteger2() {
        assertEquals(3, CompareOne.compareOne(2, 3));
    }

    @Test
    void compareOne_integers_returnsLargerInteger3() {
        assertEquals(6, CompareOne.compareOne(5, 6));
    }

    @Test
    void compareOne_strings_returnsLargerString() {
        assertEquals("2", CompareOne.compareOne("1", "2"));
    }

    @Test
    void compareOne_equalIntegers_returnsNull() {
        assertNull(CompareOne.compareOne(1, 1));
    }

    @Test
    void compareOne_equalFloats_returnsNull() {
        assertNull(CompareOne.compareOne(1.5f, 1.5f));
    }

    @Test
    void compareOne_equalStrings_returnsNull() {
        assertNull(CompareOne.compareOne("1", "1"));
    }

    @Test
    void compareOne_floatAndInteger_returnsFloat() {
        assertEquals(2.5f, CompareOne.compareOne(2.5f, 1));
    }

    @Test
    void compareOne_floatAndString_returnsString() {
        assertEquals("2,3", CompareOne.compareOne(1.0f, "2,3"));
    }

    @Test
    void compareOne_stringAndFloat_returnsString() {
        assertEquals("5,1", CompareOne.compareOne("5,1", 1.0f));
    }

    @Test
    void compareOne_stringWithCommaAndInteger_returnsString() {
        assertEquals("2,3", CompareOne.compareOne("1,2", 2));
    }

    @Test
    void compareOne_integerAndStringWithComma_returnsString() {
        assertEquals("2,3", CompareOne.compareOne(1, "2,3"));
    }

    @Test
    void compareOne_negativeIntegers_returnsLarger() {
        assertEquals(-1, CompareOne.compareOne(-2, -1));
    }

    @Test
    void compareOne_negativeAndPositive_returnsPositive() {
        assertEquals(1, CompareOne.compareOne(-1, 1));
    }

    @Test
    void compareOne_zeroAndPositive_returnsPositive() {
        assertEquals(1, CompareOne.compareOne(0, 1));
    }

    @Test
    void compareOne_zeroAndNegative_returnsZero() {
        assertEquals(0, CompareOne.compareOne(0, -1));
    }

    @Test
    void compareOne_largeNumbers_returnsLarger() {
        assertEquals(1000, CompareOne.compareOne(999, 1000));
    }

    @Test
    void compareOne_smallDecimals_returnsLarger() {
        assertEquals(0.2f, CompareOne.compareOne(0.1f, 0.2f));
    }

    @Test
    void compareOne_stringWithDotAndInteger_returnsString() {
        assertEquals("2.3", CompareOne.compareOne("1.2", 2));
    }

    @Test
    void compareOne_integerAndStringWithDot_returnsString() {
        assertEquals("2.3", CompareOne.compareOne(1, "2.3"));
    }
}