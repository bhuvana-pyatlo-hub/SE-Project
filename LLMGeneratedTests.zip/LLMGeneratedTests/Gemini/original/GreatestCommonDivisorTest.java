package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GreatestCommonDivisorTest {

    @Test
    void testGreatestCommonDivisor_aIsZero() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(0, 5));
    }

    @Test
    void testGreatestCommonDivisor_bIsZero() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(5, 0));
    }

    @Test
    void testGreatestCommonDivisor_bothAreZero() {
        assertEquals(0, GreatestCommonDivisor.greatestCommonDivisor(0, 0));
    }

    @Test
    void testGreatestCommonDivisor_aAndBArePositiveAndHaveCommonDivisor() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(25, 15));
    }

    @Test
    void testGreatestCommonDivisor_aAndBArePositiveAndHaveNoCommonDivisor() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(3, 5));
    }

    @Test
    void testGreatestCommonDivisor_aIsMultipleOfB() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(10, 5));
    }

    @Test
    void testGreatestCommonDivisor_bIsMultipleOfA() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(5, 10));
    }

    @Test
    void testGreatestCommonDivisor_aAndBAreSame() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(5, 5));
    }

    @Test
    void testGreatestCommonDivisor_aIsOne() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(1, 10));
    }

    @Test
    void testGreatestCommonDivisor_bIsOne() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(10, 1));
    }

    @Test
    void testGreatestCommonDivisor_aIsNegativeAndBIsPositive() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(-25, 15));
    }

    @Test
    void testGreatestCommonDivisor_aIsPositiveAndBIsNegative() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(25, -15));
    }

    @Test
    void testGreatestCommonDivisor_aAndBAreNegative() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(-25, -15));
    }

    @Test
    void testGreatestCommonDivisor_largeValuesWithCommonDivisor() {
        assertEquals(12, GreatestCommonDivisor.greatestCommonDivisor(144, 60));
    }

    @Test
    void testGreatestCommonDivisor_largeValuesWithNoCommonDivisor() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(101, 103));
    }

    @Test
    void testGreatestCommonDivisor_boundaryValues() {
        assertEquals(7, GreatestCommonDivisor.greatestCommonDivisor(49, 14));
    }

    @Test
    void testGreatestCommonDivisor_edgeCase1() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(2, 3));
    }

    @Test
    void testGreatestCommonDivisor_edgeCase2() {
        assertEquals(5, GreatestCommonDivisor.greatestCommonDivisor(10, 15));
    }

    @Test
    void testGreatestCommonDivisor_smallValues() {
        assertEquals(1, GreatestCommonDivisor.greatestCommonDivisor(3, 7));
    }

    @Test
    void testGreatestCommonDivisor_oneValueIsZero() {
        assertEquals(10, GreatestCommonDivisor.greatestCommonDivisor(10, 0));
    }
}