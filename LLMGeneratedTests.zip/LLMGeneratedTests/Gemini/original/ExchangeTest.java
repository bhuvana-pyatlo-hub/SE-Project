package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExchangeTest {

    @Test
    void exchange_allEvenLst1_returnsYes() {
        List<Integer> lst1 = Arrays.asList(2, 4, 6, 8);
        List<Integer> lst2 = Arrays.asList(1, 3, 5, 7);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_allOddLst1_sufficientEvenLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5, 7);
        List<Integer> lst2 = Arrays.asList(2, 4, 6, 8);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_mixedLst1_sufficientEvenLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4);
        List<Integer> lst2 = Arrays.asList(2, 4, 6, 8);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_mixedLst1_insufficientEvenLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4);
        List<Integer> lst2 = Arrays.asList(1, 3, 5, 7);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_emptyLst2_returnsNoIfLst1HasOdd() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4);
        List<Integer> lst2 = Collections.emptyList();
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_emptyLst2_returnsYesIfLst1HasOnlyEven() {
        List<Integer> lst1 = Arrays.asList(2, 4, 6, 8);
        List<Integer> lst2 = Collections.emptyList();
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_emptyLst1_returnsYes() {
        List<Integer> lst1 = Collections.emptyList();
        List<Integer> lst2 = Arrays.asList(1, 2, 3, 4);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_bothListsEmpty_returnsYes() {
        List<Integer> lst1 = Collections.emptyList();
        List<Integer> lst2 = Collections.emptyList();
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleOddInLst1_singleEvenInLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1);
        List<Integer> lst2 = Arrays.asList(2);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleOddInLst1_noEvenInLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1);
        List<Integer> lst2 = Arrays.asList(1);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_singleEvenInLst1_returnsYes() {
        List<Integer> lst1 = Arrays.asList(2);
        List<Integer> lst2 = Arrays.asList(1);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_multipleOddInLst1_sufficientEvenInLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5);
        List<Integer> lst2 = Arrays.asList(2, 4, 6);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_multipleOddInLst1_insufficientEvenInLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5);
        List<Integer> lst2 = Arrays.asList(2, 4, 1);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_largeLst1_sufficientEvenLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5, 7, 9, 11, 13, 15, 17, 19);
        List<Integer> lst2 = Arrays.asList(2, 4, 6, 8, 10, 12, 14, 16, 18, 20);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_largeLst1_insufficientEvenLst2_returnsNo() {
        List<Integer> lst1 = Arrays.asList(1, 3, 5, 7, 9, 11, 13, 15, 17, 19);
        List<Integer> lst2 = Arrays.asList(2, 4, 6, 8, 10, 12, 14, 16, 18, 1);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_zeroInLst1_returnsYes() {
        List<Integer> lst1 = Arrays.asList(0, 1, 3);
        List<Integer> lst2 = Arrays.asList(2, 4);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_zeroInLst2_returnsYes() {
        List<Integer> lst1 = Arrays.asList(1, 3);
        List<Integer> lst2 = Arrays.asList(0, 2, 4);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_negativeNumbers_returnsCorrectResult() {
        List<Integer> lst1 = Arrays.asList(-1, 2, 3);
        List<Integer> lst2 = Arrays.asList(4, -2);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_negativeAndPositiveNumbers_returnsCorrectResult() {
        List<Integer> lst1 = Arrays.asList(-1, 2, 3);
        List<Integer> lst2 = Arrays.asList(1, -2);
        assertEquals("NO", Exchange.exchange(lst1, lst2));
    }

    @Test
    void exchange_equalNumberOfOddAndEven_returnsYesIfSufficientEvens() {
        List<Integer> lst1 = Arrays.asList(1, 2, 3, 4);
        List<Integer> lst2 = Arrays.asList(2, 4, 5, 7);
        assertEquals("YES", Exchange.exchange(lst1, lst2));
    }
}