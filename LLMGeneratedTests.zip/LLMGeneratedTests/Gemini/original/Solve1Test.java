package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Solve1Test {

    @Test
    void solve_N_is_1000_returns_1() {
        assertEquals("1", Solve1.solve(1000));
    }

    @Test
    void solve_N_is_150_returns_110() {
        assertEquals("110", Solve1.solve(150));
    }

    @Test
    void solve_N_is_147_returns_1100() {
        assertEquals("1100", Solve1.solve(147));
    }

    @Test
    void solve_N_is_333_returns_1001() {
        assertEquals("1001", Solve1.solve(333));
    }

    @Test
    void solve_N_is_963_returns_10010() {
        assertEquals("10010", Solve1.solve(963));
    }

    @Test
    void solve_N_is_0_returns_0() {
        assertEquals("0", Solve1.solve(0));
    }

    @Test
    void solve_N_is_1_returns_1() {
        assertEquals("1", Solve1.solve(1));
    }

    @Test
    void solve_N_is_9_returns_1001() {
        assertEquals("1001", Solve1.solve(9));
    }

    @Test
    void solve_N_is_10_returns_1() {
        assertEquals("1", Solve1.solve(10));
    }

    @Test
    void solve_N_is_99_returns_10010() {
        assertEquals("10010", Solve1.solve(99));
    }

    @Test
    void solve_N_is_111_returns_11() {
        assertEquals("11", Solve1.solve(111));
    }

    @Test
    void solve_N_is_222_returns_110() {
        assertEquals("110", Solve1.solve(222));
    }

    @Test
    void solve1_N_is_333_returns_1001() {
        assertEquals("1001", Solve1.solve(333));
    }

    @Test
    void solve_N_is_444_returns_1100() {
        assertEquals("1100", Solve1.solve(444));
    }

    @Test
    void solve_N_is_555_returns_1111() {
        assertEquals("1111", Solve1.solve(555));
    }

    @Test
    void solve_N_is_666_returns_10010() {
        assertEquals("10010", Solve1.solve(666));
    }

    @Test
    void solve_N_is_777_returns_10101() {
        assertEquals("10101", Solve1.solve(777));
    }

    @Test
    void solve_N_is_888_returns_11000() {
        assertEquals("11000", Solve1.solve(888));
    }

    @Test
    void solve_N_is_999_returns_11011() {
        assertEquals("11011", Solve1.solve(999));
    }

    @Test
    void solve_N_is_1234_returns_1010() {
        assertEquals("1010", Solve1.solve(1234));
    }

    @Test
    void solve_N_is_5678_returns_110010() {
        assertEquals("110010", Solve1.solve(5678));
    }
}