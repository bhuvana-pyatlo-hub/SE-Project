package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FlipCaseTest {

    @Test
    void testFlipCase_emptyString() {
        assertEquals("", FlipCase.flipCase(""));
    }

    @Test
    void testFlipCase_singleLowercase() {
        assertEquals("A", FlipCase.flipCase("a"));
    }

    @Test
    void testFlipCase_singleUppercase() {
        assertEquals("a", FlipCase.flipCase("A"));
    }

    @Test
    void testFlipCase_mixedCase() {
        assertEquals("hELLO", FlipCase.flipCase("Hello"));
    }

    @Test
    void testFlipCase_withSpecialCharacters() {
        assertEquals("hELLO!", FlipCase.flipCase("Hello!"));
    }

    @Test
    void testFlipCase_withSpaces() {
        assertEquals("tHESE VIOLENT DELIGHTS HAVE VIOLENT ENDS", FlipCase.flipCase("These violent delights have violent ends"));
    }

    @Test
    void testFlipCase_allLowercase() {
        assertEquals("HELLO", FlipCase.flipCase("hello"));
    }

    @Test
    void testFlipCase_allUppercase() {
        assertEquals("hello", FlipCase.flipCase("HELLO"));
    }

    @Test
    void testFlipCase_numbersAndLetters() {
        assertEquals("123aBC", FlipCase.flipCase("123Abc"));
    }

    @Test
    void testFlipCase_specialCharactersOnly() {
        assertEquals("!@#$", FlipCase.flipCase("!@#$"));
    }

    @Test
    void testFlipCase_mixedCaseAndNumbers() {
        assertEquals("1a2B3c", FlipCase.flipCase("1A2b3C"));
    }

    @Test
    void testFlipCase_longString() {
        String input = "The Quick Brown Fox Jumps Over The Lazy Dog";
        String expected = "tHE qUICK bROWN fOX jUMPS oVER tHE lAZY dOG";
        assertEquals(expected, FlipCase.flipCase(input));
    }

    @Test
    void testFlipCase_stringWithUnicode() {
        assertEquals("你好世界", FlipCase.flipCase("你好世界"));
    }

    @Test
    void testFlipCase_stringWithMixedUnicodeAndAscii() {
        assertEquals("hELLO你好WORLD", FlipCase.flipCase("Hello你好world"));
    }

    @Test
    void testFlipCase_stringWithLeadingAndTrailingSpaces() {
        assertEquals("  hELLO  ", FlipCase.flipCase("  Hello  "));
    }

    @Test
    void testFlipCase_stringWithInternalMultipleSpaces() {
        assertEquals("hELLO  wORLD", FlipCase.flipCase("Hello  World"));
    }

    @Test
    void testFlipCase_stringWithTabs() {
        assertEquals("hELLO\tWORLD", FlipCase.flipCase("Hello\tworld"));
    }

    @Test
    void testFlipCase_stringWithNewlines() {
        assertEquals("hELLO\nWOrld", FlipCase.flipCase("Hello\nwORLD"));
    }

    @Test
    void testFlipCase_stringWithEmptyWords() {
        assertEquals("  a  B  ", FlipCase.flipCase("  A  b  "));
    }

    @Test
    void testFlipCase_stringWithOnlySpaces() {
        assertEquals("   ", FlipCase.flipCase("   "));
    }
}