package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FactorizeTest {

    @Test
    void factorize_8() {
        assertEquals(Arrays.asList(2, 2, 2), Factorize.factorize(8));
    }

    @Test
    void factorize_25() {
        assertEquals(Arrays.asList(5, 5), Factorize.factorize(25));
    }

    @Test
    void factorize_70() {
        assertEquals(Arrays.asList(2, 5, 7), Factorize.factorize(70));
    }

    @Test
    void factorize_2() {
        assertEquals(Collections.singletonList(2), Factorize.factorize(2));
    }

    @Test
    void factorize_4() {
        assertEquals(Arrays.asList(2, 2), Factorize.factorize(4));
    }

    @Test
    void factorize_57() {
        assertEquals(Arrays.asList(3, 19), Factorize.factorize(57));
    }

    @Test
    void factorize_3249() {
        assertEquals(Arrays.asList(3, 3, 19, 19), Factorize.factorize(3249));
    }

    @Test
    void factorize_185193() {
        assertEquals(Arrays.asList(3, 3, 3, 19, 19, 19), Factorize.factorize(185193));
    }

    @Test
    void factorize_20577() {
        assertEquals(Arrays.asList(3, 19, 19, 19), Factorize.factorize(20577));
    }

    @Test
    void factorize_18() {
        assertEquals(Arrays.asList(2, 3, 3), Factorize.factorize(18));
    }

    @Test
    void factorize_1() {
        assertEquals(Collections.emptyList(), Factorize.factorize(1));
    }

    @Test
    void factorize_3() {
        assertEquals(Collections.singletonList(3), Factorize.factorize(3));
    }

    @Test
    void factorize_5() {
        assertEquals(Collections.singletonList(5), Factorize.factorize(5));
    }

    @Test
    void factorize_6() {
        assertEquals(Arrays.asList(2, 3), Factorize.factorize(6));
    }

    @Test
    void factorize_9() {
        assertEquals(Arrays.asList(3, 3), Factorize.factorize(9));
    }

    @Test
    void factorize_10() {
        assertEquals(Arrays.asList(2, 5), Factorize.factorize(10));
    }

    @Test
    void factorize_12() {
        assertEquals(Arrays.asList(2, 2, 3), Factorize.factorize(12));
    }

    @Test
    void factorize_16() {
        assertEquals(Arrays.asList(2, 2, 2, 2), Factorize.factorize(16));
    }

    @Test
    void factorize_27() {
        assertEquals(Arrays.asList(3, 3, 3), Factorize.factorize(27));
    }

    @Test
    void factorize_36() {
        assertEquals(Arrays.asList(2, 2, 3, 3), Factorize.factorize(36));
    }
}