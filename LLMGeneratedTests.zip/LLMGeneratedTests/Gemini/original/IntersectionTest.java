package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class IntersectionTest {

    @Test
    void intersection_noIntersection() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(3, 5);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_sameInterval() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(1, 2);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_negativeIntervals() {
        List<Integer> interval1 = Arrays.asList(-3, -1);
        List<Integer> interval2 = Arrays.asList(-5, 5);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_negativeIntervals2() {
        List<Integer> interval1 = Arrays.asList(-2, 2);
        List<Integer> interval2 = Arrays.asList(-4, 0);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_negativeIntervals3() {
        List<Integer> interval1 = Arrays.asList(-11, 2);
        List<Integer> interval2 = Arrays.asList(-1, -1);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_onePointIntersection() {
        List<Integer> interval1 = Arrays.asList(1, 2);
        List<Integer> interval2 = Arrays.asList(2, 3);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_overlappingIntervals() {
        List<Integer> interval1 = Arrays.asList(-1, 1);
        List<Integer> interval2 = Arrays.asList(0, 4);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_negativeSinglePointInterval() {
        List<Integer> interval1 = Arrays.asList(-2, -2);
        List<Integer> interval2 = Arrays.asList(-3, -2);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_primeLength() {
        List<Integer> interval1 = Arrays.asList(1, 5);
        List<Integer> interval2 = Arrays.asList(2, 6);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_zeroLength() {
        List<Integer> interval1 = Arrays.asList(1, 1);
        List<Integer> interval2 = Arrays.asList(1, 1);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_largeNegativeIntervals() {
        List<Integer> interval1 = Arrays.asList(-100, -90);
        List<Integer> interval2 = Arrays.asList(-95, -80);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_largePositiveIntervals() {
        List<Integer> interval1 = Arrays.asList(10, 20);
        List<Integer> interval2 = Arrays.asList(15, 25);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_equalIntervalsPrimeLength() {
        List<Integer> interval1 = Arrays.asList(1, 3);
        List<Integer> interval2 = Arrays.asList(1, 3);
        assertEquals("YES", Intersection.intersection(interval1, interval2));
    }

    @Test
    void intersection_nonPrimeLength() {
        List<Integer> interval1 = Arrays.asList(1, 4);
        List<Integer> interval2 = Arrays.asList(2, 5);
        assertEquals("NO", Intersection.intersection(interval1, interval2));
    }

}