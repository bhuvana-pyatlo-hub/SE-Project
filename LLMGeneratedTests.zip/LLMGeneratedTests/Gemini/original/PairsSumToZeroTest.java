package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PairsSumToZeroTest {

    @Test
    void pairsSumToZero_emptyList_returnsFalse() {
        List<Integer> list = new ArrayList<>();
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_singleElementList_returnsFalse() {
        List<Integer> list = Collections.singletonList(5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_noPairSumsToZero_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_pairSumsToZero_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, -2, 4, 5);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_pairSumsToZeroAtEnd_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 4, 5, -5);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_pairSumsToZeroAtBeginning_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, 1, 2, 4, 5);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_multiplePairsSumToZero_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, 1, -2, 2, 5);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_zeroInList_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 0);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeListNoPair_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeListWithPair_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, -1);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_negativeNumbersOnly_returnsFalse() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_duplicateNumbersNoPair_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 1, 2, 2, 3, 3);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_duplicateNumbersWithPair_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 1, -1, 2, 2, 3, 3);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_allZeros_returnsFalse() {
        List<Integer> list = Arrays.asList(0, 0, 0, 0);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeNegativeAndPositive_returnsTrue() {
        List<Integer> list = Arrays.asList(-100, 5, 100, 2);
        assertTrue(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_largeNegativeAndPositiveNoMatch_returnsFalse() {
        List<Integer> list = Arrays.asList(-100, 5, 99, 2);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_sameIndexSumToZero_returnsFalse() {
        List<Integer> list = Arrays.asList(0, 1, 2, 3);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_negativeZeroAndPositiveZero_returnsFalse() {
        List<Integer> list = Arrays.asList(-0, 0);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_listWithZeroAndOtherNumbers_returnsFalse() {
        List<Integer> list = Arrays.asList(0, 1, 2, 3);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }

    @Test
    void pairsSumToZero_listWithNegativeAndPositiveZero_returnsFalse() {
        List<Integer> list = Arrays.asList(-0, 1, 2, 3);
        assertFalse(PairsSumToZero.pairsSumToZero(list));
    }
}