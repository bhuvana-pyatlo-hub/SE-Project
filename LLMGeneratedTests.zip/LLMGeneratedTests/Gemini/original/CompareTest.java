package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CompareTest {

    @Test
    void compare_emptyLists_returnsEmptyList() {
        List<Integer> game = new ArrayList<>();
        List<Integer> guess = new ArrayList<>();
        List<Integer> expected = new ArrayList<>();
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_equalLists_returnsListWithZeros() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_differentLists_returnsListWithDifferences() {
        List<Integer> game = Arrays.asList(1, 2, 3);
        List<Integer> guess = Arrays.asList(4, 5, 6);
        List<Integer> expected = Arrays.asList(3, 3, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_mixedLists_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> guess = Arrays.asList(1, 3, 5, 2, 4);
        List<Integer> expected = Arrays.asList(0, 1, 2, 2, 1);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_negativeNumbers_returnsAbsoluteDifferences() {
        List<Integer> game = Arrays.asList(-1, -2, -3);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_mixedPositiveNegative_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(-1, 2, -3);
        List<Integer> guess = Arrays.asList(1, -2, 3);
        List<Integer> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_zeroValues_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(0, 0, 0);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_largeDifferences_returnsCorrectDifferences() {
        List<Integer> game = Arrays.asList(100, 200, 300);
        List<Integer> guess = Arrays.asList(1, 2, 3);
        List<Integer> expected = Arrays.asList(99, 198, 297);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_allZeros_returnsAllZeros() {
        List<Integer> game = Arrays.asList(0, 0, 0, 0, 0);
        List<Integer> guess = Arrays.asList(0, 0, 0, 0, 0);
        List<Integer> expected = Arrays.asList(0, 0, 0, 0, 0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_singleElementLists_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(5);
        List<Integer> guess = Arrays.asList(2);
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_singleElementLists_sameValue() {
        List<Integer> game = Arrays.asList(5);
        List<Integer> guess = Arrays.asList(5);
        List<Integer> expected = Arrays.asList(0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_singleElementLists_negativeValues() {
        List<Integer> game = Arrays.asList(-5);
        List<Integer> guess = Arrays.asList(-2);
        List<Integer> expected = Arrays.asList(3);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_singleElementLists_zeroValue() {
        List<Integer> game = Arrays.asList(0);
        List<Integer> guess = Arrays.asList(5);
        List<Integer> expected = Arrays.asList(5);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithOneElement_returnsCorrectDifference() {
        List<Integer> game = Arrays.asList(10);
        List<Integer> guess = Arrays.asList(5);
        List<Integer> expected = Arrays.asList(5);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithOneElement_negativeValues() {
        List<Integer> game = Arrays.asList(-10);
        List<Integer> guess = Arrays.asList(-5);
        List<Integer> expected = Arrays.asList(5);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithOneElement_zeroValues() {
        List<Integer> game = Arrays.asList(0);
        List<Integer> guess = Arrays.asList(0);
        List<Integer> expected = Arrays.asList(0);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_listWithOneElement_mixedValues() {
        List<Integer> game = Arrays.asList(5);
        List<Integer> guess = Arrays.asList(-5);
        List<Integer> expected = Arrays.asList(10);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_sameSizeLists_negativeAndPositive() {
        List<Integer> game = Arrays.asList(-1, 2, -3, 4);
        List<Integer> guess = Arrays.asList(1, -2, 3, -4);
        List<Integer> expected = Arrays.asList(2, 4, 6, 8);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_sameSizeLists_withZeros() {
        List<Integer> game = Arrays.asList(0, 1, 0, 2);
        List<Integer> guess = Arrays.asList(1, 0, 2, 0);
        List<Integer> expected = Arrays.asList(1, 1, 2, 2);
        assertEquals(expected, Compare.compare(game, guess));
    }

    @Test
    void compare_sameSizeLists_largeValues() {
        List<Integer> game = Arrays.asList(100, 200, 300, 400);
        List<Integer> guess = Arrays.asList(50, 150, 250, 350);
        List<Integer> expected = Arrays.asList(50, 50, 50, 50);
        assertEquals(expected, Compare.compare(game, guess));
    }
}