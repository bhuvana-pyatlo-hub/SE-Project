package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class WordsInSentenceTest {

    @Test
    void wordsInSentence_emptySentence() {
        assertEquals("", WordsInSentence.wordsInSentence(""));
    }

    @Test
    void wordsInSentence_singleWordPrimeLength() {
        assertEquals("is", WordsInSentence.wordsInSentence("is"));
    }

    @Test
    void wordsInSentence_singleWordNonPrimeLength() {
        assertEquals("", WordsInSentence.wordsInSentence("here"));
    }

    @Test
    void wordsInSentence_multipleWordsSomePrime() {
        assertEquals("go for", WordsInSentence.wordsInSentence("lets go for swimming"));
    }

    @Test
    void wordsInSentence_multipleWordsAllPrime() {
        assertEquals("Hi am Hussein", WordsInSentence.wordsInSentence("Hi I am Hussein"));
    }

    @Test
    void wordsInSentence_multipleWordsNonePrime() {
        assertEquals("", WordsInSentence.wordsInSentence("the a an"));
    }

    @Test
    void wordsInSentence_sentenceWithLeadingAndTrailingSpaces() {
        assertEquals("is", WordsInSentence.wordsInSentence("  is  "));
    }

    @Test
    void wordsInSentence_sentenceWithMultipleSpacesBetweenWords() {
        assertEquals("is", WordsInSentence.wordsInSentence("This  is   a  test"));
    }

    @Test
    void wordsInSentence_sentenceWithOnlySpaces() {
        assertEquals("", WordsInSentence.wordsInSentence("   "));
    }

    @Test
    void wordsInSentence_sentenceWithPrimeLengthWordsAtBeginningAndEnd() {
        assertEquals("is test", WordsInSentence.wordsInSentence("is a test"));
    }

    @Test
    void wordsInSentence_sentenceWithPrimeLengthWordsInMiddle() {
        assertEquals("a", WordsInSentence.wordsInSentence("the a the"));
    }

    @Test
    void wordsInSentence_sentenceWithAllWordsPrimeLength() {
        assertEquals("go for it", WordsInSentence.wordsInSentence("go for it"));
    }

    @Test
    void wordsInSentence_sentenceWithNoWords() {
        assertEquals("", WordsInSentence.wordsInSentence(""));
    }

    @Test
    void wordsInSentence_sentenceWithOneWordPrime() {
        assertEquals("am", WordsInSentence.wordsInSentence("I am"));
    }

    @Test
    void wordsInSentence_sentenceWithOneWordNotPrime() {
        assertEquals("", WordsInSentence.wordsInSentence("the"));
    }

    @Test
    void wordsInSentence_sentenceWithMixedPrimeAndNotPrime() {
        assertEquals("is no place", WordsInSentence.wordsInSentence("there is no place"));
    }

    @Test
    void wordsInSentence_sentenceWithLongWords() {
        assertEquals("", WordsInSentence.wordsInSentence("abcdefghijk"));
    }

    @Test
    void wordsInSentence_sentenceWithShortWords() {
        assertEquals("I", WordsInSentence.wordsInSentence("I"));
    }

    @Test
    void wordsInSentence_sentenceWithBoundaryLength() {
        String longWord = "a".repeat(100);
        assertEquals("", WordsInSentence.wordsInSentence(longWord));
    }

    @Test
    void wordsInSentence_sentenceWithBoundaryLengthAndPrimeWord() {
        String longWord = "a".repeat(100);
        assertEquals("is", WordsInSentence.wordsInSentence("is " + longWord));
    }

    @Test
    void wordsInSentence_sentenceWithOnlyOneSpace() {
        assertEquals("", WordsInSentence.wordsInSentence("a a"));
    }
}