package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MinsubarraysumTest {

    @Test
    void minsubarraysum_emptyList() {
        List<Object> nums = Collections.emptyList();
        try {
            Minsubarraysum.minsubarraysum(nums);
        } catch (IndexOutOfBoundsException e) {
            // Expected behavior for an empty list
        }
    }

    @Test
    void minsubarraysum_singlePositiveNumber() {
        List<Object> nums = Arrays.asList(7);
        assertEquals(7, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_singleNegativeNumber() {
        List<Object> nums = Arrays.asList(-10);
        assertEquals(-10, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_positiveNumbers() {
        List<Object> nums = Arrays.asList(2, 3, 4, 1, 2, 4);
        assertEquals(1, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_negativeNumbers() {
        List<Object> nums = Arrays.asList(-1, -2, -3);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_mixedNumbers() {
        List<Object> nums = Arrays.asList(-1, -2, -3, 2, -10);
        assertEquals(-14, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_largeNegativeNumber() {
        List<Object> nums = Arrays.asList(-9999999999999999L);
        assertEquals(-9999999999999999L, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_zeroAndPositiveNumbers() {
        List<Object> nums = Arrays.asList(0, 10, 20, 1000000);
        assertEquals(0, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_negativeAndPositiveNumbers() {
        List<Object> nums = Arrays.asList(-1, -2, -3, 10, -5);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_positiveNegativeNumbers() {
        List<Object> nums = Arrays.asList(100, -1, -2, -3, 10, -5);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_positiveNumbers2() {
        List<Object> nums = Arrays.asList(10, 11, 13, 8, 3, 4);
        assertEquals(3, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_mixedNumbers2() {
        List<Object> nums = Arrays.asList(100, -33, 32, -1, 0, -2);
        assertEquals(-33, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_onePositiveOneNegative() {
        List<Object> nums = Arrays.asList(1, -1);
        assertEquals(-1, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_allZeros() {
        List<Object> nums = Arrays.asList(0, 0, 0, 0);
        assertEquals(0, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_alternatingPositiveNegative() {
        List<Object> nums = Arrays.asList(1, -2, 3, -4, 5);
        assertEquals(-4, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_largePositiveAndNegative() {
        List<Object> nums = Arrays.asList(1000, -1000);
        assertEquals(-1000, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_negativeAtStart() {
        List<Object> nums = Arrays.asList(-5, 1, 2, 3);
        assertEquals(-5, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_positiveAtStart() {
        List<Object> nums = Arrays.asList(5, -1, -2, -3);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_onlyNegativeNumbersWithZero() {
        List<Object> nums = Arrays.asList(-1, -2, 0, -3);
        assertEquals(-6, Minsubarraysum.minsubarraysum(nums));
    }

    @Test
    void minsubarraysum_allSameNegativeNumber() {
        List<Object> nums = Arrays.asList(-2, -2, -2, -2);
        assertEquals(-8, Minsubarraysum.minsubarraysum(nums));
    }
}