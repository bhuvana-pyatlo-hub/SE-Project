package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SortedListSumTest {

    @Test
    void sortedListSum_emptyList() {
        List<String> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_allOddLength() {
        List<String> input = Arrays.asList("a", "bb", "ccc");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SortedListSum.sortedListSum(Arrays.asList("a", "ccc")));
    }

    @Test
    void sortedListSum_allEvenLength() {
        List<String> input = Arrays.asList("aa", "bbbb", "cc");
        List<Object> expected = Arrays.asList("aa", "cc", "bbbb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_mixedLengths() {
        List<String> input = Arrays.asList("a", "bb", "ccc", "dddd");
        List<Object> expected = Arrays.asList("bb", "dddd");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_duplicateEvenLengths() {
        List<String> input = Arrays.asList("aa", "bb", "aa", "bb");
        List<Object> expected = Arrays.asList("aa", "aa", "bb", "bb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_sameLengthDifferentAlphabeticalOrder() {
        List<String> input = Arrays.asList("ba", "ab");
        List<Object> expected = Arrays.asList("ab", "ba");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_emptyString() {
        List<String> input = Arrays.asList("");
        List<Object> expected = Arrays.asList("");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_multipleEmptyStrings() {
        List<String> input = Arrays.asList("", "", "");
        List<Object> expected = Arrays.asList("", "", "");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_mixedEmptyAndNonEmpty() {
        List<String> input = Arrays.asList("", "a", "bb");
        List<Object> expected = Arrays.asList("", "bb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_longStrings() {
        List<String> input = Arrays.asList("aaaaaaaaaa", "bbbbbbbbbb");
        List<Object> expected = Arrays.asList("aaaaaaaaaa", "bbbbbbbbbb");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithNumbers() {
        List<String> input = Arrays.asList("12", "123", "1234");
        List<Object> expected = Arrays.asList("12", "1234");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithSpecialCharacters() {
        List<String> input = Arrays.asList("!@", "#$%^", "&*()");
        List<Object> expected = Arrays.asList("!@", "&*()");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithMixedCharacters() {
        List<String> input = Arrays.asList("a1", "b22", "c333");
        List<Object> expected = Arrays.asList("a1", "b22");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_largeList() {
        List<String> input = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            input.add(String.valueOf(i % 2 == 0 ? "aa" : "a"));
        }
        List<Object> expected = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            if (i % 2 == 0) {
                expected.add("aa");
            }
        }
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithSameLengthDifferentCase() {
        List<String> input = Arrays.asList("AA", "aa");
        List<Object> expected = Arrays.asList("AA", "aa");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithSameLengthDifferentCaseMixed() {
        List<String> input = Arrays.asList("Aa", "aA");
        List<Object> expected = Arrays.asList("Aa", "aA");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithDifferentLengthsAndCases() {
        List<String> input = Arrays.asList("A", "aa", "AAA", "aaaa");
        List<Object> expected = Arrays.asList("aa", "aaaa");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithLeadingAndTrailingSpaces() {
        List<String> input = Arrays.asList("  a  ", " bb ", "   ccc   ");
        List<Object> expected = Arrays.asList(" bb ");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_stringsWithInternalSpaces() {
        List<String> input = Arrays.asList("a a", "b  b", "c   c");
        List<Object> expected = Arrays.asList("a a", "b  b");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }

    @Test
    void sortedListSum_complexScenario() {
        List<String> input = Arrays.asList("a", "bb", "ccc", "dddd", "eeeee", "ffffff", "gg", "h", "iiiii", "jjjj");
        List<Object> expected = Arrays.asList("bb", "gg", "dddd", "jjjj", "ffffff");
        assertEquals(expected, SortedListSum.sortedListSum(input));
    }
}