package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChooseNumTest {

    @Test
    void chooseNum_xLessThanY_evenInRange() {
        assertEquals(14, ChooseNum.chooseNum(12, 15));
    }

    @Test
    void chooseNum_xGreaterThanY_noEvenInRange() {
        assertEquals(-1, ChooseNum.chooseNum(13, 12));
    }

    @Test
    void chooseNum_largeRange_evenInRange() {
        assertEquals(12354, ChooseNum.chooseNum(33, 12354));
    }

    @Test
    void chooseNum_xGreaterThanY_largeNumbers() {
        assertEquals(-1, ChooseNum.chooseNum(5234, 5233));
    }

    @Test
    void chooseNum_xLessThanY_evenInRange2() {
        assertEquals(28, ChooseNum.chooseNum(6, 29));
    }

    @Test
    void chooseNum_xGreaterThanY_evenInRange3() {
        assertEquals(-1, ChooseNum.chooseNum(27, 10));
    }

    @Test
    void chooseNum_xEqualsY_odd_noEvenInRange() {
        assertEquals(-1, ChooseNum.chooseNum(7, 7));
    }

    @Test
    void chooseNum_xEqualsY_even_evenInRange() {
        assertEquals(546, ChooseNum.chooseNum(546, 546));
    }

    @Test
    void chooseNum_xLessThanY_noEvenInRange_allOdd() {
        assertEquals(-1, ChooseNum.chooseNum(1, 3));
    }

    @Test
    void chooseNum_xLessThanY_noEvenInRange_xOddYOdd() {
        assertEquals(-1, ChooseNum.chooseNum(1, 3));
    }

    @Test
    void chooseNum_xLessThanY_noEvenInRange_xOddYEven() {
        assertEquals(2, ChooseNum.chooseNum(1, 2));
    }

    @Test
    void chooseNum_xLessThanY_noEvenInRange_xEvenYOdd() {
        assertEquals(2, ChooseNum.chooseNum(2, 3));
    }

    @Test
    void chooseNum_xLessThanY_multipleEvensInRange() {
        assertEquals(10, ChooseNum.chooseNum(2, 10));
    }

    @Test
    void chooseNum_xLessThanY_multipleEvensInRange2() {
        assertEquals(100, ChooseNum.chooseNum(90, 100));
    }

    @Test
    void chooseNum_xEqualsY_smallEven() {
        assertEquals(2, ChooseNum.chooseNum(2, 2));
    }

    @Test
    void chooseNum_xEqualsY_smallOdd() {
        assertEquals(-1, ChooseNum.chooseNum(1, 1));
    }

    @Test
    void chooseNum_xLessThanY_smallRange_evenAtEnd() {
        assertEquals(4, ChooseNum.chooseNum(3, 4));
    }

    @Test
    void chooseNum_xLessThanY_smallRange_evenAtStart() {
        assertEquals(2, ChooseNum.chooseNum(2, 3));
    }

    @Test
    void chooseNum_xLessThanY_smallRange_noEven() {
        assertEquals(-1, ChooseNum.chooseNum(1, 3));
    }

    @Test
    void chooseNum_xLessThanY_sameEvenNumber() {
        assertEquals(4, ChooseNum.chooseNum(4, 4));
    }
}