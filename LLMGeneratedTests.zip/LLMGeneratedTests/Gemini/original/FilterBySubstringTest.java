package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FilterBySubstringTest {

    @Test
    void testEmptyListAndEmptySubstring() {
        List<Object> inputList = new ArrayList<>();
        String substring = "";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testEmptyListAndNonEmptySubstring() {
        List<Object> inputList = new ArrayList<>();
        String substring = "a";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testNonEmptyListAndEmptySubstring() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "";
        List<Object> expected = Arrays.asList("abc", "def", "ghi");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringPresentInSomeStrings() {
        List<Object> inputList = Arrays.asList("abc", "bacd", "cde", "array");
        String substring = "a";
        List<Object> expected = Arrays.asList("abc", "bacd", "array");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringNotPresentInAnyString() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "x";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringPresentInAllStrings() {
        List<Object> inputList = Arrays.asList("abc", "bac", "cab");
        String substring = "a";
        List<Object> expected = Arrays.asList("abc", "bac", "cab");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringIsTheSameAsAString() {
        List<Object> inputList = Arrays.asList("abc", "def", "abc");
        String substring = "abc";
        List<Object> expected = Arrays.asList("abc", "abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringIsAtTheBeginning() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "ab";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringIsAtTheEnd() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "bc";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringMultipleOccurrencesInAString() {
        List<Object> inputList = Arrays.asList("abab", "def", "ghi");
        String substring = "ab";
        List<Object> expected = Arrays.asList("abab");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testCaseSensitiveSubstring() {
        List<Object> inputList = Arrays.asList("Abc", "abc", "aBC");
        String substring = "ab";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSpecialCharactersInSubstring() {
        List<Object> inputList = Arrays.asList("a.b", "a+b", "a*b");
        String substring = ".";
        List<Object> expected = Arrays.asList("a.b");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testNumbersInStringsAndSubstring() {
        List<Object> inputList = Arrays.asList("123", "456", "789");
        String substring = "2";
        List<Object> expected = Arrays.asList("123");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testMixedDataTypesInList() {
        List<Object> inputList = Arrays.asList("abc", 123, "def", 456);
        String substring = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testEmptyStringInList() {
        List<Object> inputList = Arrays.asList("abc", "", "def");
        String substring = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testNullStringInList() {
        List<Object> inputList = new ArrayList<>();
        inputList.add("abc");
        inputList.add(null);
        inputList.add("def");
        String substring = "a";
        List<Object> expected = Arrays.asList("abc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testLongListWithManyMatches() {
        List<Object> inputList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            inputList.add("string" + i);
        }
        String substring = "string";
        List<Object> expected = new ArrayList<>(inputList);
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testLongListWithNoMatches() {
        List<Object> inputList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            inputList.add("string" + i);
        }
        String substring = "xyz";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringAtTheVeryBeginningAndEnd() {
        List<Object> inputList = Arrays.asList("abcabc", "def", "ghi");
        String substring = "abc";
        List<Object> expected = Arrays.asList("abcabc");
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }

    @Test
    void testSubstringIsLongerThanString() {
        List<Object> inputList = Arrays.asList("abc", "def", "ghi");
        String substring = "abcdef";
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterBySubstring.filterBySubstring(inputList, substring));
    }
}