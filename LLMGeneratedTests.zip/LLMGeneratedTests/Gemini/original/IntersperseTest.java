package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IntersperseTest {

    @Test
    void testEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Intersperse.intersperse(input, 5));
    }

    @Test
    void testSingleElementList() {
        List<Object> input = Arrays.asList(10);
        List<Object> expected = Arrays.asList(10);
        assertEquals(expected, Intersperse.intersperse(input, 5));
    }

    @Test
    void testTwoElementList() {
        List<Object> input = Arrays.asList(10, 20);
        List<Object> expected = Arrays.asList(10, 5, 20);
        assertEquals(expected, Intersperse.intersperse(input, 5));
    }

    @Test
    void testMultipleElementsList() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 5, 2, 5, 3, 5, 4, 5, 5);
        assertEquals(expected, Intersperse.intersperse(input, 5));
    }

    @Test
    void testNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(-1, 5, -2, 5, -3);
        assertEquals(expected, Intersperse.intersperse(input, 5));
    }

    @Test
    void testZeroDelimiter() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(1, 0, 2, 0, 3);
        assertEquals(expected, Intersperse.intersperse(input, 0));
    }

    @Test
    void testSameElements() {
        List<Object> input = Arrays.asList(2, 2, 2);
        List<Object> expected = Arrays.asList(2, 2, 2, 2, 2);
        assertEquals(expected, Intersperse.intersperse(input, 2));
    }

    @Test
    void testLargeDelimiter() {
        List<Object> input = Arrays.asList(1, 2);
        List<Object> expected = Arrays.asList(1, 100, 2);
        assertEquals(expected, Intersperse.intersperse(input, 100));
    }

    @Test
    void testNegativeDelimiter() {
        List<Object> input = Arrays.asList(1, 2);
        List<Object> expected = Arrays.asList(1, -100, 2);
        assertEquals(expected, Intersperse.intersperse(input, -100));
    }
}