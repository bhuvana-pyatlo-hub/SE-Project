package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class EvenOddCountTest {

    @Test
    void testZero() {
        List<Integer> result = EvenOddCount.evenOddCount(0);
        assertEquals(1, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testPositiveEvenNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(2);
        assertEquals(1, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testPositiveOddNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(1);
        assertEquals(0, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void testNegativeEvenNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-2);
        assertEquals(1, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testNegativeOddNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-1);
        assertEquals(0, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void testPositiveMixedNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(123);
        assertEquals(1, result.get(0));
        assertEquals(2, result.get(1));
    }

    @Test
    void testNegativeMixedNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-123);
        assertEquals(1, result.get(0));
        assertEquals(2, result.get(1));
    }

    @Test
    void testPositiveAllEven() {
        List<Integer> result = EvenOddCount.evenOddCount(2468);
        assertEquals(4, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testPositiveAllOdd() {
        List<Integer> result = EvenOddCount.evenOddCount(13579);
        assertEquals(0, result.get(0));
        assertEquals(5, result.get(1));
    }

    @Test
    void testNegativeAllEven() {
        List<Integer> result = EvenOddCount.evenOddCount(-2468);
        assertEquals(4, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testNegativeAllOdd() {
        List<Integer> result = EvenOddCount.evenOddCount(-13579);
        assertEquals(0, result.get(0));
        assertEquals(5, result.get(1));
    }

    @Test
    void testSingleDigitEven() {
        List<Integer> result = EvenOddCount.evenOddCount(4);
        assertEquals(1, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testSingleDigitOdd() {
        List<Integer> result = EvenOddCount.evenOddCount(7);
        assertEquals(0, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void testNegativeSingleDigitEven() {
        List<Integer> result = EvenOddCount.evenOddCount(-6);
        assertEquals(1, result.get(0));
        assertEquals(0, result.get(1));
    }

    @Test
    void testNegativeSingleDigitOdd() {
        List<Integer> result = EvenOddCount.evenOddCount(-9);
        assertEquals(0, result.get(0));
        assertEquals(1, result.get(1));
    }

    @Test
    void testLargeMixedNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(123456789);
        assertEquals(4, result.get(0));
        assertEquals(5, result.get(1));
    }

    @Test
    void testLargeNegativeMixedNumber() {
        List<Integer> result = EvenOddCount.evenOddCount(-123456789);
        assertEquals(4, result.get(0));
        assertEquals(5, result.get(1));
    }

    @Test
    void testEvenOddEqualCount() {
        List<Integer> result = EvenOddCount.evenOddCount(246135);
        assertEquals(3, result.get(0));
        assertEquals(3, result.get(1));
    }

    @Test
    void testNegativeEvenOddEqualCount() {
        List<Integer> result = EvenOddCount.evenOddCount(-246135);
        assertEquals(3, result.get(0));
        assertEquals(3, result.get(1));
    }

    @Test
    void testNumberEndingInZero() {
        List<Integer> result = EvenOddCount.evenOddCount(1230);
        assertEquals(2, result.get(0));
        assertEquals(2, result.get(1));
    }
}