package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ProdSignsTest {

    @Test
    void prodSigns_emptyList_returnsNull() {
        assertNull(ProdSigns.prodSigns(Collections.emptyList()));
    }

    @Test
    void prodSigns_positiveNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, 3);
        assertEquals(6, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_negativeNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(-1, -2, -3);
        assertEquals(-6, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_mixedNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, -2, 3);
        assertEquals(-6, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_zeroInList_returnsZero() {
        List<Object> arr = Arrays.asList(1, 0, 3);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_onlyZeroes_returnsZero() {
        List<Object> arr = Arrays.asList(0, 0, 0);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_singlePositiveNumber_returnsCorrectSum() {
        List<Object> arr = Collections.singletonList(5);
        assertEquals(5, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_singleNegativeNumber_returnsCorrectSum() {
        List<Object> arr = Collections.singletonList(-5);
        assertEquals(-5, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_singleZero_returnsZero() {
        List<Object> arr = Collections.singletonList(0);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_multiplePositiveNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_multipleNegativeNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(-15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_multipleMixedNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, -2, 3, -4, 5);
        assertEquals(15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_mixedWithZero_returnsZero() {
        List<Object> arr = Arrays.asList(1, -2, 0, -4, 5);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_largePositiveNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(100, 200, 300);
        assertEquals(600, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_largeNegativeNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(-100, -200, -300);
        assertEquals(-600, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_largeMixedNumbers_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(100, -200, 300);
        assertEquals(-600, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_onlyOneNegativeNumber_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, 3, -4, 5);
        assertEquals(-15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_onlyOnePositiveNumber_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(-1, -2, -3, 4, -5);
        assertEquals(15, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_objectListWithNonInteger_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, "string", 4, 5);
        assertEquals(12, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_objectListWithNull_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, 2, null, 4, 5);
        assertEquals(12, ProdSigns.prodSigns(arr));
    }

    @Test
    void prodSigns_mixedTypes_returnsCorrectSum() {
        List<Object> arr = Arrays.asList(1, -2, 3, "test", 0, 5);
        assertEquals(0, ProdSigns.prodSigns(arr));
    }
}