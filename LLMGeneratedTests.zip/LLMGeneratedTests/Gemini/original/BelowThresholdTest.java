package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BelowThresholdTest {

    @Test
    void belowThreshold_emptyList_returnsTrue() {
        List<Integer> list = new ArrayList<>();
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_singleElementBelowThreshold_returnsTrue() {
        List<Integer> list = Collections.singletonList(5);
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_singleElementAboveThreshold_returnsFalse() {
        List<Integer> list = Collections.singletonList(15);
        assertFalse(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_allElementsBelowThreshold_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_allElementsAboveThreshold_returnsFalse() {
        List<Integer> list = Arrays.asList(11, 12, 13, 14, 15);
        assertFalse(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_someElementsBelowThreshold_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 13, 4, 5);
        assertFalse(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_thresholdIsZero_returnsFalseIfAnyElementPositive() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertFalse(BelowThreshold.belowThreshold(list, 0));
    }

    @Test
    void belowThreshold_thresholdIsZero_returnsTrueIfAllElementsNegative() {
        List<Integer> list = Arrays.asList(-1, -2, -3);
        assertTrue(BelowThreshold.belowThreshold(list, 0));
    }

    @Test
    void belowThreshold_thresholdIsNegative_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, -2, -3);
        assertTrue(BelowThreshold.belowThreshold(list, -4));
    }

    @Test
    void belowThreshold_thresholdIsNegative_returnsFalse() {
        List<Integer> list = Arrays.asList(-1, -2, -3);
        assertFalse(BelowThreshold.belowThreshold(list, -2));
    }

    @Test
    void belowThreshold_mixedPositiveNegative_returnsFalse() {
        List<Integer> list = Arrays.asList(-1, 2, -3);
        assertFalse(BelowThreshold.belowThreshold(list, 0));
    }

    @Test
    void belowThreshold_mixedPositiveNegative_returnsTrue() {
        List<Integer> list = Arrays.asList(-1, 2, -3);
        assertTrue(BelowThreshold.belowThreshold(list, 3));
    }

    @Test
    void belowThreshold_largeThreshold_returnsTrue() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertTrue(BelowThreshold.belowThreshold(list, 1000));
    }

    @Test
    void belowThreshold_largeValueInList_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 1001);
        assertFalse(BelowThreshold.belowThreshold(list, 1000));
    }

    @Test
    void belowThreshold_thresholdEqualsElement_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 10);
        assertFalse(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_allElementsSameValueBelowThreshold_returnsTrue() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5);
        assertTrue(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_allElementsSameValueAboveThreshold_returnsFalse() {
        List<Integer> list = Arrays.asList(15, 15, 15, 15);
        assertFalse(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_allElementsSameValueEqualToThreshold_returnsFalse() {
        List<Integer> list = Arrays.asList(10, 10, 10, 10);
        assertFalse(BelowThreshold.belowThreshold(list, 10));
    }

    @Test
    void belowThreshold_firstElementAboveThreshold_returnsFalse() {
        List<Integer> list = Arrays.asList(10, 1, 2, 3);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }

    @Test
    void belowThreshold_lastElementAboveThreshold_returnsFalse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 10);
        assertFalse(BelowThreshold.belowThreshold(list, 5));
    }
}