package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class HistogramTest {

    @Test
    void testEmptyString() {
        Map<String, Integer> expected = new HashMap<>();
        assertEquals(expected, Histogram.histogram(""));
    }

    @Test
    void testSingleCharacter() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        assertEquals(expected, Histogram.histogram("a"));
    }

    @Test
    void testBasicCase() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        expected.put("c", 1);
        assertEquals(expected, Histogram.histogram("a b c"));
    }

    @Test
    void testMultipleOccurrences() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b b a"));
    }

    @Test
    void testMultipleOccurrences2() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 2);
        expected.put("b", 2);
        assertEquals(expected, Histogram.histogram("a b c a b"));
    }

    @Test
    void testSingleMaxOccurrence() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("b", 4);
        assertEquals(expected, Histogram.histogram("b b b b a"));
    }

    @Test
    void testDifferentCharacters() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("r", 1);
        expected.put("t", 1);
        expected.put("g", 1);
        assertEquals(expected, Histogram.histogram("r t g"));
    }

    @Test
    void testOnlySpaces() {
        Map<String, Integer> expected = new HashMap<>();
        assertEquals(expected, Histogram.histogram("   "));
    }

    @Test
    void testMixedCase() {
        Map<String, Integer> expected = new HashMap<>();
        expected.put("a", 1);
        expected.put("b", 1);
        expected.put("c", 1);
        assertEquals(expected, Histogram.histogram("a b c"));
    }



    @Test
    void testEdgeCaseSameOccurrences() {
        String input = "a b c d e";
        Map<String, Integer> result = (Map<String, Integer>) Histogram.histogram(input);
        assertEquals(5, result.size());
        assertTrue(result.containsKey("a"));
        assertTrue(result.containsKey("b"));
        assertTrue(result.containsKey("c"));
        assertTrue(result.containsKey("d"));
        assertTrue(result.containsKey("e"));
        assertEquals(1, result.get("a"));
        assertEquals(1, result.get("b"));
        assertEquals(1, result.get("c"));
        assertEquals(1, result.get("d"));
        assertEquals(1, result.get("e"));
    }

    @Test
    void testEdgeCaseMultipleMax() {
        String input = "a a b b c";
        Map<String, Integer> result = (Map<String, Integer>) Histogram.histogram(input);
        assertEquals(2, result.size());
        assertTrue(result.containsKey("a"));
        assertTrue(result.containsKey("b"));
        assertEquals(2, result.get("a"));
        assertEquals(2, result.get("b"));
    }
}