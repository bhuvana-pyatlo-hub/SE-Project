package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TriplesSumToZeroTest {

    @Test
    void testEmptyList() {
        List<Integer> list = new ArrayList<>();
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithOneElement() {
        List<Integer> list = Collections.singletonList(1);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithTwoElements() {
        List<Integer> list = Arrays.asList(1, 2);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithThreeElementsSumToZero() {
        List<Integer> list = Arrays.asList(1, 2, -3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithThreeElementsNoSumToZero() {
        List<Integer> list = Arrays.asList(1, 2, 3);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithFourElementsSumToZero() {
        List<Integer> list = Arrays.asList(1, 2, -3, 4);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithFourElementsNoSumToZero() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithMultipleElementsSumToZero() {
        List<Integer> list = Arrays.asList(1, 2, -3, 4, 5, 6);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithMultipleElementsNoSumToZero() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithNegativeNumbersSumToZero() {
        List<Integer> list = Arrays.asList(-1, -2, 3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithNegativeNumbersNoSumToZero() {
        List<Integer> list = Arrays.asList(-1, -2, -3);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithZeroesSumToZero() {
        List<Integer> list = Arrays.asList(0, 0, 0);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithZeroesNoSumToZero() {
        List<Integer> list = Arrays.asList(0, 0, 1);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithDuplicateNumbersSumToZero() {
        List<Integer> list = Arrays.asList(1, 1, -2);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithDuplicateNumbersNoSumToZero() {
        List<Integer> list = Arrays.asList(1, 1, 1);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithLargeNumbersNoSumToZero() {
        List<Integer> list = Arrays.asList(100, 200, 300);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithLargeNumbersSumToZero() {
        List<Integer> list = Arrays.asList(100, 200, -300);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithMixedPositiveNegativeAndZeroSumToZero() {
        List<Integer> list = Arrays.asList(5, -2, 0, -3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithMixedPositiveNegativeAndZeroNoSumToZero() {
        List<Integer> list = Arrays.asList(5, -2, 0, 1);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithSameNumberMultipleTimesSumToZero() {
        List<Integer> list = Arrays.asList(1, 1, 1, -3);
        assertTrue(TriplesSumToZero.triplesSumToZero(list));
    }

    @Test
    void testListWithSameNumberMultipleTimesNoSumToZero() {
        List<Integer> list = Arrays.asList(1, 1, 1, 1);
        assertFalse(TriplesSumToZero.triplesSumToZero(list));
    }
}