package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AddTest {

    @Test
    void testAddPositiveNumbers() {
        assertEquals(5, Add.add(2, 3));
    }

    @Test
    void testAddZeroAndPositiveNumber() {
        assertEquals(5, Add.add(0, 5));
    }

    @Test
    void testAddPositiveNumberAndZero() {
        assertEquals(5, Add.add(5, 0));
    }

    @Test
    void testAddTwoZeros() {
        assertEquals(0, Add.add(0, 0));
    }

    @Test
    void testAddLargePositiveNumbers() {
        assertEquals(1500, Add.add(700, 800));
    }

    @Test
    void testAddBoundaryValuesPositive() {
        assertEquals(2, Add.add(1, 1));
    }

    @Test
    void testAddSmallPositiveNumbers() {
        assertEquals(3, Add.add(1, 2));
    }

    @Test
    void testAddDifferentPositiveNumbers() {
        assertEquals(10, Add.add(3, 7));
    }

    @Test
    void testAddAnotherSetOfPositiveNumbers() {
        assertEquals(15, Add.add(8, 7));
    }

    @Test
    void testAddPositiveNumbersNearZero() {
        assertEquals(1, Add.add(0, 1));
    }

    @Test
    void testAddPositiveNumbersNearZeroReversed() {
        assertEquals(1, Add.add(1, 0));
    }

    @Test
    void testAddPositiveNumbersMediumRange() {
        assertEquals(50, Add.add(20, 30));
    }

    @Test
    void testAddPositiveNumbersHighRange() {
        assertEquals(999, Add.add(499, 500));
    }

    @Test
    void testAddPositiveNumbersNearMax() {
        assertEquals(1998, Add.add(998, 1000));
    }

    @Test
    void testAddPositiveNumbersNearMaxReversed() {
        assertEquals(1998, Add.add(1000, 998));
    }

    @Test
    void testAddPositiveNumbersWithOneNearZero() {
        assertEquals(100, Add.add(99, 1));
    }

    @Test
    void testAddPositiveNumbersWithOneNearZeroReversed() {
        assertEquals(100, Add.add(1, 99));
    }

    @Test
    void testAddPositiveNumbersEqualValues() {
        assertEquals(100, Add.add(50, 50));
    }

    @Test
    void testAddPositiveNumbersCloseValues() {
        assertEquals(101, Add.add(50, 51));
    }

    @Test
    void testAddPositiveNumbersCloseValuesReversed() {
        assertEquals(101, Add.add(51, 50));
    }
}