package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class UniqueDigitsTest {

    @Test
    void testEmptyList() {
        List<Integer> input = Collections.emptyList();
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithOnlyEvenDigitNumbers() {
        List<Integer> input = Arrays.asList(2, 4, 6, 8, 10);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithOnlyOddDigitNumbers() {
        List<Integer> input = Arrays.asList(1, 3, 5, 7, 9);
        List<Object> expected = Arrays.asList(1, 3, 5, 7, 9);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithMixedDigitNumbers() {
        List<Integer> input = Arrays.asList(12, 35, 47, 19, 20);
        List<Object> expected = Arrays.asList(35, 19);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithSingleDigitEvenNumber() {
        List<Integer> input = Arrays.asList(2);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithSingleDigitOddNumber() {
        List<Integer> input = Arrays.asList(1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithMultipleNumbers() {
        List<Integer> input = Arrays.asList(15, 33, 1422, 1);
        List<Object> expected = Arrays.asList(1, 15, 33);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithNoUniqueDigits() {
        List<Integer> input = Arrays.asList(152, 323, 1422, 10);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithSomeUniqueDigits() {
        List<Integer> input = Arrays.asList(12345, 2033, 111, 151);
        List<Object> expected = Arrays.asList(111, 151);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithUnsortedUniqueDigits() {
        List<Integer> input = Arrays.asList(135, 103, 31);
        List<Object> expected = Arrays.asList(31, 135);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithZero() {
        List<Integer> input = Arrays.asList(0);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithOneAndZero() {
        List<Integer> input = Arrays.asList(1, 0);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithLargeOddNumber() {
        List<Integer> input = Arrays.asList(13579);
        List<Object> expected = Arrays.asList(13579);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithLargeEvenNumber() {
        List<Integer> input = Arrays.asList(24680);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithNumberEndingInZero() {
        List<Integer> input = Arrays.asList(10);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithNumberEndingInOdd() {
        List<Integer> input = Arrays.asList(11);
        List<Object> expected = Arrays.asList(11);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithDuplicateOddNumbers() {
        List<Integer> input = Arrays.asList(1, 1, 3, 3, 5, 5);
        List<Object> expected = Arrays.asList(1, 1, 3, 3, 5, 5);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithDuplicateEvenNumbers() {
        List<Integer> input = Arrays.asList(2, 2, 4, 4, 6, 6);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithMixedDuplicates() {
        List<Integer> input = Arrays.asList(1, 2, 1, 2, 3, 4, 3, 4);
        List<Object> expected = Arrays.asList(1, 1, 3, 3);
        Collections.sort(expected, (a, b) -> (Integer) a - (Integer) b);
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }

    @Test
    void testListWithNumberContainingOnlyZero() {
        List<Integer> input = Arrays.asList(0, 0, 0);
        List<Object> expected = Collections.emptyList();
        assertEquals(expected, UniqueDigits.uniqueDigits(input));
    }
}