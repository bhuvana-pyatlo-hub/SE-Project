package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HowManyTimesTest {

    @Test
    void howManyTimes_emptyString_emptySubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("", ""));
    }

    @Test
    void howManyTimes_emptyString_nonEmptySubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("", "a"));
    }

    @Test
    void howManyTimes_nonEmptyString_emptySubstring() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", ""));
    }

    @Test
    void howManyTimes_aaa_a() {
        assertEquals(3, HowManyTimes.howManyTimes("aaa", "a"));
    }

    @Test
    void howManyTimes_aaaa_aa() {
        assertEquals(3, HowManyTimes.howManyTimes("aaaa", "aa"));
    }

    @Test
    void howManyTimes_xyxyxyx_x() {
        assertEquals(4, HowManyTimes.howManyTimes("xyxyxyx", "x"));
    }

    @Test
    void howManyTimes_cacacacac_cac() {
        assertEquals(4, HowManyTimes.howManyTimes("cacacacac", "cac"));
    }

    @Test
    void howManyTimes_johnDoe_john() {
        assertEquals(1, HowManyTimes.howManyTimes("john doe", "john"));
    }

    @Test
    void howManyTimes_abc_d() {
        assertEquals(0, HowManyTimes.howManyTimes("abc", "d"));
    }

    @Test
    void howManyTimes_abcabc_abc() {
        assertEquals(2, HowManyTimes.howManyTimes("abcabc", "abc"));
    }

    @Test
    void howManyTimes_abcabcabc_abc() {
        assertEquals(3, HowManyTimes.howManyTimes("abcabcabc", "abc"));
    }

    @Test
    void howManyTimes_abc_ab() {
        assertEquals(1, HowManyTimes.howManyTimes("abc", "ab"));
    }

    @Test
    void howManyTimes_abc_bc() {
        assertEquals(1, HowManyTimes.howManyTimes("abc", "bc"));
    }

    @Test
    void howManyTimes_abc_c() {
        assertEquals(1, HowManyTimes.howManyTimes("abc", "c"));
    }

    @Test
    void howManyTimes_abc_a() {
        assertEquals(1, HowManyTimes.howManyTimes("abc", "a"));
    }

    @Test
    void howManyTimes_longString_shortSubstring() {
        String longString = "abcdefghijklmnopqrstuvwxyz";
        String shortSubstring = "abc";
        assertEquals(1, HowManyTimes.howManyTimes(longString, shortSubstring));
    }

    @Test
    void howManyTimes_longString_longSubstring() {
        String longString = "abcdefghijklmnopqrstuvwxyz";
        String longSubstring = "abcdefghijklmnopqrstuvwxyz";
        assertEquals(1, HowManyTimes.howManyTimes(longString, longSubstring));
    }

    @Test
    void howManyTimes_sameStringAndSubstring() {
        assertEquals(1, HowManyTimes.howManyTimes("test", "test"));
    }

    @Test
    void howManyTimes_overlappingSubstringAtEnd() {
        assertEquals(2, HowManyTimes.howManyTimes("abab", "ab"));
    }

    @Test
    void howManyTimes_substringLongerThanString() {
        assertEquals(0, HowManyTimes.howManyTimes("ab", "abc"));
    }
}