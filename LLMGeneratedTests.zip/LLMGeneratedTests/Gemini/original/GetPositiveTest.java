package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class GetPositiveTest {

    @Test
    void testGetPositive_basicPositiveNumbers() {
        List<Object> input = Arrays.asList(-1, 2, -4, 5, 6);
        List<Object> expected = Arrays.asList(2, 5, 6);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_mixedPositiveNegativeZero() {
        List<Object> input = Arrays.asList(5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10);
        List<Object> expected = Arrays.asList(5, 3, 2, 3, 9, 123, 1);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyPositiveNumbers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_zeroIncluded() {
        List<Object> input = Arrays.asList(-1, 0, 1);
        List<Object> expected = Arrays.asList(1);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_largePositiveNumbers() {
        List<Object> input = Arrays.asList(-100, 100, -50, 50);
        List<Object> expected = Arrays.asList(100, 50);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_smallNegativeNumbers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_mixedTypes() {
        List<Object> input = Arrays.asList(1, "hello", -2, 3.14, 4);
        List<Object> expected = Arrays.asList(1, 4);
        assertEquals(expected, GetPositive.getPositive(input));
    }

    @Test
    void testGetPositive_onlyStrings() {
        List<Object> input = Arrays.asList("hello", "world");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetPositive.getPositive(input));
    }
}