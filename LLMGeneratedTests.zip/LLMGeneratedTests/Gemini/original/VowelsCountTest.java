package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class VowelsCountTest {

    @Test
    void testEmptyString() {
        assertEquals(0, VowelsCount.vowelsCount(""));
    }

    @Test
    void testNoVowels() {
        assertEquals(0, VowelsCount.vowelsCount("bcdfgh"));
    }

    @Test
    void testOnlyVowelsLowercase() {
        assertEquals(5, VowelsCount.vowelsCount("aeiou"));
    }

    @Test
    void testOnlyVowelsUppercase() {
        assertEquals(5, VowelsCount.vowelsCount("AEIOU"));
    }

    @Test
    void testMixedCaseVowels() {
        assertEquals(5, VowelsCount.vowelsCount("aEiOu"));
    }

    @Test
    void testVowelsAndConsonantsLowercase() {
        assertEquals(2, VowelsCount.vowelsCount("abcde"));
    }

    @Test
    void testVowelsAndConsonantsUppercase() {
        assertEquals(2, VowelsCount.vowelsCount("AbCdE"));
    }

    @Test
    void testVowelsAndConsonantsMixedCase() {
        assertEquals(2, VowelsCount.vowelsCount("aBcDe"));
    }

    @Test
    void testYAtEndLowercase() {
        assertEquals(1, VowelsCount.vowelsCount("fly"));
    }

    @Test
    void testYAtEndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("FlY"));
    }

    @Test
    void testYAtEndMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("fLy"));
    }

    @Test
    void testYNotAtEndLowercase() {
        assertEquals(0, VowelsCount.vowelsCount("yellow"));
    }

    @Test
    void testYNotAtEndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("YeLloW"));
    }

    @Test
    void testYNotAtEndMixedCase() {
        assertEquals(0, VowelsCount.vowelsCount("yEllOw"));
    }

    @Test
    void testYAsOnlyCharacterLowercase() {
        assertEquals(1, VowelsCount.vowelsCount("y"));
    }

    @Test
    void testYAsOnlyCharacterUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("Y"));
    }

    @Test
    void testWordWithYAndOtherVowelsLowercase() {
        assertEquals(2, VowelsCount.vowelsCount("key"));
    }

    @Test
    void testWordWithYAndOtherVowelsUppercase() {
        assertEquals(2, VowelsCount.vowelsCount("KeY"));
    }

    @Test
    void testWordWithYAndOtherVowelsMixedCase() {
        assertEquals(2, VowelsCount.vowelsCount("kEy"));
    }

    @Test
    void testWordWithMultipleYsAtEnd() {
        assertEquals(1, VowelsCount.vowelsCount("byy"));
    }

    @Test
    void testWordWithMultipleYsAtEndUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("bYY"));
    }

    @Test
    void testWordWithMultipleYsAtEndMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("bYy"));
    }

    @Test
    void testWordWithOnlyYLowercase() {
        assertEquals(1, VowelsCount.vowelsCount("yyyy"));
    }

    @Test
    void testWordWithOnlyYUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("YYYY"));
    }

    @Test
    void testWordWithOnlyYMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("YYyY"));
    }

    @Test
    void testWordWithYAndOtherCharacters() {
        assertEquals(1, VowelsCount.vowelsCount("xyz"));
    }

    @Test
    void testWordWithYAndOtherCharactersUppercase() {
        assertEquals(1, VowelsCount.vowelsCount("xYz"));
    }

    @Test
    void testWordWithYAndOtherCharactersMixedCase() {
        assertEquals(1, VowelsCount.vowelsCount("xYZ"));
    }

    @Test
    void testWordWithYAndOtherVowelsAndConsonants() {
        assertEquals(3, VowelsCount.vowelsCount("abey"));
    }

    @Test
    void testWordWithYAndOtherVowelsAndConsonantsUppercase() {
        assertEquals(3, VowelsCount.vowelsCount("AbEy"));
    }

    @Test
    void testWordWithYAndOtherVowelsAndConsonantsMixedCase() {
        assertEquals(3, VowelsCount.vowelsCount("aBeY"));
    }
}