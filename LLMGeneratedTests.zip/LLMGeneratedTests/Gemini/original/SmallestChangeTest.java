package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SmallestChangeTest {

    @Test
    void smallestChange_emptyList() {
        List<Integer> arr = Collections.emptyList();
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_singleElementList() {
        List<Integer> arr = Collections.singletonList(1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_twoElementPalindrome() {
        List<Integer> arr = Arrays.asList(1, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_twoElementNotPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_threeElementPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_threeElementNotPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 3);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_fourElementPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_fourElementNotPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4);
        assertEquals(2, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example1() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 5, 4, 7, 9, 6);
        assertEquals(4, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example2() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 3, 2, 2);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_example3() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_allSameElements() {
        List<Integer> arr = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_alternatingElements() {
        List<Integer> arr = Arrays.asList(1, 2, 1, 2, 1);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_almostPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 2, 4);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_longerList() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_longerListNotPalindrome() {
        List<Integer> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2, 2);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_negativeNumbers() {
        List<Integer> arr = Arrays.asList(-1, -2, -3, -2, -1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_mixedPositiveNegative() {
        List<Integer> arr = Arrays.asList(-1, 2, 3, 2, -1);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_mixedPositiveNegativeNotPalindrome() {
        List<Integer> arr = Arrays.asList(-1, 2, 3, 2, 1);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_zeroes() {
        List<Integer> arr = Arrays.asList(0, 0, 0, 0, 0);
        assertEquals(0, SmallestChange.smallestChange(arr));
    }

    @Test
    void smallestChange_zeroesNotPalindrome() {
        List<Integer> arr = Arrays.asList(0, 0, 0, 0, 1);
        assertEquals(1, SmallestChange.smallestChange(arr));
    }
}