package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MaxFillTest {

    @Test
    void testExample1() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 0));
        grid.add(Arrays.asList(0, 1, 0, 0));
        grid.add(Arrays.asList(1, 1, 1, 1));
        assertEquals(6, MaxFill.maxFill(grid, 1));
    }

    @Test
    void testExample2() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 1));
        grid.add(Arrays.asList(0, 0, 0, 0));
        grid.add(Arrays.asList(1, 1, 1, 1));
        grid.add(Arrays.asList(0, 1, 1, 1));
        assertEquals(5, MaxFill.maxFill(grid, 2));
    }

    @Test
    void testExample3() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 0));
        grid.add(Arrays.asList(0, 0, 0));
        assertEquals(0, MaxFill.maxFill(grid, 5));
    }

    @Test
    void testAllOnes() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        grid.add(Arrays.asList(1, 1, 1, 1));
        assertEquals(4, MaxFill.maxFill(grid, 2));
    }

    @Test
    void testAllOnesLargeCapacity() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        grid.add(Arrays.asList(1, 1, 1, 1));
        assertEquals(2, MaxFill.maxFill(grid, 9));
    }

    @Test
    void testEmptyGrid() {
        List<List<Integer>> grid = new ArrayList<>();
        assertEquals(0, MaxFill.maxFill(grid, 5));
    }

    @Test
    void testSingleRow() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 0, 1, 0, 1));
        assertEquals(3, MaxFill.maxFill(grid, 2));
    }

    @Test
    void testLargeGridSmallCapacity() {
        List<List<Integer>> grid = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            grid.add(Arrays.asList(1, 1, 1, 1, 1));
        }
        assertEquals(50, MaxFill.maxFill(grid, 1));
    }

    @Test
    void testZeroesAndOnesMixed() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 1, 0, 1));
        grid.add(Arrays.asList(1, 0, 1, 0));
        assertEquals(2, MaxFill.maxFill(grid, 2));
    }

    @Test
    void testSingleOne() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 1, 0));
        assertEquals(1, MaxFill.maxFill(grid, 1));
    }

    @Test
    void testSingleZero() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(0, 0, 0, 0));
        assertEquals(0, MaxFill.maxFill(grid, 1));
    }

    @Test
    void testLargeCapacity() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1, 1));
        assertEquals(1, MaxFill.maxFill(grid, 4));
    }

    @Test
    void testCapacityGreaterThanSum() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 0, 0, 0));
        assertEquals(1, MaxFill.maxFill(grid, 5));
    }

    @Test
    void testMultipleRowsDifferentSums() {
        List<List<Integer>> grid = new ArrayList<>();
        grid.add(Arrays.asList(1, 1, 1));
        grid.add(Arrays.asList(1, 0, 0));
        grid.add(Arrays.asList(0, 0, 0));
        assertEquals(2, MaxFill.maxFill(grid, 2));
    }
}