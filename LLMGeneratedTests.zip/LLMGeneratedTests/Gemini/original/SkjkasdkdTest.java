package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SkjkasdkdTest {

    @Test
    void skjkasdkd_emptyList_returnsZero() {
        List<Integer> lst = Collections.emptyList();
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_noPrimes_returnsZero() {
        List<Integer> lst = Arrays.asList(4, 6, 8, 9, 10);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_singlePrime_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_multiplePrimes_returnsSumOfDigitsOfLargest() {
        List<Integer> lst = Arrays.asList(2, 3, 5, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_mixedPrimesAndNonPrimes_returnsSumOfDigitsOfLargest() {
        List<Integer> lst = Arrays.asList(4, 6, 2, 3, 5, 7, 8, 9);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithZero_returnsSumOfDigitsOfLargestPrime() {
        List<Integer> lst = Arrays.asList(0, 2, 3, 5);
        assertEquals(5, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithOne_returnsSumOfDigitsOfLargestPrime() {
        List<Integer> lst = Arrays.asList(1, 2, 3, 5);
        assertEquals(5, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithNegativeNumbers_ignoresNegativeNumbers() {
        List<Integer> lst = Arrays.asList(-2, -3, 2, 3, 5);
        assertEquals(5, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_largePrime_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(101);
        assertEquals(2, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_multipleOccurrencesOfSamePrime_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(7, 7, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_primeNumberAtTheEnd_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(4, 6, 8, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_primeNumberAtTheBeginning_returnsSumOfDigits() {
        List<Integer> lst = Arrays.asList(7, 4, 6, 8);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_allNumbersAreOne_returnsZero() {
        List<Integer> lst = Arrays.asList(1, 1, 1, 1);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_allNumbersAreZero_returnsZero() {
        List<Integer> lst = Arrays.asList(0, 0, 0, 0);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_listWithOneAndZero_returnsZero() {
        List<Integer> lst = Arrays.asList(0, 1, 0, 1);
        assertEquals(0, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example1() {
        List<Integer> lst = Arrays.asList(0, 3, 2, 1, 3, 5, 7, 4, 5, 5, 5, 2, 181, 32, 4, 32, 3, 2, 32, 324, 4, 3);
        assertEquals(10, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example2() {
        List<Integer> lst = Arrays.asList(1, 0, 1, 8, 2, 4597, 2, 1, 3, 40, 1, 2, 1, 2, 4, 2, 5, 1);
        assertEquals(25, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example3() {
        List<Integer> lst = Arrays.asList(1, 3, 1, 32, 5107, 34, 83278, 109, 163, 23, 2323, 32, 30, 1, 9, 3);
        assertEquals(13, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example4() {
        List<Integer> lst = Arrays.asList(0, 724, 32, 71, 99, 32, 6, 0, 5, 91, 83, 0, 5, 6);
        assertEquals(11, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example5() {
        List<Integer> lst = Arrays.asList(0, 81, 12, 3, 1, 21);
        assertEquals(3, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example6() {
        List<Integer> lst = Arrays.asList(0, 8, 1, 2, 1, 7);
        assertEquals(7, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example7() {
        List<Integer> lst = Arrays.asList(8191);
        assertEquals(19, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example8() {
        List<Integer> lst = Arrays.asList(8191, 123456, 127, 7);
        assertEquals(19, Skjkasdkd.skjkasdkd(lst));
    }

    @Test
    void skjkasdkd_example9() {
        List<Integer> lst = Arrays.asList(127, 97, 8192);
        assertEquals(10, Skjkasdkd.skjkasdkd(lst));
    }
}