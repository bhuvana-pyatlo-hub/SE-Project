package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BfTest {

    @Test
    void bf_Jupiter_Neptune() {
        assertEquals(Arrays.asList("Saturn", "Uranus"), Bf.bf("Jupiter", "Neptune"));
    }

    @Test
    void bf_Earth_Mercury() {
        assertEquals(Collections.singletonList("Venus"), Bf.bf("Earth", "Mercury"));
    }

    @Test
    void bf_Mercury_Uranus() {
        assertEquals(Arrays.asList("Venus", "Earth", "Mars", "Jupiter", "Saturn"), Bf.bf("Mercury", "Uranus"));
    }

    @Test
    void bf_Neptune_Venus() {
        assertEquals(Arrays.asList("Earth", "Mars", "Jupiter", "Saturn", "Uranus"), Bf.bf("Neptune", "Venus"));
    }

    @Test
    void bf_Earth_Earth() {
        assertEquals(Collections.emptyList(), Bf.bf("Earth", "Earth"));
    }

    @Test
    void bf_Mars_Earth() {
        assertEquals(Collections.emptyList(), Bf.bf("Mars", "Earth"));
    }

    @Test
    void bf_Jupiter_Makemake() {
        assertEquals(Collections.emptyList(), Bf.bf("Jupiter", "Makemake"));
    }

    @Test
    void bf_InvalidPlanet1() {
        assertEquals(Collections.emptyList(), Bf.bf("X", "Neptune"));
    }

    @Test
    void bf_InvalidPlanet2() {
        assertEquals(Collections.emptyList(), Bf.bf("Jupiter", "Y"));
    }

    @Test
    void bf_BothInvalidPlanets() {
        assertEquals(Collections.emptyList(), Bf.bf("A", "B"));
    }

    @Test
    void bf_Mercury_Neptune() {
        List<Object> expected = Arrays.asList("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Mercury", "Neptune"));
    }

    @Test
    void bf_Neptune_Mercury() {
        List<Object> expected = Arrays.asList("Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Neptune", "Mercury"));
    }

    @Test
    void bf_Venus_Neptune() {
        List<Object> expected = Arrays.asList("Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Venus", "Neptune"));
    }

    @Test
    void bf_Neptune_Venus_Reversed() {
        List<Object> expected = Arrays.asList("Earth", "Mars", "Jupiter", "Saturn", "Uranus");
        assertEquals(expected, Bf.bf("Neptune", "Venus"));
    }

    @Test
    void bf_Earth_Uranus() {
        List<Object> expected = Arrays.asList("Mars", "Jupiter", "Saturn");
        assertEquals(expected, Bf.bf("Earth", "Uranus"));
    }

    @Test
    void bf_Uranus_Earth() {
        List<Object> expected = Arrays.asList("Mars", "Jupiter", "Saturn");
        assertEquals(expected, Bf.bf("Uranus", "Earth"));
    }

    @Test
    void bf_Mars_Saturn() {
        List<Object> expected = Arrays.asList("Jupiter");
        assertEquals(expected, Bf.bf("Mars", "Saturn"));
    }

    @Test
    void bf_Saturn_Mars() {
        List<Object> expected = Arrays.asList("Jupiter");
        assertEquals(expected, Bf.bf("Saturn", "Mars"));
    }

    @Test
    void bf_Venus_Earth() {
        assertEquals(Collections.emptyList(), Bf.bf("Venus", "Earth"));
    }

    @Test
    void bf_Earth_Venus() {
        assertEquals(Collections.emptyList(), Bf.bf("Earth", "Venus"));
    }
}