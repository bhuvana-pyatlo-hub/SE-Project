package original;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DerivativeTest {

    @Test
    void testEmptyList() {
        List<Integer> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testSingleElementList() {
        List<Integer> input = Arrays.asList(1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testTwoElementList() {
        List<Integer> input = Arrays.asList(1, 2);
        List<Object> expected = Arrays.asList(2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testThreeElementList() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testFourElementList() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4);
        List<Object> expected = Arrays.asList(2, 6, 12);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithZero() {
        List<Integer> input = Arrays.asList(3, 2, 1, 0, 4);
        List<Object> expected = Arrays.asList(2, 2, 0, 16);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithNegativeNumbers() {
        List<Integer> input = Arrays.asList(3, -2, 1);
        List<Object> expected = Arrays.asList(-2, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithLargeNumbers() {
        List<Integer> input = Arrays.asList(3, 200, 1);
        List<Object> expected = Arrays.asList(200, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithAllZeros() {
        List<Integer> input = Arrays.asList(0, 0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithMixedPositiveNegativeZeros() {
        List<Integer> input = Arrays.asList(0, 1, -1, 0, 2);
        List<Object> expected = Arrays.asList(1, -2, 0, 8);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testExample1() {
        List<Integer> input = Arrays.asList(3, 1, 2, 4, 5);
        List<Object> expected = Arrays.asList(1, 4, 12, 20);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testExample2() {
        List<Integer> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testExample3() {
        List<Integer> input = Arrays.asList(3, 2, 1);
        List<Object> expected = Arrays.asList(2, 2);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testExample4() {
        List<Integer> input = Arrays.asList(3, 2, 1, 0, 4);
        List<Object> expected = Arrays.asList(2, 2, 0, 16);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithOnlyOneNonZeroElementAtTheEnd() {
        List<Integer> input = Arrays.asList(0, 0, 0, 5);
        List<Object> expected = Arrays.asList(0, 0, 15);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithAllSameNumbers() {
        List<Integer> input = Arrays.asList(2, 2, 2, 2);
        List<Object> expected = Arrays.asList(2, 4, 6);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithDecreasingNumbers() {
        List<Integer> input = Arrays.asList(5, 4, 3, 2, 1);
        List<Object> expected = Arrays.asList(4, 6, 6, 4);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithIncreasingNumbers() {
        List<Integer> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(2, 6, 12, 20);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithZeroAsFirstElement() {
        List<Integer> input = Arrays.asList(0, 1, 2, 3);
        List<Object> expected = Arrays.asList(1, 4, 9);
        assertEquals(expected, Derivative.derivative(input));
    }

    @Test
    void testListWithZeroAsLastElement() {
        List<Integer> input = Arrays.asList(1, 2, 3, 0);
        List<Object> expected = Arrays.asList(2, 6, 0);
        assertEquals(expected, Derivative.derivative(input));
    }
}