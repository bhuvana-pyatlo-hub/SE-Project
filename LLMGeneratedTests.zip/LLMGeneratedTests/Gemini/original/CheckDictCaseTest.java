package original;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CheckDictCaseTest {

    @Test
    void testEmptyDict() {
        Map<String, String> emptyDict = new HashMap<>();
        assertFalse(CheckDictCase.checkDictCase(emptyDict));
    }

    @Test
    void testAllLowerCase() {
        Map<String, String> lowerCaseDict = new HashMap<>();
        lowerCaseDict.put("a", "apple");
        lowerCaseDict.put("b", "banana");
        assertTrue(CheckDictCase.checkDictCase(lowerCaseDict));
    }

    @Test
    void testAllUpperCase() {
        Map<String, String> upperCaseDict = new HashMap<>();
        upperCaseDict.put("A", "apple");
        upperCaseDict.put("B", "banana");
        assertTrue(CheckDictCase.checkDictCase(upperCaseDict));
    }

    @Test
    void testMixedCase() {
        Map<String, String> mixedCaseDict = new HashMap<>();
        mixedCaseDict.put("a", "apple");
        mixedCaseDict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(mixedCaseDict));
    }

    @Test
    void testNonStringKey() {
        Map<Object, String> nonStringKeyDict = new HashMap<>();
        nonStringKeyDict.put("a", "apple");
        nonStringKeyDict.put(8, "banana");
        assertFalse(CheckDictCase.checkDictCase(nonStringKeyDict));
    }

    @Test
    void testNullDict() {
        assertFalse(CheckDictCase.checkDictCase(null));
    }

    @Test
    void testNotAMap() {
        assertFalse(CheckDictCase.checkDictCase("not a map"));
    }

    @Test
    void testSingleLowerCase() {
        Map<String, String> singleLowerCaseDict = new HashMap<>();
        singleLowerCaseDict.put("a", "apple");
        assertTrue(CheckDictCase.checkDictCase(singleLowerCaseDict));
    }

    @Test
    void testSingleUpperCase() {
        Map<String, String> singleUpperCaseDict = new HashMap<>();
        singleUpperCaseDict.put("A", "apple");
        assertTrue(CheckDictCase.checkDictCase(singleUpperCaseDict));
    }

    @Test
    void testLowerCaseWithNumbers() {
        Map<String, String> lowerCaseWithNumbersDict = new HashMap<>();
        lowerCaseWithNumbersDict.put("a1", "apple");
        lowerCaseWithNumbersDict.put("b2", "banana");
        assertTrue(CheckDictCase.checkDictCase(lowerCaseWithNumbersDict));
    }

    @Test
    void testUpperCaseWithNumbers() {
        Map<String, String> upperCaseWithNumbersDict = new HashMap<>();
        upperCaseWithNumbersDict.put("A1", "apple");
        upperCaseWithNumbersDict.put("B2", "banana");
        assertTrue(CheckDictCase.checkDictCase(upperCaseWithNumbersDict));
    }

    @Test
    void testMixedCaseWithNumbers() {
        Map<String, String> mixedCaseWithNumbersDict = new HashMap<>();
        mixedCaseWithNumbersDict.put("a1", "apple");
        mixedCaseWithNumbersDict.put("A2", "banana");
        assertFalse(CheckDictCase.checkDictCase(mixedCaseWithNumbersDict));
    }

    @Test
    void testEmptyStringKey() {
        Map<String, String> emptyStringKeyDict = new HashMap<>();
        emptyStringKeyDict.put("", "apple");
        assertTrue(CheckDictCase.checkDictCase(emptyStringKeyDict));
    }

    @Test
    void testMixedCaseAndEmptyStringKey() {
        Map<String, String> mixedCaseAndEmptyStringKeyDict = new HashMap<>();
        mixedCaseAndEmptyStringKeyDict.put("", "apple");
        mixedCaseAndEmptyStringKeyDict.put("A", "banana");
        assertFalse(CheckDictCase.checkDictCase(mixedCaseAndEmptyStringKeyDict));
    }

    @Test
    void testMixedCaseAndEmptyStringKey2() {
        Map<String, String> mixedCaseAndEmptyStringKeyDict = new HashMap<>();
        mixedCaseAndEmptyStringKeyDict.put("", "apple");
        mixedCaseAndEmptyStringKeyDict.put("a", "banana");
        assertFalse(CheckDictCase.checkDictCase(mixedCaseAndEmptyStringKeyDict));
    }

    @Test
    void testDictWithSpecialCharactersLowerCase() {
        Map<String, String> dictWithSpecialCharacters = new HashMap<>();
        dictWithSpecialCharacters.put("!@#", "value1");
        dictWithSpecialCharacters.put("$%^", "value2");
        assertTrue(CheckDictCase.checkDictCase(dictWithSpecialCharacters));
    }

    @Test
    void testDictWithSpecialCharactersUpperCase() {
        Map<String, String> dictWithSpecialCharacters = new HashMap<>();
        dictWithSpecialCharacters.put("!@#".toUpperCase(), "value1");
        dictWithSpecialCharacters.put("$%^".toUpperCase(), "value2");
        assertTrue(CheckDictCase.checkDictCase(dictWithSpecialCharacters));
    }

    @Test
    void testDictWithSpecialCharactersMixedCase() {
        Map<String, String> dictWithSpecialCharacters = new HashMap<>();
        dictWithSpecialCharacters.put("!@#", "value1");
        dictWithSpecialCharacters.put("$%^".toUpperCase(), "value2");
        assertFalse(CheckDictCase.checkDictCase(dictWithSpecialCharacters));
    }

    @Test
    void testDictWithUnicodeLowerCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("你好", "value1");
        dict.put("世界", "value2");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testDictWithUnicodeUpperCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("你好".toUpperCase(), "value1");
        dict.put("世界".toUpperCase(), "value2");
        assertTrue(CheckDictCase.checkDictCase(dict));
    }

    @Test
    void testDictWithUnicodeMixedCase() {
        Map<String, String> dict = new HashMap<>();
        dict.put("你好", "value1");
        dict.put("世界".toUpperCase(), "value2");
        assertFalse(CheckDictCase.checkDictCase(dict));
    }
}