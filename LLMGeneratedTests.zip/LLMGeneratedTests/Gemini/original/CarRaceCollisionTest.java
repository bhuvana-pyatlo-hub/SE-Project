package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CarRaceCollisionTest {

    @Test
    void carRaceCollision_positiveSmallValue() {
        assertEquals(4, CarRaceCollision.carRaceCollision(2));
    }

    @Test
    void carRaceCollision_positiveMediumValue() {
        assertEquals(9, CarRaceCollision.carRaceCollision(3));
    }

    @Test
    void carRaceCollision_positiveLargeValue() {
        assertEquals(16, CarRaceCollision.carRaceCollision(4));
    }

    @Test
    void carRaceCollision_positiveMaxValue() {
        assertEquals(64, CarRaceCollision.carRaceCollision(8));
    }

    @Test
    void carRaceCollision_positiveTen() {
        assertEquals(100, CarRaceCollision.carRaceCollision(10));
    }

    @Test
    void carRaceCollision_one() {
        assertEquals(1, CarRaceCollision.carRaceCollision(1));
    }

    @Test
    void carRaceCollision_zero() {
        assertEquals(0, CarRaceCollision.carRaceCollision(0));
    }

    @Test
    void carRaceCollision_twenty() {
        assertEquals(400, CarRaceCollision.carRaceCollision(20));
    }

    @Test
    void carRaceCollision_thirty() {
        assertEquals(900, CarRaceCollision.carRaceCollision(30));
    }

    @Test
    void carRaceCollision_forty() {
        assertEquals(1600, CarRaceCollision.carRaceCollision(40));
    }

    @Test
    void carRaceCollision_fifty() {
        assertEquals(2500, CarRaceCollision.carRaceCollision(50));
    }

    @Test
    void carRaceCollision_sixty() {
        assertEquals(3600, CarRaceCollision.carRaceCollision(60));
    }

    @Test
    void carRaceCollision_seventy() {
        assertEquals(4900, CarRaceCollision.carRaceCollision(70));
    }

    @Test
    void carRaceCollision_eighty() {
        assertEquals(6400, CarRaceCollision.carRaceCollision(80));
    }

    @Test
    void carRaceCollision_ninety() {
        assertEquals(8100, CarRaceCollision.carRaceCollision(90));
    }

    @Test
    void carRaceCollision_hundred() {
        assertEquals(10000, CarRaceCollision.carRaceCollision(100));
    }

    @Test
    void carRaceCollision_eleven() {
        assertEquals(121, CarRaceCollision.carRaceCollision(11));
    }

    @Test
    void carRaceCollision_twelve() {
        assertEquals(144, CarRaceCollision.carRaceCollision(12));
    }

    @Test
    void carRaceCollision_thirteen() {
        assertEquals(169, CarRaceCollision.carRaceCollision(13));
    }

    @Test
    void carRaceCollision_fourteen() {
        assertEquals(196, CarRaceCollision.carRaceCollision(14));
    }
}