package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MinpathTest {

    @Test
    void minpath_3x3_k3_example1() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        int k = 3;
        List<Integer> expected = Arrays.asList(1, 2, 1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_k1_example2() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(5, 9, 3),
                Arrays.asList(4, 1, 6),
                Arrays.asList(7, 8, 2)
        );
        int k = 1;
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_4x4_k4_example3() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2, 3, 4),
                Arrays.asList(5, 6, 7, 8),
                Arrays.asList(9, 10, 11, 12),
                Arrays.asList(13, 14, 15, 16)
        );
        int k = 4;
        List<Integer> expected = Arrays.asList(1, 2, 1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_4x4_k7_example4() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(6, 4, 13, 10),
                Arrays.asList(5, 7, 12, 1),
                Arrays.asList(3, 16, 11, 15),
                Arrays.asList(8, 14, 9, 2)
        );
        int k = 7;
        List<Integer> expected = Arrays.asList(1, 10, 1, 10, 1, 10, 1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_4x4_k5_example5() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(8, 14, 9, 2),
                Arrays.asList(6, 4, 13, 15),
                Arrays.asList(5, 7, 1, 12),
                Arrays.asList(3, 10, 11, 16)
        );
        int k = 5;
        List<Integer> expected = Arrays.asList(1, 7, 1, 7, 1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_4x4_k9_example6() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(11, 8, 7, 2),
                Arrays.asList(5, 16, 14, 4),
                Arrays.asList(9, 3, 15, 6),
                Arrays.asList(12, 13, 10, 1)
        );
        int k = 9;
        List<Integer> expected = Arrays.asList(1, 6, 1, 6, 1, 6, 1, 6, 1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_4x4_k12_example7() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(12, 13, 10, 1),
                Arrays.asList(9, 3, 15, 6),
                Arrays.asList(5, 16, 14, 4),
                Arrays.asList(11, 8, 7, 2)
        );
        int k = 12;
        List<Integer> expected = Arrays.asList(1, 6, 1, 6, 1, 6, 1, 6, 1, 6, 1, 6);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_k8_example8() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(2, 7, 4),
                Arrays.asList(3, 1, 5),
                Arrays.asList(6, 8, 9)
        );
        int k = 8;
        List<Integer> expected = Arrays.asList(1, 3, 1, 3, 1, 3, 1, 3);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_k8_example9() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(6, 1, 5),
                Arrays.asList(3, 8, 9),
                Arrays.asList(2, 7, 4)
        );
        int k = 8;
        List<Integer> expected = Arrays.asList(1, 5, 1, 5, 1, 5, 1, 5);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_k10_example10() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2),
                Arrays.asList(3, 4)
        );
        int k = 10;
        List<Integer> expected = Arrays.asList(1, 2, 1, 2, 1, 2, 1, 2, 1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_k10_example11() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 3),
                Arrays.asList(3, 2)
        );
        int k = 10;
        List<Integer> expected = Arrays.asList(1, 3, 1, 3, 1, 3, 1, 3, 1, 3);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_k2() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2),
                Arrays.asList(3, 4)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_k1() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2),
                Arrays.asList(3, 4)
        );
        int k = 1;
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_k2() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_k1() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        int k = 1;
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_1_at_0_1() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(2, 1),
                Arrays.asList(3, 4)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_1_at_1_0() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(2, 3),
                Arrays.asList(1, 4)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_2x2_1_at_1_1() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(2, 3),
                Arrays.asList(4, 1)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 3);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_1_at_2_2() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(2, 3, 4),
                Arrays.asList(5, 6, 7),
                Arrays.asList(8, 9, 1)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 7);
        assertEquals(expected, Minpath.minpath(grid, k));
    }

    @Test
    void minpath_3x3_1_at_0_0() {
        List<List<Integer>> grid = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        int k = 2;
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, Minpath.minpath(grid, k));
    }
}