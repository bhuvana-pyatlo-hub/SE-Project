package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WillItFlyTest {

    @Test
    void willItFly_emptyList_returnsTrue() {
        List<Integer> q = new ArrayList<>();
        int w = 5;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_singleElementList_withinWeight_returnsTrue() {
        List<Integer> q = Arrays.asList(5);
        int w = 5;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_singleElementList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(6);
        int w = 5;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_balancedList_withinWeight_returnsTrue() {
        List<Integer> q = Arrays.asList(3, 2, 3);
        int w = 9;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_balancedList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(3, 2, 3);
        int w = 1;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_unbalancedList_withinWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2);
        int w = 5;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_unbalancedList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 3);
        int w = 5;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_balancedList_zeroWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 0, 1);
        int w = 0;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_balancedList_zeroSum_returnsTrue() {
        List<Integer> q = Arrays.asList(0, 0, 0);
        int w = 1;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_unbalancedList_zeroWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2);
        int w = 0;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_longBalancedList_withinWeight_returnsTrue() {
        List<Integer> q = Arrays.asList(1, 2, 3, 4, 5, 4, 3, 2, 1);
        int w = 30;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_longBalancedList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 3, 4, 5, 4, 3, 2, 1);
        int w = 20;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_longUnbalancedList_withinWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        int w = 50;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_longUnbalancedList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        int w = 10;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_evenLengthBalancedList_withinWeight_returnsTrue() {
        List<Integer> q = Arrays.asList(1, 2, 2, 1);
        int w = 10;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_evenLengthBalancedList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 2, 1);
        int w = 5;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_evenLengthUnbalancedList_withinWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 3, 4);
        int w = 15;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_evenLengthUnbalancedList_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(1, 2, 3, 4);
        int w = 5;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_negativeNumbers_balanced_withinWeight_returnsTrue() {
        List<Integer> q = Arrays.asList(-1, 2, -1);
        int w = 1;
        assertTrue(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_negativeNumbers_balanced_exceedsWeight_returnsFalse() {
        List<Integer> q = Arrays.asList(-1, 2, -1);
        int w = -1;
        assertFalse(WillItFly.willItFly(q, w));
    }

    @Test
    void willItFly_allSameElements_returnsTrue() {
        List<Integer> q = Arrays.asList(5, 5, 5, 5, 5);
        int w = 25;
        assertTrue(WillItFly.willItFly(q, w));
    }
}