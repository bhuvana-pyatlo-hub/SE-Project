package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SolveTest {

    @Test
    void solve_emptyString() {
        assertEquals("", Solve.solve(""));
    }

    @Test
    void solve_onlyNumbers() {
        assertEquals("4321", Solve.solve("1234"));
    }

    @Test
    void solve_onlyLowercaseLetters() {
        assertEquals("AB", Solve.solve("ab"));
    }

    @Test
    void solve_onlyUppercaseLetters() {
        assertEquals("AB", Solve.solve("ab"));
    }

    @Test
    void solve_mixedCaseLetters() {
        assertEquals("aSdF", Solve.solve("AsDf"));
    }

    @Test
    void solve_specialCharactersAndLetters() {
        assertEquals("#A@c", Solve.solve("#a@C"));
    }

    @Test
    void solve_specialCharactersNumbersAndLetters() {
        assertEquals("#aSDFw^45", Solve.solve("#AsdfW^45"));
    }

    @Test
    void solve_specialCharactersAndNumbers() {
        assertEquals("2@6#", Solve.solve("#6@2"));
    }

    @Test
    void solve_specialCharactersLettersMixedCase() {
        assertEquals("#$A^d", Solve.solve("#$a^D"));
    }

    @Test
    void solve_specialCharactersLowercaseLetters() {
        assertEquals("#CCC", Solve.solve("#ccc"));
    }

    @Test
    void solve_singleLowercaseLetter() {
        assertEquals("A", Solve.solve("a"));
    }

    @Test
    void solve_singleUppercaseLetter() {
        assertEquals("a", Solve.solve("A"));
    }

    @Test
    void solve_singleNumber() {
        assertEquals("1", Solve.solve("1"));
    }

    @Test
    void solve_singleSpecialCharacter() {
        assertEquals("#", Solve.solve("#"));
    }

    @Test
    void solve_numbersAndLowercase() {
        assertEquals("321a", Solve.solve("a123"));
    }

    @Test
    void solve_numbersAndUppercase() {
        assertEquals("321A", Solve.solve("A123"));
    }

    @Test
    void solve_boundaryCase_longStringWithMixedCharacters() {
        String input = "aBcDeFgHiJkLmNoPqRsTuVwXyZ1234567890!@#$%^&*()_+";
        String expected = "AbCdEfGhIjKlMnOpQrStUvWxYz0987654321!@#$%^&*()_+";
        assertEquals(expected, Solve.solve(input));
    }

    @Test
    void solve_stringWithSpaces() {
        assertEquals(" ", Solve.solve(" "));
    }

    @Test
    void solve_stringWithLeadingAndTrailingSpaces() {
        assertEquals("   ", Solve.solve("   "));
    }

    @Test
    void solve_stringWithInternalSpacesAndLetters() {
        assertEquals("A b C", Solve.solve("a B c"));
    }

    @Test
    void solve_stringWithOnlySpecialCharacters() {
        assertEquals("!@#$", Solve.solve("$#@!"));
    }
}