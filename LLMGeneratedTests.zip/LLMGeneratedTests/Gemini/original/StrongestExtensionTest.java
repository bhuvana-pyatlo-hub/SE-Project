package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class StrongestExtensionTest {

    @Test
    void strongestExtension_emptyExtensionsList() {
        List<String> extensions = new ArrayList<>();
        String result = StrongestExtension.strongestExtension("my_class", extensions);
        assertEquals("", result);
    }

    @Test
    void strongestExtension_singleExtension() {
        List<String> extensions = Arrays.asList("AA");
        String result = StrongestExtension.strongestExtension("my_class", extensions);
        assertEquals("my_class.AA", result);
    }

    @Test
    void strongestExtension_multipleExtensions_differentStrengths() {
        List<String> extensions = Arrays.asList("AA", "Be", "CC");
        String result = StrongestExtension.strongestExtension("my_class", extensions);
        assertEquals("my_class.AA", result);
    }

    @Test
    void strongestExtension_multipleExtensions_sameStrengths() {
        List<String> extensions = Arrays.asList("AA", "BB", "CC");
        String result = StrongestExtension.strongestExtension("my_class", extensions);
        assertEquals("my_class.AA", result);
    }

    @Test
    void strongestExtension_extensionsWithMixedCase() {
        List<String> extensions = Arrays.asList("SErviNGSliCes", "Cheese", "StuFfed");
        String result = StrongestExtension.strongestExtension("Slices", extensions);
        assertEquals("Slices.SErviNGSliCes", result);
    }

    @Test
    void strongestExtension_extensionsWithNumbersAndSymbols() {
        List<String> extensions = Arrays.asList("tEN", "niNE", "eIGHt8OKe");
        String result = StrongestExtension.strongestExtension("Watashi", extensions);
        assertEquals("Watashi.eIGHt8OKe", result);
    }

    @Test
    void strongestExtension_extensionsWithDifferentLengths() {
        List<String> extensions = Arrays.asList("nani", "NazeDa", "YEs.WeCaNe", "32145tggg");
        String result = StrongestExtension.strongestExtension("Boku123", extensions);
        assertEquals("Boku123.YEs.WeCaNe", result);
    }

    @Test
    void strongestExtension_extensionsWithEmptyString() {
        List<String> extensions = Arrays.asList("t", "eMptY", "nothing", "zeR00", "NuLl__", "123NoooneB321");
        String result = StrongestExtension.strongestExtension("__YESIMHERE", extensions);
        assertEquals("__YESIMHERE.NuLl__", result);
    }

    @Test
    void strongestExtension_extensionsWithAllLowerCase() {
        List<String> extensions = Arrays.asList("Ta", "TAR", "t234An", "cosSo");
        String result = StrongestExtension.strongestExtension("K", extensions);
        assertEquals("K.TAR", result);
    }

    @Test
    void strongestExtension_extensionsWithOnlyNumbersAndSymbols() {
        List<String> extensions = Arrays.asList("Tab", "123", "781345", "-_-");
        String result = StrongestExtension.strongestExtension("__HAHA", extensions);
        assertEquals("__HAHA.123", result);
    }

    @Test
    void strongestExtension_extensionsWithNegativeStrength() {
        List<String> extensions = Arrays.asList("HhAas", "okIWILL123", "WorkOut", "Fails", "-_-");
        String result = StrongestExtension.strongestExtension("YameRore", extensions);
        assertEquals("YameRore.okIWILL123", result);
    }

    @Test
    void strongestExtension_extensionsWithEqualStrength() {
        List<String> extensions = Arrays.asList("Die", "NowW", "Wow", "WoW");
        String result = StrongestExtension.strongestExtension("finNNalLLly", extensions);
        assertEquals("finNNalLLly.WoW", result);
    }

    @Test
    void strongestExtension_shortClassName() {
        List<String> extensions = Arrays.asList("Bb", "91245");
        String result = StrongestExtension.strongestExtension("_", extensions);
        assertEquals("_.Bb", result);
    }

    @Test
    void strongestExtension_shortClassName2() {
        List<String> extensions = Arrays.asList("671235", "Bb");
        String result = StrongestExtension.strongestExtension("Sp", extensions);
        assertEquals("Sp.671235", result);
    }

    @Test
    void strongestExtension_extensionWithOnlyUpperCase() {
        List<String> extensions = Arrays.asList("ABC", "def");
        String result = StrongestExtension.strongestExtension("test", extensions);
        assertEquals("test.ABC", result);
    }

    @Test
    void strongestExtension_extensionWithOnlyLowerCase() {
        List<String> extensions = Arrays.asList("abc", "DEF");
        String result = StrongestExtension.strongestExtension("test", extensions);
        assertEquals("test.DEF", result);
    }

    @Test
    void strongestExtension_extensionWithMixedCaseAndNumbers() {
        List<String> extensions = Arrays.asList("aBc123", "DeF456");
        String result = StrongestExtension.strongestExtension("test", extensions);
        assertEquals("test.DeF456", result);
    }

    @Test
    void strongestExtension_classNameWithEmptyString() {
        List<String> extensions = Arrays.asList("ext1", "ext2");
        String result = StrongestExtension.strongestExtension("", extensions);
        assertEquals(".ext1", result);
    }

    @Test
    void strongestExtension_extensionWithSpecialCharacters() {
        List<String> extensions = Arrays.asList("!@#", "$%^");
        String result = StrongestExtension.strongestExtension("test", extensions);
        assertEquals("test.!@#", result);
    }

    @Test
    void strongestExtension_extensionWithEmptyStringInList() {
        List<String> extensions = Arrays.asList("", "ext1");
        String result = StrongestExtension.strongestExtension("test", extensions);
        assertEquals("test.ext1", result);
    }
}