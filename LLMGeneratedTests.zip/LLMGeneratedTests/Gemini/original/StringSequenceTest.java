package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringSequenceTest {

    @Test
    void stringSequence_positiveNumber() {
        assertEquals("0 1 2 3 4 5", StringSequence.stringSequence(5));
    }

    @Test
    void stringSequence_zero() {
        assertEquals("0", StringSequence.stringSequence(0));
    }

    @Test
    void stringSequence_negativeNumber() {
        assertEquals("0", StringSequence.stringSequence(-1));
    }

    @Test
    void stringSequence_largePositiveNumber() {
        assertEquals("0 1 2 3 4 5 6 7 8 9 10", StringSequence.stringSequence(10));
    }

    @Test
    void stringSequence_one() {
        assertEquals("0 1", StringSequence.stringSequence(1));
    }

    @Test
    void stringSequence_smallPositiveNumber() {
        assertEquals("0 1 2 3", StringSequence.stringSequence(3));
    }

    @Test
    void stringSequence_boundaryValue() {
        assertEquals("0 100", StringSequence.stringSequence(100));
    }
}