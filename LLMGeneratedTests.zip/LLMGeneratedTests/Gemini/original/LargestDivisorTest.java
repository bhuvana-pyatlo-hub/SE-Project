package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LargestDivisorTest {

    @Test
    void largestDivisor_validInput_returnsLargestDivisor() {
        assertEquals(5, LargestDivisor.largestDivisor(15));
    }

    @Test
    void largestDivisor_primeNumber_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(7));
    }

    @Test
    void largestDivisor_evenNumber_returnsHalf() {
        assertEquals(50, LargestDivisor.largestDivisor(100));
    }

    @Test
    void largestDivisor_smallNumber_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(3));
    }

    @Test
    void largestDivisor_anotherEvenNumber_returnsHalf() {
        assertEquals(5, LargestDivisor.largestDivisor(10));
    }

    @Test
    void largestDivisor_perfectSquare_returnsSquareRoot() {
        assertEquals(7, LargestDivisor.largestDivisor(49));
    }

    @Test
    void largestDivisor_numberWithMultipleDivisors_returnsLargest() {
        assertEquals(12, LargestDivisor.largestDivisor(24));
    }

    @Test
    void largestDivisor_numberWithOnlyOneAndItselfAsDivisors_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(2));
    }

    @Test
    void largestDivisor_numberCloseToZero_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(1));
    }

    @Test
    void largestDivisor_anotherPrimeNumber_returnsOne() {
        assertEquals(1, LargestDivisor.largestDivisor(11));
    }

    @Test
    void largestDivisor_numberWithManyDivisors_returnsLargest() {
        assertEquals(36, LargestDivisor.largestDivisor(72));
    }

    @Test
    void largestDivisor_numberWithSmallDivisor_returnsLargest() {
        assertEquals(2, LargestDivisor.largestDivisor(4));
    }

    @Test
    void largestDivisor_numberWithDivisorCloseToItself_returnsThatDivisor() {
        assertEquals(99, LargestDivisor.largestDivisor(990));
    }

    @Test
    void largestDivisor_numberWithDivisorInTheMiddle_returnsLargest() {
        assertEquals(10, LargestDivisor.largestDivisor(20));
    }

    @Test
    void largestDivisor_anotherNumberWithMultipleDivisors_returnsLargest() {
        assertEquals(8, LargestDivisor.largestDivisor(16));
    }

    @Test
    void largestDivisor_numberWithDivisorGreaterThanOne_returnsLargest() {
        assertEquals(3, LargestDivisor.largestDivisor(9));
    }

    @Test
    void largestDivisor_numberWithDivisorCloseToHalf_returnsLargest() {
        assertEquals(16, LargestDivisor.largestDivisor(32));
    }

    @Test
    void largestDivisor_numberWithDivisorSlightlyLessThanHalf_returnsLargest() {
        assertEquals(15, LargestDivisor.largestDivisor(30));
    }

    @Test
    void largestDivisor_numberWithDivisorSlightlyMoreThanHalf_returnsLargest() {
        assertEquals(17, LargestDivisor.largestDivisor(34));
    }

    @Test
    void largestDivisor_numberWithDivisorEqualToOneThird_returnsLargest() {
        assertEquals(10, LargestDivisor.largestDivisor(30));
    }
}