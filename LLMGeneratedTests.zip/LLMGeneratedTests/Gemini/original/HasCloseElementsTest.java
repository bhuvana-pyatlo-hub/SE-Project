package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class HasCloseElementsTest {

    @Test
    void testHasCloseElements_emptyList() {
        List<Double> numbers = Collections.emptyList();
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_singleElementList() {
        List<Double> numbers = Collections.singletonList(1.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_noCloseElements() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_closeElementsFound() {
        List<Double> numbers = Arrays.asList(1.0, 2.8, 3.0, 4.0, 5.0, 2.0);
        Double threshold = 0.3;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_closeElementsFound2() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2);
        Double threshold = 0.3;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_noCloseElementsSmallThreshold() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.9, 4.0, 5.0, 2.2);
        Double threshold = 0.05;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_closeElementsFoundLargeThreshold() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0);
        Double threshold = 0.95;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_noCloseElementsLargeThreshold() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 5.9, 4.0, 5.0);
        Double threshold = 0.8;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_closeElementsFoundSmallDifference() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 3.0, 4.0, 5.0, 2.0);
        Double threshold = 0.1;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_closeElementsFoundThresholdEqualsDifference() {
        List<Double> numbers = Arrays.asList(1.0, 2.0);
        Double threshold = 1.0;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_closeElementsFoundThresholdSlightlyLargerThanDifference() {
        List<Double> numbers = Arrays.asList(1.0, 2.0);
        Double threshold = 1.01;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_allElementsSame() {
        List<Double> numbers = Arrays.asList(2.0, 2.0, 2.0);
        Double threshold = 0.1;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_negativeNumbers() {
        List<Double> numbers = Arrays.asList(-1.0, -2.0, -3.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_negativeAndPositiveNumbers() {
        List<Double> numbers = Arrays.asList(-1.0, 1.0);
        Double threshold = 1.5;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_zeroThreshold() {
        List<Double> numbers = Arrays.asList(1.0, 1.0);
        Double threshold = 0.0;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_zeroThresholdNoMatch() {
        List<Double> numbers = Arrays.asList(1.0, 2.0);
        Double threshold = 0.0;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_largeThreshold() {
        List<Double> numbers = Arrays.asList(1.0, 100.0);
        Double threshold = 200.0;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_identicalElementsNoMatch() {
        List<Double> numbers = Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_identicalElementsMatch() {
        List<Double> numbers = Arrays.asList(1.1, 2.2, 3.1, 4.1, 5.1);
        Double threshold = 1.0;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_duplicateValues() {
        List<Double> numbers = Arrays.asList(1.0, 2.0, 1.0);
        Double threshold = 0.5;
        assertTrue(HasCloseElements.hasCloseElements(numbers, threshold));
    }

    @Test
    void testHasCloseElements_largeListNoMatch() {
        List<Double> numbers = Arrays.asList(1.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0, 100.0);
        Double threshold = 0.5;
        assertFalse(HasCloseElements.hasCloseElements(numbers, threshold));
    }
}