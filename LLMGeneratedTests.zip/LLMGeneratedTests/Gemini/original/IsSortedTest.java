package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class IsSortedTest {

    @Test
    void isSorted_emptyList_returnsTrue() {
        List<Object> list = Collections.emptyList();
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_singleElementList_returnsTrue() {
        List<Object> list = Collections.singletonList(5);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_sortedList_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_unsortedList_returnsFalse() {
        List<Object> list = Arrays.asList(1, 3, 2, 4, 5);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_sortedListLong_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_unsortedListLong_returnsFalse() {
        List<Object> list = Arrays.asList(1, 3, 2, 4, 5, 6, 7);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithTwoDuplicates_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 2, 3, 3, 4);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithMoreThanTwoDuplicates_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 2, 2, 3, 4);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithMoreThanTwoDuplicatesConsecutive_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 3, 3, 3, 4);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithDuplicatesAtStart_returnsTrue() {
        List<Object> list = Arrays.asList(2, 2, 3, 4, 5);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithDuplicatesAtEnd_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3, 4, 4);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithDecreasingOrder_returnsFalse() {
        List<Object> list = Arrays.asList(3, 2, 1);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithSameElements_returnsTrue() {
        List<Object> list = Arrays.asList(5, 5, 5, 5);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithTwoElementsSorted_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithTwoElementsUnsorted_returnsFalse() {
        List<Object> list = Arrays.asList(2, 1);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithThreeElementsSorted_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 3);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithThreeElementsUnsorted_returnsFalse() {
        List<Object> list = Arrays.asList(1, 3, 2);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithBoundaryValues_returnsTrue() {
        List<Object> list = Arrays.asList(0, 1, 2, 3);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithLargeValues_returnsTrue() {
        List<Object> list = Arrays.asList(100, 200, 300);
        assertTrue(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithMixedDuplicatesAndUnsorted_returnsFalse() {
        List<Object> list = Arrays.asList(1, 2, 2, 2, 3, 1);
        assertFalse(IsSorted.isSorted(list));
    }

    @Test
    void isSorted_listWithDuplicatesAndSorted_returnsTrue() {
        List<Object> list = Arrays.asList(1, 2, 2, 3, 4);
        assertTrue(IsSorted.isSorted(list));
    }
}