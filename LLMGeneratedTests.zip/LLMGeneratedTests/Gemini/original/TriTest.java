package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TriTest {

    @Test
    void tri_n0() {
        assertEquals(Arrays.asList(1), Tri.tri(0));
    }

    @Test
    void tri_n1() {
        assertEquals(Arrays.asList(1, 3), Tri.tri(1));
    }

    @Test
    void tri_n2() {
        assertEquals(Arrays.asList(1, 3, 2.0), Tri.tri(2));
    }

    @Test
    void tri_n3() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0), Tri.tri(3));
    }

    @Test
    void tri_n4() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0), Tri.tri(4));
    }

    @Test
    void tri_n5() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0), Tri.tri(5));
    }

    @Test
    void tri_n6() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0), Tri.tri(6));
    }

    @Test
    void tri_n7() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0), Tri.tri(7));
    }

    @Test
    void tri_n8() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0), Tri.tri(8));
    }

    @Test
    void tri_n9() {
        assertEquals(Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0), Tri.tri(9));
    }

    @Test
    void tri_n10() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0);
        assertEquals(expected, Tri.tri(10).subList(0, expected.size()));
    }

    @Test
    void tri_n11() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0);
        assertEquals(expected, Tri.tri(11).subList(0, expected.size()));
    }

    @Test
    void tri_n12() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0);
        assertEquals(expected, Tri.tri(12).subList(0, expected.size()));
    }

    @Test
    void tri_n13() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0);
        assertEquals(expected, Tri.tri(13).subList(0, expected.size()));
    }

    @Test
    void tri_n14() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0);
        assertEquals(expected, Tri.tri(14).subList(0, expected.size()));
    }

    @Test
    void tri_n15() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0);
        assertEquals(expected, Tri.tri(15).subList(0, expected.size()));
    }

    @Test
    void tri_n16() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0);
        assertEquals(expected, Tri.tri(16).subList(0, expected.size()));
    }

    @Test
    void tri_n17() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0);
        assertEquals(expected, Tri.tri(17).subList(0, expected.size()));
    }

    @Test
    void tri_n18() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0);
        assertEquals(expected, Tri.tri(18).subList(0, expected.size()));
    }

    @Test
    void tri_n19() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0);
        assertEquals(expected, Tri.tri(19).subList(0, expected.size()));
    }

    @Test
    void tri_n20() {
        List<Number> expected = Arrays.asList(1, 3, 2.0, 8.0, 3.0, 15.0, 4.0, 24.0, 5.0, 35.0, 6.0, 48.0, 7.0, 63.0, 8.0, 80.0, 9.0, 99.0, 10.0, 120.0, 11.0);
        assertEquals(expected, Tri.tri(20).subList(0, expected.size()));
    }
}