package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SimplifyTest {

    @Test
    void simplify_validInput_true() {
        assertTrue(Simplify.simplify("1/5", "5/1"));
    }

    @Test
    void simplify_validInput_false() {
        assertFalse(Simplify.simplify("1/6", "2/1"));
    }

    @Test
    void simplify_sameFraction_false() {
        assertFalse(Simplify.simplify("1/5", "1/5"));
    }

    @Test
    void simplify_largerNumerator_true() {
        assertTrue(Simplify.simplify("5/1", "3/1"));
    }

    @Test
    void simplify_largerDenominator_false() {
        assertFalse(Simplify.simplify("7/10", "10/2"));
    }

    @Test
    void simplify_reduceableFraction_true() {
        assertTrue(Simplify.simplify("2/10", "50/10"));
    }

    @Test
    void simplify_reduceableFraction2_true() {
        assertTrue(Simplify.simplify("7/2", "4/2"));
    }

    @Test
    void simplify_reduceableFraction3_true() {
        assertTrue(Simplify.simplify("11/6", "6/1"));
    }

    @Test
    void simplify_reduceableFraction4_false() {
        assertFalse(Simplify.simplify("2/3", "5/2"));
    }

    @Test
    void simplify_reduceableFraction5_false() {
        assertFalse(Simplify.simplify("5/2", "3/5"));
    }

    @Test
    void simplify_reduceableFraction6_true() {
        assertTrue(Simplify.simplify("2/4", "8/4"));
    }

    @Test
    void simplify_reduceableFraction7_true() {
        assertTrue(Simplify.simplify("2/4", "4/2"));
    }

    @Test
    void simplify_boundaryCase_true() {
        assertTrue(Simplify.simplify("1/1", "1/1"));
    }

    @Test
    void simplify_boundaryCase2_false() {
        assertFalse(Simplify.simplify("1/2", "1/1"));
    }

    @Test
    void simplify_smallValues_true() {
        assertTrue(Simplify.simplify("2/1", "1/2"));
    }

    @Test
    void simplify_smallValues2_false() {
        assertFalse(Simplify.simplify("2/1", "1/3"));
    }

    @Test
    void simplify_equalFractions_true() {
        assertTrue(Simplify.simplify("1/2", "2/1"));
    }

    @Test
    void simplify_equalFractions2_false() {
        assertFalse(Simplify.simplify("1/3", "2/1"));
    }

    @Test
    void simplify_largerValues_true() {
        assertTrue(Simplify.simplify("10/5", "5/2"));
    }

    @Test
    void simplify_largerValues2_false() {
        assertFalse(Simplify.simplify("10/3", "5/2"));
    }
}