package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class XOrYTest {

    @Test
    void xOrY_nIsOne_returnsY() {
        assertEquals(5, XOrY.xOrY(1, 3, 5));
    }

    @Test
    void xOrY_nIsTwo_returnsX() {
        assertEquals(2, XOrY.xOrY(2, 2, 0));
    }

    @Test
    void xOrY_nIsPrime_returnsX() {
        assertEquals(34, XOrY.xOrY(7, 34, 12));
    }

    @Test
    void xOrY_nIsComposite_returnsY() {
        assertEquals(5, XOrY.xOrY(15, 8, 5));
    }

    @Test
    void xOrY_nIsPrimeSmall_returnsX() {
        assertEquals(33, XOrY.xOrY(3, 33, 5212));
    }

    @Test
    void xOrY_nIsPrimeLarge_returnsX() {
        assertEquals(3, XOrY.xOrY(1259, 3, 52));
    }

    @Test
    void xOrY_nIsPrimeNegativeX_returnsX() {
        assertEquals(-1, XOrY.xOrY(7919, -1, 12));
    }

    @Test
    void xOrY_nIsCompositeLarge_returnsY() {
        assertEquals(583, XOrY.xOrY(3609, 1245, 583));
    }

    @Test
    void xOrY_nIsCompositeSmall_returnsY() {
        assertEquals(129, XOrY.xOrY(91, 56, 129));
    }

    @Test
    void xOrY_nIsCompositeMedium_returnsY() {
        assertEquals(1234, XOrY.xOrY(6, 34, 1234));
    }

    @Test
    void xOrY_nIsFour_returnsY() {
        assertEquals(10, XOrY.xOrY(4, 5, 10));
    }

    @Test
    void xOrY_nIsNine_returnsY() {
        assertEquals(11, XOrY.xOrY(9, 7, 11));
    }

    @Test
    void xOrY_nIsTen_returnsY() {
        assertEquals(12, XOrY.xOrY(10, 8, 12));
    }

    @Test
    void xOrY_nIsEleven_returnsX() {
        assertEquals(13, XOrY.xOrY(11, 13, 14));
    }

    @Test
    void xOrY_nIsTwelve_returnsY() {
        assertEquals(15, XOrY.xOrY(12, 14, 15));
    }

    @Test
    void xOrY_nIsThirteen_returnsX() {
        assertEquals(16, XOrY.xOrY(13, 16, 17));
    }

    @Test
    void xOrY_nIsFourteen_returnsY() {
        assertEquals(18, XOrY.xOrY(14, 17, 18));
    }

    @Test
    void xOrY_nIsFifteen_returnsY() {
        assertEquals(19, XOrY.xOrY(15, 18, 19));
    }

    @Test
    void xOrY_nIsSixteen_returnsY() {
        assertEquals(20, XOrY.xOrY(16, 19, 20));
    }

    @Test
    void xOrY_nIsSeventeen_returnsX() {
        assertEquals(21, XOrY.xOrY(17, 21, 22));
    }
}