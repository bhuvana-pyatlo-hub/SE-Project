package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MakePalindromeTest {

    @Test
    void makePalindrome_emptyString() {
        assertEquals("", MakePalindrome.makePalindrome(""));
    }

    @Test
    void makePalindrome_singleCharacter() {
        assertEquals("x", MakePalindrome.makePalindrome("x"));
    }

    @Test
    void makePalindrome_simplePalindrome() {
        assertEquals("xyx", MakePalindrome.makePalindrome("xyx"));
    }

    @Test
    void makePalindrome_noPalindromePostfix() {
        assertEquals("xyzyx", MakePalindrome.makePalindrome("xyz"));
    }

    @Test
    void makePalindrome_cat() {
        assertEquals("catac", MakePalindrome.makePalindrome("cat"));
    }

    @Test
    void makePalindrome_cata() {
        assertEquals("catac", MakePalindrome.makePalindrome("cata"));
    }

    @Test
    void makePalindrome_jerry() {
        assertEquals("jerryrrej", MakePalindrome.makePalindrome("jerry"));
    }

    @Test
    void makePalindrome_longStringNoPalindrome() {
        assertEquals("abcdefgfedcba", MakePalindrome.makePalindrome("abcdefg"));
    }

    @Test
    void makePalindrome_longStringWithPalindrome() {
        assertEquals("abcdcba", MakePalindrome.makePalindrome("abcd"));
    }

    @Test
    void makePalindrome_palindromeAtBeginning() {
        assertEquals("aba", MakePalindrome.makePalindrome("ab"));
    }

    @Test
    void makePalindrome_palindromeAtEnd() {
        assertEquals("baab", MakePalindrome.makePalindrome("baa"));
    }

    @Test
    void makePalindrome_repeatedCharacters() {
        assertEquals("aaaaa", MakePalindrome.makePalindrome("aaaa"));
    }

    @Test
    void makePalindrome_mixedCase() {
        assertEquals("abBAba", MakePalindrome.makePalindrome("abB"));
    }

    @Test
    void makePalindrome_numbersAndLetters() {
        assertEquals("123a321", MakePalindrome.makePalindrome("123a"));
    }

    @Test
    void makePalindrome_specialCharacters() {
        assertEquals("!@#$#@!", MakePalindrome.makePalindrome("!@#$"));
    }

    @Test
    void makePalindrome_stringWithSpaces() {
        assertEquals("hello olleh", MakePalindrome.makePalindrome("hello "));
    }

    @Test
    void makePalindrome_stringWithLeadingSpaces() {
        assertEquals("  a a  ", MakePalindrome.makePalindrome("  a"));
    }

    @Test
    void makePalindrome_stringWithMultipleWords() {
        assertEquals("thisisatesttsetasisiht", MakePalindrome.makePalindrome("thisisatest"));
    }

    @Test
    void makePalindrome_longPalindrome() {
        assertEquals("racecar", MakePalindrome.makePalindrome("raceca"));
    }

    @Test
    void makePalindrome_complexString() {
        assertEquals("abracadabrabadarca", MakePalindrome.makePalindrome("abracadabr"));
    }
}