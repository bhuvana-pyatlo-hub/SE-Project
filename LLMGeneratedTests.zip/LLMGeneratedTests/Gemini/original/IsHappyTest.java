package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsHappyTest {

    @Test
    void isHappy_emptyString_returnsFalse() {
        assertFalse(IsHappy.isHappy(""));
    }

    @Test
    void isHappy_singleCharacter_returnsFalse() {
        assertFalse(IsHappy.isHappy("a"));
    }

    @Test
    void isHappy_twoCharacters_returnsFalse() {
        assertFalse(IsHappy.isHappy("aa"));
    }

    @Test
    void isHappy_threeDistinctCharacters_returnsTrue() {
        assertTrue(IsHappy.isHappy("abc"));
    }

    @Test
    void isHappy_threeSameCharacters_returnsFalse() {
        assertFalse(IsHappy.isHappy("aaa"));
    }

    @Test
    void isHappy_fourDistinctCharacters_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcd"));
    }

    @Test
    void isHappy_fourCharactersWithDuplicates_returnsFalse() {
        assertFalse(IsHappy.isHappy("abca"));
    }

    @Test
    void isHappy_fiveCharactersWithDuplicates_returnsFalse() {
        assertFalse(IsHappy.isHappy("abaca"));
    }

    @Test
    void isHappy_fiveDistinctCharacters_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcde"));
    }

    @Test
    void isHappy_stringWithRepeatingAdjacentCharacters_returnsFalse() {
        assertFalse(IsHappy.isHappy("aabbcc"));
    }

    @Test
    void isHappy_stringWithRepeatingCharactersSeparated_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcabc"));
    }

    @Test
    void isHappy_stringWithRepeatingCharactersAtEnd_returnsFalse() {
        assertFalse(IsHappy.isHappy("abcc"));
    }

    @Test
    void isHappy_stringWithRepeatingCharactersAtBeginning_returnsFalse() {
        assertFalse(IsHappy.isHappy("aabc"));
    }

    @Test
    void isHappy_stringWithRepeatingCharactersInMiddle_returnsFalse() {
        assertFalse(IsHappy.isHappy("abac"));
    }

    @Test
    void isHappy_stringWithRepeatingCharactersNearEnd_returnsFalse() {
        assertFalse(IsHappy.isHappy("abcca"));
    }

    @Test
    void isHappy_stringWithRepeatingCharactersNearBeginning_returnsFalse() {
        assertFalse(IsHappy.isHappy("aabcaa"));
    }

    @Test
    void isHappy_longHappyString_returnsTrue() {
        assertTrue(IsHappy.isHappy("abcdefghijk"));
    }

    @Test
    void isHappy_longUnhappyString_returnsFalse() {
        assertFalse(IsHappy.isHappy("abcdefghiajk"));
    }

    @Test
    void isHappy_stringWithSpecialCharacters_returnsTrue() {
        assertTrue(IsHappy.isHappy("!@#"));
    }

    @Test
    void isHappy_stringWithMixedCase_returnsTrue() {
        assertTrue(IsHappy.isHappy("AbC"));
    }

    @Test
    void isHappy_stringWithNumbers_returnsTrue() {
        assertTrue(IsHappy.isHappy("123"));
    }

    @Test
    void isHappy_stringWithRepeatingNumbers_returnsFalse() {
        assertFalse(IsHappy.isHappy("122"));
    }
}