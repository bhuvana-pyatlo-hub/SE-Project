package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RemoveVowelsTest {

    @Test
    void testEmptyString() {
        assertEquals("", RemoveVowels.removeVowels(""));
    }

    @Test
    void testStringWithOnlyVowelsLowercase() {
        assertEquals("", RemoveVowels.removeVowels("aeiou"));
    }

    @Test
    void testStringWithOnlyVowelsUppercase() {
        assertEquals("", RemoveVowels.removeVowels("AEIOU"));
    }

    @Test
    void testStringWithOnlyConsonants() {
        assertEquals("bcdfghjklmnpqrstvwxyz", RemoveVowels.removeVowels("bcdfghjklmnpqrstvwxyz"));
    }

    @Test
    void testStringWithMixedCaseVowelsAndConsonants() {
        assertEquals("HllWrld", RemoveVowels.removeVowels("HelloWorld"));
    }

    @Test
    void testStringWithNumbersAndSpecialCharacters() {
        assertEquals("123!@#", RemoveVowels.removeVowels("123!@#"));
    }

    @Test
    void testStringWithVowelsAndConsonantsMixed() {
        assertEquals("bcd", RemoveVowels.removeVowels("abcde"));
    }

    @Test
    void testStringWithUppercaseVowelsAndConsonantsMixed() {
        assertEquals("BCD", RemoveVowels.removeVowels("ABCDE"));
    }

    @Test
    void testStringWithMixedCaseVowelsAndConsonantsMixed() {
        assertEquals("lmn", RemoveVowels.removeVowels("AlmOn"));
    }

    @Test
    void testStringWithSpace() {
        assertEquals(" ", RemoveVowels.removeVowels(" "));
    }

    @Test
    void testStringWithVowelsAtBeginning() {
        assertEquals("bcd", RemoveVowels.removeVowels("aeioubcd"));
    }

    @Test
    void testStringWithVowelsAtEnd() {
        assertEquals("bcd", RemoveVowels.removeVowels("bcdaeiou"));
    }

    @Test
    void testStringWithVowelsInMiddle() {
        assertEquals("bcd", RemoveVowels.removeVowels("bacdeiou"));
    }

    @Test
    void testStringWithRepeatedVowels() {
        assertEquals("bcdf", RemoveVowels.removeVowels("baaaeiioouuf"));
    }

    @Test
    void testStringWithRepeatedConsonants() {
        assertEquals("bbbb", RemoveVowels.removeVowels("abbbb"));
    }

    @Test
    void testStringWithNewlineCharacter() {
        assertEquals("bcd\nfgh", RemoveVowels.removeVowels("abcde\nfghiou"));
    }

    @Test
    void testStringWithTabs() {
        assertEquals("bcd\tfgh", RemoveVowels.removeVowels("abcde\tfghiou"));
    }

    @Test
    void testStringWithSpecialCharactersAndVowels() {
        assertEquals("!@#%$^&*()_+", RemoveVowels.removeVowels("!@#%$^&*()_+aeiou"));
    }

    @Test
    void testStringWithMixedCaseAndSpecialChars() {
        assertEquals("Ths s tst", RemoveVowels.removeVowels("This is a test"));
    }

    @Test
    void testStringWithOnlyOneCharacterVowel() {
        assertEquals("", RemoveVowels.removeVowels("a"));
    }

    @Test
    void testStringWithOnlyOneCharacterConsonant() {
        assertEquals("b", RemoveVowels.removeVowels("b"));
    }

    @Test
    void testStringWithUnicodeCharacters() {
        assertEquals("\u00E4\u00F6\u00FC", RemoveVowels.removeVowels("\u00E4\u00E4\u00F6\u00F6\u00FC\u00FC"));
    }
}