package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FixSpacesTest {

    @Test
    void testNoSpaces() {
        assertEquals("Example", FixSpaces.fixSpaces("Example"));
    }

    @Test
    void testSingleSpace() {
        assertEquals("Example_1", FixSpaces.fixSpaces("Example 1"));
    }

    @Test
    void testLeadingSpace() {
        assertEquals("_Example_2", FixSpaces.fixSpaces(" Example 2"));
    }

    @Test
    void testMultipleConsecutiveSpacesGreaterThanTwo() {
        assertEquals("_Example-3", FixSpaces.fixSpaces(" Example   3"));
    }

    @Test
    void testTrailingSpace() {
        assertEquals("Mudasir_Hanif_", FixSpaces.fixSpaces("Mudasir Hanif "));
    }

    @Test
    void testMultipleSpacesBetweenWords() {
        assertEquals("Yellow_Yellow__Dirty__Fellow", FixSpaces.fixSpaces("Yellow Yellow  Dirty  Fellow"));
    }

    @Test
    void testConsecutiveSpacesGreaterThanTwoInMiddle() {
        assertEquals("Exa-mple", FixSpaces.fixSpaces("Exa   mple"));
    }

    @Test
    void testLeadingAndMultipleSpaces() {
        assertEquals("-Exa_1_2_2_mple", FixSpaces.fixSpaces("   Exa 1 2 2 mple"));
    }

    @Test
    void testEmptyString() {
        assertEquals("", FixSpaces.fixSpaces(""));
    }

    @Test
    void testOnlySpaces() {
        assertEquals("-", FixSpaces.fixSpaces("   "));
    }

    @Test
    void testTwoSpaces() {
        assertEquals("A__B", FixSpaces.fixSpaces("A  B"));
    }

    @Test
    void testSingleLeadingSpace() {
        assertEquals("_Test", FixSpaces.fixSpaces(" Test"));
    }

    @Test
    void testSingleTrailingSpace() {
        assertEquals("Test_", FixSpaces.fixSpaces("Test "));
    }

    @Test
    void testMultipleLeadingSpaces() {
        assertEquals("-Test", FixSpaces.fixSpaces("   Test"));
    }

    @Test
    void testMultipleTrailingSpaces() {
        assertEquals("Test-", FixSpaces.fixSpaces("Test   "));
    }

    @Test
    void testMixOfSingleAndMultipleSpaces() {
        assertEquals("A_B-C_D", FixSpaces.fixSpaces("A B   C D"));
    }

    @Test
    void testStringWithOnlyOneCharacter() {
        assertEquals("A", FixSpaces.fixSpaces("A"));
    }

    @Test
    void testStringWithOnlySpaceCharacter() {
        assertEquals("_", FixSpaces.fixSpaces(" "));
    }

    @Test
    void testStringWithTwoSpaceCharacters() {
        assertEquals("__", FixSpaces.fixSpaces("  "));
    }

    @Test
    void testStringStartingAndEndingWithSpaces() {
        assertEquals("_Test_", FixSpaces.fixSpaces(" Test "));
    }

    @Test
    void testStringWithConsecutiveSpacesAtEndGreaterThanTwo() {
        assertEquals("Test-", FixSpaces.fixSpaces("Test   "));
    }

    @Test
    void testStringWithConsecutiveSpacesAtBeginningGreaterThanTwo() {
        assertEquals("-Test", FixSpaces.fixSpaces("   Test"));
    }
}