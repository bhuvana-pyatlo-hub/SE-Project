package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TriangleAreaTest {

    @Test
    void testTriangleArea_validInput_smallValues() {
        assertEquals(7.5, TriangleArea.triangleArea(5, 3));
    }

    @Test
    void testTriangleArea_validInput_equalValues() {
        assertEquals(2.0, TriangleArea.triangleArea(2, 2));
    }

    @Test
    void testTriangleArea_validInput_largerValues() {
        assertEquals(40.0, TriangleArea.triangleArea(10, 8));
    }

    @Test
    void testTriangleArea_validInput_zeroBase() {
        assertEquals(0.0, TriangleArea.triangleArea(0, 5));
    }

    @Test
    void testTriangleArea_validInput_zeroHeight() {
        assertEquals(0.0, TriangleArea.triangleArea(5, 0));
    }

    @Test
    void testTriangleArea_validInput_oneBase() {
        assertEquals(2.5, TriangleArea.triangleArea(1, 5));
    }

    @Test
    void testTriangleArea_validInput_oneHeight() {
        assertEquals(2.5, TriangleArea.triangleArea(5, 1));
    }

    @Test
    void testTriangleArea_validInput_largeBase() {
        assertEquals(499.5, TriangleArea.triangleArea(999, 1));
    }

    @Test
    void testTriangleArea_validInput_largeHeight() {
        assertEquals(499.5, TriangleArea.triangleArea(1, 999));
    }

    @Test
    void testTriangleArea_validInput_bothLarge() {
        assertEquals(499500.0, TriangleArea.triangleArea(1000, 999));
    }

    @Test
    void testTriangleArea_validInput_baseIsDoubleHeight() {
        assertEquals(50.0, TriangleArea.triangleArea(10, 10));
    }

    @Test
    void testTriangleArea_validInput_heightIsDoubleBase() {
        assertEquals(50.0, TriangleArea.triangleArea(10, 10));
    }

    @Test
    void testTriangleArea_validInput_sameValues() {
        assertEquals(50.0, TriangleArea.triangleArea(10, 10));
    }

    @Test
    void testTriangleArea_validInput_baseGreaterThanHeight() {
        assertEquals(15.0, TriangleArea.triangleArea(6, 5));
    }

    @Test
    void testTriangleArea_validInput_heightGreaterThanBase() {
        assertEquals(15.0, TriangleArea.triangleArea(5, 6));
    }

    @Test
    void testTriangleArea_validInput_maxIntBase() {
        assertEquals(1.07374182E9, TriangleArea.triangleArea(Integer.MAX_VALUE, 1));
    }

    @Test
    void testTriangleArea_validInput_maxIntHeight() {
        assertEquals(1.07374182E9, TriangleArea.triangleArea(1, Integer.MAX_VALUE));
    }

    @Test
    void testTriangleArea_validInput_maxIntBoth() {
        assertEquals(4.611686016279904E18, TriangleArea.triangleArea(Integer.MAX_VALUE, Integer.MAX_VALUE));
    }

    @Test
    void testTriangleArea_validInput_closeToZero() {
        assertEquals(0.5, TriangleArea.triangleArea(1, 1));
    }

    @Test
    void testTriangleArea_validInput_mediumValues() {
        assertEquals(1250.0, TriangleArea.triangleArea(50, 50));
    }
}