package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CircularShiftTest {

    @Test
    void circularShift_smallNumberSmallShift() {
        assertEquals("21", CircularShift.circularShift(12, 1));
    }

    @Test
    void circularShift_smallNumberLargeShift() {
        assertEquals("21", CircularShift.circularShift(12, 2));
    }

    @Test
    void circularShift_largerNumberSmallShift() {
        assertEquals("001", CircularShift.circularShift(100, 2));
    }

    @Test
    void circularShift_largerNumberLargeShift() {
        assertEquals("79", CircularShift.circularShift(97, 8));
    }

    @Test
    void circularShift_singleDigitNumberSmallShift() {
        assertEquals("7", CircularShift.circularShift(7, 1));
    }

    @Test
    void circularShift_singleDigitNumberLargeShift() {
        assertEquals("7", CircularShift.circularShift(7, 5));
    }

    @Test
    void circularShift_zeroShift() {
        assertEquals("123", CircularShift.circularShift(123, 0));
    }

    @Test
    void circularShift_equalShift() {
        assertEquals("321", CircularShift.circularShift(123, 3));
    }

    @Test
    void circularShift_twoDigitNumberEqualShift() {
        assertEquals("21", CircularShift.circularShift(12, 2));
    }

    @Test
    void circularShift_threeDigitNumberEqualShift() {
        assertEquals("321", CircularShift.circularShift(123, 3));
    }

    @Test
    void circularShift_fourDigitNumberSmallShift() {
        assertEquals("4123", CircularShift.circularShift(1234, 1));
    }

    @Test
    void circularShift_fourDigitNumberLargeShift() {
        assertEquals("4321", CircularShift.circularShift(1234, 5));
    }

    @Test
    void circularShift_twoDigitNumberZeroShift() {
        assertEquals("11", CircularShift.circularShift(11, 0));
    }

    @Test
    void circularShift_twoDigitNumberLargeShift() {
        assertEquals("11", CircularShift.circularShift(11, 101));
    }

    @Test
    void circularShift_threeDigitNumberZeroShift() {
        assertEquals("111", CircularShift.circularShift(111, 0));
    }

    @Test
    void circularShift_threeDigitNumberLargeShift() {
        assertEquals("111", CircularShift.circularShift(111, 101));
    }

    @Test
    void circularShift_boundaryShiftOneLessThanLength() {
        assertEquals("312", CircularShift.circularShift(123, 2));
    }

    @Test
    void circularShift_boundaryShiftEqualToLengthMinusOne() {
        assertEquals("312", CircularShift.circularShift(123, 2));
    }

    @Test
    void circularShift_numberWithLeadingZerosSmallShift() {
        assertEquals("001", CircularShift.circularShift(100, 2));
    }

    @Test
    void circularShift_numberWithLeadingZerosLargeShift() {
        assertEquals("001", CircularShift.circularShift(100, 5));
    }
}