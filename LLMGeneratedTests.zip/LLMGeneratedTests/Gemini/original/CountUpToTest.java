package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class CountUpToTest {

    @Test
    void countUpTo_zero() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, CountUpTo.countUpTo(0));
    }

    @Test
    void countUpTo_one() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, CountUpTo.countUpTo(1));
    }

    @Test
    void countUpTo_two() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        assertEquals(expected, CountUpTo.countUpTo(3));
    }

    @Test
    void countUpTo_five() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        assertEquals(expected, CountUpTo.countUpTo(5));
    }

    @Test
    void countUpTo_six() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        assertEquals(expected, CountUpTo.countUpTo(6));
    }

    @Test
    void countUpTo_seven() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        assertEquals(expected, CountUpTo.countUpTo(7));
    }

    @Test
    void countUpTo_ten() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        assertEquals(expected, CountUpTo.countUpTo(10));
    }

    @Test
    void countUpTo_eleven() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        assertEquals(expected, CountUpTo.countUpTo(11));
    }

    @Test
    void countUpTo_twelve() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        assertEquals(expected, CountUpTo.countUpTo(12));
    }

    @Test
    void countUpTo_twenty() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        expected.add(19);
        assertEquals(expected, CountUpTo.countUpTo(20));
    }

    @Test
    void countUpTo_eighteen() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        assertEquals(expected, CountUpTo.countUpTo(18));
    }

    @Test
    void countUpTo_fortySeven() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        expected.add(19);
        expected.add(23);
        expected.add(29);
        expected.add(31);
        expected.add(37);
        expected.add(41);
        expected.add(43);
        assertEquals(expected, CountUpTo.countUpTo(47));
    }

    @Test
    void countUpTo_primeNumber() {
        List<Object> expected = new ArrayList<>();
        expected.add(2);
        expected.add(3);
        expected.add(5);
        expected.add(7);
        expected.add(11);
        expected.add(13);
        expected.add(17);
        assertEquals(expected, CountUpTo.countUpTo(19));
    }
}