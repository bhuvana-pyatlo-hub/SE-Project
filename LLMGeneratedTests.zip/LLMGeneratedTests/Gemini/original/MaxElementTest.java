package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MaxElementTest {

    @Test
    void testMaxElement_emptyList() {
        List<Integer> list = new ArrayList<>();
        assertEquals(Integer.MIN_VALUE, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_singleElementList() {
        List<Integer> list = Collections.singletonList(5);
        assertEquals(5, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_positiveNumbers() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(5, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_negativeNumbers() {
        List<Integer> list = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(-1, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_mixedNumbers() {
        List<Integer> list = Arrays.asList(-1, 2, -3, 4, -5);
        assertEquals(4, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_duplicateMax() {
        List<Integer> list = Arrays.asList(1, 5, 3, 5, 2);
        assertEquals(5, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_allSameNumbers() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(5, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_zeroInList() {
        List<Integer> list = Arrays.asList(-1, 0, 1);
        assertEquals(1, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_maxAtBeginning() {
        List<Integer> list = Arrays.asList(10, 1, 2, 3);
        assertEquals(10, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_maxAtEnd() {
        List<Integer> list = Arrays.asList(1, 2, 3, 10);
        assertEquals(10, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_maxInMiddle() {
        List<Integer> list = Arrays.asList(1, 10, 2, 3);
        assertEquals(10, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_largePositiveNumbers() {
        List<Integer> list = Arrays.asList(100, 200, 300);
        assertEquals(300, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_largeNegativeNumbers() {
        List<Integer> list = Arrays.asList(-100, -200, -300);
        assertEquals(-100, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_mixedLargeNumbers() {
        List<Integer> list = Arrays.asList(-100, 200, -300);
        assertEquals(200, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_minValue() {
        List<Integer> list = Arrays.asList(Integer.MIN_VALUE, 1, 2);
        assertEquals(2, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_minValueOnly() {
        List<Integer> list = Collections.singletonList(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_minValueAndZero() {
        List<Integer> list = Arrays.asList(Integer.MIN_VALUE, 0);
        assertEquals(0, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_minValueAndNegative() {
        List<Integer> list = Arrays.asList(Integer.MIN_VALUE, -1);
        assertEquals(-1, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_minValueAndMaxValue() {
        List<Integer> list = Arrays.asList(Integer.MIN_VALUE, Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, MaxElement.maxElement(list));
    }

    @Test
    void testMaxElement_maxValueOnly() {
        List<Integer> list = Collections.singletonList(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, MaxElement.maxElement(list));
    }
}