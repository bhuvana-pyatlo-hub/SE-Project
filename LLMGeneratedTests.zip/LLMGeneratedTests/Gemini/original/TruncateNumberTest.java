package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TruncateNumberTest {

    @Test
    void truncateNumber_positiveNumberWithDecimal_returnsDecimalPart() {
        assertEquals(0.5, TruncateNumber.truncateNumber(3.5), 0.000001);
    }

    @Test
    void truncateNumber_positiveNumberWithMultipleDecimals_returnsDecimalPart() {
        assertEquals(0.33, TruncateNumber.truncateNumber(1.33), 0.000001);
    }

    @Test
    void truncateNumber_largePositiveNumberWithDecimals_returnsDecimalPart() {
        assertEquals(0.456, TruncateNumber.truncateNumber(123.456), 0.000001);
    }

    @Test
    void truncateNumber_wholeNumber_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(5.0), 0.000001);
    }

    @Test
    void truncateNumber_zero_returnsZero() {
        assertEquals(0.0, TruncateNumber.truncateNumber(0.0), 0.000001);
    }

    @Test
    void truncateNumber_smallDecimal_returnsDecimal() {
        assertEquals(0.1, TruncateNumber.truncateNumber(0.1), 0.000001);
    }

    @Test
    void truncateNumber_numberCloseToZero_returnsDecimal() {
        assertEquals(0.001, TruncateNumber.truncateNumber(0.001), 0.000001);
    }

    @Test
    void truncateNumber_numberWithRepeatingDecimal_returnsTruncatedDecimal() {
        assertEquals(0.333, TruncateNumber.truncateNumber(1.333333333), 0.000001);
    }

    @Test
    void truncateNumber_numberWithLongDecimal_returnsTruncatedDecimal() {
        assertEquals(0.123, TruncateNumber.truncateNumber(1.123456789), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalGreaterThanOne_returnsDecimalPart() {
        assertEquals(0.999, TruncateNumber.truncateNumber(10.999), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalCloseToOne_returnsDecimalPart() {
        assertEquals(0.999, TruncateNumber.truncateNumber(5.999), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointZeroZeroOne_returnsDecimalPart() {
        assertEquals(0.001, TruncateNumber.truncateNumber(10.001), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointZeroZeroZeroOne_returnsDecimalPart() {
        assertEquals(0.0, TruncateNumber.truncateNumber(10.0001), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointZeroZeroZeroNine_returnsDecimalPart() {
        assertEquals(0.0, TruncateNumber.truncateNumber(10.0009), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointNineNineNineNine_returnsDecimalPart() {
        assertEquals(1.0, TruncateNumber.truncateNumber(10.9999), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointNineNineNineFive_returnsDecimalPart() {
        assertEquals(1.0, TruncateNumber.truncateNumber(10.9995), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointNineNineNineFour_returnsDecimalPart() {
        assertEquals(0.999, TruncateNumber.truncateNumber(10.9994), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointZeroZeroZeroFive_returnsDecimalPart() {
        assertEquals(0.001, TruncateNumber.truncateNumber(10.0005), 0.000001);
    }

    @Test
    void truncateNumber_numberWithDecimalZeroPointZeroZeroZeroZeroFive_returnsDecimalPart() {
        assertEquals(0.0, TruncateNumber.truncateNumber(10.00005), 0.000001);
    }

    @Test
    void truncateNumber_largeNumberWithSmallDecimal_returnsDecimalPart() {
        assertEquals(0.001, TruncateNumber.truncateNumber(999.001), 0.000001);
    }
}