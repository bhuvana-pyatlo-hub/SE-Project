package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HexKeyTest {

    @Test
    void hexKey_emptyString() {
        assertEquals(0, HexKey.hexKey(""));
    }

    @Test
    void hexKey_nullInput() {
        assertEquals(0, HexKey.hexKey(null));
    }

    @Test
    void hexKey_singlePrimeHexDigit() {
        assertEquals(1, HexKey.hexKey("2"));
    }

    @Test
    void hexKey_singleNonPrimeHexDigit() {
        assertEquals(0, HexKey.hexKey("0"));
    }

    @Test
    void hexKey_multiplePrimeHexDigits() {
        assertEquals(2, HexKey.hexKey("23"));
    }

    @Test
    void hexKey_multipleNonPrimeHexDigits() {
        assertEquals(0, HexKey.hexKey("014689ACEF"));
    }

    @Test
    void hexKey_mixedPrimeAndNonPrimeHexDigits() {
        assertEquals(3, HexKey.hexKey("12345"));
    }

    @Test
    void hexKey_allPrimeHexDigits() {
        assertEquals(6, HexKey.hexKey("2357BD"));
    }

    @Test
    void hexKey_longStringWithPrimeHexDigits() {
        assertEquals(6, HexKey.hexKey("123456789ABCDEF0"));
    }

    @Test
    void hexKey_longStringWithoutPrimeHexDigits() {
        assertEquals(0, HexKey.hexKey("014689ACEF014689ACEF"));
    }

    @Test
    void hexKey_stringWithOnlyTwos() {
        assertEquals(5, HexKey.hexKey("22222"));
    }

    @Test
    void hexKey_stringWithOnlyThrees() {
        assertEquals(5, HexKey.hexKey("33333"));
    }

    @Test
    void hexKey_stringWithOnlyFives() {
        assertEquals(5, HexKey.hexKey("55555"));
    }

    @Test
    void hexKey_stringWithOnlySevens() {
        assertEquals(5, HexKey.hexKey("77777"));
    }

    @Test
    void hexKey_stringWithOnlyBs() {
        assertEquals(5, HexKey.hexKey("BBBBB"));
    }

    @Test
    void hexKey_stringWithOnlyDs() {
        assertEquals(5, HexKey.hexKey("DDDDD"));
    }

    @Test
    void hexKey_mixedCaseString() {
        assertEquals(1, HexKey.hexKey("aB"));
    }

    @Test
    void hexKey_stringWithNonHexCharacters() {
        assertEquals(2, HexKey.hexKey("2x3y"));
    }

    @Test
    void hexKey_numberAsString() {
        assertEquals(1, HexKey.hexKey("11"));
    }

    @Test
    void hexKey_largeStringWithPrimes() {
        assertEquals(12, HexKey.hexKey("112233445566778899AABBCCDDEEFF00"));
    }

    @Test
    void hexKey_objectInput() {
        Object input = "2357BD";
        assertEquals(6, HexKey.hexKey(input));
    }

    @Test
    void hexKey_zero() {
        assertEquals(0, HexKey.hexKey("0"));
    }
}