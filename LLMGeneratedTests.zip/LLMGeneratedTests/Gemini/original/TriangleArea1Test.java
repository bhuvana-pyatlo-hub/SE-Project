package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TriangleArea1Test {

    @Test
    void testValidTriangle1() {
        assertEquals(6.0, TriangleArea1.triangleArea(3, 4, 5));
    }

    @Test
    void testInvalidTriangle1() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 10));
    }

    @Test
    void testValidTriangle2() {
        assertEquals(8.18, TriangleArea1.triangleArea(4, 8, 5));
    }

    @Test
    void testValidTriangle3() {
        assertEquals(1.73, TriangleArea1.triangleArea(2, 2, 2));
    }

    @Test
    void testInvalidTriangle2() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 3));
    }

    @Test
    void testValidTriangle4() {
        assertEquals(16.25, TriangleArea1.triangleArea(10, 5, 7));
    }

    @Test
    void testInvalidTriangle3() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 6, 3));
    }

    @Test
    void testValidTriangle5() {
        assertEquals(0.43, TriangleArea1.triangleArea(1, 1, 1));
    }

    @Test
    void testInvalidTriangle4() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 2, 10));
    }

    @Test
    void testBoundaryCase1() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 1, 2));
    }

    @Test
    void testBoundaryCase2() {
        assertEquals(-1, TriangleArea1.triangleArea(2, 1, 1));
    }

    @Test
    void testBoundaryCase3() {
        assertEquals(-1, TriangleArea1.triangleArea(1, 2, 1));
    }

    @Test
    void testSmallValidTriangle() {
        assertEquals(0.33, TriangleArea1.triangleArea(1, 2, 2));
    }

    @Test
    void testAnotherValidTriangle() {
        assertEquals(2.9, TriangleArea1.triangleArea(3, 5, 5));
    }

    @Test
    void testEdgeCase1() {
        assertEquals(2.83, TriangleArea1.triangleArea(2, 4, 4));
    }

    @Test
    void testEdgeCase2() {
        assertEquals(14.7, TriangleArea1.triangleArea(6, 8, 10));
    }

    @Test
    void testValidTriangleWithSimilarSides() {
        assertEquals(1.98, TriangleArea1.triangleArea(2, 3, 4));
    }

    @Test
    void testInvalidTriangleWithZeroSide() {
        assertEquals(-1, TriangleArea1.triangleArea(0, 5, 5));
    }

    @Test
    void testInvalidTriangleWithNegativeSide() {
        assertEquals(-1, TriangleArea1.triangleArea(-1, 5, 5));
    }

    @Test
    void testLargeValidTriangle() {
        assertEquals(49.92, TriangleArea1.triangleArea(10, 12, 12));
    }
}