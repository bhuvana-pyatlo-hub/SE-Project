package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class NumericalLetterGradeTest {

    @Test
    void testNumericalLetterGrade_emptyList() {
        List<Number> grades = Collections.emptyList();
        List<String> expected = Collections.emptyList();
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_A_plus() {
        List<Number> grades = Collections.singletonList(4.0);
        List<String> expected = Collections.singletonList("A+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_A() {
        List<Number> grades = Collections.singletonList(3.8);
        List<String> expected = Collections.singletonList("A");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_A_minus() {
        List<Number> grades = Collections.singletonList(3.4);
        List<String> expected = Collections.singletonList("A-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_B_plus() {
        List<Number> grades = Collections.singletonList(3.1);
        List<String> expected = Collections.singletonList("B+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_B() {
        List<Number> grades = Collections.singletonList(2.8);
        List<String> expected = Collections.singletonList("B");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_B_minus() {
        List<Number> grades = Collections.singletonList(2.4);
        List<String> expected = Collections.singletonList("B-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_C_plus() {
        List<Number> grades = Collections.singletonList(2.1);
        List<String> expected = Collections.singletonList("C+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_C() {
        List<Number> grades = Collections.singletonList(1.8);
        List<String> expected = Collections.singletonList("C");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_C_minus() {
        List<Number> grades = Collections.singletonList(1.4);
        List<String> expected = Collections.singletonList("C-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_D_plus() {
        List<Number> grades = Collections.singletonList(1.1);
        List<String> expected = Collections.singletonList("D+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_D() {
        List<Number> grades = Collections.singletonList(0.8);
        List<String> expected = Collections.singletonList("D");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_D_minus() {
        List<Number> grades = Collections.singletonList(0.1);
        List<String> expected = Collections.singletonList("D-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_singleGrade_E() {
        List<Number> grades = Collections.singletonList(0.0);
        List<String> expected = Collections.singletonList("E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_multipleGrades() {
        List<Number> grades = Arrays.asList(4.0, 3.0, 1.7, 2.0, 3.5);
        List<String> expected = Arrays.asList("A+", "B+", "C", "C+", "A-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_3_7() {
        List<Number> grades = Collections.singletonList(3.71);
        List<String> expected = Collections.singletonList("A");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_3_3() {
        List<Number> grades = Collections.singletonList(3.31);
        List<String> expected = Collections.singletonList("A-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_3_0() {
        List<Number> grades = Collections.singletonList(3.01);
        List<String> expected = Collections.singletonList("B+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_2_7() {
        List<Number> grades = Collections.singletonList(2.71);
        List<String> expected = Collections.singletonList("B");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_2_3() {
        List<Number> grades = Collections.singletonList(2.31);
        List<String> expected = Collections.singletonList("B-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_2_0() {
        List<Number> grades = Collections.singletonList(2.01);
        List<String> expected = Collections.singletonList("C+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_1_7() {
        List<Number> grades = Collections.singletonList(1.71);
        List<String> expected = Collections.singletonList("C");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_1_3() {
        List<Number> grades = Collections.singletonList(1.31);
        List<String> expected = Collections.singletonList("C-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_1_0() {
        List<Number> grades = Collections.singletonList(1.01);
        List<String> expected = Collections.singletonList("D+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_0_7() {
        List<Number> grades = Collections.singletonList(0.71);
        List<String> expected = Collections.singletonList("D");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_boundary_0_0() {
        List<Number> grades = Collections.singletonList(0.01);
        List<String> expected = Collections.singletonList("D-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_mixed_grades() {
        List<Number> grades = Arrays.asList(4.0, 3.8, 3.4, 3.1, 2.8, 2.4, 2.1, 1.8, 1.4, 1.1, 0.8, 0.1, 0.0);
        List<String> expected = Arrays.asList("A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_integer_grades() {
        List<Number> grades = Arrays.asList(4, 3, 1, 2, 3);
        List<String> expected = Arrays.asList("A+", "B+", "D", "C+", "B+");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_double_grades() {
        List<Number> grades = Arrays.asList(4.0, 3.0, 1.7, 2.0, 3.5);
        List<String> expected = Arrays.asList("A+", "B+", "C", "C+", "A-");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }

    @Test
    void testNumericalLetterGrade_zero_grade() {
        List<Number> grades = Collections.singletonList(0);
        List<String> expected = Collections.singletonList("E");
        assertEquals(expected, NumericalLetterGrade.numericalLetterGrade(grades));
    }
}