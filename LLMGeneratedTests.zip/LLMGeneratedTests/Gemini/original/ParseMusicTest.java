package original;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ParseMusicTest {

    @Test
    void testEmptyString() {
        List<Object> result = ParseMusic.parseMusic("");
        assertTrue(result.isEmpty());
    }

    @Test
    void testOnlyWholeNotes() {
        List<Object> result = ParseMusic.parseMusic("o o o o");
        assertEquals(List.of(4, 4, 4, 4), result);
    }

    @Test
    void testOnlyQuarterNotes() {
        List<Object> result = ParseMusic.parseMusic(".| .| .| .|");
        assertEquals(List.of(1, 1, 1, 1), result);
    }

    @Test
    void testMixedNotes1() {
        List<Object> result = ParseMusic.parseMusic("o| o| .| .| o o o o");
        assertEquals(List.of(2, 2, 1, 1, 4, 4, 4, 4), result);
    }

    @Test
    void testMixedNotes2() {
        List<Object> result = ParseMusic.parseMusic("o| .| o| .| o o| o o|");
        assertEquals(List.of(2, 1, 2, 1, 4, 2, 4, 2), result);
    }

    @Test
    void testBasicExample() {
        List<Object> result = ParseMusic.parseMusic("o o| .| o| o| .| .| .| .| o o");
        assertEquals(List.of(4, 2, 1, 2, 2, 1, 1, 1, 1, 4, 4), result);
    }

    @Test
    void testNoNotes() {
        List<Object> result = ParseMusic.parseMusic("   ");
        assertTrue(result.isEmpty());
    }

    @Test
    void testOnlyHalfNotes() {
        List<Object> result = ParseMusic.parseMusic("o| o| o| o|");
        assertEquals(List.of(2, 2, 2, 2), result);
    }

    @Test
    void testEdgeCaseWholeNoteAtEnd() {
        List<Object> result = ParseMusic.parseMusic("o");
        assertEquals(List.of(4), result);
    }

    @Test
    void testEdgeCaseHalfNoteAtEnd() {
        List<Object> result = ParseMusic.parseMusic("o|");
        assertEquals(List.of(2), result);
    }

    @Test
    void testEdgeCaseQuarterNoteAtEnd() {
        List<Object> result = ParseMusic.parseMusic(".|");
        assertEquals(List.of(1), result);
    }

    @Test
    void testMixedNotesWithSpaces() {
        List<Object> result = ParseMusic.parseMusic(" o | . | o | . | o   o | o   o |");
        assertEquals(List.of(2, 1, 2, 1, 4, 2, 4, 2), result);
    }

    @Test
    void testOnlySpaces() {
        List<Object> result = ParseMusic.parseMusic("     ");
        assertTrue(result.isEmpty());
    }

    @Test
    void testInvalidInput() {
        List<Object> result = ParseMusic.parseMusic("x y z");
        assertTrue(result.isEmpty());
    }

    @Test
    void testCombinedNotesAndInvalidInput() {
        List<Object> result = ParseMusic.parseMusic("o| .| x o o| y");
        assertEquals(List.of(2, 1, 4, 2), result);
    }

    @Test
    void testOnlyOneNoteType() {
        List<Object> result = ParseMusic.parseMusic("o o o");
        assertEquals(List.of(4, 4, 4), result);
    }
}