package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ChangeBaseTest {

    @Test
    void testChangeBase_8_3() {
        assertEquals("22", ChangeBase.changeBase(8, 3));
    }

    @Test
    void testChangeBase_8_2() {
        assertEquals("1000", ChangeBase.changeBase(8, 2));
    }

    @Test
    void testChangeBase_7_2() {
        assertEquals("111", ChangeBase.changeBase(7, 2));
    }

    @Test
    void testChangeBase_9_3() {
        assertEquals("100", ChangeBase.changeBase(9, 3));
    }

    @Test
    void testChangeBase_234_2() {
        assertEquals("11101010", ChangeBase.changeBase(234, 2));
    }

    @Test
    void testChangeBase_16_2() {
        assertEquals("10000", ChangeBase.changeBase(16, 2));
    }

    @Test
    void testChangeBase_2_3() {
        assertEquals("2", ChangeBase.changeBase(2, 3));
    }

    @Test
    void testChangeBase_3_4() {
        assertEquals("3", ChangeBase.changeBase(3, 4));
    }

    @Test
    void testChangeBase_4_5() {
        assertEquals("4", ChangeBase.changeBase(4, 5));
    }

    @Test
    void testChangeBase_5_6() {
        assertEquals("5", ChangeBase.changeBase(5, 6));
    }

    @Test
    void testChangeBase_6_7() {
        assertEquals("6", ChangeBase.changeBase(6, 7));
    }

    @Test
    void testChangeBase_7_8() {
        assertEquals("7", ChangeBase.changeBase(7, 8));
    }

    @Test
    void testChangeBase_1_2() {
        assertEquals("1", ChangeBase.changeBase(1, 2));
    }

    @Test
    void testChangeBase_0_2() {
        assertEquals("", ChangeBase.changeBase(0, 2));
    }

    @Test
    void testChangeBase_10_3() {
        assertEquals("101", ChangeBase.changeBase(10, 3));
    }

    @Test
    void testChangeBase_15_4() {
        assertEquals("33", ChangeBase.changeBase(15, 4));
    }

    @Test
    void testChangeBase_100_10() {
        assertEquals("100", ChangeBase.changeBase(100, 10));
    }

    @Test
    void testChangeBase_100_2() {
        assertEquals("1100100", ChangeBase.changeBase(100, 2));
    }

    @Test
    void testChangeBase_999_10() {
        assertEquals("999", ChangeBase.changeBase(999, 10));
    }

    @Test
    void testChangeBase_999_2() {
        assertEquals("1111100111", ChangeBase.changeBase(999, 2));
    }

    @Test
    void testChangeBase_10_9() {
        assertEquals("11", ChangeBase.changeBase(10, 9));
    }
}