package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsSimplePowerTest {

    @Test
    void isSimplePower_xIsOne_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 4));
    }

    @Test
    void isSimplePower_nIsOne_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(3, 1));
    }

    @Test
    void isSimplePower_xIsSimplePower_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(2, 2));
    }

    @Test
    void isSimplePower_xIsNotSimplePower_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(3, 2));
    }

    @Test
    void isSimplePower_xIsLargerSimplePower_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(16, 2));
    }

    @Test
    void isSimplePower_xIsLargeAndNotSimplePower_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(143214, 16));
    }

    @Test
    void isSimplePower_fourAndTwo_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(4, 2));
    }

    @Test
    void isSimplePower_nineAndThree_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(9, 3));
    }

    @Test
    void isSimplePower_sixteenAndFour_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(16, 4));
    }

    @Test
    void isSimplePower_twentyFourAndTwo_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(24, 2));
    }

    @Test
    void isSimplePower_oneTwentyEightAndFour_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(128, 4));
    }

    @Test
    void isSimplePower_twelveAndSix_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(12, 6));
    }

    @Test
    void isSimplePower_oneAndOne_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 1));
    }

    @Test
    void isSimplePower_oneAndTwelve_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(1, 12));
    }

    @Test
    void isSimplePower_smallValues_returnsCorrectResult() {
        assertTrue(IsSimplePower.isSimplePower(8, 2));
    }

    @Test
    void isSimplePower_anotherNotSimplePower_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(5, 3));
    }

    @Test
    void isSimplePower_boundaryCase_returnsCorrectResult() {
        assertTrue(IsSimplePower.isSimplePower(27, 3));
    }

    @Test
    void isSimplePower_edgeCase_returnsCorrectResult() {
        assertFalse(IsSimplePower.isSimplePower(10, 3));
    }

    @Test
    void isSimplePower_cornerCase_returnsCorrectResult() {
        assertFalse(IsSimplePower.isSimplePower(26, 3));
    }

    @Test
    void isSimplePower_xEqualsN_returnsTrue() {
        assertTrue(IsSimplePower.isSimplePower(5, 5));
    }

    @Test
    void isSimplePower_nGreaterThanX_returnsFalse() {
        assertFalse(IsSimplePower.isSimplePower(2, 3));
    }
}