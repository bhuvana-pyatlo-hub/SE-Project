package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CountDistinctCharactersTest {

    @Test
    void testEmptyString() {
        assertEquals(0, CountDistinctCharacters.countDistinctCharacters(""));
    }

    @Test
    void testSingleCharacter() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("a"));
    }

    @Test
    void testAllSameCharacters() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("aaaa"));
    }

    @Test
    void testAllSameCharactersDifferentCase() {
        assertEquals(1, CountDistinctCharacters.countDistinctCharacters("AAAAaaaa"));
    }

    @Test
    void testDistinctCharacters() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcde"));
    }

    @Test
    void testMixedCaseDistinctCharacters() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcdeABCDE"));
    }

    @Test
    void testMixedCaseRepeatedCharacters() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("aAbBcC"));
    }

    @Test
    void testStringWithSpaces() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("a b c"));
    }

    @Test
    void testStringWithNumbers() {
        assertEquals(6, CountDistinctCharacters.countDistinctCharacters("a1b2c3"));
    }

    @Test
    void testStringWithSpecialCharacters() {
        assertEquals(4, CountDistinctCharacters.countDistinctCharacters("a!b@c#"));
    }

    @Test
    void testLongString() {
        assertEquals(26, CountDistinctCharacters.countDistinctCharacters("abcdefghijklmnopqrstuvwxyz"));
    }

    @Test
    void testLongStringMixedCase() {
        assertEquals(26, CountDistinctCharacters.countDistinctCharacters("aBcDeFgHiJkLmNoPqRsTuVwXyZ"));
    }

    @Test
    void testRealisticString() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("Jerry"));
    }

    @Test
    void testRealisticStringMixedCaseRepeated() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("Jerry jERRY JeRRRY"));
    }

    @Test
    void testRealisticStringMixedCaseRepeated2() {
        assertEquals(5, CountDistinctCharacters.countDistinctCharacters("abcdecadeCADE"));
    }

    @Test
    void testRealisticStringMixedCaseRepeated3() {
        assertEquals(3, CountDistinctCharacters.countDistinctCharacters("xyzXYZ"));
    }
}