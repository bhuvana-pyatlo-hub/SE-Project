package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PluckTest {

    @Test
    void pluck_emptyArray_returnsEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_noEvenNumbers_returnsEmptyList() {
        List<Object> input = Arrays.asList(1, 3, 5, 7);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_singleEvenNumber_returnsCorrectList() {
        List<Object> input = Arrays.asList(1, 2, 3, 5);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_multipleEvenNumbers_returnsSmallestEvenNumberAndIndex() {
        List<Object> input = Arrays.asList(4, 2, 3);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_multipleEvenNumbersSameValue_returnsFirstOccurrence() {
        List<Object> input = Arrays.asList(5, 0, 3, 0, 4, 2);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_evenNumberAtEnd_returnsCorrectList() {
        List<Object> input = Arrays.asList(1, 3, 5, 2);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_onlyEvenNumbers_returnsSmallest() {
        List<Object> input = Arrays.asList(4, 2, 6, 8);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_zeroInArray_returnsZeroAndIndex() {
        List<Object> input = Arrays.asList(1, 0, 3, 5);
        List<Object> expected = Arrays.asList(0, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_allZeros_returnsFirstZero() {
        List<Object> input = Arrays.asList(0, 0, 0, 0);
        List<Object> expected = Arrays.asList(0, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_largeEvenNumbers_returnsSmallest() {
        List<Object> input = Arrays.asList(200, 400, 100, 300);
        List<Object> expected = Arrays.asList(100, 2);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_negativeNumbers_ignoresNegativeNumbers() {
        List<Object> input = Arrays.asList(-2, 4, 2, -6);
        List<Object> expected = Arrays.asList(2, 2);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_mixedDataTypes_onlyInteger() {
        List<Object> input = Arrays.asList(1, 2, "string", 4);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_mixedDataTypes_onlyString() {
        List<Object> input = Arrays.asList("string", "string2");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_mixedDataTypes_stringAndInteger() {
        List<Object> input = Arrays.asList("string", 1, 3, 2);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_onlyOneElementEven() {
        List<Object> input = Arrays.asList(2);
        List<Object> expected = Arrays.asList(2, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_onlyOneElementOdd() {
        List<Object> input = Arrays.asList(1);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_zeroAsFirstElement() {
        List<Object> input = Arrays.asList(0, 1, 3);
        List<Object> expected = Arrays.asList(0, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_zeroAsLastElement() {
        List<Object> input = Arrays.asList(1, 3, 0);
        List<Object> expected = Arrays.asList(0, 2);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_multipleZeros() {
        List<Object> input = Arrays.asList(0, 2, 0, 4);
        List<Object> expected = Arrays.asList(0, 0);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_largeArrayWithEvenAndOdd() {
        List<Object> input = Arrays.asList(1, 3, 5, 2, 4, 6, 8, 10, 7, 9);
        List<Object> expected = Arrays.asList(2, 3);
        assertEquals(expected, Pluck.pluck(input));
    }

    @Test
    void pluck_allOddNumbers() {
        List<Object> input = Arrays.asList(1, 3, 5, 7, 9);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, Pluck.pluck(input));
    }
}