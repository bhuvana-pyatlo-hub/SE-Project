package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CorrectBracketingTest {

    @Test
    void testEmptyString() {
        assertTrue(CorrectBracketing.correctBracketing(""));
    }

    @Test
    void testSimpleCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<>"));
    }

    @Test
    void testMultipleCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<<>>"));
    }

    @Test
    void testNestedCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<<><>>"));
    }

    @Test
    void testComplexCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<><>><>"));
    }

    @Test
    void testUnclosedBracketAtEnd() {
        assertFalse(CorrectBracketing.correctBracketing("<"));
    }

    @Test
    void testUnclosedBracketsAtEnd() {
        assertFalse(CorrectBracketing.correctBracketing("<<<"));
    }

    @Test
    void testUnopenedBracketAtBeginning() {
        assertFalse(CorrectBracketing.correctBracketing(">"));
    }

    @Test
    void testUnopenedBracketsAtBeginning() {
        assertFalse(CorrectBracketing.correctBracketing(">>>"));
    }

    @Test
    void testMixedUnbalancedBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("><"));
    }

    @Test
    void testMixedUnbalancedBrackets2() {
        assertFalse(CorrectBracketing.correctBracketing("<<>"));
    }

    @Test
    void testMixedUnbalancedBrackets3() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>><<>"));
    }

    @Test
    void testMixedUnbalancedBrackets4() {
        assertFalse(CorrectBracketing.correctBracketing("<><><<><>><>>><>"));
    }

    @Test
    void testLargeCorrectBracketing() {
        assertTrue(CorrectBracketing.correctBracketing("<><><<<><><>><>><<><><<>>>"));
    }

    @Test
    void testLargeIncorrectBracketing() {
        assertFalse(CorrectBracketing.correctBracketing("<<<><>>>>"));
    }

    @Test
    void testIncorrectBracketingStartWithClose() {
        assertFalse(CorrectBracketing.correctBracketing("><<>"));
    }

    @Test
    void testSingleOpenBracket() {
        assertFalse(CorrectBracketing.correctBracketing("<"));
    }

    @Test
    void testSingleCloseBracket() {
        assertFalse(CorrectBracketing.correctBracketing(">"));
    }

    @Test
    void testAlternatingUnbalanced() {
        assertFalse(CorrectBracketing.correctBracketing("><<>"));
    }

    @Test
    void testOnlyOpenBrackets() {
        assertFalse(CorrectBracketing.correctBracketing("<<<<<<<<<<"));
    }

    @Test
    void testOnlyCloseBrackets() {
        assertFalse(CorrectBracketing.correctBracketing(">>>>>>>>>>"));
    }
}