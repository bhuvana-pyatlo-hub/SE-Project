package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CountNumsTest {

    @Test
    void testEmptyArray() {
        List<Object> arr = new ArrayList<>();
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testPositiveNumbers() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(5, CountNums.countNums(arr));
    }

    @Test
    void testNegativeNumbers() {
        List<Object> arr = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testMixedNumbers() {
        List<Object> arr = Arrays.asList(-1, 1, -2, 2, -3, 3);
        assertEquals(3, CountNums.countNums(arr));
    }

    @Test
    void testZero() {
        List<Object> arr = Arrays.asList(0, 0, 0);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testLargeNumbers() {
        List<Object> arr = Arrays.asList(100, 99, -100, -99);
        assertEquals(2, CountNums.countNums(arr));
    }

    @Test
    void testSingleNumber() {
        List<Object> arr = Arrays.asList(50);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void testSingleNegativeNumber() {
        List<Object> arr = Arrays.asList(-50);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testMixedLargeAndSmall() {
        List<Object> arr = Arrays.asList(1, 100, -1, -100);
        assertEquals(2, CountNums.countNums(arr));
    }

    @Test
    void testAllZerosAndOne() {
        List<Object> arr = Arrays.asList(0, 0, 0, 1);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void testNegativeAndZero() {
        List<Object> arr = Arrays.asList(-1, -2, 0);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testPositiveAndZero() {
        List<Object> arr = Arrays.asList(1, 0, 2);
        assertEquals(2, CountNums.countNums(arr));
    }

    @Test
    void testNegativeAndPositive() {
        List<Object> arr = Arrays.asList(-1, 1);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void testNegativePositiveAndZero() {
        List<Object> arr = Arrays.asList(-1, 1, 0);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void testLargeNegativeNumber() {
        List<Object> arr = Arrays.asList(-99);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testLargePositiveNumber() {
        List<Object> arr = Arrays.asList(99);
        assertEquals(1, CountNums.countNums(arr));
    }

    @Test
    void testNegativeSingleDigit() {
        List<Object> arr = Arrays.asList(-5);
        assertEquals(0, CountNums.countNums(arr));
    }

    @Test
    void testPositiveSingleDigit() {
        List<Object> arr = Arrays.asList(5);
        assertEquals(1, CountNums.countNums(arr));
    }
}