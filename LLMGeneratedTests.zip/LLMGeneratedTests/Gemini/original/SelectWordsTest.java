package original;

import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

class SelectWordsTest {

    @Test
    void testEmptyString() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SelectWords.selectWords("", 4));
    }

    @Test
    void testSingleWordMatch() {
        List<Object> expected = new ArrayList<>();
        expected.add("little");
        assertEquals(expected, SelectWords.selectWords("Mary had a little lamb", 4));
    }

    @Test
    void testMultipleWordsMatch() {
        List<Object> expected = new ArrayList<>();
        expected.add("Mary");
        expected.add("lamb");
        assertEquals(expected, SelectWords.selectWords("Mary had a little lamb", 3));
    }

    @Test
    void testNoWordsMatch() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SelectWords.selectWords("simple white space", 2));
    }

    @Test
    void testSingleWordMatchAtEnd() {
        List<Object> expected = new ArrayList<>();
        expected.add("world");
        assertEquals(expected, SelectWords.selectWords("Hello world", 4));
    }

    @Test
    void testSingleWordMatchAtBeginning() {
        List<Object> expected = new ArrayList<>();
        expected.add("Uncle");
        assertEquals(expected, SelectWords.selectWords("Uncle sam", 3));
    }

    @Test
    void testOnlyVowels() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SelectWords.selectWords("a e i o u", 1));
    }

    @Test
    void testOnlyConsonants() {
        List<Object> expected = new ArrayList<>();
        expected.add("bcdfghjklmnpqrstvwxyz");
        assertEquals(expected, SelectWords.selectWords("bcdfghjklmnpqrstvwxyz", 19));
    }

    @Test
    void testMixedCaseVowels() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SelectWords.selectWords("A E I O U", 1));
    }

    @Test
    void testMixedCaseWord() {
        List<Object> expected = new ArrayList<>();
        expected.add("tEst");
        assertEquals(expected, SelectWords.selectWords("tEst", 3));
    }

    @Test
    void testZeroConsonantsRequired() {
        List<Object> expected = new ArrayList<>();
        expected.add("a");
        expected.add("e");
        expected.add("i");
        expected.add("o");
        expected.add("u");
        assertEquals(expected, SelectWords.selectWords("a e i o u", 0));
    }

    @Test
    void testSingleCharacterWords() {
        List<Object> expected = new ArrayList<>();
        expected.add("b");
        expected.add("c");
        expected.add("d");
        expected.add("f");
        assertEquals(expected, SelectWords.selectWords("a b c d e f", 1));
    }

    @Test
    void testLeadingAndTrailingSpaces() {
        List<Object> expected = new ArrayList<>();
        assertEquals(new ArrayList<>(), SelectWords.selectWords("  hello world  ", 5));
    }

    @Test
    void testMultipleSpacesBetweenWords() {
        List<Object> expected = new ArrayList<>();
        assertEquals(new ArrayList<>(), SelectWords.selectWords("hello  world", 5));
    }

    @Test
    void testWordWithAllConsonants() {
        List<Object> expected = new ArrayList<>();
        expected.add("strngth");
        assertEquals(expected, SelectWords.selectWords("strngth", 7));
    }

    @Test
    void testWordWithAllVowels() {
        List<Object> expected = new ArrayList<>();
        assertEquals(new ArrayList<>(), SelectWords.selectWords("aeiou", 1));
    }

    @Test
    void testWordWithMixedVowelsAndConsonants() {
        List<Object> expected = new ArrayList<>();
        expected.add("example");
        assertEquals(expected, SelectWords.selectWords("example", 4));
    }

    @Test
    void testStringWithOnlySpaces() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, SelectWords.selectWords("   ", 1));
    }

    @Test
    void testStringWithNumber() {
        List<Object> expected = new ArrayList<>();
        assertEquals(new ArrayList<>(), SelectWords.selectWords("123", 1));
    }

    @Test
    void testStringWithSpecialCharacters() {
        List<Object> expected = new ArrayList<>();
        assertEquals(new ArrayList<>(), SelectWords.selectWords("!@#", 1));
    }
}