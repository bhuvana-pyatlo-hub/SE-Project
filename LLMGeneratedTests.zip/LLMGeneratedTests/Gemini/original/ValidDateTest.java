package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ValidDateTest {

    @Test
    void validDate_validDate_returnsTrue() {
        assertTrue(ValidDate.validDate("03-11-2000"));
    }

    @Test
    void validDate_invalidDay_returnsFalse() {
        assertFalse(ValidDate.validDate("15-01-2012"));
    }

    @Test
    void validDate_invalidDayZero_returnsFalse() {
        assertFalse(ValidDate.validDate("04-0-2040"));
    }

    @Test
    void validDate_validDate2_returnsTrue() {
        assertTrue(ValidDate.validDate("06-04-2020"));
    }

    @Test
    void validDate_validDate3_returnsTrue() {
        assertTrue(ValidDate.validDate("01-01-2007"));
    }

    @Test
    void validDate_invalidDay32_returnsFalse() {
        assertFalse(ValidDate.validDate("03-32-2011"));
    }

    @Test
    void validDate_emptyString_returnsFalse() {
        assertFalse(ValidDate.validDate(""));
    }

    @Test
    void validDate_invalidDay31InApril_returnsFalse() {
        assertFalse(ValidDate.validDate("04-31-3000"));
    }

    @Test
    void validDate_validDate4_returnsTrue() {
        assertTrue(ValidDate.validDate("06-06-2005"));
    }

    @Test
    void validDate_invalidDay31InFebruary_returnsFalse() {
        assertFalse(ValidDate.validDate("02-31-2000"));
    }

    @Test
    void validDate_validDate5_returnsTrue() {
        assertTrue(ValidDate.validDate("04-12-2003"));
    }

    @Test
    void validDate_invalidFormat1_returnsFalse() {
        assertFalse(ValidDate.validDate("04122003"));
    }

    @Test
    void validDate_invalidFormat2_returnsFalse() {
        assertFalse(ValidDate.validDate("20030412"));
    }

    @Test
    void validDate_invalidFormat3_returnsFalse() {
        assertFalse(ValidDate.validDate("2003-04"));
    }

    @Test
    void validDate_invalidFormat4_returnsFalse() {
        assertFalse(ValidDate.validDate("2003-04-12"));
    }

    @Test
    void validDate_invalidFormat5_returnsFalse() {
        assertFalse(ValidDate.validDate("04-2003"));
    }

    @Test
    void validDate_nullInput_returnsFalse() {
        assertFalse(ValidDate.validDate(null));
    }

    @Test
    void validDate_invalidMonthZero_returnsFalse() {
        assertFalse(ValidDate.validDate("00-01-2023"));
    }

    @Test
    void validDate_invalidMonth13_returnsFalse() {
        assertFalse(ValidDate.validDate("13-01-2023"));
    }

    @Test
    void validDate_validLeapYearFebruary29_returnsTrue() {
        assertTrue(ValidDate.validDate("02-29-2020"));
    }

    @Test
    void validDate_invalidNonLeapYearFebruary29_returnsFalse() {
        assertFalse(ValidDate.validDate("02-29-2021"));
    }

    @Test
    void validDate_validDay31InJanuary_returnsTrue() {
        assertTrue(ValidDate.validDate("01-31-2023"));
    }

    @Test
    void validDate_validDay30InApril_returnsTrue() {
        assertTrue(ValidDate.validDate("04-30-2023"));
    }

    @Test
    void validDate_invalidDay0InJanuary_returnsFalse() {
        assertFalse(ValidDate.validDate("01-00-2023"));
    }

    @Test
    void validDate_invalidDay0InApril_returnsFalse() {
        assertFalse(ValidDate.validDate("04-00-2023"));
    }

    @Test
    void validDate_invalidDay0InFebruary_returnsFalse() {
        assertFalse(ValidDate.validDate("02-00-2023"));
    }

    @Test
    void validDate_validDay1InJanuary_returnsTrue() {
        assertTrue(ValidDate.validDate("01-01-2023"));
    }

    @Test
    void validDate_validDay1InApril_returnsTrue() {
        assertTrue(ValidDate.validDate("04-01-2023"));
    }

    @Test
    void validDate_validDay1InFebruary_returnsTrue() {
        assertTrue(ValidDate.validDate("02-01-2023"));
    }

    @Test
    void validDate_invalidFormatTooShort_returnsFalse() {
        assertFalse(ValidDate.validDate("01-01-23"));
    }

    @Test
    void validDate_invalidFormatTooLong_returnsFalse() {
        assertFalse(ValidDate.validDate("01-01-20234"));
    }
}