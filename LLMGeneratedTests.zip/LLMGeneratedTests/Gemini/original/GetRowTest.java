package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetRowTest {

    @Test
    void getRow_emptyList_returnsEmptyList() {
        List<Object> lst = new ArrayList<>();
        int x = 1;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_noMatchingElement_returnsEmptyList() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6));
        int x = 7;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_singleMatchingElement_returnsCorrectCoordinate() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6));
        int x = 5;
        List<Object> expected = Arrays.asList(Arrays.asList(1, 1));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_multipleMatchingElements_returnsSortedCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 1), Arrays.asList(1, 5, 1));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 2), Arrays.asList(0, 0), Arrays.asList(1, 2), Arrays.asList(1, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_emptyRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(new ArrayList<>(), Arrays.asList(1), Arrays.asList(1, 2, 3));
        int x = 3;
        List<Object> expected = Arrays.asList(Arrays.asList(2, 2));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_multipleRows_returnsSortedCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1), Arrays.asList(1, 2), Arrays.asList(1, 2, 3));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0), Arrays.asList(1, 0), Arrays.asList(2, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_sameRowMultipleMatches_returnsDescendingColumnOrder() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 1, 1));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 2), Arrays.asList(0, 1), Arrays.asList(0, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_differentRowsMultipleMatches_returnsCorrectOrder() {
        List<Object> lst = Arrays.asList(Arrays.asList(2, 1), Arrays.asList(1, 2));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 1), Arrays.asList(1, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsZero_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(0, 1), Arrays.asList(1, 0));
        int x = 0;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0), Arrays.asList(1, 1));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsNegative_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(-1, 1), Arrays.asList(1, -1));
        int x = -1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0), Arrays.asList(1, 1));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_largeList_returnsCorrectCoordinates() {
        List<Object> lst = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            List<Object> row = new ArrayList<>();
            for (int j = 0; j < 10; j++) {
                row.add(i * 10 + j);
            }
            lst.add(row);
        }
        int x = 55;
        List<Object> expected = Arrays.asList(Arrays.asList(5, 5));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_allRowsEmpty_returnsEmptyList() {
        List<Object> lst = Arrays.asList(new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
        int x = 1;
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xPresentOnlyInFirstRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6), Arrays.asList(7, 8, 9));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xPresentOnlyInLastRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(10, 11, 12), Arrays.asList(13, 14, 15), Arrays.asList(1, 2, 3));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(2, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xPresentInFirstAndLastRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6), Arrays.asList(1, 8, 9));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0), Arrays.asList(2, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xPresentMultipleTimesInMultipleRows_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 1), Arrays.asList(1, 5, 1), Arrays.asList(7, 1, 9));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 2), Arrays.asList(0, 0), Arrays.asList(1, 2), Arrays.asList(1, 0), Arrays.asList(2, 1));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsLastElementInLastRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(10, 11, 12), Arrays.asList(13, 14, 15), Arrays.asList(7, 8, 1));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(2, 2));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsFirstElementInFirstRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6), Arrays.asList(7, 8, 9));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsOnlyElementInSingleRow_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }

    @Test
    void getRow_xIsPresentInAllRowsAndColumns_returnsCorrectCoordinates() {
        List<Object> lst = Arrays.asList(Arrays.asList(1, 1, 1), Arrays.asList(1, 1, 1), Arrays.asList(1, 1, 1));
        int x = 1;
        List<Object> expected = Arrays.asList(Arrays.asList(0, 2), Arrays.asList(0, 1), Arrays.asList(0, 0), Arrays.asList(1, 2), Arrays.asList(1, 1), Arrays.asList(1, 0), Arrays.asList(2, 2), Arrays.asList(2, 1), Arrays.asList(2, 0));
        assertEquals(expected, GetRow.getRow(lst, x));
    }
}