package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FileNameCheckTest {

    @Test
    void fileNameCheck_validFileNameTxt() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("example.txt"));
    }

    @Test
    void fileNameCheck_validFileNameExe() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("K.exe"));
    }

    @Test
    void fileNameCheck_validFileNameDll() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("MY16FILE3.dll"));
    }

    @Test
    void fileNameCheck_invalidFileNameMultipleDots() {
        assertEquals("No", FileNameCheck.fileNameCheck("all.exe.txt"));
    }

    @Test
    void fileNameCheck_invalidFileNameNoDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("final132"));
    }

    @Test
    void fileNameCheck_invalidFileNameEmptyBeforeDot() {
        assertEquals("No", FileNameCheck.fileNameCheck(".txt"));
    }

    @Test
    void fileNameCheck_invalidFileNameEmptyBeforeDot2() {
        assertEquals("No", FileNameCheck.fileNameCheck(".exe"));
    }

    @Test
    void fileNameCheck_invalidFileNameEmptyBeforeDot3() {
        assertEquals("No", FileNameCheck.fileNameCheck(".dll"));
    }

    @Test
    void fileNameCheck_invalidFileNameNoLetterStart() {
        assertEquals("No", FileNameCheck.fileNameCheck("1example.dll"));
    }

    @Test
    void fileNameCheck_invalidFileNameTooManyDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("His12FILE94.exe"));
    }

    @Test
    void fileNameCheck_invalidFileNameInvalidSuffix() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_valid.wow"));
    }

    @Test
    void fileNameCheck_invalidFileNameLongSuffix() {
        assertEquals("No", FileNameCheck.fileNameCheck("this_is_valid.txtexe"));
    }

    @Test
    void fileNameCheck_invalidFileNameSpecialCharStart() {
        assertEquals("No", FileNameCheck.fileNameCheck("_Y.txt"));
    }

    @Test
    void fileNameCheck_invalidFileNameSpecialCharStart2() {
        assertEquals("No", FileNameCheck.fileNameCheck("?aREYA.exe"));
    }

    @Test
    void fileNameCheck_invalidFileNameSpecialCharStart3() {
        assertEquals("No", FileNameCheck.fileNameCheck("/this_is_valid.dll"));
    }

    @Test
    void fileNameCheck_validFileNameEdgeCaseThreeDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("I563_No.exe"));
    }

    @Test
    void fileNameCheck_validFileNameEdgeCaseTwoDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("Is3youfault.txt"));
    }

    @Test
    void fileNameCheck_validFileNameSpecialCharMiddle() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("no_one#knows.dll"));
    }

    @Test
    void fileNameCheck_invalidFileNameDigitStartAndTooManyDigits() {
        assertEquals("No", FileNameCheck.fileNameCheck("1I563_Yes3.exe"));
    }

    @Test
    void fileNameCheck_invalidFileNameInvalidSuffix2() {
        assertEquals("No", FileNameCheck.fileNameCheck("I563_Yes3.txtt"));
    }

    @Test
    void fileNameCheck_invalidFileNameDoubleDot() {
        assertEquals("No", FileNameCheck.fileNameCheck("final..txt"));
    }

    @Test
    void fileNameCheck_invalidFileNameNoSuffix() {
        assertEquals("No", FileNameCheck.fileNameCheck("_f4indsartal132."));
    }

    @Test
    void fileNameCheck_validFileNameNoDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("valid.txt"));
    }

    @Test
    void fileNameCheck_validFileNameOneDigit() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("a1.txt"));
    }

    @Test
    void fileNameCheck_validFileNameTwoDigits() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("a12.txt"));
    }

    @Test
    void fileNameCheck_invalidFileNameDotAtEnd() {
        assertEquals("No", FileNameCheck.fileNameCheck("s."));
    }

    @Test
    void fileNameCheck_validFileNameWithUnderscore() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("file_name.txt"));
    }

    @Test
    void fileNameCheck_validFileNameWithUpperCase() {
        assertEquals("Yes", FileNameCheck.fileNameCheck("FileName.txt"));
    }
}