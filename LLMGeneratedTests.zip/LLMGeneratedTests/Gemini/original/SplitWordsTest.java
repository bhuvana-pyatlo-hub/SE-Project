package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SplitWordsTest {

    @Test
    void splitWords_withSpaces_returnsListOfWords() {
        List<String> expected = Arrays.asList("Hello", "world!");
        assertEquals(expected, SplitWords.splitWords("Hello world!"));
    }

    @Test
    void splitWords_withCommas_returnsListOfWords() {
        List<String> expected = Arrays.asList("Hello", "world!");
        assertEquals(expected, SplitWords.splitWords("Hello,world!"));
    }

    @Test
    void splitWords_withNoSpacesOrCommas_returnsCountOfOddOrderedLowercaseLetters() {
        assertEquals(3, SplitWords.splitWords("abcdef"));
    }

    @Test
    void splitWords_withMixedSpacesAndCommas_splitsOnSpaces() {
        List<String> expected = Arrays.asList("Hello", "world,!");
        assertEquals(expected, SplitWords.splitWords("Hello world,!"));
    }

    @Test
    void splitWords_withMultipleCommas_splitsOnCommas() {
        List<String> expected = Arrays.asList("Hello", "Hello", "world !");
        assertEquals(expected, SplitWords.splitWords("Hello,Hello,world !"));
    }

    @Test
    void splitWords_withEmptyString_returnsZero() {
        assertEquals(0, SplitWords.splitWords(""));
    }

    @Test
    void splitWords_withOnlySpaces_returnsListOfEmptyStrings() {
        List<String> expected = Arrays.asList("", "");
        assertEquals(expected, SplitWords.splitWords(" "));
    }

    @Test
    void splitWords_withOnlyCommas_returnsListOfEmptyStrings() {
        List<String> expected = Arrays.asList("", "");
        assertEquals(expected, SplitWords.splitWords(","));
    }

    @Test
    void splitWords_withLowercaseLettersAndOddOrder_returnsCorrectCount() {
        assertEquals(2, SplitWords.splitWords("aaabb"));
    }

    @Test
    void splitWords_withLowercaseAndUppercaseLettersAndOddOrder_returnsCorrectCount() {
        assertEquals(1, SplitWords.splitWords("aaaBb"));
    }

    @Test
    void splitWords_withOnlyUppercaseLetters_returnsZero() {
        assertEquals(0, SplitWords.splitWords("ABCDEF"));
    }

    @Test
    void splitWords_withNumbers_returnsZero() {
        assertEquals(0, SplitWords.splitWords("12345"));
    }

    @Test
    void splitWords_withSpecialCharacters_returnsZero() {
        assertEquals(0, SplitWords.splitWords("!@#$%"));
    }

    @Test
    void splitWords_withMixedCharacters_returnsCorrectCount() {
        assertEquals(1, SplitWords.splitWords("a1bC!"));
    }

    @Test
    void splitWords_withSingleSpaceAtBeginning_splitsCorrectly() {
        List<String> expected = Arrays.asList("", "word");
        assertEquals(expected, SplitWords.splitWords(" word"));
    }

    @Test
    void splitWords_withSingleSpaceAtEnd_splitsCorrectly() {
        List<String> expected = Arrays.asList("word", "");
        assertEquals(expected, SplitWords.splitWords("word "));
    }

    @Test
    void splitWords_withSingleCommaAtBeginning_splitsCorrectly() {
        List<String> expected = Arrays.asList("", "word");
        assertEquals(expected, SplitWords.splitWords(",word"));
    }

    @Test
    void splitWords_withSingleCommaAtEnd_splitsCorrectly() {
        List<String> expected = Arrays.asList("word", "");
        assertEquals(expected, SplitWords.splitWords("word,"));
    }

    @Test
    void splitWords_withSingleLetter_returnsZeroOrOne() {
        assertEquals(0, SplitWords.splitWords("a"));
        assertEquals(1, SplitWords.splitWords("b"));
    }

    @Test
    void splitWords_withOnlyOneWordAndSpace_returnsList() {
        List<String> expected = Arrays.asList("word");
        assertEquals(expected, SplitWords.splitWords("word "));
    }

    @Test
    void splitWords_withOnlyOneWordAndComma_returnsList() {
        List<String> expected = Arrays.asList("word");
        assertEquals(expected, SplitWords.splitWords("word,"));
    }

    @Test
    void splitWords_withSpaceAndComma_splitsOnSpace() {
        List<String> expected = Arrays.asList("a,b", "c");
        assertEquals(expected, SplitWords.splitWords("a,b c"));
    }
}