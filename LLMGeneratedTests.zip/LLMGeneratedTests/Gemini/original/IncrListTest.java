package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class IncrListTest {

    @Test
    void incrList_emptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithIntegers() {
        List<Object> input = Arrays.asList(1, 2, 3);
        List<Object> expected = Arrays.asList(2, 3, 4);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMixedTypes() {
        List<Object> input = Arrays.asList(1, "hello", 3.14, 4);
        List<Object> expected = Arrays.asList(2, 5);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithOnlyStrings() {
        List<Object> input = Arrays.asList("hello", "world");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithOnlyDoubles() {
        List<Object> input = Arrays.asList(1.1, 2.2, 3.3);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -2, -3);
        List<Object> expected = Arrays.asList(0, -1, -2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithZero() {
        List<Object> input = Arrays.asList(0, 0, 0);
        List<Object> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithLargeIntegers() {
        List<Object> input = Arrays.asList(100, 200, 300);
        List<Object> expected = Arrays.asList(101, 201, 301);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMixedPositiveAndNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, 0, 1);
        List<Object> expected = Arrays.asList(0, 1, 2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithDuplicateIntegers() {
        List<Object> input = Arrays.asList(1, 1, 1);
        List<Object> expected = Arrays.asList(2, 2, 2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithNull() {
        List<Object> input = Arrays.asList(1, null, 3);
        List<Object> expected = Arrays.asList(2, 4);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithOnlyNulls() {
        List<Object> input = Arrays.asList(null, null, null);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithIntegerAndString() {
        List<Object> input = Arrays.asList(5, "test");
        List<Object> expected = Arrays.asList(6);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithIntegerAndDouble() {
        List<Object> input = Arrays.asList(5, 3.14);
        List<Object> expected = Arrays.asList(6);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithIntegerAndBoolean() {
        List<Object> input = Arrays.asList(5, true);
        List<Object> expected = Arrays.asList(6);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMultipleTypes() {
        List<Object> input = Arrays.asList(1, "a", 2.0, 3, true, 4);
        List<Object> expected = Arrays.asList(2, 4, 5);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMaxIntValue() {
        List<Object> input = Arrays.asList(Integer.MAX_VALUE);
        List<Object> expected = Arrays.asList((long)Integer.MAX_VALUE + 1);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithMinIntValue() {
        List<Object> input = Arrays.asList(Integer.MIN_VALUE);
        List<Object> expected = Arrays.asList((long)Integer.MIN_VALUE + 1);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithZeroAndOne() {
        List<Object> input = Arrays.asList(0, 1);
        List<Object> expected = Arrays.asList(1, 2);
        assertEquals(expected, IncrList.incrList(input));
    }

    @Test
    void incrList_listWithOneAndZero() {
        List<Object> input = Arrays.asList(1, 0);
        List<Object> expected = Arrays.asList(2, 1);
        assertEquals(expected, IncrList.incrList(input));
    }
}