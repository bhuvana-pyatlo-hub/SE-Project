package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FilterIntegersTest {

    @Test
    void testEmptyList() {
        List<Object> input = new ArrayList<>();
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testOnlyIntegers() {
        List<Object> input = Arrays.asList(1, 2, 3, 4, 5);
        List<Object> expected = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testNoIntegers() {
        List<Object> input = Arrays.asList("a", "b", "c", 3.14, true);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testMixedTypes() {
        List<Object> input = Arrays.asList(1, "a", 2, 3.14, 3, true, 4);
        List<Object> expected = Arrays.asList(1, 2, 3, 4);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testNullValue() {
        List<Object> input = Arrays.asList(1, null, 2, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testOnlyNullValues() {
        List<Object> input = Arrays.asList(null, null, null);
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testLargeIntegers() {
        List<Object> input = Arrays.asList(100, 200, 300, 400, 500);
        List<Object> expected = Arrays.asList(100, 200, 300, 400, 500);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, -2, -3, -4, -5);
        List<Object> expected = Arrays.asList(-1, -2, -3, -4, -5);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testMixedPositiveAndNegativeIntegers() {
        List<Object> input = Arrays.asList(-1, 2, -3, 4, -5);
        List<Object> expected = Arrays.asList(-1, 2, -3, 4, -5);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testZeroInteger() {
        List<Object> input = Arrays.asList(0, "a", 1, 2);
        List<Object> expected = Arrays.asList(0, 1, 2);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testMultipleZeroIntegers() {
        List<Object> input = Arrays.asList(0, 0, 0, "a");
        List<Object> expected = Arrays.asList(0, 0, 0);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testIntegersAndStrings() {
        List<Object> input = Arrays.asList(1, "hello", 2, "world", 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testIntegersAndDoubles() {
        List<Object> input = Arrays.asList(1, 2.5, 2, 3.7, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testIntegersAndBooleans() {
        List<Object> input = Arrays.asList(1, true, 2, false, 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testIntegersAndCharacters() {
        List<Object> input = Arrays.asList(1, 'a', 2, 'b', 3);
        List<Object> expected = Arrays.asList(1, 2, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testIntegersAndMixedTypes() {
        List<Object> input = Arrays.asList(1, "a", 2.5, true, 3, 'c');
        List<Object> expected = Arrays.asList(1, 3);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testRepeatedIntegers() {
        List<Object> input = Arrays.asList(1, 1, 1, 1, 1);
        List<Object> expected = Arrays.asList(1, 1, 1, 1, 1);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testRepeatedIntegersMixedWithOtherTypes() {
        List<Object> input = Arrays.asList(1, "a", 1, 2.5, 1, true);
        List<Object> expected = Arrays.asList(1, 1, 1);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testListWithOnlyOneInteger() {
        List<Object> input = Arrays.asList(5);
        List<Object> expected = Arrays.asList(5);
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }

    @Test
    void testListWithOneNonInteger() {
        List<Object> input = Arrays.asList("test");
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, FilterIntegers.filterIntegers(input));
    }
}