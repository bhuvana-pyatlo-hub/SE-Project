package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FizzBuzzTest {

    @Test
    void fizzBuzz_zero() {
        assertEquals(0, FizzBuzz.fizzBuzz(0));
    }

    @Test
    void fizzBuzz_one() {
        assertEquals(0, FizzBuzz.fizzBuzz(1));
    }

    @Test
    void fizzBuzz_ten() {
        assertEquals(0, FizzBuzz.fizzBuzz(10));
    }

    @Test
    void fizzBuzz_eleven() {
        assertEquals(0, FizzBuzz.fizzBuzz(11));
    }

    @Test
    void fizzBuzz_twelve() {
        assertEquals(0, FizzBuzz.fizzBuzz(12));
    }

    @Test
    void fizzBuzz_thirteen() {
        assertEquals(0, FizzBuzz.fizzBuzz(13));
    }

    @Test
    void fizzBuzz_fourteen() {
        assertEquals(0, FizzBuzz.fizzBuzz(14));
    }

    @Test
    void fizzBuzz_seventeen() {
        assertEquals(1, FizzBuzz.fizzBuzz(77));
    }

    @Test
    void fizzBuzz_seventyEight() {
        assertEquals(2, FizzBuzz.fizzBuzz(78));
    }

    @Test
    void fizzBuzz_seventyNine() {
        assertEquals(3, FizzBuzz.fizzBuzz(79));
    }

    @Test
    void fizzBuzz_fifty() {
        assertEquals(0, FizzBuzz.fizzBuzz(50));
    }

    @Test
    void fizzBuzz_oneHundred() {
        assertEquals(3, FizzBuzz.fizzBuzz(100));
    }

    @Test
    void fizzBuzz_twoHundred() {
        assertEquals(6, FizzBuzz.fizzBuzz(200));
    }

    @Test
    void fizzBuzz_smallValue() {
        assertEquals(0, FizzBuzz.fizzBuzz(22));
    }

    @Test
    void fizzBuzz_anotherSmallValue() {
        assertEquals(0, FizzBuzz.fizzBuzz(26));
    }

    @Test
    void fizzBuzz_boundaryValue() {
        assertEquals(0, FizzBuzz.fizzBuzz(143));
    }

    @Test
    void fizzBuzz_edgeCase() {
        assertEquals(0, FizzBuzz.fizzBuzz(144));
    }

    @Test
    void fizzBuzz_cornerCase() {
        assertEquals(0, FizzBuzz.fizzBuzz(156));
    }

    @Test
    void fizzBuzz_validInput() {
        assertEquals(0, FizzBuzz.fizzBuzz(169));
    }

    @Test
    void fizzBuzz_largeNumberWithSevens() {
        assertEquals(12, FizzBuzz.fizzBuzz(777));
    }

    @Test
    void fizzBuzz_fourThousand() {
        assertEquals(192, FizzBuzz.fizzBuzz(4000));
    }

    @Test
    void fizzBuzz_tenThousand() {
        assertEquals(639, FizzBuzz.fizzBuzz(10000));
    }

    @Test
    void fizzBuzz_tenThousandWithSevens() {
        assertEquals(639, FizzBuzz.fizzBuzz(10000));
    }

    @Test
    void fizzBuzz_oneHundredThousand() {
        assertEquals(8026, FizzBuzz.fizzBuzz(100000));
    }
}