package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SpecialfilterTest {

    @Test
    void specialfilter_emptyList_returnsZero() {
        assertEquals(0, Specialfilter.specialfilter(Collections.emptyList()));
    }

    @Test
    void specialfilter_nullList_throwsException() {
        assertThrows(NullPointerException.class, () -> Specialfilter.specialfilter(null));
    }

    @Test
    void specialfilter_singleElementLessThanOrEqualToTen_returnsZero() {
        List<Object> nums = Arrays.asList(5);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_singleElementGreaterThanTenButNotOddDigits_returnsZero() {
        List<Object> nums = Arrays.asList(12);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_singleElementGreaterThanTenAndOddDigits_returnsOne() {
        List<Object> nums = Arrays.asList(15);
        assertEquals(1, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements_correctCount() {
        List<Object> nums = Arrays.asList(15, -73, 14, -15);
        assertEquals(1, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements_correctCount2() {
        List<Object> nums = Arrays.asList(33, -2, -3, 45, 21, 109);
        assertEquals(2, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements_correctCount3() {
        List<Object> nums = Arrays.asList(43, -12, 93, 125, 121, 109);
        assertEquals(4, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_multipleElements_correctCount4() {
        List<Object> nums = Arrays.asList(71, -2, -33, 75, 21, 19);
        assertEquals(3, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_onlyOneElement_returnsZero() {
        List<Object> nums = Arrays.asList(1);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_allElementsLessThanTen_returnsZero() {
        List<Object> nums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_allElementsGreaterThanTenButNotOddDigits_returnsZero() {
        List<Object> nums = Arrays.asList(12, 24, 36, 48, 62, 84);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_allElementsGreaterThanTenAndOddDigits_returnsCorrectCount() {
        List<Object> nums = Arrays.asList(15, 35, 55, 75, 95, 11, 31, 51, 71, 91);
        assertEquals(10, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_mixedElements_correctCount() {
        List<Object> nums = Arrays.asList(5, 15, 24, 35, 10, 11);
        assertEquals(3, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_negativeNumbers_correctCount() {
        List<Object> nums = Arrays.asList(-15, -35, -55, -75, -95);
        assertEquals(0, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_zeroInList_correctCount() {
        List<Object> nums = Arrays.asList(0, 15, 35);
        assertEquals(2, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_largeNumbers_correctCount() {
        List<Object> nums = Arrays.asList(111, 333, 555, 777, 999);
        assertEquals(5, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_listWithNonIntegerObjects_throwsClassCastException() {
        List<Object> nums = new ArrayList<>();
        nums.add(15);
        nums.add("string");
        nums.add(35);
        assertThrows(ClassCastException.class, () -> Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_numberStartingWithZero_correctCount() {
        List<Object> nums = Arrays.asList(15, 35, 101, 303);
        assertEquals(2, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_numberEndingWithZero_correctCount() {
        List<Object> nums = Arrays.asList(10, 11, 31, 51, 71, 91);
        assertEquals(5, Specialfilter.specialfilter(nums));
    }

    @Test
    void specialfilter_numberWithSameFirstAndLastDigit_correctCount() {
        List<Object> nums = Arrays.asList(11, 33, 55, 77, 99);
        assertEquals(5, Specialfilter.specialfilter(nums));
    }
}