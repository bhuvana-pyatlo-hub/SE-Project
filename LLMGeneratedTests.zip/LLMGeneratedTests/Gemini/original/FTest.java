package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FTest {

    @Test
    void testF_nEquals1() {
        List<Integer> expected = Arrays.asList(1);
        assertEquals(expected, F.f(1));
    }

    @Test
    void testF_nEquals2() {
        List<Integer> expected = Arrays.asList(1, 2);
        assertEquals(expected, F.f(2));
    }

    @Test
    void testF_nEquals3() {
        List<Integer> expected = Arrays.asList(1, 2, 6);
        assertEquals(expected, F.f(3));
    }

    @Test
    void testF_nEquals4() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24);
        assertEquals(expected, F.f(4));
    }

    @Test
    void testF_nEquals5() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15);
        assertEquals(expected, F.f(5));
    }

    @Test
    void testF_nEquals6() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720);
        assertEquals(expected, F.f(6));
    }

    @Test
    void testF_nEquals7() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28);
        assertEquals(expected, F.f(7));
    }

    @Test
    void testF_nEquals0() {
        List<Integer> expected = Arrays.asList();
        assertEquals(expected, F.f(0));
    }

    @Test
    void testF_nEquals10() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800);
        assertEquals(expected, F.f(10));
    }

    @Test
    void testF_nEquals8() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320);
        assertEquals(expected, F.f(8));
    }

    @Test
    void testF_nEquals9() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45);
        assertEquals(expected, F.f(9));
    }

    @Test
    void testF_nEquals11() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66);
        assertEquals(expected, F.f(11));
    }

    @Test
    void testF_nEquals12() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600);
        assertEquals(expected, F.f(12));
    }

    @Test
    void testF_nEquals13() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91);
        assertEquals(expected, F.f(13));
    }

    @Test
    void testF_nEquals14() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912);
        assertEquals(expected, F.f(14));
    }

    @Test
    void testF_nEquals15() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120);
        assertEquals(expected, F.f(15));
    }

    @Test
    void testF_nEquals16() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278986);
        assertEquals(expected, F.f(16));
    }

    @Test
    void testF_nEquals17() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278986, 153);
        assertEquals(expected, F.f(17));
    }

    @Test
    void testF_nEquals18() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278986, 153, 640237370);
        assertEquals(expected, F.f(18));
    }

    @Test
    void testF_nEquals19() {
        List<Integer> expected = Arrays.asList(1, 2, 6, 24, 15, 720, 28, 40320, 45, 3628800, 66, 479001600, 91, 871782912, 120, 2092278986, 153, 640237370, 190);
        assertEquals(expected, F.f(19));
    }
}