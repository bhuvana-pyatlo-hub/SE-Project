package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsBoredTest {

    @Test
    void isBored_emptyString_returnsZero() {
        assertEquals(0, IsBored.isBored(""));
    }

    @Test
    void isBored_noSentences_returnsZero() {
        assertEquals(0, IsBored.isBored("Hello world"));
    }

    @Test
    void isBored_oneSentenceNotStartingWithI_returnsZero() {
        assertEquals(0, IsBored.isBored("The sky is blue."));
    }

    @Test
    void isBored_oneSentenceStartingWithI_returnsOne() {
        assertEquals(1, IsBored.isBored("I love this weather."));
    }

    @Test
    void isBored_multipleSentencesOneStartingWithI_returnsOne() {
        assertEquals(1, IsBored.isBored("The sky is blue. I love this weather."));
    }

    @Test
    void isBored_multipleSentencesMultipleStartingWithI_returnsCorrectCount() {
        assertEquals(2, IsBored.isBored("I feel good today. I will be productive."));
    }

    @Test
    void isBored_sentenceWithQuestionMark_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("Is the sky blue? I am happy."));
    }

    @Test
    void isBored_sentenceWithExclamationMark_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("I love It !"));
    }

    @Test
    void isBored_sentenceWithMultipleDelimiters_returnsCorrectCount() {
        assertEquals(2, IsBored.isBored("I feel good today. I will be productive! will kill It?"));
    }

    @Test
    void isBored_sentenceWithLeadingAndTrailingSpaces_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("  I feel good today.  "));
    }

    @Test
    void isBored_sentenceWithOnlySpaces_returnsZero() {
        assertEquals(0, IsBored.isBored("   "));
    }

    @Test
    void isBored_sentenceWithEmptyWords_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("I  feel good today."));
    }

    @Test
    void isBored_sentenceWithOnlyDelimiter_returnsZero() {
        assertEquals(0, IsBored.isBored("."));
    }

    @Test
    void isBored_sentenceStartingWithIBfollowedBySpace_returnsZero() {
        assertEquals(0, IsBored.isBored("IB test."));
    }

    @Test
    void isBored_sentenceStartingWithILowercase_returnsZero() {
        assertEquals(0, IsBored.isBored("i test."));
    }

    @Test
    void isBored_multipleSentencesWithEmptySentences_returnsCorrectCount() {
        assertEquals(1, IsBored.isBored("I am happy..I am sad."));
    }

    @Test
    void isBored_sentenceWithIAsSecondWord_returnsZero() {
        assertEquals(0, IsBored.isBored("You and I are going for a walk."));
    }

    @Test
    void isBored_sentenceWithIAndOtherWords_returnsOne() {
        assertEquals(1, IsBored.isBored("I am going for a walk."));
    }

    @Test
    void isBored_sentenceWithIAtTheEnd_returnsZero() {
        assertEquals(0, IsBored.isBored("Hello I."));
    }

    @Test
    void isBored_multipleSentencesWithIAtTheEnd_returnsZero() {
        assertEquals(0, IsBored.isBored("Hello I. Goodbye I."));
    }

    @Test
    void isBored_sentenceWithIAndPunctuationImmediatelyAfter_returnsOne() {
        assertEquals(1, IsBored.isBored("I! am happy."));
    }
}