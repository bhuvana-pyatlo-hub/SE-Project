package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StringXorTest {

    @Test
    void stringXor_sameStrings_returnsZeroString() {
        assertEquals("000", StringXor.stringXor("111", "111"));
    }

    @Test
    void stringXor_differentStrings_returnsCorrectXor() {
        assertEquals("100", StringXor.stringXor("010", "110"));
    }

    @Test
    void stringXor_longerStrings_returnsCorrectXor() {
        assertEquals("010010", StringXor.stringXor("111000", "101010"));
    }

    @Test
    void stringXor_singleCharacterStrings_returnsCorrectXor() {
        assertEquals("0", StringXor.stringXor("1", "1"));
    }

    @Test
    void stringXor_zeroAndZero_returnsZero() {
        assertEquals("0", StringXor.stringXor("0", "0"));
    }

    @Test
    void stringXor_oneAndZero_returnsOne() {
        assertEquals("1", StringXor.stringXor("1", "0"));
    }

    @Test
    void stringXor_zeroAndOne_returnsOne() {
        assertEquals("1", StringXor.stringXor("0", "1"));
    }

    @Test
    void stringXor_allZeros_returnsZeroString() {
        assertEquals("0000", StringXor.stringXor("0000", "0000"));
    }

    @Test
    void stringXor_allOnes_returnsZeroString() {
        assertEquals("0000", StringXor.stringXor("1111", "1111"));
    }

    @Test
    void stringXor_alternatingBits_returnsCorrectXor() {
        assertEquals("1010", StringXor.stringXor("0101", "1111"));
    }

    @Test
    void stringXor_alternatingBits2_returnsCorrectXor() {
        assertEquals("1010", StringXor.stringXor("1111", "0101"));
    }

    @Test
    void stringXor_mixedBits_returnsCorrectXor() {
        assertEquals("0101", StringXor.stringXor("0101", "0000"));
    }

    @Test
    void stringXor_mixedBits2_returnsCorrectXor() {
        assertEquals("1010", StringXor.stringXor("1010", "0000"));
    }

    @Test
    void stringXor_shortStrings_returnsCorrectXor() {
        assertEquals("01", StringXor.stringXor("11", "10"));
    }

    @Test
    void stringXor_shortStrings2_returnsCorrectXor() {
        assertEquals("10", StringXor.stringXor("00", "10"));
    }

    @Test
    void stringXor_differentPatterns_returnsCorrectXor() {
        assertEquals("110011", StringXor.stringXor("001100", "111111"));
    }

    @Test
    void stringXor_differentPatterns2_returnsCorrectXor() {
        assertEquals("001100", StringXor.stringXor("110011", "111111"));
    }

    @Test
    void stringXor_longStrings_returnsCorrectXor() {
        assertEquals("10101010", StringXor.stringXor("01010101", "11111111"));
    }

    @Test
    void stringXor_longStrings2_returnsCorrectXor() {
        assertEquals("01010101", StringXor.stringXor("10101010", "11111111"));
    }

    @Test
    void stringXor_complexStrings_returnsCorrectXor() {
        assertEquals("10011010", StringXor.stringXor("01100101", "11111111"));
    }

    @Test
    void stringXor_complexStrings2_returnsCorrectXor() {
        assertEquals("01100101", StringXor.stringXor("10011010", "11111111"));
    }
}