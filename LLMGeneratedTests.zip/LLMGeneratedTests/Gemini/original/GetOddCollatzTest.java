package original;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GetOddCollatzTest {

    @Test
    void getOddCollatz_n1_returnsSingletonList() {
        List<Integer> expected = Collections.singletonList(1);
        assertEquals(expected, GetOddCollatz.getOddCollatz(1));
    }

    @Test
    void getOddCollatz_n5_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5);
        assertEquals(expected, GetOddCollatz.getOddCollatz(5));
    }

    @Test
    void getOddCollatz_n12_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 3, 5);
        assertEquals(expected, GetOddCollatz.getOddCollatz(12));
    }

    @Test
    void getOddCollatz_n14_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5, 7, 11, 13, 17);
        assertEquals(expected, GetOddCollatz.getOddCollatz(14));
    }

    @Test
    void getOddCollatz_n2_returnsCorrectList() {
        List<Integer> expected = Collections.singletonList(1);
        assertEquals(expected, GetOddCollatz.getOddCollatz(2));
    }

    @Test
    void getOddCollatz_n3_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 3, 5);
        assertEquals(expected, GetOddCollatz.getOddCollatz(3));
    }

    @Test
    void getOddCollatz_n4_returnsCorrectList() {
        List<Integer> expected = Collections.singletonList(1);
        assertEquals(expected, GetOddCollatz.getOddCollatz(4));
    }

    @Test
    void getOddCollatz_n6_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 3, 5);
        assertEquals(expected, GetOddCollatz.getOddCollatz(6));
    }

    @Test
    void getOddCollatz_n7_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 7, 11, 13, 17);
        assertEquals(expected, GetOddCollatz.getOddCollatz(7));
    }

    @Test
    void getOddCollatz_n8_returnsCorrectList() {
        List<Integer> expected = Collections.singletonList(1);
        assertEquals(expected, GetOddCollatz.getOddCollatz(8));
    }

    @Test
    void getOddCollatz_n9_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5, 7, 13, 19);
        assertEquals(expected, GetOddCollatz.getOddCollatz(9));
    }

    @Test
    void getOddCollatz_n10_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5);
        assertEquals(expected, GetOddCollatz.getOddCollatz(10));
    }

    @Test
    void getOddCollatz_n11_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 11, 17, 19, 41, 53);
        assertEquals(expected, GetOddCollatz.getOddCollatz(11));
    }

    @Test
    void getOddCollatz_n13_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5, 13);
        assertEquals(expected, GetOddCollatz.getOddCollatz(13));
    }

    @Test
    void getOddCollatz_n15_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 35);
        assertEquals(expected, GetOddCollatz.getOddCollatz(15));
    }

    @Test
    void getOddCollatz_n16_returnsCorrectList() {
        List<Integer> expected = Collections.singletonList(1);
        assertEquals(expected, GetOddCollatz.getOddCollatz(16));
    }

    @Test
    void getOddCollatz_n17_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 13, 17, 19, 23, 29, 35, 41, 47, 53);
        assertEquals(expected, GetOddCollatz.getOddCollatz(17));
    }

    @Test
    void getOddCollatz_n18_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5, 7, 11, 13, 17);
        assertEquals(expected, GetOddCollatz.getOddCollatz(18));
    }

    @Test
    void getOddCollatz_n19_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 7, 11, 13, 19, 29, 31, 37, 43, 59, 61, 67, 79);
        assertEquals(expected, GetOddCollatz.getOddCollatz(19));
    }

    @Test
    void getOddCollatz_n20_returnsCorrectList() {
        List<Integer> expected = Arrays.asList(1, 5);
        assertEquals(expected, GetOddCollatz.getOddCollatz(20));
    }
}