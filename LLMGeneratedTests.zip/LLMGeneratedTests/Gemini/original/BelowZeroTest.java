package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BelowZeroTest {

    @Test
    void belowZero_emptyList_returnsFalse() {
        List<Object> operations = Collections.emptyList();
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_positiveOperations_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2, 3);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_negativeOperation_returnsTrue() {
        List<Object> operations = Arrays.asList(1, 2, -4, 5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedOperations_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2, -3, 1, 2, -3);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedOperations_returnsTrue() {
        List<Object> operations = Arrays.asList(1, 2, -4, 5, 6);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_balancedOperations_returnsFalse() {
        List<Object> operations = Arrays.asList(1, -1, 2, -2, 5, -5, 4, -4);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_almostBalancedOperations_returnsTrue() {
        List<Object> operations = Arrays.asList(1, -1, 2, -2, 5, -5, 4, -5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_initialNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(-1);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_doubleOperations_returnsFalse() {
        List<Object> operations = Arrays.asList(1.0, 2.0, 3.0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_doubleNegativeOperation_returnsTrue() {
        List<Object> operations = Arrays.asList(1.0, 2.0, -4.0, 5.0);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedTypes_returnsTrue() {
        List<Object> operations = Arrays.asList(1, 2.0, -4, 5);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_mixedTypes_returnsFalse() {
        List<Object> operations = Arrays.asList(1, 2.0, -2, 1);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_zeroBalance_returnsFalse() {
        List<Object> operations = Arrays.asList(0, 0, 0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_largePositiveThenNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(100.0, -200);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_largePositiveThenNegative_returnsFalse() {
        List<Object> operations = Arrays.asList(200, -100.0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_multipleNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(-1, -2, -3);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_zeroThenNegative_returnsTrue() {
        List<Object> operations = Arrays.asList(0, -1);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_zeroThenPositive_returnsFalse() {
        List<Object> operations = Arrays.asList(0, 1);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_onlyZeroes_returnsFalse() {
        List<Object> operations = Arrays.asList(0.0, 0, 0.0);
        assertFalse(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_invalidInputType_throwsException() {
        List<Object> operations = new ArrayList<>();
        operations.add("invalid");

        assertThrows(IllegalArgumentException.class, () -> BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_doubleAndInteger_returnsTrue() {
        List<Object> operations = Arrays.asList(1.0, -2);
        assertTrue(BelowZero.belowZero(operations));
    }

    @Test
    void belowZero_doubleAndInteger_returnsFalse() {
        List<Object> operations = Arrays.asList(2.0, -1);
        assertFalse(BelowZero.belowZero(operations));
    }
}