package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ConcatenateTest {

    @Test
    void testConcatenateEmptyList() {
        List<Object> emptyList = Collections.emptyList();
        assertEquals("", Concatenate.concatenate(emptyList));
    }

    @Test
    void testConcatenateSingleString() {
        List<Object> singleStringList = Collections.singletonList("hello");
        assertEquals("hello", Concatenate.concatenate(singleStringList));
    }

    @Test
    void testConcatenateMultipleStrings() {
        List<Object> stringList = Arrays.asList("a", "b", "c");
        assertEquals("abc", Concatenate.concatenate(stringList));
    }

    @Test
    void testConcatenateStringsWithNumbers() {
        List<Object> mixedList = Arrays.asList("1", "2", "3");
        assertEquals("123", Concatenate.concatenate(mixedList));
    }

    @Test
    void testConcatenateStringsWithSpecialCharacters() {
        List<Object> specialCharsList = Arrays.asList("!", "@", "#");
        assertEquals("!@#", Concatenate.concatenate(specialCharsList));
    }

    @Test
    void testConcatenateMixedTypes() {
        List<Object> mixedList = Arrays.asList("a", 1, "b", 2);
        assertEquals("a1b2", Concatenate.concatenate(mixedList));
    }

    @Test
    void testConcatenateEmptyStringInList() {
        List<Object> listWithEmptyString = Arrays.asList("a", "", "b");
        assertEquals("ab", Concatenate.concatenate(listWithEmptyString));
    }

    @Test
    void testConcatenateListWithNull() {
        List<Object> listWithNull = new ArrayList<>();
        listWithNull.add("a");
        listWithNull.add(null);
        listWithNull.add("b");
        assertEquals("anullb", Concatenate.concatenate(listWithNull));
    }

    @Test
    void testConcatenateLongList() {
        List<Object> longList = Arrays.asList("a", "b", "c", "d", "e", "f", "g", "h", "i", "j");
        assertEquals("abcdefghij", Concatenate.concatenate(longList));
    }

    @Test
    void testConcatenateNumbersAndStrings() {
        List<Object> numbersAndStrings = Arrays.asList(1, "a", 2, "b");
        assertEquals("1a2b", Concatenate.concatenate(numbersAndStrings));
    }

    @Test
    void testConcatenateBooleanValues() {
        List<Object> booleanList = Arrays.asList(true, false, true);
        assertEquals("truefalsetrue", Concatenate.concatenate(booleanList));
    }

    @Test
    void testConcatenateObjectToString() {
        Object obj = new Object();
        List<Object> objectList = Collections.singletonList(obj);
        assertEquals(obj.toString(), Concatenate.concatenate(objectList));
    }

    @Test
    void testConcatenateListWithMultipleNulls() {
        List<Object> listWithNulls = Arrays.asList(null, null, null);
        assertEquals("nullnullnull", Concatenate.concatenate(listWithNulls));
    }

    @Test
    void testConcatenateListWithLeadingAndTrailingSpaces() {
        List<Object> listWithSpaces = Arrays.asList("  a", "b  ", " c ");
        assertEquals("  ab   c ", Concatenate.concatenate(listWithSpaces));
    }

    @Test
    void testConcatenateListWithUnicodeCharacters() {
        List<Object> unicodeList = Arrays.asList("你好", "世界");
        assertEquals("你好世界", Concatenate.concatenate(unicodeList));
    }

    @Test
    void testConcatenateListWithEmptyStringsOnly() {
        List<Object> emptyStringsList = Arrays.asList("", "", "");
        assertEquals("", Concatenate.concatenate(emptyStringsList));
    }

    @Test
    void testConcatenateListWithNumbersAsStrings() {
        List<Object> numbersAsStrings = Arrays.asList("123", "456", "789");
        assertEquals("123456789", Concatenate.concatenate(numbersAsStrings));
    }

    @Test
    void testConcatenateListWithZero() {
        List<Object> listWithZero = Arrays.asList("a", 0, "b");
        assertEquals("a0b", Concatenate.concatenate(listWithZero));
    }

    @Test
    void testConcatenateListWithDecimalNumbers() {
        List<Object> decimalList = Arrays.asList("a", 1.5, "b");
        assertEquals("a1.5b", Concatenate.concatenate(decimalList));
    }

    @Test
    void testConcatenateListWithLargeNumbers() {
        List<Object> largeNumberList = Arrays.asList("a", 1000, "b");
        assertEquals("a1000b", Concatenate.concatenate(largeNumberList));
    }
}