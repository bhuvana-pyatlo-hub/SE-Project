package original;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SearchTest {

    @Test
    void search_emptyList_returnsNegativeOne() {
        List<Integer> list = Arrays.asList();
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_singleElementList_elementIsOne_returnsOne() {
        List<Integer> list = Arrays.asList(1);
        assertEquals(1, Search.search(list));
    }

    @Test
    void search_singleElementList_elementGreaterThanOne_returnsNegativeOne() {
        List<Integer> list = Arrays.asList(2);
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_example1() {
        List<Integer> list = Arrays.asList(4, 1, 2, 2, 3, 1);
        assertEquals(2, Search.search(list));
    }

    @Test
    void search_example2() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3, 3, 3, 4, 4, 4);
        assertEquals(3, Search.search(list));
    }

    @Test
    void search_example3() {
        List<Integer> list = Arrays.asList(5, 5, 4, 4, 4);
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_example4() {
        List<Integer> list = Arrays.asList(5, 5, 5, 5, 1);
        assertEquals(1, Search.search(list));
    }

    @Test
    void search_example5() {
        List<Integer> list = Arrays.asList(4, 1, 4, 1, 4, 4);
        assertEquals(4, Search.search(list));
    }

    @Test
    void search_example6() {
        List<Integer> list = Arrays.asList(3, 3);
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_example7() {
        List<Integer> list = Arrays.asList(8, 8, 8, 8, 8, 8, 8, 8);
        assertEquals(8, Search.search(list));
    }

    @Test
    void search_example8() {
        List<Integer> list = Arrays.asList(2, 3, 3, 2, 2);
        assertEquals(2, Search.search(list));
    }

    @Test
    void search_example9() {
        List<Integer> list = Arrays.asList(2, 7, 8, 8, 4, 8, 7, 3, 9, 6, 5, 10, 4, 3, 6, 7, 1, 7, 4, 10, 8, 1);
        assertEquals(1, Search.search(list));
    }

    @Test
    void search_example10() {
        List<Integer> list = Arrays.asList(3, 2, 8, 2);
        assertEquals(2, Search.search(list));
    }

    @Test
    void search_example11() {
        List<Integer> list = Arrays.asList(6, 7, 1, 8, 8, 10, 5, 8, 5, 3, 10);
        assertEquals(1, Search.search(list));
    }

    @Test
    void search_example12() {
        List<Integer> list = Arrays.asList(8, 8, 3, 6, 5, 6, 4);
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_example13() {
        List<Integer> list = Arrays.asList(6, 9, 6, 7, 1, 4, 7, 1, 8, 8, 9, 8, 10, 10, 8, 4, 10, 4, 10, 1, 2, 9, 5, 7, 9);
        assertEquals(1, Search.search(list));
    }

    @Test
    void search_example14() {
        List<Integer> list = Arrays.asList(1, 9, 10, 1, 3);
        assertEquals(1, Search.search(list));
    }

    @Test
    void search_example15() {
        List<Integer> list = Arrays.asList(6, 9, 7, 5, 8, 7, 5, 3, 7, 5, 10, 10, 3, 6, 10, 2, 8, 6, 5, 4, 9, 5, 3, 10);
        assertEquals(5, Search.search(list));
    }

    @Test
    void search_allElementsGreaterThanTen_returnsNegativeOne() {
        List<Integer> list = Arrays.asList(11, 12, 13);
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_listWithZero_returnsNegativeOne() {
        List<Integer> list = Arrays.asList(0, 1, 2);
        assertEquals(-1, Search.search(list));
    }

    @Test
    void search_listWithMultipleValidAndInvalidValues() {
        List<Integer> list = Arrays.asList(1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10);
        assertEquals(10, Search.search(list));
    }

    @Test
    void search_listWithOnlyTens_returnsTen() {
        List<Integer> list = Arrays.asList(10, 10, 10, 10, 10, 10, 10, 10, 10, 10);
        assertEquals(10, Search.search(list));
    }

    @Test
    void search_listWithOneAndTen_returnsOne() {
        List<Integer> list = Arrays.asList(1, 10);
        assertEquals(1, Search.search(list));
    }
}