package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class GenerateIntegersTest {

    @Test
    void generateIntegers_aLessThanB_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(2, 8));
    }

    @Test
    void generateIntegers_aGreaterThanB_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(8, 2));
    }

    @Test
    void generateIntegers_noEvenNumbers_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(10, 14));
    }

    @Test
    void generateIntegers_aIs2_bIs10_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(2, 10));
    }

    @Test
    void generateIntegers_aIs10_bIs2_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(10, 2));
    }

    @Test
    void generateIntegers_aIs132_bIs2_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(132, 2));
    }

    @Test
    void generateIntegers_aIs17_bIs89_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(17, 89));
    }

    @Test
    void generateIntegers_aIs1_bIs9_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(1, 9));
    }

    @Test
    void generateIntegers_aIs3_bIs7_returnsEvenNumbers() {
        List<Object> expected = List.of(4, 6);
        assertEquals(expected, GenerateIntegers.generateIntegers(3, 7));
    }

    @Test
    void generateIntegers_aIs2_bIs2_returnsTwo() {
        List<Object> expected = List.of(2);
        assertEquals(expected, GenerateIntegers.generateIntegers(2, 2));
    }

    @Test
    void generateIntegers_aIs8_bIs8_returnsEight() {
        List<Object> expected = List.of(8);
        assertEquals(expected, GenerateIntegers.generateIntegers(8, 8));
    }

    @Test
    void generateIntegers_aIs4_bIs6_returnsFourSix() {
        List<Object> expected = List.of(4, 6);
        assertEquals(expected, GenerateIntegers.generateIntegers(4, 6));
    }

    @Test
    void generateIntegers_aIs6_bIs4_returnsFourSix() {
        List<Object> expected = List.of(4, 6);
        assertEquals(expected, GenerateIntegers.generateIntegers(6, 4));
    }

    @Test
    void generateIntegers_aIs1_bIs1_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(1, 1));
    }

    @Test
    void generateIntegers_aIs9_bIs9_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(9, 9));
    }

    @Test
    void generateIntegers_aIs0_bIs10_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(0, 10));
    }

    @Test
    void generateIntegers_aIs10_bIs0_returnsEvenNumbers() {
        List<Object> expected = List.of(2, 4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(10, 0));
    }

    @Test
    void generateIntegers_aIs5_bIs5_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(5, 5));
    }

    @Test
    void generateIntegers_aIs7_bIs7_returnsEmptyList() {
        List<Object> expected = new ArrayList<>();
        assertEquals(expected, GenerateIntegers.generateIntegers(7, 7));
    }

    @Test
    void generateIntegers_aIs3_bIs9_returnsFourSixEight() {
        List<Object> expected = List.of(4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(3, 9));
    }

    @Test
    void generateIntegers_aIs9_bIs3_returnsFourSixEight() {
        List<Object> expected = List.of(4, 6, 8);
        assertEquals(expected, GenerateIntegers.generateIntegers(9, 3));
    }
}