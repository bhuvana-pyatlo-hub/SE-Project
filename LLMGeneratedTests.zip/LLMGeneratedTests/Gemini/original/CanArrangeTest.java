package original;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CanArrangeTest {

    @Test
    void canArrange_emptyList() {
        List<Object> arr = new ArrayList<>();
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_increasingList() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_decreasingElement() {
        List<Object> arr = Arrays.asList(1, 2, 4, 3, 5);
        assertEquals(3, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_decreasingElementAtBeginning() {
        List<Object> arr = Arrays.asList(4, 2, 3, 5);
        assertEquals(1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_decreasingElementAtEnd() {
        List<Object> arr = Arrays.asList(1, 2, 3, 0);
        assertEquals(3, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_singleElement() {
        List<Object> arr = Arrays.asList(5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_negativeNumbers() {
        List<Object> arr = Arrays.asList(-5, -3, -10, 0, 2);
        assertEquals(2, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_mixedPositiveNegative() {
        List<Object> arr = Arrays.asList(-5, -3, 0, -1, 2);
        assertEquals(3, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_allSameElements() {
        List<Object> arr = Arrays.asList(5, 5, 5, 5, 5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_largeListWithDecreasingElement() {
        List<Object> arr = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 5);
        assertEquals(10, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithNonInteger() {
        List<Object> arr = Arrays.asList(1, 2, "a", 4, 5);
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithNonIntegerAndDecreasing() {
        List<Object> arr = Arrays.asList(1, 2, "a", 3, 1);
        assertEquals(4, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithOnlyNonInteger() {
        List<Object> arr = Arrays.asList("a", "b", "c");
        assertEquals(-1, CanArrange.canArrange(arr));
    }

    @Test
    void canArrange_listWithIntegerAndNonIntegerAtTheBeginning() {
        List<Object> arr = Arrays.asList("a", 1, 0);
        assertEquals(2, CanArrange.canArrange(arr));
    }
}