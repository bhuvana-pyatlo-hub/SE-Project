package original;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class IsEqualToSumEvenTest {

    @Test
    void isEqualToSumEven_LessThan8_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(4));
    }

    @Test
    void isEqualToSumEven_EqualTo8_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(8));
    }

    @Test
    void isEqualToSumEven_EqualTo6_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(6));
    }

    @Test
    void isEqualToSumEven_EqualTo7_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(7));
    }

    @Test
    void isEqualToSumEven_EqualTo0_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(0));
    }

    @Test
    void isEqualToSumEven_NegativeNumber_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(-2));
    }

    @Test
    void isEqualToSumEven_EqualTo10_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(10));
    }

    @Test
    void isEqualToSumEven_EqualTo11_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(11));
    }

    @Test
    void isEqualToSumEven_EqualTo12_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(12));
    }

    @Test
    void isEqualToSumEven_EqualTo13_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(13));
    }

    @Test
    void isEqualToSumEven_EqualTo16_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(16));
    }

    @Test
    void isEqualToSumEven_LargeEvenNumber_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(100));
    }

    @Test
    void isEqualToSumEven_LargeOddNumber_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(99));
    }

    @Test
    void isEqualToSumEven_EqualTo1_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(1));
    }

    @Test
    void isEqualToSumEven_EqualTo2_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(2));
    }

    @Test
    void isEqualToSumEven_EqualTo3_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(3));
    }

    @Test
    void isEqualToSumEven_EqualTo5_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(5));
    }

    @Test
    void isEqualToSumEven_EqualTo9_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(9));
    }

    @Test
    void isEqualToSumEven_EqualTo14_ReturnsTrue() {
        assertTrue(IsEqualToSumEven.isEqualToSumEven(14));
    }

    @Test
    void isEqualToSumEven_EqualTo15_ReturnsFalse() {
        assertFalse(IsEqualToSumEven.isEqualToSumEven(15));
    }
}