import os
import requests
import re
import subprocess
import time
from collections import deque

# API Keys
GEMINI_API_KEY = "AIzaSyBgBkqaLsaBdrKxnwwhYfYjDbu8CHnvGNY"
GPT4O_API_KEY = "ddc-noz0WLqnf5RpMmHBdbS1qdwB8ElIBTWd95cElulNcLnj0XCbw3"

# Directory Paths
SRC_DIR = "E:/SoftwareEngineeringProject/src/main/java/original"
TEST_DIR = "E:/SoftwareEngineeringProject/src/test/java/original"
PROJECT_DIR = "E:/SoftwareEngineeringProject"  # Root project directory


# Rate limiter for GPT-4o API (3 requests per 60 seconds)
class RateLimiter:
    def __init__(self, max_requests, time_window):
        self.max_requests = max_requests
        self.time_window = time_window  # in seconds
        self.request_timestamps = deque()

    def wait_if_needed(self):
        current_time = time.time()

        # Remove timestamps older than the time window
        while self.request_timestamps and current_time - self.request_timestamps[0] > self.time_window:
            self.request_timestamps.popleft()

        # If at capacity, wait until we can make another request
        if len(self.request_timestamps) >= self.max_requests:
            sleep_time = self.time_window - (current_time - self.request_timestamps[0])
            if sleep_time > 0:
                print(f"⏱️ Rate limit reached. Waiting for {sleep_time:.2f} seconds...")
                time.sleep(sleep_time)

        # Add current timestamp after waiting (if needed)
        self.request_timestamps.append(time.time())


# Initialize rate limiter for GPT-4o API (3 requests per 60 seconds)
gpt4o_rate_limiter = RateLimiter(max_requests=3, time_window=60)


def get_java_files(directory):
    """Get all Java files from the specified directory."""
    return [f for f in os.listdir(directory) if f.endswith(".java")]


def read_file(filepath):
    """Read the content of a file."""
    with open(filepath, "r", encoding="utf-8") as file:
        return file.read()


def write_test_file(class_name, test_code):
    """Write refined test cases to a file."""
    os.makedirs(TEST_DIR, exist_ok=True)
    test_filepath = os.path.join(TEST_DIR, f"{class_name}Test.java")
    with open(test_filepath, "w", encoding="utf-8") as file:
        file.write(test_code)
    print(f"✅ Refined test file saved: {test_filepath}")


def extract_class_details(java_code):
    """Extract package, class name, and imports from Java code."""
    package_match = re.search(r"package\s+(.*?);", java_code)
    package_name = package_match.group(1).strip() if package_match else "original"

    class_match = re.search(r"(public\s+)?(class|interface|enum)\s+(\w+)", java_code)
    class_name = class_match.group(3) if class_match else None

    return {
        "package": package_name,
        "class_name": class_name
    }


def call_gemini_api(prompt):
    """Call Google Gemini API to generate or refine JUnit test cases."""
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
    headers = {"Content-Type": "application/json"}
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.2,  # Lower temperature for more focused output
            "topP": 0.9
        }
    }
    response = requests.post(f"{url}?key={GEMINI_API_KEY}", headers=headers, json=payload)

    if response.status_code == 200:
        result = response.json()
        return result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
    else:
        print(f"❌ Gemini API Error {response.status_code}: {response.text}")
        return None


def call_gpt4o_api(prompt):
    """Call GPT-4o API to refine and add edge cases to JUnit tests."""
    # Apply rate limiting before making the request
    gpt4o_rate_limiter.wait_if_needed()

    url = "https://api.sree.shop/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GPT4O_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "claude-3-5-sonnet",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.3
    }

    # Make API request with retry logic for rate limit errors
    max_retries = 3
    for attempt in range(max_retries):
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code == 200:
            result = response.json()
            return result["choices"][0]["message"]["content"]
        elif response.status_code == 429:  # Rate limit error
            wait_time = min(2 ** attempt * 10, 60)  # Exponential backoff with max 60 seconds
            print(
                f"❌ GPT-4o API Rate Limit Error (Attempt {attempt + 1}/{max_retries}). Waiting {wait_time} seconds...")
            time.sleep(wait_time)
        else:
            print(f"❌ GPT-4o API Error {response.status_code}: {response.text}")
            return None

    print("❌ Maximum retry attempts reached for GPT-4o API. Skipping this request.")
    return None


def clean_code_response(response_text):
    """Remove Markdown-style Java code blocks if present."""
    cleaned_text = re.sub(r"```java\s*", "", response_text.strip())  # Remove starting ```java
    cleaned_text = re.sub(r"```\s*$", "", cleaned_text.strip())  # Remove ending ```

    # Check if the code appears to be truncated (missing closing braces)
    if cleaned_text.count("{") > cleaned_text.count("}"):
        print("⚠️ Warning: Test code appears to be truncated. Requesting again with shorter output.")
        return None

    return cleaned_text.strip()


def analyze_java_code(java_code):
    """Analyze Java code to extract method signatures, conditionals, and potential edge cases."""
    # Extract method signatures
    method_pattern = r"(public|private|protected)?\s+\w+\s+(\w+)\s*\((.*?)\)\s*\{"
    methods = re.findall(method_pattern, java_code)

    # Extract conditionals (if statements) to identify branches
    if_pattern = r"if\s*\((.*?)\)"
    conditions = re.findall(if_pattern, java_code)

    # Extract data types from method parameters and variables
    param_pattern = r"\b(int|double|float|long|boolean|String|char|byte|short)\b\s+(\w+)"
    data_types = re.findall(param_pattern, java_code)

    return {
        "methods": methods,
        "conditions": conditions,
        "data_types": data_types
    }


def generate_test_cases(java_code, class_info):
    """Generate initial test cases for the given Java class using Gemini AI."""
    class_name = class_info["class_name"]
    code_analysis = analyze_java_code(java_code)

    # Count number of conditional branches to estimate coverage needs
    branch_count = len(code_analysis["conditions"])

    # Extract data types used in the code
    data_types = set([dt[0] for dt in code_analysis["data_types"]])
    data_type_str = ", ".join(data_types) if data_types else "unknown"

    gemini_prompt = f"""
    Generate comprehensive JUnit5 test cases for the following Java class that achieve 100% LINE AND BRANCH COVERAGE:

    IMPORTANT REQUIREMENTS:
    - Create precise test cases for each conditional branch in the code (there are approximately {branch_count} branches)
    - Use appropriate data types: {data_type_str}
    - Use realistic SMALL values for inputs (avoid using large numbers over 1000 or extremely small decimals)
    - Include tests for boundary values, edge cases, and corner cases
    - Ensure tests for both valid and invalid inputs
    - Use meaningful assertions to verify correct behavior
    - Test EACH possible execution path through the code
    - Use descriptive test method names that explain what is being tested
    - Include necessary imports
    - Use the proper package statement
    - Provide a complete test class that will compile without errors
    - DO NOT TRUNCATE THE CODE - include the entire test class with all closing braces
    - Ensure 100% line coverage by testing every line of code in the class
    - Ensure 100% branch coverage by testing all possible branches in the code
    - do not generate for private methods
    -generate at least 20 test cases so that all the lines and branches should be covered

    *Java Class:*  
    ```java
    {java_code}
    ```

    Return ONLY the complete JUnit test class with no explanations before or after.
    """

    generated_test_code = call_gemini_api(gemini_prompt)
    cleaned_code = clean_code_response(generated_test_code) if generated_test_code else None

    # If code appears to be truncated or invalid, try with a more focused approach
    if not cleaned_code:
        print("📝 Retrying with a more targeted prompt...")
        gemini_prompt = f"""
        Generate a JUnit5 test class for the Java class below. Focus on COMPLETE test code with NO TRUNCATION:

        STRICTLY FOLLOW THESE RULES:
        1. Use small, realistic test values (integers between -100 and 100)
        2. Cover ALL branches and lines (100% coverage)
        3. Test basic cases, edge cases, and invalid inputs
        4. Keep the test class SHORT but COMPLETE
        5. Make sure ALL opening braces have matching closing braces
        6. Return ONLY valid, compilable Java code
        7. Ensure 100% line coverage by testing every line of code in the class
        8. Ensure 100% branch coverage by testing all possible branches in the code

        Java Class:
        ```java
        {java_code}
        ```
        """
        generated_test_code = call_gemini_api(gemini_prompt)
        cleaned_code = clean_code_response(generated_test_code) if generated_test_code else None

    return cleaned_code


def refine_test_cases(java_code, test_code, class_info):
    """Generate test cases if they do not exist, then refine them using GPT-4o."""
    if not test_code or test_code.strip() == "// Placeholder for initial test cases, modify as needed":
        print(f"📝 Generating test cases for {class_info['class_name']}...")
        test_code = generate_test_cases(java_code, class_info)

    if not test_code:
        print(f"❌ Failed to generate test cases for {class_info['class_name']}.")
        return None

    print(f"🔄 Refining test cases for {class_info['class_name']}...")

    code_analysis = analyze_java_code(java_code)

    gpt4o_prompt = f"""
    Improve the following JUnit test class to achieve 100% branch and line coverage.

    CRITICAL REQUIREMENTS:
    1. ENSURE THE TEST CLASS IS COMPLETE - don't truncate any part
    2. Use small, reasonable test values (integers between -100 and 100, avoid large numbers)
    3. Test ALL conditional branches in the original code (identified: {len(code_analysis["conditions"])})
    4. Verify EVERY method in the class is thoroughly tested
    5. Include tests for edge cases:
       - Boundary values
       - Minimum/maximum valid inputs
       - Zero values
       - Negative values (if applicable)
       - Invalid inputs
    6. Use descriptive test method names
    7. Ensure test code matches the class name exactly
    8. Use proper package statement to match the original code
    9. Include necessary imports
    10. Ensure that the provided test cases are correct the code should pass all the test cases
    11. If the method is private then we cannot access it through the test file so while generating please keep in mind about the access modifiers also
    12. The test cases should take less time to execute time limit should not be exceeded
    13. Ensure 100% line coverage by testing every line of code in the class
    14. Ensure 100% branch coverage by testing all possible branches in the code
    15.do not generate for private methods

    Original Java Class:
    ```java
    {java_code}
    ```

    Test Class to Improve:
    ```java
    {test_code}
    ```

    Return ONLY the complete, improved test class with no explanations.
    """

    refined_test_code = call_gpt4o_api(gpt4o_prompt)
    cleaned_code = clean_code_response(refined_test_code) if refined_test_code else None

    # If refined code appears truncated, return the original test code
    if not cleaned_code:
        print("⚠️ Refined test code appears truncated. Using original test code.")
        return clean_code_response(test_code)

    return cleaned_code


# Process all Java files and refine test cases
java_files = get_java_files(SRC_DIR)

for java_file in java_files:
    java_code = read_file(os.path.join(SRC_DIR, java_file))
    class_info = extract_class_details(java_code)

    if class_info["class_name"]:
        test_code = "// Placeholder for initial test cases, modify as needed"
        refined_test_code = refine_test_cases(java_code, test_code, class_info)

        if refined_test_code:
            write_test_file(class_info["class_name"], refined_test_code)

print("✅ Test case generation, refinement, and execution completed!")