import os
import requests
import re
import time
from collections import deque

# Replace with your actual Gemini API key
GEMINI_API_KEY = "AIzaSyBgBkqaLsaBdrKxnwwhYfYjDbu8CHnvGNY"

# Directory Paths
SRC_DIR = "E:/SoftwareEngineeringProject/src/main/java/original"
TEST_DIR = "E:/SoftwareEngineeringProject/src/test/java/original"
PROJECT_DIR = "E:/SoftwareEngineeringProject"  # Root project directory


def get_java_files(directory):
    """Get all Java files from the specified directory."""
    return [f for f in os.listdir(directory) if f.endswith(".java")]


def read_file(filepath):
    """Read the content of a file."""
    with open(filepath, "r", encoding="utf-8") as file:
        return file.read()


def write_test_file(class_name, test_code):
    """Write refined test cases to a file."""
    os.makedirs(TEST_DIR, exist_ok=True)
    test_filepath = os.path.join(TEST_DIR, f"{class_name}Test.java")
    with open(test_filepath, "w", encoding="utf-8") as file:
        file.write(test_code)
    print(f"✅ Refined test file saved: {test_filepath}")


def extract_class_details(java_code):
    """Extract package, class name, and imports from Java code."""
    package_match = re.search(r"package\s+(.*?);", java_code)
    package_name = package_match.group(1).strip() if package_match else "original"

    class_match = re.search(r"(public\s+)?(class|interface|enum)\s+(\w+)", java_code)
    class_name = class_match.group(3) if class_match else None

    return {
        "package": package_name,
        "class_name": class_name
    }


def call_gemini_api(prompt):
    """Call Google Gemini API to generate or refine JUnit test cases."""
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
    headers = {"Content-Type": "application/json"}
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.2,  # Lower temperature for more focused output
            "topP": 0.9
        }
    }

    try:
        response = requests.post(f"{url}?key={GEMINI_API_KEY}", headers=headers, json=payload)
        response.raise_for_status()  # Raise an exception for bad responses

        result = response.json()
        generated_text = result.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")
        return generated_text
    except requests.exceptions.RequestException as e:
        print(f"❌ Gemini API Error: {e}")
        return None


def analyze_java_code(java_code):
    """Analyze Java code to extract method signatures, conditionals, and potential edge cases."""
    # Extract method signatures
    method_pattern = r"(public|private|protected)?\s+\w+\s+(\w+)\s*\((.*?)\)\s*\{"
    methods = re.findall(method_pattern, java_code)

    # Extract conditionals (if statements) to identify branches
    if_pattern = r"if\s*\((.*?)\)"
    conditions = re.findall(if_pattern, java_code)

    # Extract data types from method parameters and variables
    param_pattern = r"\b(int|double|float|long|boolean|String|char|byte|short)\b\s+(\w+)"
    data_types = re.findall(param_pattern, java_code)

    return {
        "methods": methods,
        "conditions": conditions,
        "data_types": data_types
    }


def clean_code_response(response_text):
    """Remove Markdown-style Java code blocks if present."""
    if not response_text:
        return None

    cleaned_text = re.sub(r"```java\s*", "", response_text.strip())  # Remove starting ```java
    cleaned_text = re.sub(r"```\s*$", "", cleaned_text.strip())  # Remove ending ```

    # Check if the code appears to be truncated (missing closing braces)
    if cleaned_text.count("{") > cleaned_text.count("}"):
        print("⚠️ Warning: Test code appears to be truncated. Requesting again with shorter output.")
        return None

    return cleaned_text.strip()


def generate_test_cases(java_code, class_info):
    """Generate initial test cases for the given Java class using Gemini AI."""
    class_name = class_info["class_name"]
    code_analysis = analyze_java_code(java_code)

    # Count number of conditional branches to estimate coverage needs
    branch_count = len(code_analysis["conditions"])

    # Extract data types used in the code
    data_types = set([dt[0] for dt in code_analysis["data_types"]])
    data_type_str = ", ".join(data_types) if data_types else "unknown"

    gemini_prompt = f"""
    Generate comprehensive JUnit5 test cases for the Java class that achieve 100% LINE AND BRANCH COVERAGE:

    CRITICAL REQUIREMENTS:
    - Create precise test cases for each conditional branch in the code (there are approximately {branch_count} branches)
    - Use appropriate data types: {data_type_str}
    - Use realistic SMALL values for inputs (avoid using large numbers over 1000 or extremely small decimals)
    - Include tests for boundary values, edge cases, and corner cases
    - Ensure tests for both valid and invalid inputs
    - Use meaningful assertions to verify correct behavior
    - Test EACH possible execution path through the code
    - Use descriptive test method names that explain what is being tested
    - Include necessary imports
    - Use the proper package statement
    - Provide a complete test class that will compile without errors
    - DO NOT TRUNCATE THE CODE - include the entire test class with all closing braces
    - Ensure 100% line coverage by testing every line of code in the class
    - Ensure 100% branch coverage by testing all possible branches in the code
    - Do not generate tests for private methods
    - Generate at least 20 test cases to cover all lines and branches

    *Java Class:*  
    ```java
    {java_code}
    ```

    Return ONLY the complete JUnit test class with no explanations before or after.
    """

    generated_test_code = call_gemini_api(gemini_prompt)
    cleaned_code = clean_code_response(generated_test_code) if generated_test_code else None

    # If code appears to be truncated or invalid, try with a more focused approach
    if not cleaned_code:
        print("📝 Retrying with a more targeted prompt...")
        gemini_prompt = f"""
        Generate a JUnit5 test class for the Java class below. Focus on COMPLETE test code with NO TRUNCATION:

        STRICTLY FOLLOW THESE RULES:
        1. Use small, realistic test values (integers between -100 and 100)
        2. Cover ALL branches and lines (100% coverage)
        3. Test basic cases, edge cases, and invalid inputs
        4. Keep the test class SHORT but COMPLETE
        5. Make sure ALL opening braces have matching closing braces
        6. Return ONLY valid, compilable Java code
        7. Ensure 100% line coverage by testing every line of code in the class
        8. Ensure 100% branch coverage by testing all possible branches in the code

        Java Class:
        ```java
        {java_code}
        ```
        """
        generated_test_code = call_gemini_api(gemini_prompt)
        cleaned_code = clean_code_response(generated_test_code) if generated_test_code else None

    return cleaned_code


def main():
    """Main function to process all Java files and generate test cases."""
    # Process all Java files and generate test cases
    java_files = get_java_files(SRC_DIR)

    for java_file in java_files:
        java_filepath = os.path.join(SRC_DIR, java_file)
        java_code = read_file(java_filepath)
        class_info = extract_class_details(java_code)

        if class_info["class_name"]:
            refined_test_code = generate_test_cases(java_code, class_info)

            if refined_test_code:
                write_test_file(class_info["class_name"], refined_test_code)
            else:
                print(f"❌ Failed to generate test cases for {java_file}")

    print("✅ Test case generation completed!")


if __name__ == "__main__":
    main()